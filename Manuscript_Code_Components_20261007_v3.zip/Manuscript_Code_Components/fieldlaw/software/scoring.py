"""Count-ensemble probability scores, without fitting or parameter selection."""
import numpy as np


def _numeric_array(value, label):
    try:
        raw = np.asarray(value)
        if raw.dtype.kind not in "biuf":
            raise ValueError
        result = raw.astype(float)
    except (TypeError, ValueError, OverflowError):
        raise ValueError(label + " must contain real numeric values") from None
    if not np.isfinite(result).all():
        raise ValueError(label + " must be finite")
    return result


def _aligned_regions(value, regions, label):
    result = _numeric_array(value, label)
    if result.ndim == 0:
        return np.full(regions, float(result))
    if result.ndim != 1 or result.shape != (regions,):
        raise ValueError(label + " must be scalar or an aligned region vector")
    return result


def _scaled(value, scale):
    try:
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            result = value / scale
    except FloatingPointError:
        raise ValueError("Nonfinite score arithmetic; no clipping or repair is permitted") from None
    if not np.isfinite(result).all():
        raise ValueError("Nonfinite score arithmetic; no clipping or repair is permitted")
    return result


def score_ensembles(samples, truth, source_scale, *, IID=True):
    """Score scenarios-by-regions or a one-region scenario vector.

    The RPS expression equals scalar CRPS for integer-valued counts. It uses
    sorted pair sums, never an scenarios-by-scenarios distance allocation.
    IID correction is valid only for independently generated scenarios.
    """
    if not isinstance(IID, (bool, np.bool_)):
        raise ValueError("IID must be an explicit boolean")
    values = _numeric_array(samples, "Samples")
    if values.ndim == 1:
        values = values[:, None]
    if values.ndim != 2 or min(values.shape) < 1:
        raise ValueError("Samples must have nonempty scenario and region dimensions")
    observation = _aligned_regions(truth, values.shape[1], "Truth")
    scale = _aligned_regions(source_scale, values.shape[1], "Source scale")
    if np.any(scale <= 0):
        raise ValueError("Source scale must be strictly positive")
    if (np.any(values < 0) or np.any(values != np.floor(values))
            or np.any(observation < 0) or np.any(observation != np.floor(observation))):
        raise ValueError("Count samples and truth must be nonnegative integers")
    count = len(values)
    if IID and count < 2:
        raise ValueError("IID-fair RPS requires at least two scenarios")
    ordered = np.sort(values, axis=0)
    coefficients = 2.0 * np.arange(count) - count + 1.0
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        pair_sum = coefficients @ ordered
        absolute_error = np.mean(np.abs(values - observation), axis=0)
        empirical = absolute_error - pair_sum / count ** 2
        fair = absolute_error - pair_sum / (count * (count - 1)) if IID else None
    if not np.isfinite(empirical).all() or (IID and not np.isfinite(fair).all()):
        raise ValueError("Nonfinite score arithmetic; no clipping or repair is permitted")
    median = ordered[(count + 1) // 2 - 1]
    median_error = np.abs(median - observation)
    weighted_intervals = 0.5 * median_error
    intervals = {}
    for percentage in (50, 80, 90, 95):
        alpha = (100 - percentage) / 100.0
        # Inverted-CDF ranks ceil(q*M) use exact percentage rationals. A
        # floating q such as (1-.95)/2 otherwise shifts an atom boundary.
        lower_rank = ((100 - percentage) * count + 199) // 200
        upper_rank = ((100 + percentage) * count + 199) // 200
        lower = ordered[max(0, lower_rank - 1)]
        upper = ordered[min(count - 1, upper_rank - 1)]
        width = upper - lower
        left = observation < lower
        right = observation > upper
        with np.errstate(over="ignore", invalid="ignore"):
            interval_score = width + 2.0 / alpha * (
                np.where(left, lower - observation, 0.0)
                + np.where(right, observation - upper, 0.0))
            weighted_intervals = weighted_intervals + alpha / 2 * interval_score
        intervals[str(percentage)] = {
            "level": percentage / 100.0,
            "lower": lower,
            "upper": upper,
            "left_miss": left,
            "right_miss": right,
            "width": width,
            "scaled_width": _scaled(width, scale),
            "interval_score": interval_score,
            "scaled_interval_score": _scaled(interval_score, scale),
        }
    wis = weighted_intervals / (len(intervals) + 0.5)
    return {
        "empirical_rps": empirical,
        "fair_rps": fair,
        "scaled_empirical_rps": _scaled(empirical, scale),
        "scaled_fair_rps": _scaled(fair, scale) if IID else None,
        "IID": bool(IID),
        "scenario_count": count,
        "median": median,
        "median_absolute_error": median_error,
        "scaled_median_absolute_error": _scaled(median_error, scale),
        "intervals": intervals,
        "wis": wis,
        "scaled_wis": _scaled(wis, scale),
    }


def event_brier(event_samples, truth):
    """Return actual ensemble event probability and its ordinary Brier score.

    Input indicators are scenarios-by-regions or a single-region vector. No
    IID/fair adjustment is applied to this empirical forecast probability.
    """
    events = _numeric_array(event_samples, "Event samples")
    if events.ndim == 1:
        events = events[:, None]
    if events.ndim != 2 or min(events.shape) < 1:
        raise ValueError("Events must have nonempty scenario and region dimensions")
    observed = _aligned_regions(truth, events.shape[1], "Event truth")
    if np.any((events != 0) & (events != 1)) or np.any((observed != 0) & (observed != 1)):
        raise ValueError("Event samples and truth must be binary indicators")
    probability = events.mean(axis=0)
    return {"event_probability": probability, "brier": (probability - observed) ** 2}
