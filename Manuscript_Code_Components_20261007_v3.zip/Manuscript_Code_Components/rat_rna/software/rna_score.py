"""Source-RNA point-mean scoring with exact count and zero-mean contracts."""

import numpy as np
from pathlib import Path
import argparse
import csv
import json
import sys

from rna_inputs import (GENES, PARENTS, REAL_MODE, SYNTHETIC_MODE, read_json, record, sha,
                        verify_bindings, config_bindings, write_json)

METHODS = ("AnchorRate", "memberRidge", "memberPoisson", "sourceTotal_fixedComposition", "sourceTotal_learnedComposition")


def poisson_deviance(y, mu):
    """Elementwise 2*(y*log(y/mu)-y+mu), retaining zero and infinite limits."""
    observed = np.asarray(y, dtype=float)
    means = np.asarray(mu, dtype=float)
    if observed.shape != means.shape:
        raise ValueError("count truth and point means must have identical shapes")
    if not np.isfinite(observed).all() or np.any(observed < 0) or np.any(observed != np.floor(observed)):
        raise ValueError("truth must be exact finite nonnegative integer counts")
    if not np.isfinite(means).all() or np.any(means < 0):
        raise ValueError("point means must be finite and nonnegative")
    result = np.zeros(observed.shape, dtype=float)
    zero_truth = observed == 0
    result[zero_truth] = 2.0 * means[zero_truth]
    impossible = (observed > 0) & (means == 0)
    result[impossible] = np.inf
    positive = (observed > 0) & (means > 0)
    values, expected = observed[positive], means[positive]
    delta = (expected - values) / values
    close = np.abs(delta) <= 1e-3
    contribution = np.empty_like(values)
    # Stable evaluation of delta-log(1+delta); this is an analytic series,
    # not a loss floor, mean adjustment, or outcome-selected parameter.
    powers = delta[close] * delta[close]
    terms = powers / 2.0
    for order in range(3, 19):
        powers = powers * delta[close]
        terms += ((-1.0) ** order) * powers / order
    contribution[close] = 2.0 * values[close] * terms
    contribution[~close] = 2.0 * (values[~close] * (np.log(values[~close]) - np.log(expected[~close])) - values[~close] + expected[~close])
    result[positive] = contribution
    return result


def _allocation(truth, means, truth_total, mean_total):
    allocation = np.zeros(len(truth), dtype=float)
    defined = np.ones(len(truth), dtype=bool)
    for row in range(len(truth)):
        if truth_total[row] == 0:
            continue
        if mean_total[row] == 0:
            allocation[row] = np.nan
            defined[row] = False
            continue
        proportions = means[row] / mean_total[row]
        allocated = truth_total[row] * proportions
        terms = poisson_deviance(truth[row], allocated)
        # A positive mean fraction can underflow in division, even though its
        # finite log-ratio allocation term is defined. Evaluate that term by
        # separate logs; no probability or prediction is floored.
        underflow = (truth[row] > 0) & (means[row] > 0) & (allocated == 0)
        terms[underflow] = 2.0 * (truth[row, underflow] * (
            np.log(truth[row, underflow]) - np.log(truth_total[row])
            - np.log(means[row, underflow]) + np.log(mean_total[row])) - truth[row, underflow])
        allocation[row] = terms.sum()
    return allocation, defined


def _evaluate_level(means, truth, scale7, total_scale):
    deviance = poisson_deviance(truth, means)
    total_values = [sum(int(value) for value in row) for row in truth]
    if any(value > np.iinfo(np.int64).max for value in total_values):
        raise ValueError("programme truth total exceeds exact int64 range")
    observed_total = np.array(total_values, dtype=np.int64)
    mean_total = means.sum(axis=1)
    total_deviance = poisson_deviance(observed_total, mean_total)
    member_sum = deviance.sum(axis=1)
    allocation, defined = _allocation(truth, means, observed_total, mean_total)
    error = np.full(len(truth), np.nan)
    finite = defined & np.isfinite(member_sum) & np.isfinite(total_deviance) & np.isfinite(allocation)
    error[finite] = member_sum[finite] - total_deviance[finite] - allocation[finite]
    return {"member_truth": truth.copy(), "member_mean": means.copy(),
            "member_deviance": deviance, "scaled_member_deviance": deviance / scale7,
            "member_absolute_error": np.abs(truth - means), "truth_is_zero": truth == 0,
            "programme_truth": observed_total, "programme_mean": mean_total,
            "programme_deviance": total_deviance, "scaled_programme_deviance": total_deviance / total_scale,
            "programme_absolute_error": np.abs(observed_total - mean_total),
            "sum_member_deviance": member_sum, "allocation_deviance": allocation,
            "allocation_defined": defined, "decomposition_error": error,
            "mean_seven_scaled_deviance": np.mean(deviance / scale7, axis=1)}


def mean_evaluation(geneMeans, truth, roi, scales):
    """Retain complete native/ROI7-member and total loss arrays; no row selection.

    ``scales`` has ``members`` (seven training-only reference scales) and
    ``total``. ROI indices belong to one complete section and are contiguous.
    Undefined zero-total-prediction allocation has a separate Boolean flag.
    """
    means = np.asarray(geneMeans, dtype=float)
    counts = np.asarray(truth)
    regions = np.asarray(roi)
    if means.ndim != 2 or means.shape[1] != 7 or counts.shape != means.shape or len(means) == 0:
        raise ValueError("complete geneMeans/truth must have nonempty shape (N,7)")
    poisson_deviance(counts, means)
    if any(int(value) > np.iinfo(np.int64).max for value in counts.flat):
        raise ValueError("truth exceeds int64 exact count storage")
    counts = counts.astype(np.int64)
    if regions.shape != (len(counts),) or regions.dtype.kind not in "iu" or np.any(regions < 0):
        raise ValueError("ROI indices must be nonnegative integer identifiers for every row")
    region_count = int(regions.max()) + 1
    if not np.array_equal(np.unique(regions), np.arange(region_count)):
        raise ValueError("ROI indices must preserve every nonempty contiguous region")
    scale7 = np.asarray(scales["members"], dtype=float)
    total_scale = float(scales["total"])
    if scale7.shape != (7,) or not np.isfinite(scale7).all() or np.any(scale7 < 1) or not np.isfinite(total_scale) or total_scale < 1:
        raise ValueError("all training-only member/total scales must be finite and at least1")
    roi_truth = np.zeros((region_count, 7), dtype=np.int64)
    for region in range(region_count):
        for gene in range(7):
            total = sum(int(value) for value in counts[regions == region, gene])
            if total > np.iinfo(np.int64).max:
                raise ValueError("ROI count total exceeds exact int64 range")
            roi_truth[region, gene] = total
    roi_means = np.zeros((region_count, 7), dtype=float)
    np.add.at(roi_means, regions, means)
    if not np.isfinite(roi_means).all():
        raise ValueError("projected ROI means must be finite; no sum cap")
    return {"native": _evaluate_level(means, counts, scale7, total_scale),
            "ROI": _evaluate_level(roi_means, roi_truth, scale7, total_scale),
            "native_observations": len(counts), "regions": region_count, "all_seven_members_retained": True,
            "no_eligibility_or_positive_count_filter": True}


def _binding(descriptor, expected=None):
    path = Path(descriptor["path"]).resolve()
    if expected is not None and path != Path(expected).resolve():
        raise ValueError("committed RNA artifact path differs from its declared stage")
    if sha(path) != descriptor["sha256"]:
        raise ValueError("committed RNA artifact hash mismatch")
    return path


def _verified_forecasts(specification, config_hash, root, prepared_hash):
    barrier = read_json(root / "ALL_FORECASTS_COMMIT.json")
    if (barrier["status"] != "ALL_FOUR_OUTER_FORECASTS_COMMITTED" or set(barrier["folds"]) != set(PARENTS)
            or barrier["config_sha256"] != config_hash or barrier["prepared_commit_sha256"] != prepared_hash):
        raise ValueError("complete ALL_FORECASTS_COMMIT/config/prepared barrier required")
    result = {}
    for parent in PARENTS:
        descriptor = barrier["folds"][parent]
        if type(descriptor["external_exit_code"]) is not int or descriptor["external_exit_code"] != 0:
            raise ValueError("every RNA forecast requires actual external exit0")
        receipt_path = root / "process_receipts" / ("fold_" + parent + ".json")
        receipt = read_json(receipt_path)
        if (receipt["stage"] != "fold_" + parent or type(receipt["external_exit_code"]) is not int
                or receipt["external_exit_code"] != 0 or receipt["resource_violation"] is not None):
            raise ValueError("matching actual external forecast exit receipt required")
        folder = root / "folds" / parent
        commit_path = _binding(descriptor, folder / "FORECAST_COMMIT.json")
        commit = read_json(commit_path)
        required = {"NATIVE_MEANS.npz", "ROI_MEANS.npz", "FOLD_PARAMS.json", "SELECTION.json"}
        expected_sections = [section["section_folder"] for section in specification["sections"] if section["parent"] == parent]
        if (commit["status"] != "RNA_OUTER_FORECAST_COMMITTED" or commit["holdout_parent"] != parent
                or commit["config_sha256"] != config_hash or commit["prepared_commit_sha256"] != prepared_hash
                or set(commit["methods"]) != set(METHODS) or set(commit["artifacts"]) != required
                or set(commit["training_parents"]) != set(PARENTS) - {parent}
                or commit["eval_sections"] != expected_sections or commit["heldout_response_reads"] != 0):
            raise ValueError("outer RNA forecast must cover exact parent/method/role support")
        for name, artifact in commit["artifacts"].items():
            _binding(artifact, folder / name)
        params = read_json(folder / "FOLD_PARAMS.json")
        if (params["source_scales7"] != commit["source_scales7"] or params["source_scale_total"] != commit["source_scale_total"]
                or params["training_parents"] != commit["training_parents"] or params["ordered_roles"] != specification["ordered_roles"]):
            raise ValueError("score scales/roles must come from the held-out fold's source training only")
        with np.load(folder / "NATIVE_MEANS.npz", allow_pickle=False) as archive:
            if set(archive.files) != {*METHODS, "region_id", "barcode", "section_id", "parent_id"}:
                raise ValueError("complete native means role schema required")
            native = {name: archive[name] for name in archive.files}
        with np.load(folder / "ROI_MEANS.npz", allow_pickle=False) as archive:
            if set(archive.files) != {*METHODS, "roi_section_id", "roi_keys"}:
                raise ValueError("complete projected ROI means role schema required")
            rois = {name: archive[name] for name in archive.files}
        result[parent] = {"commit": commit, "params": params, "native": native, "ROI": rois,
                          "commit_binding": record(commit_path), "external_receipt_binding": record(receipt_path)}
    return result


def _portable(value):
    if isinstance(value, np.ndarray):
        return [_portable(item) for item in value.tolist()]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (float, np.floating)):
        if np.isposinf(value):
            return "Infinity"
        if np.isneginf(value):
            raise ValueError("negative infinite loss is invalid")
        if np.isnan(value):
            return None
        return float(value)
    if isinstance(value, dict):
        return {key: _portable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_portable(item) for item in value]
    return value


def _level_summary(level):
    member_deviance = level["member_deviance"]
    summary = {"mean7_training_scaled_deviance": float(level["mean_seven_scaled_deviance"].mean()),
               "mean_D7_unscaled": float(level["sum_member_deviance"].mean()),
               "mean_Dtotal_unscaled": float(level["programme_deviance"].mean()),
               "member_MAE": float(level["member_absolute_error"].mean()),
               "programme_MAE": float(level["programme_absolute_error"].mean()),
               "infinite_member_loss_entries": int(np.isposinf(member_deviance).sum()),
               "allocation_defined_rows": int(level["allocation_defined"].sum()),
               "allocation_undefined_rows": int((~level["allocation_defined"]).sum()),
               "rows": len(level["programme_truth"]), "members": {}}
    defined = level["allocation_defined"]
    summary["mean_allocation_defined_unscaled"] = float(level["allocation_deviance"][defined].mean()) if defined.any() else None
    summary["decomposition_max_abs_finite_error"] = float(np.nanmax(np.abs(level["decomposition_error"]))) if np.isfinite(level["decomposition_error"]).any() else None
    for index, gene in enumerate(GENES):
        summary["members"][gene] = {"mean_deviance": float(member_deviance[:, index].mean()),
            "mean_training_scaled_deviance": float(level["scaled_member_deviance"][:, index].mean()),
            "MAE": float(level["member_absolute_error"][:, index].mean()),
            "truth_mass": sum(int(value) for value in level["member_truth"][:, index]),
            "predicted_mass": float(level["member_mean"][:, index].sum()),
            "zero_truth_rows": int((level["member_truth"][:, index] == 0).sum()),
            "infinite_loss_rows": int(np.isposinf(member_deviance[:, index]).sum())}
    return summary


def _loss_status(truth, mean, loss):
    if np.isfinite(loss):
        return "finite"
    return "positive_truth_zero_mean" if truth > 0 and mean == 0 else "arithmetic_overflow_retained"


def score_committed(config, complete_forecast_root, fresh_output):
    """Separate source-RNA scorer after all four verified forecasts and child exits.

    Source labels were previously exposed. This barrier enforces each frozen
    computational forecast before evaluation, not a new blind-source claim.
    """
    root, output = Path(complete_forecast_root).resolve(), Path(fresh_output).resolve()
    if not (root / "ALL_FORECASTS_COMMIT.json").is_file():
        raise ValueError("ALL_FORECASTS_COMMIT is required before separate source-label scoring")
    if output.exists():
        raise ValueError("RNA score output must be fresh")
    config_path = Path(config).resolve()
    specification, config_hash = read_json(config_path), sha(config_path)
    if specification["mode"] not in (REAL_MODE, SYNTHETIC_MODE):
        raise ValueError("RNA scoring mode is not authorized")
    prepared_path = root / "prepared/PREPARE_COMMIT.json"
    prepared, prepared_hash = read_json(prepared_path), sha(prepared_path)
    if prepared["status"] != "RNA_INPUTS_PREPARED" or prepared["config_sha256"] != config_hash:
        raise ValueError("source preparation/config identity mismatch")
    # No SOURCE_LABELS.npz is opened or hashed until all four forecast/actual
    # exit records have been checked. There is no partial-fold evaluation.
    forecasts = _verified_forecasts(specification, config_hash, root, prepared_hash)
    before = verify_bindings(config_bindings(specification))
    section_results, rows, pair_differences = {}, [], []
    native_observations, roi_regions = 0, 0
    for section in specification["sections"]:
        folder, parent = section["section_folder"], section["parent"]
        descriptors = prepared["sections"][folder]["artifacts"]
        input_path = _binding(descriptors["INPUTS.npz"], root / "prepared/sections" / folder / "INPUTS.npz")
        label_path = _binding(descriptors["SOURCE_LABELS.npz"], root / "prepared/sections" / folder / "SOURCE_LABELS.npz")
        with np.load(input_path, allow_pickle=False) as archive:
            ids, barcodes, roi, keys = archive["region_id"], archive["barcode"], archive["roi_indices"], archive["roi_keys"]
        with np.load(label_path, allow_pickle=False) as archive:
            if set(archive.files) != {"region_id", "barcode", "y_counts"} or not np.array_equal(archive["region_id"], ids) or not np.array_equal(archive["barcode"], barcodes):
                raise ValueError("source labels must match the complete prepared canonical input identity")
            truth = archive["y_counts"]
        item = forecasts[parent]
        ns = item["native"]["section_id"].astype(str) == folder
        rs = item["ROI"]["roi_section_id"].astype(str) == folder
        if (len(ids) != section["expected_rows"] or not np.array_equal(item["native"]["region_id"][ns], ids)
                or not np.array_equal(item["native"]["barcode"][ns], barcodes)
                or not np.all(item["native"]["parent_id"][ns] == parent)
                or not np.array_equal(item["ROI"]["roi_keys"][rs], keys)):
            raise ValueError("every forecast must preserve exact complete native/ROI source identity")
        scales = {"members": item["params"]["source_scales7"], "total": item["params"]["source_scale_total"]}
        section_results[folder] = {"parent": parent, "section_id": section["section_id"], "source_scales7": scales["members"],
                                  "source_scale_total": scales["total"], "native": {}, "ROI": {}}
        native_observations += len(ids)
        roi_regions += len(keys)
        for method in METHODS:
            means = item["native"][method][ns]
            values = mean_evaluation(means, truth, roi, scales)
            if not np.allclose(values["ROI"]["member_mean"], item["ROI"][method][rs], rtol=1e-12, atol=1e-12):
                raise ValueError("ROI expected means must equal full native-mean projection")
            for level in ("native", "ROI"):
                block = values[level]
                section_results[folder][level][method] = _level_summary(block)
                for index in range(len(block["programme_truth"])):
                    roi_index = int(roi[index]) if level == "native" else index
                    common = {"level": level, "holdout_parent": parent, "section_id": folder, "method": method,
                              "region_id": str(ids[index]) if level == "native" else folder + "|ROI" + str(index),
                              "roi_x": int(keys[roi_index, 0]), "roi_y": int(keys[roi_index, 1])}
                    for gene_index, gene in enumerate(GENES):
                        y = int(block["member_truth"][index, gene_index]); mu = float(block["member_mean"][index, gene_index]); loss = float(block["member_deviance"][index, gene_index])
                        rows.append({**common, "endpoint": gene, "truth_count": y, "predicted_mean": mu,
                                     "source_scale": scales["members"][gene_index], "poisson_deviance": loss,
                                     "scaled_poisson_deviance": float(block["scaled_member_deviance"][index, gene_index]),
                                     "absolute_error": float(block["member_absolute_error"][index, gene_index]),
                                     "truth_is_zero": y == 0, "score_status": _loss_status(y, mu, loss)})
                    y = int(block["programme_truth"][index]); mu = float(block["programme_mean"][index]); loss = float(block["programme_deviance"][index])
                    defined = bool(block["allocation_defined"][index])
                    status = "undefined_zero_total_prediction" if not defined else "zero_truth_allocation_limit0" if y == 0 else "finite_identity" if np.isfinite(block["decomposition_error"][index]) else "extended_infinite_identity"
                    rows.append({**common, "endpoint": "TOTAL", "truth_count": y, "predicted_mean": mu,
                                 "source_scale": scales["total"], "poisson_deviance": loss,
                                 "scaled_poisson_deviance": float(block["scaled_programme_deviance"][index]),
                                 "absolute_error": float(block["programme_absolute_error"][index]), "truth_is_zero": y == 0,
                                 "score_status": _loss_status(y, mu, loss), "D7_unscaled": float(block["sum_member_deviance"][index]),
                                 "Dtotal_unscaled": loss, "allocation_unscaled": float(block["allocation_deviance"][index]) if defined else None,
                                 "allocation_defined": defined, "decomposition_status": status,
                                 "mean7_training_scaled_deviance": float(block["mean_seven_scaled_deviance"][index])})
        fixed = item["native"][METHODS[3]][ns].sum(axis=1)
        learned = item["native"][METHODS[4]][ns].sum(axis=1)
        if not np.allclose(fixed, learned, rtol=1e-12, atol=1e-12):
            raise ValueError("paired sourceTotal methods must retain the exact same total mean")
        pair_differences.append(float(np.max(np.abs(fixed - learned))))
    if native_observations != specification["expected_total_rows"] or len(section_results) != 8:
        raise ValueError("score cannot select a subset of source observations or sections")
    parents, macro = {}, {level: {} for level in ("native", "ROI")}
    average_fields = ("mean7_training_scaled_deviance", "mean_D7_unscaled", "mean_Dtotal_unscaled", "member_MAE", "programme_MAE")
    for parent in PARENTS:
        members = [value for value in section_results.values() if value["parent"] == parent]
        if len(members) != 2:
            raise ValueError("both source sections required for every parent")
        parents[parent] = {level: {method: {metric: float(np.mean([value[level][method][metric] for value in members]))
                             for metric in average_fields} for method in METHODS} for level in ("native", "ROI")}
    for level in ("native", "ROI"):
        for method in METHODS:
            macro[level][method] = {metric: float(np.mean([parents[parent][level][method][metric] for parent in PARENTS])) for metric in average_fields}
    summary = {"status": "RNA_POINT_MEAN_SUMMARY_COMPLETE", "mode": specification["mode"], "config_sha256": config_hash,
               "prepared_commit_sha256": prepared_hash, "all_forecasts_commit_sha256": sha(root / "ALL_FORECASTS_COMMIT.json"),
               "native_observations": native_observations, "ROI_regions": roi_regions, "sections": section_results,
               "parents": parents, "hierarchical_macro": macro, "methods": list(METHODS), "all_seven_members_retained": True,
               "primary": {"level": "ROI", "endpoint": "mean7_training_scaled_deviance", "methods": {method: macro["ROI"][method]["mean7_training_scaled_deviance"] for method in METHODS}},
               "aggregation": "Native/ROI rows equal within each section; sections equal within parent; four held-out parents equal. Fold-specific source-training scales remain distinct.",
               "positive_infinity_representation": "Infinity string plus explicit status/count; no loss floor, member removal or complete-case filtering",
               "zero_truth_allocation_convention": "Allocation limit0 when programme truth0, including mean0; observed composition itself is undefined. Positive truth with zero programme mean has undefined allocation, D7=Dtotal=Infinity.",
               "paired_total_max_abs_difference": max(pair_differences), "label_exposure": "Already exposed source-RNA development, not fresh blind or independent animal validation",
               "forecasts": {parent: {"commit": value["commit_binding"], "actual_external_receipt": value["external_receipt_binding"]} for parent, value in forecasts.items()},
               "rows": len(rows), "all_adverse_and_nonfinite_outcomes_retained": True}
    after = verify_bindings(config_bindings(specification))
    if before != after or sha(config_path) != config_hash:
        raise ValueError("RNA source/code/config changed during scoring")
    output.mkdir(parents=True, exist_ok=False)
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with (output / "ROWS.tsv").open("x", encoding="utf8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows([{key: _portable(value) for key, value in row.items()} for row in rows])
    write_json(output / "SUMMARY.json", _portable(summary))
    commit = {"status": "SCORES_COMPLETE", "config_sha256": config_hash, "prepared_commit_sha256": prepared_hash,
              "all_forecasts_commit_sha256": sha(root / "ALL_FORECASTS_COMMIT.json"), "native_observations": native_observations,
              "ROI_regions": roi_regions, "sections": len(section_results), "rows": len(rows), "methods": list(METHODS),
              "all_seven_members_retained": True, "artifacts": {name: record(output / name) for name in ("ROWS.tsv", "SUMMARY.json")},
              "bindings_before": before, "bindings_after": after, "no_fits_or_new_predictions": True}
    write_json(output / "SCORE_COMMIT.json", commit)
    return commit


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["score"])
    parser.add_argument("--config", required=True)
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        result = score_committed(args.config, args.run_root, args.output)
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({"status": "RNA_SCORE_BLOCKED", "reason": str(error)}), flush=True)
        sys.exit(2)
    print(json.dumps({"status": result["status"], "rows": result["rows"], "native_observations": result["native_observations"]}), flush=True)
