"""Synthetic-only behavioral checks at the agreed source-statistics seams."""

import copy
import unittest

import numpy as np

from source_statistics import (fit_source, source_basis, source_pit_gaussian_scores,
                               source_state_basis, source_state_weights)


def synthetic_inputs():
    """Eight made-up observations, four anchor states, and seven count genes."""
    x = np.zeros((8, 126), dtype=float)
    for row in range(8):
        x[row, row // 2] = 10 + row % 2
    y = np.tile(np.arange(8, dtype=float)[:, None], (1, 7))
    y[:, 1] = [1, 2, 1, 2, 1, 2, 1, 2]
    mu = np.full((8, 7), 2.0)
    mu[:, 1] = 1.5
    captures = np.array(["capture_a"] * 4 + ["capture_b"] * 4)
    return x, y, mu, captures


class SourceStatisticsTests(unittest.TestCase):
    def test_nb2_moment_has_literal_overdispersion_and_poisson_limit(self):
        x, y, mu, captures = synthetic_inputs()
        parameters = fit_source(x, y, mu, captures)
        # Hand example: sum squared residuals=60, n=8, mean=2;
        # (60/8 - 2)/4 = 1.375. Second gene's residual variance is .25.
        self.assertEqual(parameters["alpha7"][0], 1.375)
        self.assertEqual(parameters["alpha7"][1], 0.0)
        self.assertEqual(parameters["observation_weights"], [0.125] * 8)

    def test_capture_replication_preserves_balanced_source_moments(self):
        x, y, mu, captures = synthetic_inputs()
        parameters = fit_source(x, y, mu, captures)
        repeat = np.r_[np.arange(8), np.arange(4)]
        repeated = fit_source(x[repeat], y[repeat], mu[repeat], captures[repeat])
        weights = np.asarray(repeated["observation_weights"])
        self.assertAlmostEqual(weights[captures[repeat] == "capture_a"].sum(), 0.5)
        self.assertAlmostEqual(weights[captures[repeat] == "capture_b"].sum(), 0.5)
        np.testing.assert_allclose(repeated["alpha7"], parameters["alpha7"], atol=1e-14)
        np.testing.assert_allclose(repeated["anchor_mean127"], parameters["anchor_mean127"], atol=1e-14)
        np.testing.assert_allclose(repeated["anchor_sd127"], parameters["anchor_sd127"], atol=1e-14)

    def test_frozen_state_map_applies_to_inputs_without_response_or_refit(self):
        centroids = np.zeros((4, 127))
        centroids[:, 0] = np.sqrt(127 * np.log(2) * np.arange(4))
        frozen = {
            "anchor_mean127": [0.0] * 127,
            "anchor_sd127": [1.0] * 127,
            "state_centroids4x127": centroids.tolist(),
        }
        unchanged = copy.deepcopy(frozen)
        applied = source_state_weights(np.zeros((1, 126)), frozen)
        np.testing.assert_allclose(applied, [[8/15, 4/15, 2/15, 1/15]], atol=1e-14)
        self.assertEqual(frozen, unchanged)

    def test_source_fit_finds_four_known_states_with_replayable_weights(self):
        x, y, mu, captures = synthetic_inputs()
        x[x != 0] = 10
        fitted = fit_source(x, y, mu, captures)
        centers = np.asarray(fitted["state_centroids4x127"])
        order = np.argsort(np.argmax(centers[:, :4], axis=1))
        expected = np.full((4, 4), -0.5773502691896258)
        np.fill_diagonal(expected, 1.7320508075688772)
        np.testing.assert_allclose(centers[order, :4], expected, atol=1e-13)
        np.testing.assert_allclose(centers[:, 4:], 0.0, atol=1e-13)
        np.testing.assert_allclose(source_state_weights(x, fitted), fitted["state_weights"], atol=1e-15)
        self.assertEqual(fitted, fit_source(x, y, mu, captures))
        self.assertLessEqual(fitted["state_fit"]["steps"], 100)

    def test_source_residual_correlations_are_shrunk_unit_diagonal_and_psd(self):
        x, y, mu, captures = synthetic_inputs()
        fitted = fit_source(x, y, mu, captures)
        bank = fitted["residual_correlations"]
        matrices = [bank["pooled"], *bank["states"]]
        self.assertEqual(len(matrices), 5)
        for matrix in matrices:
            correlation = np.asarray(matrix)
            np.testing.assert_allclose(correlation, correlation.T, atol=1e-14)
            np.testing.assert_allclose(np.diag(correlation), np.ones(7), atol=1e-14)
            self.assertGreaterEqual(np.linalg.eigvalsh(correlation).min(), 0.099999999999)
            # Genes 0 and 2 have identical increasing counts, unlike gene 1.
            self.assertGreater(correlation[0, 2], 0.75)
        self.assertEqual(fitted["pit_seed"], 2026100602)
        self.assertEqual(bank, fit_source(x, y, mu, captures)["residual_correlations"])

    def test_complete_support_rbf_state_basis_has_unit_row_norm(self):
        coords = np.array([[10, 20], [30, 20], [10, 60], [30, 60], [20, 40]], dtype=float)
        phi = source_basis(coords)
        self.assertEqual(phi.shape, (5, 16))
        np.testing.assert_array_equal(phi[[0, 1, 2, 3], [0, 3, 12, 15]], np.ones(4))
        np.testing.assert_allclose(source_basis(coords * [3, 5] + [27, -13]), phi, atol=1e-15)
        states = np.array([[1, 0, 0, 0], [.25, .25, .25, .25], [0, 1, 0, 0],
                           [0, 0, 1, 0], [0, 0, 0, 1]], dtype=float)
        h = source_state_basis(coords, states)
        self.assertEqual(h.shape, (5, 4, 16))
        np.testing.assert_allclose(np.sum(h * h, axis=(1, 2)), np.ones(5), atol=1e-14)
        np.testing.assert_array_equal(h[0, 1:], np.zeros((3, 16)))
        np.testing.assert_allclose(h[1, 0], h[1, 3], atol=1e-15)

    def test_source_fit_rejects_invalid_counts_and_nonfinite_or_negative_means(self):
        x, y, mu, captures = synthetic_inputs()
        for field, invalid in [("x", 0.5), ("x", -1.0), ("x", np.inf),
                               ("y", 0.5), ("y", -1.0), ("y", np.nan),
                               ("mu", -1.0), ("mu", np.inf)]:
            with self.subTest(field=field, invalid=invalid):
                inputs = {"x": x.copy(), "y": y.copy(), "mu": mu.copy()}
                inputs[field][0, 0] = invalid
                with self.assertRaises(ValueError):
                    fit_source(inputs["x"], inputs["y"], inputs["mu"], captures)

    def test_two_capture_contract_and_undefined_source_fit_are_blocked(self):
        x, y, mu, captures = synthetic_inputs()
        for invalid_captures in [np.array(["one"] * 8), np.array(["a", "b", "c", "a", "b", "c", "a", "b"])]:
            with self.subTest(captures=invalid_captures.tolist()):
                with self.assertRaisesRegex(ValueError, "two"):
                    fit_source(x, y, mu, invalid_captures)
        undefined_mu = mu.copy()
        undefined_mu[:, 0] = 0
        with self.assertRaisesRegex(ValueError, "denominator"):
            fit_source(x, y, undefined_mu, captures)
        with self.assertRaisesRegex(ValueError, "state"):
            fit_source(np.zeros_like(x), y, mu, captures)

    def test_frozen_state_map_rejects_nonfinite_or_undefined_parameters(self):
        x, y, mu, captures = synthetic_inputs()
        parameters = fit_source(x, y, mu, captures)
        for key, index, invalid in [("anchor_mean127", 0, np.nan),
                                    ("anchor_sd127", 0, 0.0),
                                    ("anchor_sd127", 0, 0.05)]:
            with self.subTest(key=key, invalid=invalid):
                changed = copy.deepcopy(parameters)
                changed[key][index] = invalid
                with self.assertRaises(ValueError):
                    source_state_weights(x, changed)
        changed = copy.deepcopy(parameters)
        changed["state_centroids4x127"][0][0] = np.inf
        with self.assertRaises(ValueError):
            source_state_weights(x, changed)
        del changed["anchor_mean127"]
        with self.assertRaises(ValueError):
            source_state_weights(x, changed)

    def test_missing_capture_identifiers_block_source_parameters(self):
        x, y, mu, _ = synthetic_inputs()
        captures = np.array([1.0] * 4 + [np.nan] * 4)
        with self.assertRaisesRegex(ValueError, "capture"):
            fit_source(x, y, mu, captures)

    def test_frozen_mapping_blocks_unrepresentable_squared_distances(self):
        frozen = {"anchor_mean127": [1e308] * 127, "anchor_sd127": [1.0] * 127,
                  "state_centroids4x127": np.zeros((4, 127)).tolist()}
        with self.assertRaises(ValueError):
            source_state_weights(np.zeros((1, 126)), frozen)

    def test_rare_poisson_upper_tail_retains_finite_scores_above_eight_sigma(self):
        # For mu=1e-12, P(Y>=5) is about 8.33e-63; the CDF rounds to 1.
        scores = source_pit_gaussian_scores(np.full((1, 7), 5.0),
                                            np.full((1, 7), 1e-12), np.zeros(7))
        self.assertTrue(np.all(np.isfinite(scores)))
        self.assertTrue(np.all(scores > 8.0))
        # Hand Poisson tails mu**5/5! and mu**6/6! give selected tail
        # 3.085520957808544e-63 for v=.6297374850630796. An independent
        # sqrt(2)*inverse_erfc(2*tail) evaluation gives this fixed literal.
        self.assertAlmostEqual(scores[0, 0], 16.744884223485716, delta=5e-12)

    def test_tiny_nb2_dispersion_preserves_the_non_degenerate_poisson_limit(self):
        counts = np.full((1, 7), 5.0)
        means = np.ones((1, 7))
        poisson_scores = source_pit_gaussian_scores(counts, means, np.zeros(7))
        nb2_scores = source_pit_gaussian_scores(counts, means, np.full(7, 1e-20))
        np.testing.assert_allclose(nb2_scores, poisson_scores, atol=1e-12, rtol=1e-10)

    def test_selected_source_tail_underflow_blocks_without_score_clipping(self):
        # The Poisson upper tail is about 1e-1000/10!, below float64 range.
        with self.assertRaisesRegex(ValueError, "BLOCKED_NUMERIC_SOURCE"):
            source_pit_gaussian_scores(np.full((1, 7), 10.0),
                                       np.full((1, 7), 1e-100), np.zeros(7))

    def test_zero_mean_degenerate_law_randomizes_only_supported_zero_counts(self):
        counts = np.zeros((1, 7))
        means = np.zeros((1, 7))
        poisson_scores = source_pit_gaussian_scores(counts, means, np.zeros(7))
        mixed_scores = source_pit_gaussian_scores(counts, means, np.array([0, 1, 1e-20, 2, 0, .5, 3]))
        np.testing.assert_array_equal(mixed_scores, poisson_scores)
        self.assertTrue(np.all(np.isfinite(mixed_scores)))
        self.assertGreater(np.std(mixed_scores), .2)
        counts[0, 0] = 1
        with self.assertRaisesRegex(ValueError, "BLOCKED_NUMERIC_SOURCE"):
            source_pit_gaussian_scores(counts, means, np.zeros(7))

    def test_large_uncapped_nb2_dispersion_preserves_its_near_unit_zero_mass(self):
        # P0=(1+alpha*mu)**(-1/alpha) is within 5e-19 of 1 here.
        # q rounds to 1, but using its directly evaluated complement retains P0.
        counts = np.zeros((1, 7))
        expected = source_pit_gaussian_scores(counts, np.zeros((1, 7)), np.zeros(7))
        observed = source_pit_gaussian_scores(counts, np.ones((1, 7)), np.full(7, 1e20))
        np.testing.assert_allclose(observed, expected, atol=1e-12, rtol=0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
