"""Separate source-only parameter stage; the CLI requires a fresh output path."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys

import numpy as np

GENES = ["TBXT", "KRT8", "KRT18", "KRT19", "ACAN", "COL2A1", "SOX9"]
REAL_MODE = "AUTHORIZED_REAL_SOURCE_FIT"
SYNTHETIC_MODE = "SYNTHETIC_SOURCE_STAGE"
SUPERVISOR_SYNTHETIC_MODE = "SYNTHETIC_SUPERVISOR_TEST"


def _sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _write_json(path, value):
    with Path(path).open("x", encoding="utf8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _binding_records(config):
    records = list(config["code_binding"]) + [config["spec_binding"], config["authorization_binding"]]
    for source in config["source_records"]:
        records.extend([source["input"], source["predictions"], source["head_params"], source["total_params"]])
        records.extend(source["commits"])
    return records


def _verified_bindings(records):
    verified = {}
    for record in records:
        if not isinstance(record, dict) or not isinstance(record.get("path"), str) or not isinstance(record.get("sha256"), str):
            raise ValueError("source file binding requires a path and sha256 hash")
        if re.fullmatch(r"[0-9a-f]{64}", record["sha256"]) is None:
            raise ValueError("source file binding has an invalid sha256 hash")
        path = str(Path(record["path"]).resolve())
        actual = _sha(path)
        if actual != record["sha256"]:
            raise ValueError("source file hash differs from frozen binding: " + path)
        verified[path] = actual
    return verified


def _forbidden_path(path, metadata_code=False):
    value = Path(path)
    lowered = value.as_posix().casefold()
    parts = [part.casefold() for part in value.parts]
    target_parts = parts[:-1] if metadata_code else parts
    return ("gse216511" in lowered or value.suffix.casefold() in [".rds", ".rdata"]
            or any(part == "target" or part.startswith("target_") or part.startswith("target-") for part in target_parts)
            or value.name.casefold().startswith("raw_source"))


def _install_open_guard(allowed_paths, output, metadata_code_paths):
    allowed = {str(Path(path).resolve()).casefold() for path in allowed_paths}
    output = output.resolve()
    runtime = {Path(sys.prefix).resolve(), Path(sys.base_prefix).resolve(), Path(np.__file__).resolve().parents[1]}
    code = {str(path.resolve()).casefold() for path in metadata_code_paths}
    reads, writes, denied = [], [], []

    def audit(event, args):
        if event != "open" or isinstance(args[0], int):
            return
        path = Path(os.fsdecode(args[0])).resolve()
        mode = args[1] or ""
        flags = args[2] or 0
        writing = any(letter in mode for letter in "wax+") or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC))
        is_output = path == output or output in path.parents
        is_runtime = any(path == prefix or prefix in path.parents for prefix in runtime)
        accepted = not _forbidden_path(path, metadata_code=str(path).casefold() in code) and (is_output if writing else
                    (str(path).casefold() in allowed or is_output or is_runtime))
        if not accepted:
            denied.append({"path": str(path), "writing": writing})
            raise PermissionError("source stage Python open guard denied: " + str(path))
        (writes if writing else reads).append(str(path))

    sys.addaudithook(audit)
    return reads, writes, denied


def _guard_probes(output):
    paths = [output.parent / "GSE216511" / "READ_GUARD_PROBE_DO_NOT_CREATE.bin",
             output.parent / "RAW_SOURCE_READ_GUARD_PROBE_DO_NOT_CREATE.rds",
             output.parent / "UNLISTED_READ_GUARD_PROBE_DO_NOT_CREATE.bin"]
    probes = []
    for path in paths:
        try:
            with path.open("rb"):
                pass
        except PermissionError:
            probes.append({"path": str(path), "denied": True})
        else:
            raise ValueError("source stage forbidden-read guard probe was not denied")
    return probes


def _read_capture(record, linkage):
    capture = record["capture"]
    with np.load(record["input"]["path"], allow_pickle=False) as archive:
        if set(archive.files) != {"region_id", "x_counts", "y_counts", "row", "col"}:
            raise ValueError("source input capsule has an invalid role schema")
        ids = archive["region_id"].astype(str)
        x = archive["x_counts"]
        y = archive["y_counts"]
        row, col = archive["row"], archive["col"]
    if ids.ndim != 1 or len(ids) == 0 or len(set(ids)) != len(ids):
        raise ValueError("source input region IDs must be nonempty and unique")
    if any(not value.startswith(capture + "|") for value in ids):
        raise ValueError("source region IDs do not match the declared capture")
    if x.shape != (len(ids), 126) or y.shape != (len(ids), 7) or row.shape != ids.shape or col.shape != ids.shape:
        raise ValueError("source input arrays have invalid shapes")
    with np.load(record["predictions"]["path"], allow_pickle=False) as archive:
        prediction_ids = archive[linkage["source_region_id_key"]].astype(str)
        means = archive[linkage["source_prediction_key"]]
        if "member_ids" in archive.files and archive["member_ids"].astype(str).tolist() != linkage["member_ids"]:
            raise ValueError("source prediction member roles differ from linkage")
    if prediction_ids.ndim != 1 or len(set(prediction_ids)) != len(prediction_ids) or set(prediction_ids) != set(ids):
        raise ValueError("source count/prediction region IDs must match exactly and uniquely")
    if means.shape != (len(ids), 7):
        raise ValueError("source cross-capture means must have shape (N, 7)")
    lookup = {value: index for index, value in enumerate(prediction_ids)}
    order = np.argsort(ids, kind="stable")
    canonical = ids[order]
    aligned_mean = means[[lookup[value] for value in canonical]]
    return canonical, x[order], y[order], aligned_mean, row[order], col[order]


def _source_roi_summary(y, row, col):
    if not np.all(np.isfinite(row)) or not np.all(np.isfinite(col)) or np.any(row != np.floor(row)) or np.any(col != np.floor(col)):
        raise ValueError("source row/col must be finite integer coordinates")
    if not np.all(np.isfinite(y)) or np.any(y < 0) or np.any(y != np.floor(y)):
        raise ValueError("source ROI truths require exact nonnegative integer counts")
    coords = 48.0 * np.column_stack((col + 0.5, row + 0.5))
    keys, inverse = np.unique(np.floor(coords / 500.0).astype(np.int64), axis=0, return_inverse=True)
    totals = np.zeros((len(keys), 7), dtype=np.int64)
    for gene in range(7):
        if sum(int(value) for value in y[:, gene]) > np.iinfo(np.int64).max:
            raise ValueError("source ROI count sum cannot be represented exactly in int64")
    np.add.at(totals, inverse, y.astype(np.int64))
    summaries = {"ALL7": float(np.mean([sum(int(value) for value in values) for values in totals])),
                 "ACAN_COL2A1": float(np.mean([int(values[4]) + int(values[5]) for values in totals])),
                 "OTHER5": float(np.mean([sum(int(values[i]) for i in [0, 1, 2, 3, 6]) for values in totals]))}
    return summaries, len(keys)


def run_source_stage(config_path, output_path):
    """Load two hash-bound source captures and commit source-only parameters."""
    config_path, output = Path(config_path).resolve(), Path(output_path).resolve()
    config = json.loads(config_path.read_text(encoding="utf8"))
    if output.exists():
        raise ValueError("source stage output must be fresh and must not already exist")
    if config["mode"] not in [REAL_MODE, SYNTHETIC_MODE, SUPERVISOR_SYNTHETIC_MODE]:
        raise ValueError("invalid source stage mode")
    synthetic = config["mode"] in [SYNTHETIC_MODE, SUPERVISOR_SYNTHETIC_MODE]
    if len(config["source_records"]) != 2 or len({record["capture"] for record in config["source_records"]}) != 2:
        raise ValueError("source stage requires exactly two distinct capture records")
    for record in config["source_records"]:
        commits = record["commits"]
        if not isinstance(commits, list) or len(commits) != 2 or len({str(Path(item["path"]).resolve()).casefold() for item in commits}) != 2:
            raise ValueError("each source capture requires two distinct original V2/old-total commit bindings")
        if any(Path(record[role]["path"]).suffix.casefold() != ".npz" for role in ["input", "predictions"]):
            raise ValueError("source count/prediction roles must retain NPZ capsules")
        if any(Path(descriptor["path"]).suffix.casefold() != ".json" for descriptor in [record["head_params"], record["total_params"], *commits]):
            raise ValueError("source stage forbids non-JSON parameter and commit capsules")
    if config["mode"] == REAL_MODE and config["expected_source_observations"] != 30829:
        raise ValueError("real source stage requires the fixed 30829 observations")
    if synthetic and any(not record["capture"].startswith("SYN_") for record in config["source_records"]):
        raise ValueError("synthetic source captures must use SYN_ identifiers")
    linkage = config["linkage"]
    if len(linkage["input_ids"]) != 126 or len(set(linkage["input_ids"])) != 126 or linkage["member_ids"] != GENES:
        raise ValueError("source input/member gene linkage is invalid")
    if set(linkage["input_ids"]) & set(linkage["member_ids"]):
        raise ValueError("source input/member gene roles overlap")
    if linkage["source_prediction_key"] != "TotalXGB" or linkage["source_region_id_key"] != "region_id":
        raise ValueError("source mean and ID fields must retain their original keys")
    records = _binding_records(config)
    code_paths = {Path(record["path"]).resolve() for record in config["code_binding"]}
    metadata_code_paths = {path for path in code_paths if path.suffix.casefold() == ".py"}
    if any(_forbidden_path(record["path"], metadata_code=Path(record["path"]).resolve() in metadata_code_paths)
           for record in records) or _forbidden_path(output):
        raise ValueError("source-only stage forbids target and raw source paths even if configured")
    required_code = {Path(__file__).resolve(), Path(__file__).resolve().with_name("source_statistics.py")}
    if not required_code.issubset(code_paths):
        raise ValueError("code binding must freeze source_stage.py and source_statistics.py")
    reads, writes, denied = _install_open_guard([config_path] + [record["path"] for record in records], output, metadata_code_paths)
    probes = _guard_probes(output)
    before = _verified_bindings(records)
    config_before = _sha(config_path)
    from source_statistics import fit_source
    captures = []
    source_io = []
    roi_means = []
    for record in sorted(config["source_records"], key=lambda item: item["capture"]):
        head = json.loads(Path(record["head_params"]["path"]).read_text(encoding="utf8"))
        if head["input_ids"] != linkage["input_ids"] or head["member_ids"] != linkage["member_ids"]:
            raise ValueError("source head gene roles differ from frozen linkage")
        ids, x, y, mu, row, col = _read_capture(record, linkage)
        summaries, roi_count = _source_roi_summary(y, row, col)
        roi_means.append(summaries)
        captures.append((record["capture"], x, y, mu))
        source_io.append({**record, "observations": len(ids), "source_roi_count": roi_count,
                          "canonical_region_ids_sha256": hashlib.sha256(json.dumps(ids.tolist(), separators=(",", ":")).encode("utf8")).hexdigest(),
                          "complete_count_prediction_ID_join": True})
    observations = sum(len(item[1]) for item in captures)
    if observations != config["expected_source_observations"]:
        raise ValueError("source observation count differs from the fixed config expectation")
    parameters = fit_source(np.concatenate([item[1] for item in captures]), np.concatenate([item[2] for item in captures]),
                            np.concatenate([item[3] for item in captures]), np.concatenate([[item[0]] * len(item[1]) for item in captures]))
    scales = {name: max(1.0, 0.5 * roi_means[0][name] + 0.5 * roi_means[1][name]) for name in ["ALL7", "ACAN_COL2A1", "OTHER5"]}
    after = _verified_bindings(records)
    if before != after:
        raise ValueError("source file hashes changed during parameter fitting")
    if _sha(config_path) != config_before:
        raise ValueError("source stage config hash changed during parameter fitting")
    capsule = {**parameters, "source_scales": scales, "source_io_binding": source_io,
               "linkage": linkage, "parameter_source_map": {
                   "mu7": "original committed cross-capture TotalXGB means; no new point training",
                   "alpha7_and_PIT_correlation_banks": "source Y7, frozen source means and source A0 only",
                   "source_anchor_states": "capture-balanced source A0 only",
                   "H": "fixed RBF centers/bandwidth and geometry-only complete-support coordinate normalization; sqrt of frozen state weights",
                   "source_scales": "equal-capture average of complete source ROI truth-total means"}}
    output.mkdir(parents=True, exist_ok=False)
    _write_json(output / "SOURCE_PARAMS.json", capsule)
    commit = {"status": "SOURCE_ONLY_PARAMETERS_COMMITTED", "mode": SYNTHETIC_MODE if synthetic else REAL_MODE, "source_observations": observations,
              "SOURCE_PARAMS_sha256": _sha(output / "SOURCE_PARAMS.json"), "source_io_binding": source_io,
              "bindings_before": before, "bindings_after": after, "config_sha256": config_before,
              "code_binding": config["code_binding"], "spec_binding": config["spec_binding"],
              "authorization_binding": config["authorization_binding"], "linkage": linkage,
              "new_point_model_fits": 0, "target_reads": 0,
              "read_audit": {"scope": "Python open audit events in fresh CLI process; not an OS sandbox",
                             "read_paths": sorted(set(reads)), "write_paths": sorted(set(writes)),
                             "denied_paths": denied, "denied_read_probes": probes, "target_reads": 0}}
    _write_json(output / "SOURCE_COMMIT.json", commit)
    return commit


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        committed = run_source_stage(args.config, args.output)
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({"status": "SOURCE_STAGE_BLOCKED", "reason": str(error)}), flush=True)
        return 2
    print(json.dumps({"status": committed["status"], "source_observations": committed["source_observations"]}), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
