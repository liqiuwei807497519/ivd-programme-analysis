"""New independent prepared-count checker.

Independent math helpers are copied from the schema-repaired verifier. This
public run replaces its raw27/RUN_SPEC boundary; the legacy run is not invoked.
No producer numerical functions are imported.
"""
from __future__ import annotations
import argparse
import csv
import gzip
import hashlib
from itertools import combinations
import json
import math
from pathlib import Path
import time
import numpy as np
from capsule_contract import load, sha, META_SHA, CORE_SHA as INPUT_CORE_SHA

PROGRAMMES = (
    ('Resident_identity','lower',('TBXT','KRT8','KRT18','KRT19','ACAN','COL2A1','SOX9')),
    ('Fibrosis','higher',('COL1A1','COL3A1','FN1','POSTN','TGFBI')),
    ('ECM_degradation','higher',('MMP3','MMP13','ADAMTS5','CTSB','CTSS')),
    ('Stress_senescence','higher',('CDKN1A','SERPINE1','GDF15','DDIT3')),
    ('JAK_STAT_NFkB','higher',('SOCS3','SOCS1','BCL3','PIM1','OSMR','JUNB','IL6','STAT3','NFKB1','NFKBIA','TNFAIP3')),
    ('Myeloid_signature','higher',('PTPRC','CD14','CD68','C1QA','C1QB','C1QC','TYROBP','FCGR3B','CSF1R','LYZ','AIF1','ITGAM','MRC1','FCN1','CD163')),
)
SAMPLES = ['GSM'+str(i) for i in range(6917305,6917314)]
GROUPS = ['asymptomatic']*4+['back_pain']*3+['stress','no_stress']
LAYERS = ['natural_IVD']*7+['cultured_pair']*2
MEMBERS = [g for _,_,genes in PROGRAMMES for g in genes]
PROGRAMME_SHA = 'ee2ea983f83bf63c8d4424113c69e9ebce59decaf7d6717c724f3c9ef5343afd'
CORE_SHA = '515f3d6cf382327717dfcd9691e962bc487a61a1976659ea79dcdc8e4a19b368'


def _sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def _read(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def _eq(observed, expected, label):
    if expected is None or (isinstance(expected,float) and math.isnan(expected)):
        if observed not in (None,'NA','', 'nan','NaN'):raise ValueError(label+': unavailable value was replaced')
    elif isinstance(expected,bool):
        if isinstance(observed,bool):value=observed
        elif isinstance(observed,str) and observed in ('True','False'):value=observed=='True'
        else:raise ValueError(label+': invalid boolean representation')
        if value is not expected:raise ValueError(label+': boolean differs')
    elif isinstance(expected,(int,np.integer)):
        try:value=float(observed)
        except (ValueError,TypeError):raise ValueError(label+': integral value absent') from None
        if not math.isfinite(value) or value!=expected:raise ValueError(label+': integral value differs')
    elif isinstance(expected,(int,float,np.number)):
        try:value=float(observed)
        except (ValueError,TypeError):raise ValueError(label+': numeric value absent') from None
        if label.endswith(('.p_exact','.p_holm6','.empirical_specificity_p')):
            ok=value==float(expected)
        elif math.isinf(float(expected)):
            ok=value==float(expected)
        else:ok=math.isfinite(value) and math.isclose(value,float(expected),rel_tol=1e-10,abs_tol=1e-10)
        if not ok:raise ValueError(label+': independent numeric value differs')
    elif observed!=expected:raise ValueError(label+': value differs')


def _dict(observed, expected, label, strict=False):
    if strict and set(observed)!=set(expected):raise ValueError(label+': complete JSON key schema differs')
    for key,value in expected.items():
        if key not in observed:raise ValueError(label+': missing '+key)
        if isinstance(value,dict):_dict(observed[key],value,label+'.'+key,strict=strict)
        elif isinstance(value,list):
            if not isinstance(observed[key],list) or len(value)!=len(observed[key]):raise ValueError(label+': list differs')
            for i,(a,b) in enumerate(zip(observed[key],value)):
                if isinstance(b,dict):_dict(a,b,label+'.'+key+'.'+str(i),strict=strict)
                else:_eq(a,b,label+'.'+key+'.'+str(i))
        else:_eq(observed[key],value,label+'.'+key)


def _table(path, expected, keys):
    with Path(path).open(encoding='utf-8',newline='') as stream:rows=list(csv.DictReader(stream,delimiter='\t'))
    wanted={tuple(row[k] for k in keys):row for row in expected}
    actual={tuple(row[k] for k in keys):row for row in rows}
    if len(rows)!=len(actual) or set(actual)!=set(wanted):raise ValueError(str(path)+': complete row-key set differs')
    for key,row in wanted.items():_dict(actual[key],row,Path(path).name+str(key))
    return len(rows)


def _transform(counts):
    # Separate direct implementation of the frozen log2CPM expression.
    library=counts.sum(axis=1,dtype=np.float64)
    if not np.isfinite(library).all() or np.any(library<=0):raise ValueError('Structurally zero/nonfinite sample library')
    return np.log2(1+counts*1_000_000/library[:,None])


def _standardize(log_expression):
    mean=np.mean(log_expression,axis=0)
    sd=np.sqrt(np.sum((log_expression-mean)**2,axis=0)/(len(log_expression)-1))
    available=np.isfinite(sd)&(sd>0)
    result=np.full(log_expression.shape,np.nan,dtype=np.float64)
    result[:,available]=(log_expression[:,available]-mean[available])/sd[available]
    return result,available


def _welch(values, positive):
    # Scalar sample calculations rather than the vendor's vectorized helper.
    a=[float(values[i]) for i in positive]
    positive=set(positive);b=[float(v) for i,v in enumerate(values) if i not in positive]
    if len(a)<2 or len(b)<2:raise ValueError('Two independent samples per group are required')
    ma,mb=sum(a)/len(a),sum(b)/len(b)
    va=sum((v-ma)**2 for v in a)/(len(a)-1)
    vb=sum((v-mb)**2 for v in b)/(len(b)-1)
    effect=ma-mb;den=va/len(a)+vb/len(b)
    statistic=effect/math.sqrt(den) if den else (-math.inf if effect<0 else math.inf if effect>0 else 0.)
    return effect,statistic


def _exact(values,positive,direction):
    effect,observed=_welch(values,positive)
    statistics=[_welch(values,indices)[1] for indices in combinations(range(len(values)),len(positive))]
    extreme=sum(v<=observed for v in statistics) if direction=='lower' else sum(v>=observed for v in statistics)
    if not extreme:raise ValueError('Observed allocation is absent from its reference distribution')
    return {'effect':effect,'statistic':observed,'p_exact':extreme/len(statistics),'direction':direction,
            'allocations':len(statistics),'extreme_allocations':extreme}


def _programme_scores(z,genes,definitions=PROGRAMMES):
    position={g:i for i,g in enumerate(genes)};scores={};coverage=[]
    for name,_,members in definitions:
        used=[g for g in members if g in position and np.isfinite(z[:,position[g]]).all()]
        required=len(members) if name=='Resident_identity' else max(3,math.ceil(.8*len(members)))
        passed=len(used)>=required
        coverage.append({'programme':name,'declared_n':len(members),'required_n':required,
                         'available_n':len(used),'available_genes':used,
                         'missing_or_zero_sd_genes':[g for g in members if g not in used],'coverage_pass':passed})
        if passed:scores[name]=np.mean(z[:,[position[g] for g in used]],axis=1)
    return scores,coverage


def _natural(counts,genes):
    z,available=_standardize(_transform(counts));scores,coverage=_programme_scores(z,genes)
    tests={};raw={}
    for name,direction,_ in PROGRAMMES:
        if name in scores:tests[name]={'status':'ANALYZED',**_exact(scores[name],[4,5,6],direction)}
        else:tests[name]={'status':'MAPPING_COVERAGE_FAIL','effect':None,'statistic':None,'p_exact':1.,
                         'allocations':35,'direction':direction,'extreme_allocations':None}
        raw[name]=tests[name]['p_exact']
    running=0.
    for i,(name,p) in enumerate(sorted(raw.items(),key=lambda pair:(pair[1],pair[0]))):
        running=max(running,(6-i)*p);tests[name]['p_holm6']=min(1.,running)
    resident=tests['Resident_identity']
    terminal=('NO_GO_MAPPING_OR_SCHEMA' if resident['status']!='ANALYZED' else
              'SUPPORTED_BOUNDED_PRIMARY' if resident['effect']<0 and resident['p_exact']<=.05 else
              'DIRECTIONAL_NOT_SIGNIFICANT' if resident['effect']<0 else 'OPPOSITE_OR_NULL')
    return z,available,scores,coverage,tests,terminal


def _LOO(counts,genes,primary,z):
    position={g:i for i,g in enumerate(genes)};resident=PROGRAMMES[0][2]
    gene_rows=[];sample_rows=[]
    for omitted in resident:
        row={'omitted_gene':omitted,'status':'NOT_ESTIMABLE','effect':None,'statistic':None,'p_exact':None,'allocations':None}
        if primary:
            selected=[position[g] for g in resident if g!=omitted]
            row.update(status='ANALYZED',**_exact(np.mean(z[:,selected],axis=1),[4,5,6],'lower'))
        else:row['reason']='PRIMARY_RESIDENT_NOT_ESTIMABLE'
        gene_rows.append(row)
    for omitted,sample in enumerate(SAMPLES[:7]):
        remaining=[i for i in range(7) if i!=omitted];positive=[i for i,j in enumerate(remaining) if j>=4]
        row={'omitted_sample':sample,'omitted_group':GROUPS[omitted],
             'remaining_back_pain':len(positive),'remaining_asymptomatic':6-len(positive),
             'status':'NOT_ESTIMABLE','effect':None,'statistic':None,'p_exact':None,'allocations':None,'coverage':None}
        if primary:
            loo_z,_=_standardize(_transform(counts[remaining]));score,coverage=_programme_scores(loo_z,genes,PROGRAMMES[:1])
            row['coverage']=coverage[0]
            if 'Resident_identity' in score:row.update(status='ANALYZED',**_exact(score['Resident_identity'],positive,'lower'))
            else:row['reason']='LOO_RESIDENT_MISSING_OR_ZERO_SD'
        else:row['reason']='PRIMARY_RESIDENT_NOT_ESTIMABLE'
        sample_rows.append(row)
    return gene_rows,sample_rows


def _matching(stats,log,z,genes,terminal):
    summary=_read(stats/'MATCHED_NULL_SUMMARY.json');position={g:i for i,g in enumerate(genes)}
    excluded=set(MEMBERS);mean=log.mean(axis=0);variance=log.var(axis=0,ddof=1)
    eligible=[i for i,g in enumerate(genes) if g not in excluded and variance[i]>0 and np.isfinite(z[:,i]).all()]
    _dict(summary,{'seed':222182,'pool_size_per_resident_gene':200,'minimum_eligible_gene_count':207,'eligible_gene_count':len(eligible)},'matched.summary')
    expected_status='NOT_RUN_PRIMARY_NO_GO' if terminal=='NO_GO_MAPPING_OR_SCHEMA' else 'NOT_ESTIMABLE' if len(eligible)<207 else 'COMPUTED'
    _eq(summary['status'],expected_status,'matched.status')
    with gzip.open(stats/'MATCHED_NULL_SETS.tsv.gz','rt',encoding='utf-8',newline='') as stream:rows=list(csv.DictReader(stream,delimiter='\t'))
    if expected_status!='COMPUTED':
        _eq(summary['replicates'],0,'matched.replicates')
        reason='PRIMARY_RESIDENT_NOT_ESTIMABLE' if expected_status=='NOT_RUN_PRIMARY_NO_GO' else 'FROZEN_IMPLEMENTATION_ELIGIBLE_BELOW207'
        _eq(summary.get('reason'),reason,'matched.reason')
        if rows:raise ValueError('Unestimable matched null contains scored sets')
        return 0,expected_status
    _eq(summary['replicates'],10000,'matched.replicates')
    if len(rows)!=10000:raise ValueError('Matched null is not the complete10000 sets')
    def ranks(values):
        order=sorted(range(len(values)),key=lambda i:float(values[i]));rank=np.empty(len(values))
        for n,i in enumerate(order):rank[i]=n/(len(values)-1) if len(values)>1 else 0.
        return rank
    mr,vr=ranks(mean),ranks(variance);pools=[]
    for focal in PROGRAMMES[0][2]:
        j=position[focal]
        distances={genes[i]:float((mr[i]-mr[j])**2+(vr[i]-vr[j])**2) for i in eligible}
        pools.append(dict(sorted(distances.items(),key=lambda item:(item[1],item[0]))[:200]))
    observed=_exact(np.mean(z[:,[position[g] for g in PROGRAMMES[0][2]]],axis=1),[4,5,6],'lower')
    _dict(summary['observed_resident'],observed,'matched.observed')
    checked=[];set_keys=set()
    rng=np.random.Generator(np.random.PCG64(222182))
    for n,row in enumerate(rows,1):
        _eq(row['replicate'],n,'matched.replicate')
        chosen=row['genes'].split(';');distances=[float(v) for v in row['match_squared_distances'].split(';')]
        if len(chosen)!=7 or len(set(chosen))!=7 or set(chosen)&excluded or len(distances)!=7:
            raise ValueError('Matched set is not seven distinct nonprogramme genes')
        drawn=[]
        for pool in pools:
            legal=[gene for gene in pool if gene not in drawn]
            drawn.append(legal[int(rng.integers(0,len(legal)))])
        if chosen!=drawn:raise ValueError('Matched RNG draw sequence differs from fixed seed222182')
        for p,gene in enumerate(chosen):
            if gene not in pools[p]:raise ValueError('Matched gene is outside its legal frozen nearest200 pool')
            _eq(distances[p],pools[p][gene],'matched.rank_distance')
        effects,statistic=_welch(np.mean(z[:,[position[g] for g in chosen]],axis=1),[4,5,6])
        _eq(row['effect'],effects,'matched.effect');_eq(row['statistic'],statistic,'matched.statistic')
        checked.append(statistic);set_keys.add(tuple(sorted(chosen)))
    empirical=(1+sum(v<=observed['statistic'] for v in checked))/10001
    _dict(summary,{'empirical_specificity_p':empirical,'null_statistic_min':min(checked),
                   'null_statistic_median':float(np.median(checked)),'null_statistic_max':max(checked)},'matched.distribution')
    return 10000,expected_status


def _stream_qc(row, library, gene_count, artificial):
    """Check added reader metadata independently of the nine-column QC TSV.

    Older small artificial seams contain only the original QC fields. Actual
    released-count preparation, and realistic rich artificial seams, must
    provide the complete conservation/layout/precision declarations.
    """
    if artificial and 'blank_feature_rows' not in row:return
    for name in ('released_barcodes','zero_library_barcodes_removed','retained_barcodes',
                 'released_feature_rows','collapsed_symbols','blank_feature_rows',
                 'blank_count_total','raw_library_total','declared_entries','entries_read'):
        value=row.get(name)
        if isinstance(value,bool) or not isinstance(value,int) or value<0:
            raise ValueError('Stream QC nonnegative integer metadata differs: '+name)
    _eq(row['raw_library_total'],int(library),'metadata.raw_library_total')
    _eq(row['blank_count_total'],0,'metadata.blank_count_total')
    _eq(row['collapsed_symbols'],gene_count,'metadata.collapsed_symbols')
    for name in ('full_library_counts_preserved','new_raw_count_guards_not_present_in_original_reader',
                 'integer_validation_does_not_certify_UMI'):
        _eq(row.get(name),True,'metadata.'+name)
    _eq(row.get('gene_mapping'),'strip_and_upper_only; duplicate_nonempty_source_symbols_summed_in_first_occurrence_order','metadata.gene_mapping')
    if row.get('matrix_field') not in ('integer','real'):raise ValueError('Stream matrix-field metadata differs')
    _eq(row['entries_read'],row['declared_entries'],'metadata.entries_read')
    if row['raw_library_total']>2**53 or row['blank_feature_rows']>row['released_feature_rows']:
        raise ValueError('Stream raw-library precision/blank-row metadata differs')
    if row['collapsed_symbols']>row['released_feature_rows']-row['blank_feature_rows']:
        raise ValueError('Stream duplicate-collapse/blank-row metadata differs')
    shape=row.get('raw_matrix_shape');transposed=row.get('transposed_to_feature_rows')
    if not isinstance(shape,list) or len(shape)!=2 or any(isinstance(v,bool) or not isinstance(v,int) or v<0 for v in shape):
        raise ValueError('Stream raw-matrix shape metadata differs')
    if not isinstance(transposed,bool):raise ValueError('Stream transpose metadata is not boolean')
    native=[row['released_feature_rows'],row['released_barcodes']]
    if (not transposed and shape!=native) or (transposed and (shape!=native[::-1] or shape==native)):
        raise ValueError('Stream native-first orientation metadata differs')


PAYLOADS={'ALL_GENE_DATA.npz','NATURAL_ANALYSIS.json','PROGRAMME_TESTS.tsv','PROGRAMME_COVERAGE.tsv',
    'SAMPLE_PROGRAMME_SCORES.tsv','SAMPLE_PSEUDOBULK_QC.tsv','PROGRAMME_MEMBERS.tsv','CULTURED_PAIR_SCORES.tsv',
    'RESIDENT_LEAVE_ONE_GENE_OUT.tsv','RESIDENT_LEAVE_ONE_SAMPLE_OUT.tsv','MATCHED_NULL_SUMMARY.json','MATCHED_NULL_SETS.tsv.gz'}
TABLE_FIELDS={
    'PROGRAMME_TESTS.tsv':'programme status effect statistic direction p_exact p_holm6 allocations extreme_allocations',
    'PROGRAMME_COVERAGE.tsv':'programme declared_n required_n available_n available_genes missing_or_zero_sd_genes coverage_pass',
    'SAMPLE_PROGRAMME_SCORES.tsv':'sample_accession group programme score status',
    'SAMPLE_PSEUDOBULK_QC.tsv':'sample_accession layer group released_barcodes zero_library_barcodes_removed retained_barcodes released_feature_rows collapsed_symbols library_count_sum',
    'PROGRAMME_MEMBERS.tsv':'sample_accession layer group gene measured raw_count log2_cpm available_natural z_natural',
    'CULTURED_PAIR_SCORES.tsv':'programme available_n required_n stressed_score nonstressed_score difference_stressed_minus_nonstressed inferential_status',
    'RESIDENT_LEAVE_ONE_GENE_OUT.tsv':'omitted_gene status reason effect statistic p_exact allocations',
    'RESIDENT_LEAVE_ONE_SAMPLE_OUT.tsv':'omitted_sample omitted_group remaining_back_pain remaining_asymptomatic status reason effect statistic p_exact allocations',
    'MATCHED_NULL_SETS.tsv.gz':'replicate genes match_squared_distances effect statistic',
}


def run(capsule, metadata, root, output_dir):
    started=time.monotonic();root=Path(root).resolve();stats=root/'statistics'
    output=Path(output_dir).resolve()
    if output.exists():raise FileExistsError('One-shot verification output exists; choose a new path')
    if output==root or output.is_relative_to(stats):raise ValueError('Checker output cannot replace result payloads')
    arrays,meta=load(capsule,metadata);artificial=False
    commit_path=stats/'ANALYSIS_COMMIT.json';commit=_read(commit_path)
    _dict(commit,{'status':'GSE222182_ANALYSIS_COMMITTED','sample_count':9,'natural_sample_count':7,
        'cultured_sample_count':2,'programme_count':6,'member_identity_count':47,'sample_score_rows':42,
        'member_measurement_rows':423,'completion_is_last_statistics_write':True,'outer_completion_claimed':False,
        'cell_level_inference_used':False,'spatial_method_validation':False,
        'evidence_scope':'SOURCE_CONFOUNDED_SAMPLE_LEVEL_ASSOCIATION_NOT_CONFIRMATORY'},'commit')
    if {p.name for p in stats.iterdir()}!=PAYLOADS|{'ANALYSIS_COMMIT.json'}:
        raise ValueError('Complete statistics file roster differs')
    payloads=commit['artifacts']
    if len(payloads)!=12 or {p['relative_path'] for p in payloads}!=PAYLOADS:
        raise ValueError('Complete statistics manifest roster differs')
    for item in payloads:
        path=stats/item['relative_path']
        if path.stat().st_size!=item['bytes'] or _sha(path)!=item['sha256']:
            raise ValueError('Statistics payload identity differs')
    if commit['pseudobulk_meta_sha256']!=META_SHA or commit['authorization_sha256']!=meta['authorization_sha256'] or commit['source_hashes']!=meta['source_hashes']:
        raise ValueError('Historical metadata and source binding differs')
    inp=root/'PSEUDOBULK.npz'
    if inp.exists():
        if _sha(inp)!=commit['pseudobulk_sha256']:raise ValueError('Replayed count input identity differs')
        with np.load(inp,allow_pickle=False) as prepared:
            if set(prepared.files)!=set(arrays):raise ValueError('Replayed five-array schema differs')
            for name,value in arrays.items():
                if not np.array_equal(prepared[name],value):raise ValueError('Replayed full count values differ: '+name)
    elif commit['pseudobulk_sha256']!='a69a23eb72efc10e15142ceb3ee82ca431c845b07ccc75b44c4347e2acdb6abc':
        raise ValueError('Original submitted prepared-count identity differs')
    for name,fields in TABLE_FIELDS.items():
        opener=gzip.open if name.endswith('.gz') else open
        with opener(stats/name,'rt',encoding='utf8',newline='') as handle:
            if next(csv.reader(handle,delimiter='\t'))!=fields.split():
                raise ValueError('Complete result table schema differs: '+name)
    if commit['frozen_core_sha256']!=CORE_SHA:raise ValueError('Reported frozen-core identity differs')
    counts=arrays['counts'];texts={k:arrays[k] for k in ('genes','samples','groups','layers')}
    if (counts.dtype!=np.float64 or counts.ndim!=2 or counts.shape[0]!=9 or not counts.shape[1]
            or not np.isfinite(counts).all() or np.any(counts<0) or np.any(counts!=np.floor(counts))):
        raise ValueError('Nine-sample integer float64 count contract differs')
    exact_libraries=counts.astype(np.longdouble).sum(axis=1)
    if np.any(exact_libraries<=0) or np.any(exact_libraries>2**53):raise ValueError('Sample library outside exact float64 integer support')
    for name,array in texts.items():
        if array.ndim!=1 or array.dtype.kind!='U' or len(array)!=(counts.shape[1] if name=='genes' else 9):
            raise ValueError('Unicode schema differs: '+name)
    genes=texts['genes'].tolist()
    if len(set(genes))!=len(genes) or any(not g or g!=g.strip().upper() for g in genes):raise ValueError('Canonical gene identity differs')
    for name,expected in [('samples',SAMPLES),('groups',GROUPS),('layers',LAYERS)]:
        if texts[name].tolist()!=expected:raise ValueError('Natural/cultured sample roster differs')
    if [q['sample_accession'] for q in meta['qc']]!=SAMPLES:raise ValueError('QC sample keys differ')
    log_all=_transform(counts);z,available,scores,coverage,tests,terminal=_natural(counts[:7],genes)
    analysis=_read(stats/'NATURAL_ANALYSIS.json')
    gene_loo,sample_loo=_LOO(counts[:7],genes,tests['Resident_identity']['status']=='ANALYZED',z)
    _dict(analysis,{'terminal_state':terminal,'sample_count':7,'back_pain_count':3,'asymptomatic_count':4,
                    'available_gene_count':int(available.sum()),'coverage':coverage,'programme_tests':tests,
                    'resident_leave_one_gene_out':gene_loo,'resident_leave_one_sample_out':sample_loo,
                    'cell_level_inference_used':False,'exact_allocation_count':35,'frozen_programme_family_size':6,
                    'frozen_programmes_source_sha256':PROGRAMME_SHA,
                    'evidence_scope':'SOURCE_CONFOUNDED_SAMPLE_LEVEL_ASSOCIATION_NOT_CONFIRMATORY',
                    'source_stratified_sensitivity':'NOT_IDENTIFIABLE_NO_OFFICIAL_GSM_SOURCE_MAPPING',
                    'spatial_method_validation':False,
                    'secondary_family_resolution_ceiling':'minimum_raw_p_1_over_35;Holm6_cannot_reach_0.05',
                    'exchangeability_assumption':'Labels exchangeable across7donors for the reference exact test; tissue origin may violate this assumption.',
                    'tissue_source_confounding':'2of4asymptomaticcadaver;remaining2asymptomatic+3backpainsurgical;GSMsourcecrosswalkunavailable'},'natural',strict=True)
    _eq(commit['terminal_state'],terminal,'commit.terminal')
    _eq(commit['primary_test_status'],'NOT_ESTIMABLE' if terminal=='NO_GO_MAPPING_OR_SCHEMA' else 'ANALYZED','commit.primary')
    loo_status='ANALYZED' if all(r['status']=='ANALYZED' for r in sample_loo) else 'PARTIALLY_NOT_ESTIMABLE' if any(r['status']=='ANALYZED' for r in sample_loo) else 'NOT_ESTIMABLE'
    _eq(commit['resident_sample_loo_status'],loo_status,'commit.sample_loo_status')
    with np.load(stats/'ALL_GENE_DATA.npz',allow_pickle=False) as source:
        expected={'counts':counts,**texts,'log2_cpm_all':log_all,'z_natural':z,'natural_indices':np.arange(7),
                  'cultured_indices':np.array([7,8]),'available_natural':available}
        if set(source.files)!=set(expected):raise ValueError('All-gene source array keys differ')
        for name,value in expected.items():
            observed=source[name]
            if observed.shape!=value.shape:raise ValueError('All-gene shape differs: '+name)
            if observed.dtype!=value.dtype:raise ValueError('All-gene dtype/precision differs: '+name)
            if value.dtype.kind in 'USbui':ok=np.array_equal(observed,value)
            else:ok=np.allclose(observed,value,rtol=1e-10,atol=1e-10,equal_nan=True)
            if not ok:raise ValueError('Full source array value differs: '+name)
    _table(stats/'PROGRAMME_TESTS.tsv',[{'programme':p,**value} for p,value in tests.items()],['programme'])
    cov_rows=[{**row,'available_genes':';'.join(row['available_genes']),
               'missing_or_zero_sd_genes':';'.join(row['missing_or_zero_sd_genes'])} for row in coverage]
    _table(stats/'PROGRAMME_COVERAGE.tsv',cov_rows,['programme'])
    sample_rows=[{'sample_accession':sample,'group':GROUPS[i],'programme':p,'score':float(scores[p][i]) if p in scores else None,
                  'status':'ANALYZED' if p in scores else 'MAPPING_COVERAGE_FAIL'} for p,_,_ in PROGRAMMES for i,sample in enumerate(SAMPLES[:7])]
    score_checked=_table(stats/'SAMPLE_PROGRAMME_SCORES.tsv',sample_rows,['sample_accession','programme'])
    qc_rows=[]
    qc_columns=('sample_accession','layer','group','released_barcodes','zero_library_barcodes_removed',
                'retained_barcodes','released_feature_rows','collapsed_symbols','library_count_sum')
    for i,row in enumerate(meta['qc']):
        if int(row['released_barcodes'])-int(row['zero_library_barcodes_removed'])!=int(row['retained_barcodes']):
            raise ValueError('QC barcode conservation differs')
        if 'library_count_sum' in row:_eq(row['library_count_sum'],float(counts[i].sum()),'metadata.library_count_sum')
        _stream_qc(row,exact_libraries[i],counts.shape[1],artificial)
        # The published QC TSV deliberately has nine fields. Rich stream-reader
        # provenance remains in PSEUDOBULK_META.json and is checked above.
        expected={**row,'group':GROUPS[i],'layer':LAYERS[i],'library_count_sum':float(counts[i].sum())}
        qc_rows.append({key:expected[key] for key in qc_columns})
    _table(stats/'SAMPLE_PSEUDOBULK_QC.tsv',qc_rows,['sample_accession'])
    position={g:i for i,g in enumerate(genes)};members=[]
    for i,sample in enumerate(SAMPLES):
        for gene in MEMBERS:
            j=position.get(gene)
            members.append({'sample_accession':sample,'layer':LAYERS[i],'group':GROUPS[i],'gene':gene,
                            'measured':j is not None,'raw_count':float(counts[i,j]) if j is not None else None,
                            'log2_cpm':float(log_all[i,j]) if j is not None else None,
                            'available_natural':bool(available[j]) if j is not None else False,
                            'z_natural':float(z[i,j]) if i<7 and j is not None and available[j] else None})
    member_checked=_table(stats/'PROGRAMME_MEMBERS.tsv',members,['sample_accession','gene'])
    # JSON retains allocation direction/extreme counts; published LOO TSVs have
    # the smaller declared schema. Verify each independently at its own seam.
    gene_table=[{k:v for k,v in row.items() if k not in ('direction','extreme_allocations')} for row in gene_loo]
    _table(stats/'RESIDENT_LEAVE_ONE_GENE_OUT.tsv',gene_table,['omitted_gene'])
    sample_table=[{k:v for k,v in row.items() if k not in ('coverage','direction','extreme_allocations')} for row in sample_loo]
    _table(stats/'RESIDENT_LEAVE_ONE_SAMPLE_OUT.tsv',sample_table,['omitted_sample'])
    culture=[]
    for name,_,wanted in PROGRAMMES:
        used=[position[g] for g in wanted if g in position];required=len(wanted) if name=='Resident_identity' else max(3,math.ceil(.8*len(wanted)))
        passed=len(used)>=required
        stress=float(np.mean(log_all[7,used])) if passed else None;plain=float(np.mean(log_all[8,used])) if passed else None
        culture.append({'programme':name,'available_n':len(used),'required_n':required,'stressed_score':stress,'nonstressed_score':plain,
                        'difference_stressed_minus_nonstressed':stress-plain if passed else None,
                        'inferential_status':'DESCRIPTIVE_SINGLE_PAIR_NO_P_VALUE' if passed else 'DESCRIPTIVE_MAPPING_COVERAGE_FAIL'})
    _table(stats/'CULTURED_PAIR_SCORES.tsv',culture,['programme'])
    matched_count,matched_status=_matching(stats,log_all[:7],z,genes,terminal)
    _eq(commit['matched_null_status'],matched_status,'commit.matched_status')
    _eq(commit['matched_null_replicates'],matched_count,'commit.matched_replicates')

    result={'status':'PASS_PREPARED_COUNT_RESULTS','primary_terminal_state':terminal,
        'mode':'COMPLETE_SUBMITTED_PREPARED_COUNTS','analysis_commit_sha256':_sha(commit_path),
        'capsule_sha256':sha(capsule),'metadata_sha256':sha(metadata),
        'independent_verifier_sha256':_sha(Path(__file__)),'frozen_core_sha256':CORE_SHA,
        'historical_authorization_sha256':meta['authorization_sha256'],
        'statistics_payloads_checked':len(payloads),'all_gene_raw_and_transformed_arrays_checked':True,
        'gene_count':36591,'natural_donors':7,'cultured_samples':2,
        'programme_sample_scores_checked':score_checked,'member_measurements_checked':member_checked,
        'six_programme_exact_test_and_Holm_values_checked':6,'label_allocations_per_test':35,
        'gene_LOO_states_checked':7,'sample_LOO_states_checked':7,'matched_null_sets_checked':matched_count,
        'matched_status':matched_status,'all_matched_effects_statistics_and_legal_pools_checked':matched_count==10000,
        'matched_rng_draw_sequence_independently_rebuilt':True,'frozen_core_math_functions_called':0,
        'new_analysis_or_early_stopping_or_thresholds_chosen':False,'raw_27_files_reconstructed':False,
        'source_exchangeability_p_is_reference_not_causal_or_population_certification':True,
        'spatial_method_validation':False,'outer_completion_claimed':False,'elapsed_seconds':time.monotonic()-started}
    output.mkdir(parents=True,exist_ok=False)
    with (output/'PREPARED_COUNT_CHECK.json').open('x',encoding='utf8') as handle:
        json.dump(result,handle,indent=2,ensure_ascii=False,allow_nan=False);handle.write('\n')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--capsule',type=Path,required=True)
    parser.add_argument('--metadata',type=Path,required=True)
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(run(args.capsule,args.metadata,args.results,args.output),allow_nan=False))
