"""Guard the independent audit under the original source-fit resource budget."""
import argparse
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

import psutil

from real_supervisor import (REAL_BUDGET, REAL_MODE, SYNTHETIC_MODE, PINNED_PYTHON,
                            RunBlocked, binding, identity, identity_matches,
                            readj, sha, terminate_tree, tree_bytes, utc,
                            verify_binding, writej)


def audit_guard(run_root, external_exit, output):
    run, external_path, output = Path(run_root).resolve(), Path(external_exit).resolve(), Path(output).resolve()
    config_path = run / "RUN_CONFIG.json"
    config, start, complete = readj(config_path), readj(run / "RUN_START.json"), readj(run / "RUN_COMPLETE.json")
    config_hash, external = sha(config_path), readj(external_path)
    external_hash = sha(external_path)
    if config["mode"] not in (REAL_MODE, SYNTHETIC_MODE):
        raise RunBlocked("audit guard mode is not authorized")
    budget = config["resource_contract"]
    if set(budget) != set(REAL_BUDGET) or any(isinstance(number, bool) or not isinstance(number, (int, float)) or number <= 0 for number in budget.values()):
        raise RunBlocked("invalid original audit resource contract")
    if config["mode"] == REAL_MODE and budget != REAL_BUDGET:
        raise RunBlocked("real audit must retain CPU2/RSS4GiB/wall4h/output2GiB")
    if config["mode"] == SYNTHETIC_MODE and (budget["CPU"] != 2 or any(budget[name] > REAL_BUDGET[name] for name in budget)):
        raise RunBlocked("synthetic audit cannot increase the original real budget")
    if (start["status"] != "BOUNDED_RUN_STARTED" or start["config_sha256"] != config_hash or start["resource_contract"] != budget
            or complete["status"] != "BOUNDED_RUN_COMPLETE" or complete["config_sha256"] != config_hash or complete["external_exits_all_zero"] is not True):
        raise RunBlocked("audit requires matching original START/config/COMPLETE")
    if (type(external["external_exit_code"]) is not int or external["external_exit_code"] != 0
            or external["status"] != "ACTUAL_EXTERNAL_SUPERVISOR_EXIT"):
        raise RunBlocked("actual zero external supervisor exit is required before audit")
    provenance = external["process"]
    source_program = Path(__file__).with_name("real_supervisor.py").resolve()
    if (Path(provenance["run_root"]).resolve() != run or provenance["config_sha256"] != config_hash
            or sha(provenance["config_path"]) != config_hash or provenance["supervisor_sha256"] != sha(source_program)):
        raise RunBlocked("external exit receipt belongs to a different run/config/supervisor")
    python = Path(config["python_executable"]).resolve()
    if not python.is_file() or Path(provenance["executable"]).resolve() != python:
        raise RunBlocked("audit must use the same pinned Python launcher")
    code = {Path(item["path"]).resolve(): item for item in config["code_binding"]}
    for item in code.values():
        verify_binding(item)
    if config["mode"] == REAL_MODE:
        if python != PINNED_PYTHON or "synthetic_audit_program" in config:
            raise RunBlocked("real audit cannot substitute the approved launcher or program")
        program = Path(__file__).with_name("postrun_audit.py").resolve()
        if not {program, Path(__file__).resolve(), source_program}.issubset(code):
            raise RunBlocked("real audit guard/program/supervisor must be frozen code bindings")
        owner = readj(run / "OWNER_LOCK.json")
        if owner["python_executable"] != str(python) or owner["python_sha256"] != sha(python):
            raise RunBlocked("original pinned Python launcher changed before audit")
    else:
        descriptor = config.get("synthetic_audit_program")
        program = Path(descriptor["path"]).resolve() if descriptor is not None else Path(__file__).with_name("postrun_audit.py").resolve()
        if descriptor is not None:
            verify_binding(descriptor)
            if not program.name.startswith("SYN_") or program not in code:
                raise RunBlocked("synthetic audit boundary program must be SYN_ and hash-bound")
    control = run / "audit_control"
    receipt_path = run / "POSTRUN_CHILD_EXIT.json"
    if control.exists() or receipt_path.exists() or output.exists() or run not in output.parents:
        raise RunBlocked("audit control/output must be fresh; no restart or overwritten audit")
    original_start = start["monotonic_start"]
    if isinstance(original_start, bool) or not isinstance(original_start, (int, float)) or not math.isfinite(original_start) or original_start > time.monotonic():
        raise RunBlocked("invalid cross-process original monotonic clock")
    control.mkdir(exist_ok=False)
    process = psutil.Process(os.getpid())
    affinity = process.cpu_affinity()[:2]
    if not affinity:
        raise RunBlocked("audit CPU affinity unavailable")
    process.cpu_affinity(affinity)
    writej(control / "OWNER_LOCK.json", {**identity(process), "program": str(Path(__file__).resolve()),
           "config_sha256": config_hash, "original_monotonic_start": original_start, "created_utc": utc(), "no_restart": True})
    command = [str(python), "-B", str(program), "--run-root", str(run), "--external-exit", str(external_path), "--output", str(output)]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
        env[name] = "2"
    stdout, stderr = control / "child.stdout.log", control / "child.stderr.log"
    peak_rss, maximum_output, observed = 0, 0, {}

    def sample():
        nonlocal peak_rss, maximum_output
        rss = 0
        family = [process] + process.children(recursive=True)
        for member in family:
            try:
                rss += member.memory_info().rss
                if member.cpu_affinity() != affinity:
                    member.cpu_affinity(affinity)
                if member.pid != process.pid:
                    record = identity(member)
                    observed[(record["pid"], record["creation_time"])] = record
            except psutil.NoSuchProcess:
                pass
        size = tree_bytes(run)
        peak_rss, maximum_output = max(peak_rss, rss), max(maximum_output, size)
        if time.monotonic() - original_start >= budget["wall_seconds"]:
            return "original wall_seconds exceeded"
        if rss > budget["RSS_bytes"]:
            return "audit process plus descendants RSS exceeded"
        if size > budget["output_bytes"]:
            return "original run output bytes exceeded"
        return None

    violation, child_identity, exit_code = sample(), None, None
    with stdout.open("xb") as out, stderr.open("xb") as err:
        if violation is None:
            child = subprocess.Popen(command, stdout=out, stderr=err, env=env, cwd=str(Path(__file__).parent))
            child_process = psutil.Process(child.pid)
            child_identity = identity(child_process)
            try:
                child_process.cpu_affinity(affinity)
            except psutil.NoSuchProcess:
                pass
            writej(control / "CHILD_START.json", {"status": "AUDIT_CHILD_RUNNING", "command": command, "process_identity": child_identity,
                   "config_sha256": config_hash, "original_monotonic_start": original_start,
                   "remaining_wall_seconds": max(0, budget["wall_seconds"] - (time.monotonic() - original_start)), "started_utc": utc()})
            while child.poll() is None:
                violation = sample()
                if violation:
                    terminate_tree(child_process, child_identity)
                    break
                time.sleep(0.1)
            exit_code = child.wait()
    violation = violation or sample()
    success = violation is None and exit_code == 0 and output.is_file()
    if success:
        result = readj(output)
        success = (result["status"] == "INDEPENDENT_FULL_ROW_AUDIT_PASS" and result["config_sha256"] == config_hash
                   and Path(result["run_root"]).resolve() == run and result["mode"] == config["mode"]
                   and result["external_exit_receipt_sha256"] == external_hash
                   and result["elapsed_through_audit_seconds"] <= budget["wall_seconds"])
        if sha(config_path) != config_hash or sha(external_path) != external_hash:
            success = False
        for item in code.values():
            verify_binding(item)
        violation = sample()
        success = success and violation is None
    writej(receipt_path, {"status": "POSTRUN_AUDIT_GUARD_PASS" if success else "STOPFAILED", "external_exit_code": exit_code,
           "command": command, "process_identity": child_identity, "resource_contract": budget,
           "resource_violation": violation, "peak_audit_process_tree_RSS_bytes": peak_rss,
           "run_output_bytes": maximum_output, "CPU_affinity": affinity,
           "observed_descendant_identities": list(observed.values()),
           "config_sha256": config_hash, "external_supervisor_receipt": binding(external_path),
           "elapsed_since_source_fit_seconds": time.monotonic() - original_start,
           "stdout": binding(stdout), "stderr": binding(stderr), "output_exists": output.is_file(), "finished_utc": utc()})
    return 0 if success else (2 if violation else (exit_code or 2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--external-exit", required=True)
    parser.add_argument("--output", required=True)
    arguments = parser.parse_args()
    try:
        result = audit_guard(arguments.run_root, arguments.external_exit, arguments.output)
    except (RunBlocked, ValueError, KeyError, OSError, psutil.Error) as error:
        print(json.dumps({"status": "STOPFAILED", "reason": str(error)}), flush=True)
        return 2
    print(json.dumps({"status": "POSTRUN_AUDIT_GUARD_PASS" if result == 0 else "STOPFAILED", "exit_code": result}), flush=True)
    return result


if __name__ == "__main__":
    sys.exit(main())
