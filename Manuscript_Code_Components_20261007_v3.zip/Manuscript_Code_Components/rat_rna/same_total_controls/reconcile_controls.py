"""Explicit no-fit member allocation under a frozen common total mean."""
import numpy as np


def reconcile_means(member_means, total_mean, source_proportions):
    means = np.asarray(member_means, dtype=float)
    totals = np.asarray(total_mean, dtype=float)
    proportions = np.asarray(source_proportions, dtype=float)
    if (means.ndim != 2 or len(means) == 0 or totals.shape != (len(means),)
            or proportions.shape != (means.shape[1],) or not np.isfinite(means).all()
            or not np.isfinite(totals).all() or not np.isfinite(proportions).all()
            or np.any(means < 0) or np.any(totals < 0) or np.any(proportions < 0)
            or not np.isclose(proportions.sum(), 1.0, rtol=0, atol=1e-12)):
        raise ValueError("complete nonnegative finite member/total means and saved probability vector required")
    sums = means.sum(axis=1)
    if not np.isfinite(sums).all():
        raise ValueError("member mean denominator is nonfinite; no cap or rescue")
    probability = np.divide(means, sums[:, None], out=np.zeros_like(means), where=sums[:, None] > 0)
    fallback = (sums == 0) & (totals > 0)
    probability[fallback] = proportions
    output = totals[:, None] * probability
    if not np.isfinite(output).all() or not np.allclose(output.sum(axis=1), totals, rtol=1e-12, atol=1e-12):
        raise ValueError("reconciled control violates frozen total identity")
    return output, {"zero_denominator_fallback_rows": int(fallback.sum()), "zero_total_rows": int((totals == 0).sum()),
                    "observations": len(means), "member_count": means.shape[1], "epsilon_or_pseudocount": False,
                    "fallback_definition": "exact saved training fixed_composition only for member_sum0 and positive frozen total"}
