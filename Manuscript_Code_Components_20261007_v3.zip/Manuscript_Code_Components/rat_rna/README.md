# Within-rat RNA count mean and allocation reference

This material exposes the complete seven-member comparison at a fixed 126-anchor, native-observation interface. Four parent holdouts retain both sections, every source observation and every nonempty per-section nominal 500-µm ROI. The source tables include all five predefined methods and two separately labelled, no-fit shared-total controls. Fold-specific coefficients, scalers, source-only reference scales and complete inner-selection logs accompany the original owned code.

The primary endpoint is the seven-member training-scaled Poisson mean deviance on held-out ROI totals, averaged by ROI, section and parent. Infinity is retained as an endpoint, with its status visible in the tables. The same-total controls retain the frozen programme total; their explicit all-zero-vector fallback uses the saved training composition. The controls are posthoc and do not retune the original member-Poisson heads for the normalized-allocation endpoint.

## What is provided

- `software/`: seven original RNA analysis modules and their original synthetic seam tests. Copied production modules retain their completed-run byte hashes.
- `same_total_controls/`: three original no-fit control scripts, literal seam tests, plans and assessment.
- `reference/folds/`: all four fitted parameter and selection capsules; no raw source counts.
- `proofs/`: synthetic development logs, actual stage-exit records and independent audit results. Workspace prefixes in execution copies are replaced by a provenance placeholder; original-record hashes are retained.
- `reference/INPUT_REQUIREMENTS.json`: portable relative source-file requirements, eight section identities, all 133 ordered roles and original source fingerprints.
- `../../Source_Data/RNA_Mean/`: complete ROI-level derived truth totals and point means, hierarchical summaries, all seven members, both native/ROI summary scopes and source-only scales.

## Source acquisition prerequisites

The source is Liang et al., *Clinical and Translational Medicine* (2025), DOI [10.1002/ctm2.70370](https://onlinelibrary.wiley.com/doi/10.1002/ctm2.70370). Its methods describe fresh-frozen rat IVD sections profiled with Visium V1. The article states that raw sequencing data are available from the authors upon reasonable request. This package does not contact the authors, grant access to their data, or assert a new licence over the original counts or images.

A user seeking source-training reproduction must separately possess authorized original CTM data or the exact previously exported section files. For each of the eight folders named in `reference/INPUT_REQUIREMENTS.json`, the required inputs are `counts.csv`, `spots.csv`, `FEATURE_MAP.csv` and `EXPORT.json`. Their fingerprints must match the completed reference. Raw RDS files, individual native count tables, prepared count NPZ files and histology images are not redistributed here. The publication's supplementary DOCX contained extractable figure captions rather than the processing-method text needed to close the rat genome/annotation/alignment versions; that provenance gap remains explicit.

## Portable configuration boundary

Run `configuration_adapter.py --source-inputs /authorized/section_exports --output /new/CONFIG_LOCAL.json` with Python. The adapter resolves package-relative requirements against the supplied directory, verifies byte hashes and writes an absolute local configuration without numerical source parsing. It does not download, extract, normalize, fit or predict.

The scientific stage modules expose `rna_inputs.prepare`, `rna_mean.fit_bundle/predict_bundle`, `rna_fold.run`, `rna_score.score_committed` and the independent audit CLI. Their source and parameter serialization are provided. `portable_execute.py --config /new/CONFIG_LOCAL.json --run-root /new/FRESH_RUN` is a separate orchestration adapter using the current declared Python environment, original scientific stage CLIs, fixed resource ceiling, actual process receipts and all-four-forecast barrier. It does not change the preserved scientific modules. It has not been run on raw source data from this release package.

The preserved `rna_supervisor.py` and `same_total_controls/run_controls.py` are the original deployment harnesses, including the original fixed venv/workspace safeguards and read-only resource-helper dependency. They remain historical executable evidence; use the explicit portable adapter instead of treating their original machine paths as portable commands. Localizing a configuration does not itself fabricate process receipts or perform training.

The exact completed dependency versions were NumPy 2.5.2, SciPy 1.18.1 and psutil 7.2.2. Dependency binaries and a global environment snapshot are not included. No raw-source training reproduction has been performed from this release package. The supplied completed-run proofs document the original authorized local execution, and direct-array synthetic tests remain available as software examples.

## Evidence scope and reuse

This is exposed within-rat operator development. Parent/time/batch and section relationships remain as declared, and independent animal identities are unresolved. The named rat features do not establish strict one-to-one rat–mouse orthology. All seven members remain in the endpoint; no gene dropping, zero filling, source-scale refit or cross-species target prediction is implied by the release.

The authors' approved MIT licence applies to their original new analysis software and documentation. Preserve publication attribution and any source-specific access conditions for underlying data. ROI source tables and fitted parameter capsules are derived analysis materials; this licence does not transfer ownership of third-party source measurements. No Genome Biology readiness or independent biological validation is asserted by an execution receipt.
