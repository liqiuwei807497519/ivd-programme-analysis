"""MC verification in the real CLI path, on artificial three-library data."""

import csv
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

from build_genuine_synthetic_fixture import HERE, PINNED_PYTHON
from test_genuine_synthetic_integration import exercise_pipeline


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding="utf8")


class IndependentMCIntegrationTests(unittest.TestCase):
    def test_actual_pipeline_rejects_rehashed_row_mcse_and_deletion_packet_corruption(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_v2_MC_genuine_synthetic_") as temporary:
            root = Path(temporary)
            receipt = exercise_pipeline(root)
            run = Path(receipt["run_root"])
            audit = json.loads((run / "INDEPENDENT_AUDIT_PASS.json").read_text(encoding="utf8"))
            self.assertTrue(audit["all_mc_packet_and_row_values_reconstructed"])
            self.assertGreater(audit["independent_mc_numerical_checks"], 0)
            rows_path = run / "targets/SYN_A/score/ROWS.tsv"
            commit_path = rows_path.with_name("SCORE_COMMIT.json")
            original_rows = (root / "ORIGINAL_PASSING_SYN_A_ROWS.tsv").read_bytes()
            original_commit = (root / "ORIGINAL_PASSING_SYN_A_SCORE_COMMIT.json").read_bytes()
            rows_path.write_bytes(original_rows)
            commit_path.write_bytes(original_commit)
            with rows_path.open(encoding="utf8", newline="") as stream:
                reader = csv.DictReader(stream, delimiter="\t")
                columns, rows = reader.fieldnames, list(reader)
            altered = next(row for row in rows if row["law"] == "INDEPENDENT_GENE_FIELDS"
                           and row["diagnostic"] == "NONE" and row["functional"] == "ALL7")
            altered["mcse_fair_rps"] = str(float(altered["mcse_fair_rps"]) + 1.0)
            with rows_path.open("w", encoding="utf8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=columns, delimiter="\t")
                writer.writeheader()
                writer.writerows(rows)
            commit = json.loads(original_commit)
            commit["artifacts"]["ROWS.tsv"]["sha256"] = _sha(rows_path)
            _write_json(commit_path, commit)

            def reject(label):
                output = root / ("SYN_REJECT_" + label + ".json")
                process = subprocess.run([str(PINNED_PYTHON), "-B", str(HERE / "postrun_audit.py"),
                    "--run-root", str(run), "--external-exit", str(root / "ACTUAL_EXTERNAL_SUPERVISOR_EXIT.json"),
                    "--output", str(output)], capture_output=True, text=True, encoding="utf8", timeout=90)
                self.assertEqual(process.returncode, 2, process.stdout + process.stderr)
                self.assertIn("Independent MC numerical mismatch", process.stdout)
                self.assertFalse(output.exists())

            reject("ROW_MCSE")
            rows_path.write_bytes(original_rows)
            commit_path.write_bytes(original_commit)
            scores_path = rows_path.with_name("SCORES.json")
            scores = json.loads(scores_path.read_text(encoding="utf8"))
            scores["mc_precision"]["INDEPENDENT_GENE_FIELDS"]["shared_world_delete_group"]["functionals"]["ALL7"]["delete_group_region_metric_arrays"]["fair_rps"][0][0] += 1.0
            _write_json(scores_path, scores)
            commit = json.loads(original_commit)
            commit["artifacts"]["SCORES.json"]["sha256"] = _sha(scores_path)
            _write_json(commit_path, commit)
            reject("DELETION_PACKET")


if __name__ == "__main__":
    unittest.main(verbosity=2)
