"""Standard-library external exit/resource receipt; not a scientific analysis."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def working_set(pid):
    if os.name != "nt":
        return 0
    from ctypes import wintypes
    class Counters(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
            (name, ctypes.c_size_t) for name in (
                "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
                "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage", "QuotaNonPagedPoolUsage",
                "PagefileUsage", "PeakPagefileUsage")]
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    process = kernel.OpenProcess(0x410, False, pid)
    if not process:
        return 0
    try:
        value = Counters(); value.cb = ctypes.sizeof(value)
        query = ctypes.WinDLL("psapi").GetProcessMemoryInfo
        query.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
        query(process, ctypes.byref(value), value.cb)
        return int(value.PeakWorkingSetSize)
    finally:
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle(process)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--cwd", type=Path, required=True)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    environment = os.environ.copy()
    environment["PYTHONUTF8"] = "1"
    environment["PYTHONIOENCODING"] = "utf8"
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        environment[name] = "2"
    started = time.monotonic()
    process = subprocess.Popen(command, cwd=args.cwd, env=environment,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                               encoding="utf8", errors="replace")
    affinity_enforced = False
    if os.name == "nt":
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        handle = kernel.OpenProcess(0x200 | 0x400, False, process.pid)
        if handle:
            allowed, system = ctypes.c_size_t(), ctypes.c_size_t()
            kernel.GetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
            kernel.SetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
            if kernel.GetProcessAffinityMask(handle, ctypes.byref(allowed), ctypes.byref(system)):
                bits = [1 << i for i in range(allowed.value.bit_length()) if allowed.value & (1 << i)][:2]
                affinity_enforced = bool(kernel.SetProcessAffinityMask(handle, sum(bits)))
            kernel.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel.CloseHandle(handle)
        if not affinity_enforced and process.poll() is None:
            process.kill()
            raise RuntimeError("Cannot enforce two-CPU subprocess affinity")
    peak = 0; exceeded = None; largest_output = 0
    while process.poll() is None:
        peak = max(peak, working_set(process.pid))
        if args.output_root and args.output_root.exists():
            largest_output = max(largest_output, sum(p.stat().st_size for p in args.output_root.rglob("*") if p.is_file()))
        if peak > 4 * 1024**3: exceeded = "RSS_4_GiB"
        if largest_output > 1024**3: exceeded = "OUTPUT_1_GiB"
        if time.monotonic() - started > 7200: exceeded = "WALL_7200_SECONDS"
        if exceeded:
            process.kill()
            break
        time.sleep(.1)
    stdout, stderr = process.communicate()
    receipt = {"command": command, "cwd": str(args.cwd), "exit_code": process.returncode,
               "elapsed_seconds": time.monotonic() - started, "observed_peak_process_RSS_bytes": peak,
               "observed_output_bytes": largest_output, "resource_limit_exceeded": exceeded,
               "CPU_thread_environment": 2, "RSS_limit_bytes": 4 * 1024**3,
               "CPU_affinity_enforced": affinity_enforced,
               "wall_limit_seconds": 7200, "output_limit_bytes": 1024**3,
               "stdout": stdout, "stderr": stderr}
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    with args.receipt.open("x", encoding="utf8") as handle:
        json.dump(receipt, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
    print(json.dumps({k: v for k, v in receipt.items() if k not in ("stdout", "stderr", "command", "cwd")}))
    print(stdout); print(stderr, file=sys.stderr)
    return process.returncode


if __name__ == "__main__":
    raise SystemExit(main())
