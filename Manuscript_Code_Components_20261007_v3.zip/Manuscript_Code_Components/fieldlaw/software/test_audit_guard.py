"""Public audit guard CLI: artificial exit/deadline child processes only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

import psutil

HERE = Path(__file__).resolve().parent
PINNED_PYTHON = HERE.parents[1] / "IVD_Nonlinear_Baseline_20261002/preflight_v2/environment/venv/Scripts/python.exe"
FAKE_CHILD = r'''
import argparse,json,pathlib,subprocess,sys,time,psutil
p=argparse.ArgumentParser(); p.add_argument('--run-root'); p.add_argument('--external-exit'); p.add_argument('--output'); a=p.parse_args()
run=pathlib.Path(a.run_root); c=json.loads((run/'RUN_CONFIG.json').read_text(encoding='utf8'))
if c['synthetic_audit_action']=='exit7': sys.exit(7)
child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(3)'])
process=psutil.Process(child.pid)
(run/'SYN_AUDIT_DESCENDANT.json').write_text(json.dumps({'pid':process.pid,'creation_time':process.create_time()}),encoding='utf8')
time.sleep(3)
'''


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def writej(path, value):
    Path(path).write_text(json.dumps(value), encoding="utf8")


def binding(path):
    return {"path": str(Path(path).resolve()), "sha256": sha(path)}


def fixture(root, action, wall):
    root = Path(root)
    run = root / "RUN"
    run.mkdir()
    script = root / "SYN_FAKE_AUDIT.py"
    script.write_text(FAKE_CHILD, encoding="utf8")
    config = {"mode": "SYNTHETIC_SUPERVISOR_TEST", "python_executable": str(PINNED_PYTHON),
              "synthetic_audit_program": binding(script), "synthetic_audit_action": action,
              "resource_contract": {"CPU": 2, "RSS_bytes": 4294967296, "wall_seconds": wall, "output_bytes": 2147483648},
              "code_binding": [binding(HERE / "real_supervisor.py"), binding(script)]}
    path = run / "RUN_CONFIG.json"
    writej(path, config)
    started = time.monotonic()
    writej(run / "RUN_START.json", {"status": "BOUNDED_RUN_STARTED", "config_sha256": sha(path), "monotonic_start": started,
                                   "resource_contract": config["resource_contract"]})
    writej(run / "RUN_COMPLETE.json", {"status": "BOUNDED_RUN_COMPLETE", "config_sha256": sha(path), "external_exits_all_zero": True})
    receipt = root / "EXTERNAL_EXIT.json"
    writej(receipt, {"status": "ACTUAL_EXTERNAL_SUPERVISOR_EXIT", "external_exit_code": 0,
                     "process": {"run_root": str(run.resolve()), "config_path": str(path.resolve()), "config_sha256": sha(path),
                                 "supervisor_sha256": sha(HERE / "real_supervisor.py"), "executable": str(PINNED_PYTHON)}})
    return run, receipt, run / "INDEPENDENT_FULL_ROW_AUDIT.json"


def cli(run, receipt, output):
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    return subprocess.run([str(PINNED_PYTHON), "-B", str(HERE / "audit_guard.py"), "--run-root", str(run),
                           "--external-exit", str(receipt), "--output", str(output)],
                          capture_output=True, text=True, encoding="utf8", env=env, timeout=15)


class AuditGuardTests(unittest.TestCase):
    def test_original_source_deadline_kills_the_actual_audit_child_and_its_descendant(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_audit_deadline_") as temporary:
            run, external, output = fixture(temporary, "sleep", 1)
            process = cli(run, external, output)
            self.assertEqual(process.returncode, 2, process.stdout + process.stderr)
            receipt = json.loads((run / "POSTRUN_CHILD_EXIT.json").read_text(encoding="utf8"))
            self.assertNotEqual(receipt["external_exit_code"], 0)
            self.assertIn("wall_seconds", receipt["resource_violation"])
            self.assertEqual(receipt["status"], "STOPFAILED")
            self.assertLess(receipt["elapsed_since_source_fit_seconds"], 3)
            record = json.loads((run / "SYN_AUDIT_DESCENDANT.json").read_text(encoding="utf8"))
            try:
                child = psutil.Process(record["pid"])
                alive = child.create_time() == record["creation_time"] and child.is_running() and child.status() != psutil.STATUS_ZOMBIE
            except psutil.NoSuchProcess:
                alive = False
            self.assertFalse(alive)
            self.assertFalse(output.exists())

    def test_actual_nonzero_audit_exit_is_retained_and_never_reported_as_pass(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_audit_exit_") as temporary:
            run, external, output = fixture(temporary, "exit7", 30)
            process = cli(run, external, output)
            self.assertEqual(process.returncode, 7, process.stdout + process.stderr)
            receipt = json.loads((run / "POSTRUN_CHILD_EXIT.json").read_text(encoding="utf8"))
            self.assertEqual(receipt["external_exit_code"], 7)
            self.assertEqual(receipt["status"], "STOPFAILED")
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
