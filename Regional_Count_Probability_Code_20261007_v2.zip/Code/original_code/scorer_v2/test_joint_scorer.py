import csv
import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
from joint_scorer import score_committed_joint_forecasts

LAWS=["FULLY_FACTORIZED_ATOMS","TRUE_ALL_ATOM_GLOBAL_FACTOR_RHO025","RBF_INDEPENDENT_GENE_FIELDS","RBF_FIXED_GENE_RHO025","RBF_POOLED_SOURCE_PIT_CORR"]
FUNCTIONS=["TBXT","KRT8","KRT18","KRT19","ACAN","COL2A1","SOX9","ALL7","ACAN_COL2A1","OTHER5"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def commit_sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":")).encode()).hexdigest()


class JointScorer(unittest.TestCase):
    def fixture(self):
        temporary=tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root=Path(temporary.name)
        cfg={"mode":"SYNTHETIC_JOINT_SCORE_V1","M":2,"sections":[{"capture":"SYN_S1","parent":"E1"},{"capture":"SYN_S2","parent":"E3"}],
             "source_scales":{name:1. for name in FUNCTIONS},"mc_precision":False}
        forecast={"status":"GLOBAL_FORECAST_COMMITTED","complete":True,"external_exit_code":0,"M":2,"sections":{}}
        truth={"status":"GLOBAL_TRUTH_COMMITTED","complete":True,"external_exit_code":0,"sections":{}}
        for section in cfg["sections"]:
            capture=section["capture"]
            laws={}
            for law in LAWS:
                path=root/(capture+"_"+law+".npz")
                values=np.array([[[0]*7],[[2]*7]],dtype=np.int64)
                np.savez_compressed(path,gene_region_totals=values,gene_region_means=np.ones((1,7)),roi_keys=np.array([[0,0]],dtype=np.int64))
                laws[law]={"path":str(path),"sha256":sha(path)}
            forecast["sections"][capture]={"parent":section["parent"],"laws":laws}
            tpath=root/(capture+"_truth.npz")
            np.savez_compressed(tpath,gene_region_truth=np.ones((1,7),dtype=np.int64),roi_keys=np.array([[0,0]],dtype=np.int64))
            truth["sections"][capture]={"parent":section["parent"],"path":str(tpath),"sha256":sha(tpath)}
        truth["forecast_commit_sha256"]=commit_sha(forecast)
        return root,cfg,forecast,truth

    def test_sixteen_shared_delete_groups_have_zero_paired_MCSE_for_identical_laws(self):
        root,cfg,forecast,truth=self.fixture()
        cfg.update(M=32,mc_precision=True)
        forecast["M"]=32
        for section in forecast["sections"].values():
            for record in section["laws"].values():
                path=Path(record["path"])
                np.savez_compressed(path,gene_region_totals=np.tile(np.array([[[0]*7],[[2]*7]],dtype=np.int64),(16,1,1)),
                                    gene_region_means=np.ones((1,7)),roi_keys=np.array([[0,0]],dtype=np.int64))
                record["sha256"]=sha(path)
        truth["forecast_commit_sha256"]=commit_sha(forecast)
        score_committed_joint_forecasts(cfg,forecast,truth,root/"scores")
        summary=json.loads((root/"scores"/"SCORES.json").read_text(encoding="utf-8"))
        precision=summary["MC_precision"]
        self.assertTrue(precision["enabled"])
        self.assertEqual(precision["delete_groups"],16)
        pair=precision["paired_primary"][LAWS[1]]
        self.assertEqual(pair["improvement_scaled_fair_RPS"],0.)
        self.assertEqual(pair["paired_MCSE"],0.)
        self.assertEqual(len(pair["delete_group_improvement"]),16)
        packet=precision["laws"][LAWS[0]]["TBXT"]["scaled_fair_rps"]
        self.assertEqual(packet["MCSE"],0.)
        self.assertEqual(len(packet["delete_group_macro"]),16)
        self.assertAlmostEqual(packet["half_world_macro"][0],7./15.)

    def test_partial_global_forecast_or_truth_refuses_before_arrays(self):
        for missing in ("forecast","truth"):
            root,cfg,forecast,truth=self.fixture()
            for section in forecast["sections"].values():
                for record in section["laws"].values():
                    record["path"]=str(root/"NEVER_OPEN_FORECAST.npz")
            for record in truth["sections"].values():
                record["path"]=str(root/"NEVER_OPEN_TRUTH.npz")
            if missing=="forecast":
                forecast["sections"]["SYN_S1"]["laws"].pop(LAWS[-1])
            else:
                truth["sections"].pop("SYN_S2")
            truth["forecast_commit_sha256"]=commit_sha(forecast)
            with self.subTest(missing=missing),self.assertRaisesRegex(ValueError,"GLOBAL_COMMIT_INCOMPLETE"):
                score_committed_joint_forecasts(cfg,forecast,truth,root/"scores")
            self.assertFalse((root/"scores").exists())

    def test_literal_fair_zero_empirical_half_and_factorial_Brier(self):
        root,cfg,forecast,truth=self.fixture()
        result=score_committed_joint_forecasts(cfg,forecast,truth,root/"scores")
        with (root/"scores"/"COUNT_ROWS.tsv").open(encoding="utf-8") as handle:
            rows=list(csv.DictReader(handle,delimiter="\t"))
        with (root/"scores"/"EVENT_ROWS.tsv").open(encoding="utf-8") as handle:
            events=list(csv.DictReader(handle,delimiter="\t"))
        row=next(r for r in rows if r["section_capture"]=="SYN_S1" and r["law"]==LAWS[0] and r["functional"]=="TBXT")
        self.assertEqual(float(row["fair_rps"]),0.)
        self.assertEqual(float(row["empirical_rps"]),.5)
        self.assertEqual(float(events[0]["fair_brier"]),0.)
        self.assertEqual(float(events[0]["empirical_brier"]),.25)
        self.assertEqual(len(rows),100)
        self.assertEqual(len(events),10)
        self.assertEqual(result["count_score_rows"],100)


if __name__=="__main__":
    unittest.main()
