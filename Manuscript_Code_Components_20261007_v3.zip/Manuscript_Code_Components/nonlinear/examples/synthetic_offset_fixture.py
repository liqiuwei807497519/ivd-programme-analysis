"""Artificial constant-rate count fixture; evaluation labels are separate.

The input exposure is m*100000 and training member j has m*(j+1) counts.
Hence the training-only rate has the independent literal (j+1)/100000.
No real capture counts or model have been read; these are engineering inputs.
"""
from pathlib import Path
import argparse
import json
import numpy as np

EXPECTED_PRIORS = [0.00001, 0.00002, 0.00003, 0.00004, 0.00005, 0.00006, 0.00007]
EXPECTED_DIRECT_ZERO_TREE = [
    [1,2,3,4,5,6,7], [2,4,6,8,10,12,14], [3,6,9,12,15,18,21],
    [4,8,12,16,20,24,28], [5,10,15,20,25,30,35], [6,12,18,24,30,36,42],
]
FROZEN_TOTAL = [25, 28, 31, 34, 37, 40]
MEMBER_SCALES = [12.5,25,37.5,50,62.5,75,87.5]


def fixture():
    train = np.zeros((24,126), dtype=np.int64)
    train[:,0] = np.arange(1,25) * 100000 - 1
    y = np.arange(1,25)[:,None] * np.arange(1,8)[None,:]
    evaluation = np.zeros((6,126), dtype=np.int64)
    evaluation[:,0] = np.arange(1,7) * 100000 - 1
    return {
        "train_x126": train, "train_y7": y, "eval_x126": evaluation,
        "frozen_total": np.array(FROZEN_TOTAL, dtype=float),
        "train_ids": np.array([f"SYN_TRAIN_{i}" for i in range(24)]),
        "eval_ids": np.array([f"SYN_EVAL_{i}" for i in range(6)]),
        "input_ids": np.array([f"SYN_INPUT_{i}" for i in range(126)]),
        "member_ids": np.array([f"SYN_MEMBER_{i}" for i in range(7)]),
    }


def generate(out):
    out = Path(out).resolve()
    out.mkdir(parents=True, exist_ok=False)
    data = fixture()
    np.savez_compressed(out / "train_input.npz", X=data["train_x126"], Y=data["train_y7"],
                        region_ids=data["train_ids"], input_ids=data["input_ids"], member_ids=data["member_ids"])
    np.savez_compressed(out / "eval_input.npz", X=data["eval_x126"], region_ids=data["eval_ids"],
                        input_ids=data["input_ids"], member_ids=data["member_ids"])
    np.savez_compressed(out / "frozen_total.npz", total=data["frozen_total"], region_ids=data["eval_ids"])
    # Only the independent synthetic scorer is permitted this separate file.
    np.savez_compressed(out / "evaluation_truth_scorer_only.npz",
                        Y=np.array(EXPECTED_DIRECT_ZERO_TREE, dtype=np.int64),
                        region_ids=data["eval_ids"], member_ids=data["member_ids"])
    expected = {"mode":"synthetic", "measured_data":False, "rate_priors":EXPECTED_PRIORS,
                "zero_tree_count_means":EXPECTED_DIRECT_ZERO_TREE, "frozen_total":FROZEN_TOTAL,
                "member_scales":MEMBER_SCALES, "total_scale":350.,
                "training_rows":24, "evaluation_rows":6,
                "zero_tree_control_is_not_the_200_round_candidate":True}
    with (out / "EXPECTED_LITERAL.json").open("x", encoding="utf8") as stream:
        json.dump(expected, stream, indent=2, allow_nan=False)
    return expected


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(generate(args.out)))

