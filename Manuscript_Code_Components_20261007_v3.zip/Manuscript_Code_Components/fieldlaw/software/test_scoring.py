"""Worked examples and finite synthetic checks at the scoring seam."""
import unittest

import numpy as np

from scoring import score_ensembles


class ScoringTests(unittest.TestCase):
    def test_literal_count_ensemble_has_distinct_empirical_and_fair_scores(self):
        result = score_ensembles([0, 1, 2], 1, 2)
        np.testing.assert_allclose(result["empirical_rps"], [2 / 9])
        np.testing.assert_allclose(result["fair_rps"], [0], atol=1e-15)
        np.testing.assert_allclose(result["scaled_empirical_rps"], [1 / 9])

    def test_inverted_cdf_intervals_and_wis_follow_worked_discrete_example(self):
        result = score_ensembles([0, 2, 4, 6], 8, 2)
        interval = result["intervals"]["50"]
        np.testing.assert_array_equal(interval["lower"], [0])
        np.testing.assert_array_equal(interval["upper"], [4])
        np.testing.assert_array_equal(interval["left_miss"], [False])
        np.testing.assert_array_equal(interval["right_miss"], [True])
        np.testing.assert_allclose(interval["width"], [4])
        np.testing.assert_allclose(interval["scaled_width"], [2])
        np.testing.assert_allclose(interval["interval_score"], [20])
        np.testing.assert_array_equal(result["median"], [2])
        np.testing.assert_allclose(result["median_absolute_error"], [6])
        np.testing.assert_allclose(result["wis"], [301 / 90])
        np.testing.assert_allclose(result["scaled_wis"], [301 / 180])

    def test_counterfactual_is_scored_as_its_actual_empirical_distribution(self):
        result = score_ensembles([0, 1, 2], 1, 1, IID=False)
        np.testing.assert_allclose(result["empirical_rps"], [2 / 9])
        self.assertIsNone(result["fair_rps"])
        self.assertIsNone(result["scaled_fair_rps"])
        single = score_ensembles([3], 1, 1, IID=False)
        np.testing.assert_allclose(single["empirical_rps"], [2])
        np.testing.assert_allclose(single["wis"], [2])

    def test_regions_and_source_scales_are_aligned_and_invalid_inputs_rejected(self):
        result = score_ensembles([[0, 2], [1, 3], [2, 4]], [1, 0], [2, 4])
        np.testing.assert_allclose(result["empirical_rps"], [2 / 9, 23 / 9])
        np.testing.assert_allclose(result["fair_rps"], [0, 7 / 3], atol=1e-15)
        np.testing.assert_allclose(result["scaled_empirical_rps"], [1 / 9, 23 / 36])
        np.testing.assert_array_equal(result["intervals"]["50"]["left_miss"], [False, True])
        invalid = (
            ([], 0, 1, True), ([[[]]], 0, 1, True), ([0], 0, 1, True),
            ([0, 1], [0, 1], 1, True), ([0, 1], 0, [1, 2], True),
            ([0, 1], 0, 0, True), ([0, 1], 0, -1, True),
            ([0, 1], 0, np.inf, True), ([0, np.nan], 0, 1, True),
            ([0, 1], np.nan, 1, True), ([0, 1], 0, 1, "False"),
            ([0.5, 1.5], 1, 1, True), ([0, 1], -1, 1, True),
            ([0, 1j], 0, 1, True),
        )
        for index, (samples, truth, scale, iid) in enumerate(invalid):
            with self.subTest(case=index), self.assertRaises(ValueError):
                score_ensembles(samples, truth, scale, IID=iid)

    def test_discrete_quantile_uses_exact_probability_rank_at_atom_boundary(self):
        result = score_ensembles(np.arange(40), 10, 1)
        np.testing.assert_array_equal(result["intervals"]["95"]["lower"], [0])
        np.testing.assert_array_equal(result["intervals"]["95"]["upper"], [38])

    def test_event_brier_uses_observed_event_indicators(self):
        from scoring import event_brier
        result = event_brier([[True, False], [False, False], [True, True]], [True, False])
        np.testing.assert_allclose(result["event_probability"], [2 / 3, 1 / 3])
        np.testing.assert_allclose(result["brier"], [1 / 9, 1 / 9])
        np.testing.assert_allclose(event_brier([0, 1, 1], True)["brier"], [1 / 9])
        for events, truth in (([], False), ([0, 0.3], False), ([0, np.nan], False),
                              ([0, 1], [False, True]), ([0, 1], 2)):
            with self.subTest(events=events, truth=truth), self.assertRaises(ValueError):
                event_brier(events, truth)

    def test_nonfinite_score_arithmetic_stops_without_clipping_or_repair(self):
        for samples, truth, scale in (([0, 1], 1, np.nextafter(0.0, 1.0)),
                                       ([1e308, 1e308, 1e308], 0, 1)):
            with self.subTest(scale=scale), self.assertRaises(ValueError):
                score_ensembles(samples, truth, scale)


if __name__ == "__main__":
    unittest.main()
