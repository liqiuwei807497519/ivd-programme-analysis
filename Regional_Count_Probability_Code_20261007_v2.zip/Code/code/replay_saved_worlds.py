"""Portable ALL7/event arithmetic replay from frozen saved worlds, never new draws."""
import os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[_key]='2'
import argparse,csv,gzip,hashlib,json,math
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
import time
import numpy as np
LAWS=('FULLY_FACTORIZED_ATOMS','TRUE_ALL_ATOM_GLOBAL_FACTOR_RHO025','RBF_INDEPENDENT_GENE_FIELDS','RBF_FIXED_GENE_RHO025','RBF_POOLED_SOURCE_PIT_CORR')
LEVELS=(50,80,90,95)
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def path_in(root,record):
    relative=Path(record['path']);require(not relative.is_absolute() and '..' not in relative.parts,'Packet paths must be relative without traversal')
    path=(root/relative).resolve();require(root in path.parents,'Packet path escaped extraction root')
    require(sha(path)==record['sha256'],'Frozen packet bytehash mismatch: '+record['path']);return path
def exact(text):
    value=Decimal(str(text));require(value.is_finite() and value==value.to_integral_value(),'Expected exact integer field');return int(value)
def near(value,expected,label):
    b=float(expected);require(math.isfinite(value) and math.isfinite(b) and math.isclose(value,b,rel_tol=1e-10,abs_tol=1e-10),'Numeric mismatch: '+label)
def count_metrics(samples,truth,scale):
    values=sorted(samples);M=len(values);A=sum(abs(value-truth) for value in values)
    P=sum((2*index-M+1)*value for index,value in enumerate(values))
    fn=A*(M-1)-P;en=A*M-P;require(fn>=0 and en>=0,'Negative exact count score numerator')
    fair=float(Fraction(fn,M*(M-1)));empirical=float(Fraction(en,M*M))
    result={'truth_count':truth,'scale':scale,'fair_rps':fair,'scaled_fair_rps':fair/scale,'empirical_rps':empirical,'scaled_empirical_rps':empirical/scale,
        'fair_numerator':fn,'fair_denominator':M*(M-1),'empirical_numerator':en,'empirical_denominator':M*M}
    def quantile(numerator,denominator):return values[(M*numerator+denominator-1)//denominator-1]
    median=quantile(1,2);wis=Fraction(abs(truth-median),2)
    for level in LEVELS:
        alpha=Fraction(100-level,100);lower=quantile(100-level,200);upper=quantile(100+level,200)
        left=int(truth<lower);right=int(truth>upper);width=upper-lower
        interval=Fraction(width)+2/alpha*((lower-truth)*left+(truth-upper)*right)
        wis+=alpha/2*interval
        result.update({f'lower{level}':lower,f'upper{level}':upper,f'coverage{level}':1-left-right,f'lower_miss{level}':left,
            f'upper_miss{level}':right,f'width{level}':width,f'IS{level}':float(interval)})
    result.update(scaled_IS90=result['IS90']/scale,WIS=float(wis/Fraction(9,2)))
    result['scaled_WIS']=result['WIS']/scale;return result
def event_metrics(counts,truth):
    M=len(counts);k=sum(all(int(value)>0 for value in row) for row in counts);observed=int(all(int(value)>0 for value in truth))
    q=(M-k) if observed else k;fair_n=q*(q-1);emp_n=q*q
    return {'observed_event':observed,'positive_scenarios':k,'worlds':M,'probability':k/M,'fair_brier':float(Fraction(fair_n,M*(M-1))),
        'empirical_brier':float(Fraction(emp_n,M*M)),'fair_brier_numerator':fair_n,'fair_brier_denominator':M*(M-1),
        'empirical_brier_numerator':emp_n,'empirical_brier_denominator':M*M}
def compare(result,row):
    integer_fields={'truth_count','fair_numerator','fair_denominator','empirical_numerator','empirical_denominator','observed_event','positive_scenarios','worlds',
        'fair_brier_numerator','fair_brier_denominator','empirical_brier_numerator','empirical_brier_denominator'}
    for level in LEVELS:integer_fields|={f'{name}{level}' for name in ('lower','upper','coverage','lower_miss','upper_miss','width')}
    for key,value in result.items():
        require(key in row,'Frozen reference column absent: '+key)
        if key in integer_fields:require(value==exact(row[key]),'Exact integer mismatch: '+key)
        else:near(float(value),row[key],key)
def replay_saved_worlds(packet_root,output_root):
    root=Path(packet_root).resolve();out=Path(output_root).resolve();require(not out.exists(),'Fresh replay output required')
    began=time.monotonic();index=json.loads((root/'REPLAY_INDEX.json').read_text(encoding='utf8'))
    require(index['schema']=='SAVED_WORLD_ALL7_EVENT_REPLAY_INDEX_V1' and index['mode'] in ('FROZEN_REAL_SAVED_WORLDS','SYNTHETIC'),'Replay index scope refused')
    M=index['M'];require(type(M) is int and M>=2,'At least two saved worlds required')
    sections=index['sections'];require(len({section['capture'] for section in sections})==len(sections),'Duplicate section')
    if index['mode']=='FROZEN_REAL_SAVED_WORLDS':
        require(M==2048 and len(sections)==14 and sum(section['regions'] for section in sections)==1110
            and index['expected_count_keys']==index['expected_event_keys']==5550,'Exact real replay scope required')
    else:require(all(section['capture'].startswith('SYN_') for section in sections),'Synthetic captures required')
    require(len(index['member_uids'])==7 and len(set(index['member_uids']))==7,'Full seven frozen members required')
    count_path=path_in(root,index['count_rows']);event_path=path_in(root,index['event_rows'])
    if count_path.suffix=='.gz':
        with gzip.open(count_path,'rb') as stream:require(hashlib.file_digest(stream,'sha256').hexdigest()==index['count_rows']['uncompressed_sha256'],'Lossless original COUNT TSV digest differs')
    selected={};events={};total_rows=0
    opener=gzip.open if count_path.suffix=='.gz' else open
    with opener(count_path,'rt',encoding='utf8',newline='') as stream:
        for row in csv.DictReader(stream,delimiter='\t'):
            total_rows+=1
            if row['functional']!='ALL7':continue
            key=(row['section_capture'],exact(row['roi_x']),exact(row['roi_y']),row['law'])
            require(key not in selected,'Duplicate ALL7 count key');selected[key]=row
    with event_path.open(encoding='utf8',newline='') as stream:
        for row in csv.DictReader(stream,delimiter='\t'):
            key=(row['section_capture'],exact(row['roi_x']),exact(row['roi_y']),row['law']);require(key not in events,'Duplicate event key');events[key]=row
    require(total_rows==index['expected_full_count_rows'],'Complete all-functional table missing rows')
    require(len(selected)==index['expected_count_keys'] and len(events)==index['expected_event_keys'],'All scoped frozen reference keys required')
    rows=[];event_rows=[];expected=set();bindings={};banks=0
    for section in sections:
        require(time.monotonic()-began<300,'Five-minute replay limit exceeded')
        truth_path=path_in(root,section['truth']);bindings[section['truth']['path']]=section['truth']['sha256']
        with np.load(truth_path,allow_pickle=False) as archive:
            truth=archive['gene_region_truth'];keys=archive['roi_keys'];members=archive['member_uids'].tolist()
        require(truth.shape==(section['regions'],7) and truth.dtype==np.int64 and np.all(truth>=0) and keys.shape==(section['regions'],2)
            and members==index['member_uids'],'Exact seven-member truth/ROI support required')
        require(set(section['laws'])==set(LAWS),'All five saved banks required')
        for law in LAWS:
            path=path_in(root,section['laws'][law]);bindings[section['laws'][law]['path']]=section['laws'][law]['sha256']
            with np.load(path,allow_pickle=False) as archive:
                counts=archive['gene_region_totals'];bank_keys=archive['roi_keys'];bank_members=archive['member_uids'].tolist()
            require(counts.shape==(M,section['regions'],7) and counts.dtype==np.int64 and np.all(counts>=0)
                and np.array_equal(bank_keys,keys) and bank_members==members,'Complete saved integer bank support required')
            for region,(x,y) in enumerate(keys):
                key=(section['capture'],int(x),int(y),law);require(key not in expected,'Duplicate saved ROI key');expected.add(key)
                require(key in selected and key in events,'Missing scoped frozen score key')
                require(selected[key]['parent']==events[key]['parent']==section['parent'],'Parent metadata mismatch')
                scale=float(selected[key]['scale']);require(math.isfinite(scale) and scale>=1,'Frozen source scale missing')
                saved=counts[:,region,:].tolist();samples=[sum(row) for row in saved];target=sum(int(v) for v in truth[region])
                metrics=count_metrics(samples,target,scale);compare(metrics,selected[key])
                event=event_metrics(saved,truth[region]);compare(event,events[key])
                common={'section_capture':section['capture'],'parent':section['parent'],'roi_x':int(x),'roi_y':int(y),'law':law}
                rows.append({**common,**metrics});event_rows.append({**common,**event})
            banks+=1
    require(expected==set(selected)==set(events),'Exact ALL7/event expected key sets differ')
    for relative,digest in bindings.items():require(sha(root/relative)==digest,'Packet payload changed during replay')
    require(time.monotonic()-began<300,'Five-minute replay limit exceeded')
    out.mkdir(parents=True,exist_ok=False)
    for name,records in [('COUNT_ALL7_REPLAY.tsv',rows),('EVENT_REPLAY.tsv',event_rows)]:
        with (out/name).open('x',encoding='utf8',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(records[0]),delimiter='\t');writer.writeheader();writer.writerows(records)
    report={'status':'SAVED_WORLD_ALL7_EVENT_REPLAY_PASS','mode':index['mode'],'M':M,'sections':len(sections),'saved_banks_checked':banks,
        'ALL7_count_keys_checked':len(rows),'event_keys_checked':len(event_rows),'complete_count_table_rows_present':total_rows,
        'full55500_numeric_or_MC_replay_claim':False,'new_draws_or_fits':0,'old_absolute_launch_controls_used':False,
        'elapsed_seconds':time.monotonic()-began,'packet_index_sha256':sha(root/'REPLAY_INDEX.json'),'saved_payload_bindings_unchanged':True,
        'source_reference_files':{'COUNT':index['count_rows'],'EVENT':index['event_rows']},
        'numeric_scope':'ALL7 fair/empirical RPS exactnumerators,source-scaled RPS;50/80/90/95 rationalquantiles/coverage/misses/width/IS/WIS;positive-all7 event probability,exactfactorialfair/empiricalBrier',
        'artifacts':{name:{'path':name,'sha256':sha(out/name)} for name in ('COUNT_ALL7_REPLAY.tsv','EVENT_REPLAY.tsv')}}
    with (out/'REPLAY_REPORT.json').open('x',encoding='utf8') as stream:json.dump(report,stream,indent=2,allow_nan=False)
    return report
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--packet-root',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
    report=replay_saved_worlds(args.packet_root,args.output);print(json.dumps({key:report[key] for key in ('status','ALL7_count_keys_checked','event_keys_checked','elapsed_seconds','new_draws_or_fits')}))
if __name__=='__main__':main()
