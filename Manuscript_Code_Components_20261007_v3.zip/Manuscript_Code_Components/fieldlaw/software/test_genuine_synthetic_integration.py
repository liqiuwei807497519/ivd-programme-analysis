"""Actual supervisor/source/target CLI integration on artificial capsules only."""

import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

import psutil

from build_genuine_synthetic_fixture import build_fixture, HERE, PINNED_PYTHON


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def _write_new(path, value):
    with Path(path).open("x", encoding="utf8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def exercise_pipeline(fixture_root):
    """Record actual child exits, verify all rows, then reject a rehashed toy error."""
    root = Path(fixture_root)
    config, run = build_fixture(root)
    command = [str(PINNED_PYTHON), "-B", str(HERE / "real_supervisor.py"),
               "--config", str(config), "--run-root", str(run)]
    launched = datetime.now(timezone.utc).isoformat()
    supervisor_hash = _sha(HERE / "real_supervisor.py")
    child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf8")
    identity = psutil.Process(child.pid)
    process_identity = {"launcher_pid": child.pid, "launcher_creation_time": identity.create_time(),
                        "actual_command": identity.cmdline(), "config_path": str(config), "config_sha256": _sha(config),
                        "run_root": str(run), "supervisor_sha256": supervisor_hash, "executable": str(PINNED_PYTHON)}
    stdout, stderr = child.communicate(timeout=210)
    process = subprocess.CompletedProcess(command, child.returncode, stdout, stderr)
    (root / "SUPERVISOR_STDOUT.txt").write_text(stdout, encoding="utf8")
    (root / "SUPERVISOR_STDERR.txt").write_text(stderr, encoding="utf8")
    actual_exit = root / "ACTUAL_EXTERNAL_SUPERVISOR_EXIT.json"
    _write_new(actual_exit, {"status": "ACTUAL_EXTERNAL_SUPERVISOR_EXIT", "external_exit_code": process.returncode,
                            "scope": "ACTUAL_PROCESS_ON_SYNTHETIC_CAPSULES_ONLY", "command": command,
                            "process": process_identity,
                            "run_root": str(run), "config_sha256": _sha(config), "started_utc": launched,
                            "finished_utc": datetime.now(timezone.utc).isoformat(),
                            "stdout_sha256": _sha(root / "SUPERVISOR_STDOUT.txt"),
                            "stderr_sha256": _sha(root / "SUPERVISOR_STDERR.txt"),
                            "real_count_or_parameter_reads": 0, "network_requests": 0})
    if process.returncode != 0:
        reason = _read(run / "RUN_FAILURE.json") if (run / "RUN_FAILURE.json").exists() else {}
        raise AssertionError("Actual synthetic supervisor failed: " + json.dumps(reason) + "\n" + process.stdout + process.stderr)
    complete = _read(run / "RUN_COMPLETE.json")
    if complete["external_processes"] != 16 or not complete["external_exits_all_zero"]:
        raise AssertionError("Complete real child process coverage is required")
    params = _read(run / "source/SOURCE_PARAMS.json")
    if params["source_scales"] != {"ALL7": 135.0, "ACAN_COL2A1": 42.0, "OTHER5": 93.0}:
        raise AssertionError("Hand-worked capture-balanced source scales differ")
    exit_receipts = [_read(path) for path in (run / "process_receipts").glob("*.json")]
    if len(exit_receipts) != 16 or any(item["external_exit_code"] != 0 for item in exit_receipts):
        raise AssertionError("All actual child exit receipts must be zero")
    times = {item["label"]: item["finished_utc"] for item in exit_receipts}
    if max(times["forecast_" + capture] for capture in ["SYN_A", "SYN_B", "SYN_C"]) >= min(
            times["truth_" + capture] for capture in ["SYN_A", "SYN_B", "SYN_C"]):
        raise AssertionError("All forecasts must externally exit before any truth stage")
    latest_forecast_exit = max(item["run_elapsed_seconds"] for item in exit_receipts if item["label"].startswith("forecast_"))
    earliest_truth_launch = min(item["run_elapsed_seconds"] - item["elapsed_seconds"] for item in exit_receipts
                                if item["label"].startswith("truth_"))
    if latest_forecast_exit >= earliest_truth_launch:
        raise AssertionError("Every forecast exit must precede the first actual truth process launch")
    audit_output = run / "INDEPENDENT_AUDIT_PASS.json"
    audit_command = [str(PINNED_PYTHON), "-B", str(HERE / "audit_guard.py"), "--run-root", str(run),
                     "--external-exit", str(actual_exit), "--output", str(audit_output)]
    audited = subprocess.run(audit_command, capture_output=True, text=True, encoding="utf8", timeout=60)
    if audited.returncode != 0:
        raise AssertionError("Independent audit failed: " + audited.stdout + audited.stderr)
    audit = _read(audit_output)
    if audit["complete_score_rows"] != 384 or audit["complete_observations"] != 12:
        raise AssertionError("Independent audit must cover all3 libraries/all384 score rows")
    # Retain the passing original rows, then intentionally mutate exactly one
    # artificial score and update its declared hash. The independent numerical
    # audit must still detect the wrong value after simple hash checks pass.
    rows_path = run / "targets/SYN_A/score/ROWS.tsv"
    original_rows = root / "ORIGINAL_PASSING_SYN_A_ROWS.tsv"
    original_rows.write_bytes(rows_path.read_bytes())
    original_score_commit = root / "ORIGINAL_PASSING_SYN_A_SCORE_COMMIT.json"
    original_score_commit.write_bytes(rows_path.with_name("SCORE_COMMIT.json").read_bytes())
    with rows_path.open(encoding="utf8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        fields, rows = reader.fieldnames, list(reader)
    altered = next(row for row in rows if row["functional"] == "ALL7" and row["diagnostic"] == "NONE"
                   and row["law"] == "INDEPENDENT_GENE_FIELDS")
    original_value = float(altered["empirical_rps"])
    altered["empirical_rps"] = str(original_value + 1.0)
    with rows_path.open("w", encoding="utf8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    score_commit = rows_path.with_name("SCORE_COMMIT.json")
    commit = _read(score_commit)
    commit["artifacts"]["ROWS.tsv"]["sha256"] = _sha(rows_path)
    if "bytes" in commit["artifacts"]["ROWS.tsv"]:
        commit["artifacts"]["ROWS.tsv"]["bytes"] = rows_path.stat().st_size
    with score_commit.open("w", encoding="utf8") as stream:
        stream.write(json.dumps(commit, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    failure_output = root / "INTENTIONAL_TOY_CORRUPTION_MUST_NOT_PASS.json"
    negative_command = [str(PINNED_PYTHON), "-B", str(HERE / "postrun_audit.py"), "--run-root", str(run),
                        "--external-exit", str(actual_exit), "--output", str(failure_output)]
    rejected = subprocess.run(negative_command, capture_output=True,
                              text=True, encoding="utf8", timeout=60)
    if rejected.returncode != 2 or "Independent numerical mismatch" not in rejected.stdout or failure_output.exists():
        raise AssertionError("Rehashed artificial score corruption was not numerically rejected: " + rejected.stdout + rejected.stderr)
    receipt = {"status": "GENUINE_THREE_LIBRARY_SYNTHETIC_INTEGRATION_PASS", "scope": "SOFTWARE_ONLY_NOT_EMPIRICAL_VALIDATION",
               "source_observations": 16, "target_libraries": 3, "target_observations": 12, "worlds": 64,
               "actual_external_supervisor_exit": process.returncode, "actual_stage_processes": 16,
               "independent_audit_exit": audited.returncode, "independent_rows_checked": 384,
               "independent_numerical_checks": audit["independent_numerical_checks"],
               "intentional_rehashed_toy_score_corruption_audit_exit": rejected.returncode,
               "intentional_corruption_reason": json.loads(rejected.stdout)["reason"],
               "run_payload_is_intentionally_corrupted_after_passing_audit": True,
               "passing_audit_sha256": _sha(audit_output), "actual_exit_receipt_sha256": _sha(actual_exit),
               "original_passing_SYN_A_rows_sha256": _sha(original_rows), "real_count_or_parameter_reads": 0,
               "original_passing_SYN_A_score_commit_sha256": _sha(original_score_commit),
               "network_requests": 0, "run_root": str(run)}
    _write_new(root / "GENUINE_SYNTHETIC_INTEGRATION_RECEIPT.json", receipt)
    return receipt


class GenuineSyntheticIntegrationTests(unittest.TestCase):
    def test_actual_three_stage_three_library_pipeline_and_independent_corruption_gate(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_genuine_three_library_synthetic_") as temporary:
            receipt = exercise_pipeline(temporary)
            self.assertEqual(receipt["actual_external_supervisor_exit"], 0)
            self.assertEqual(receipt["actual_stage_processes"], 16)
            self.assertEqual(receipt["independent_audit_exit"], 0)
            self.assertEqual(receipt["intentional_rehashed_toy_score_corruption_audit_exit"], 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
