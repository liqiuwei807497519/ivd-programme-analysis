"""Synthetic contract tests; these are software checks, not empirical evidence."""

import unittest
from unittest.mock import patch
import math
import numpy as np

from field_core import CountMarginal, FieldLaw


class CountMarginalTests(unittest.TestCase):
    def test_geometric_nb2_has_literal_cdf_and_quantiles(self):
        marginal = CountMarginal(mu=2.0, alpha=1.0)
        self.assertAlmostEqual(marginal.cdf(0), 1.0 / 3.0, places=14)
        self.assertEqual(marginal.quantile(0.5), 1)
        self.assertEqual(marginal.quantile(0.9), 5)

    def test_poisson_limit_and_zero_mean_have_literal_marginals(self):
        poisson = CountMarginal(mu=2.0, alpha=0.0)
        self.assertAlmostEqual(poisson.cdf(0), math.exp(-2.0), places=14)
        self.assertEqual(poisson.quantile(0.5), 2)
        self.assertEqual(poisson.quantile(0.9), 4)
        for alpha in (0.0, 1.0):
            degenerate = CountMarginal(mu=0.0, alpha=alpha)
            self.assertEqual(degenerate.cdf(0), 1.0)
            self.assertEqual(degenerate.quantile(0.9), 0)

    def test_invalid_marginal_inputs_are_rejected_without_count_flooring(self):
        for mu, alpha in ((-1.0, 0.0), (0.0, -1.0), (math.nan, 1.0), (1.0, math.inf)):
            with self.subTest(mu=mu, alpha=alpha), self.assertRaises(ValueError):
                CountMarginal(mu, alpha)
        marginal = CountMarginal(2.0, 1.0)
        for count in (-1.0, 0.5, math.nan, math.inf):
            with self.subTest(count=count), self.assertRaises(ValueError):
                marginal.cdf(count)
        for probability in (-0.1, 1.0, 1.1, math.nan, math.inf):
            with self.subTest(probability=probability), self.assertRaises(ValueError):
                marginal.quantile(probability)
        self.assertEqual(marginal.quantile(0.0), 0)

    def test_broadcast_marginals_preserve_poisson_nb2_and_zero_counts(self):
        marginal = CountMarginal([[2.0, 2.0, 0.0], [2.0, 2.0, 0.0]], [1.0, 0.0, 1.0])
        np.testing.assert_allclose(marginal.cdf(np.zeros((2, 3))),
                                   [[1.0 / 3.0, math.exp(-2), 1.0]] * 2,
                                   rtol=0, atol=1e-14)
        quantiles = marginal.quantile([[0.5, 0.5, 0.5], [0.9, 0.9, 0.9]])
        np.testing.assert_array_equal(quantiles, [[1, 2, 0], [5, 4, 0]])
        self.assertTrue(np.issubdtype(quantiles.dtype, np.integer))

    def test_nearest_interior_upper_probability_has_exact_geometric_quantile(self):
        # For p = 1 - 2**-53 and F(k) = 1 - (2/3)**(k+1),
        # (2/3)**90 > 2**-53 >= (2/3)**91: the literal quantile is 90.
        self.assertEqual(CountMarginal(2.0, 1.0).quantile(np.nextafter(1.0, 0.0)), 90)

    def test_small_positive_dispersion_preserves_the_nb2_marginal(self):
        marginal = CountMarginal(2.0, 1e-16)
        self.assertAlmostEqual(marginal.cdf(0), math.exp(-2.0), places=14)
        self.assertEqual(marginal.quantile(0.5), 2)
        self.assertEqual(marginal.quantile(0.9), 4)
        even_smaller = CountMarginal(2.0, 1e-20)
        self.assertAlmostEqual(even_smaller.cdf(0), math.exp(-2.0), places=14)
        self.assertEqual(even_smaller.quantile(0.9), 4)

    def test_large_nb2_product_keeps_a_positive_geometric_zero_mass(self):
        marginal = CountMarginal(float(2 ** 54), 1.0)
        self.assertAlmostEqual(marginal.cdf(0) / (1.0 / (2 ** 54 + 1)), 1.0, places=14)


class FieldLawTests(unittest.TestCase):
    @staticmethod
    def literal_field(corr_bank=None):
        weights = np.tile([1.0, 0.0, 0.0, 0.0], (2, 1))
        basis = np.zeros((2, 4, 16))
        basis[:, 0, 0] = 1.0
        if corr_bank is None:
            corr_bank = np.tile(np.eye(2), (4, 1, 1))
        return FieldLaw(np.full((2, 2), 2.0), np.ones(2), weights, basis, corr_bank, gamma=0.25)

    def test_literal_spatial_kernel_is_the_same_gene_covariance(self):
        field = self.literal_field()
        np.testing.assert_allclose(field.one_gene_covariance(), [[1.0, 0.25], [0.25, 1.0]],
                                   rtol=0, atol=1e-14)

    def test_fixed_rho025_has_distinct_gene_and_spatial_covariances(self):
        fixed = np.tile([[1.0, 0.25], [0.25, 1.0]], (4, 1, 1))
        field = self.literal_field(fixed)
        np.testing.assert_allclose(field.cross_covariance(0, 1),
                                   [[0.25, 0.0625], [0.0625, 0.25]], rtol=0, atol=1e-14)
        np.testing.assert_allclose(field.cross_covariance(0, 0),
                                   [[1.0, 0.25], [0.25, 1.0]], rtol=0, atol=1e-14)

    def test_complete_field_validation_guarantees_whole_gene_covariance_identity(self):
        basis = np.zeros((2, 4, 16))
        basis[:, 0, 0] = 1.0
        inputs = dict(mu7=np.full((2, 2), 2.0), alpha7=np.ones(2),
                      state_weights=np.tile([1.0, 0.0, 0.0, 0.0], (2, 1)),
                      H=basis, corr_bank=np.tile(np.eye(2), (4, 1, 1)), gamma=0.25)
        invalid = [dict(mu7=[[-1.0, 2.0], [2.0, 2.0]]), dict(alpha7=[1.0, math.inf]),
                   dict(state_weights=np.ones((2, 4))), dict(H=np.ones((2, 4, 16))),
                   dict(corr_bank=np.tile([[1.0, 1.5], [1.5, 1.0]], (4, 1, 1))),
                   dict(corr_bank=np.tile([[2.0, 0.0], [0.0, 1.0]], (4, 1, 1))),
                   dict(corr_bank=np.tile([[1.0, 0.2], [0.3, 1.0]], (4, 1, 1))),
                   dict(H=np.zeros((1, 4, 16))), dict(gamma=math.nan), dict(gamma=1.1)]
        for replacement in invalid:
            with self.subTest(replacement=list(replacement)), self.assertRaises(ValueError):
                FieldLaw(**(inputs | replacement))
        banks = [np.tile(np.eye(2), (4, 1, 1)),
                 np.tile([[1.0, 0.25], [0.25, 1.0]], (4, 1, 1)),
                 np.tile([[1.0, -0.5], [-0.5, 1.0]], (4, 1, 1)),
                 np.array([[[1.0, r], [r, 1.0]] for r in (0.1, -0.3, 0.6, 0.9)])]
        for bank in banks:
            field = FieldLaw(**(inputs | dict(corr_bank=bank)))
            for gene in (0, 1):
                np.testing.assert_allclose(field.cross_covariance(gene, gene),
                                           [[1.0, 0.25], [0.25, 1.0]], rtol=0, atol=1e-14)
            np.testing.assert_allclose(field.one_gene_covariance(),
                                       [[1.0, 0.25], [0.25, 1.0]], rtol=0, atol=1e-14)
        field = FieldLaw(**inputs)
        basis[:] = 0.0
        np.testing.assert_allclose(field.one_gene_covariance(),
                                   [[1.0, 0.25], [0.25, 1.0]], rtol=0, atol=1e-14)

    def test_whole_world_sampling_is_exactly_chunk_and_roi_projective(self):
        fixed = np.tile([[1.0, 0.25], [0.25, 1.0]], (4, 1, 1))
        field = self.literal_field(fixed)
        totals, receipt = field.sample_gene_region_totals([0, 1], 64, "synthetic/library-A/replicate-0", chunk_size=13)
        rechunked, _ = field.sample_gene_region_totals([0, 1], 64, "synthetic/library-A/replicate-0", chunk_size=1)
        first, _ = field.sample_gene_region_totals([0, 1], 41, "synthetic/library-A/replicate-0", chunk_size=7)
        second, _ = field.sample_gene_region_totals([0, 1], 23, "synthetic/library-A/replicate-0", scenario_start=41, chunk_size=5)
        projected, _ = field.sample_gene_region_totals([0, 0], 64, "synthetic/library-A/replicate-0", chunk_size=17)
        other, _ = field.sample_gene_region_totals([0, 1], 64, "synthetic/library-B/replicate-0", chunk_size=13)
        self.assertEqual(totals.shape, (64, 2, 2))
        self.assertTrue(np.issubdtype(totals.dtype, np.integer))
        np.testing.assert_array_equal(totals, rechunked)
        np.testing.assert_array_equal(totals, np.concatenate([first, second], axis=0))
        np.testing.assert_array_equal(projected[:, 0, :], totals.sum(axis=1))
        self.assertFalse(np.array_equal(totals, other))
        self.assertEqual(receipt["world_count"], 64)
        self.assertEqual(receipt["support_size"], 2)
        self.assertEqual(receipt["phi_endpoint_zero_count"], 0)
        self.assertEqual(receipt["phi_endpoint_one_count"], 0)

    def test_sampling_rejects_invalid_world_and_roi_addresses(self):
        field = self.literal_field()
        inputs = dict(roi_indices=[0, 1], M=4, seed_domain="synthetic/address", scenario_start=0, chunk_size=2)
        invalid = [dict(roi_indices=[-1, 0]), dict(roi_indices=[0, 0.5]),
                   dict(roi_indices=[0, 2]), dict(roi_indices=[0]),
                   dict(M=0), dict(M=2.5), dict(M=True),
                   dict(seed_domain=""), dict(seed_domain=7),
                   dict(scenario_start=-1), dict(scenario_start=0.5),
                   dict(chunk_size=0), dict(chunk_size=-1), dict(chunk_size=1.5)]
        for replacement in invalid:
            with self.subTest(replacement=replacement), self.assertRaises(ValueError):
                field.sample_gene_region_totals(**(inputs | replacement))

    def test_roi_integer_totals_block_overflow_instead_of_wrapping(self):
        basis = np.zeros((2, 4, 16))
        basis[:, 0, 0] = 1.0
        field = FieldLaw(np.full((2, 1), 5e18), np.zeros(1),
                         np.tile([1.0, 0.0, 0.0, 0.0], (2, 1)),
                         basis, np.ones((4, 1, 1)), gamma=0.0)

        class ZeroNormals:
            def standard_normal(self, shape):
                return np.zeros(shape)

        with patch("field_core.np.random.Generator", return_value=ZeroNormals()):
            with self.assertRaises(ValueError):
                field.sample_gene_region_totals([0, 0], 1, "synthetic/overflow", chunk_size=1)

    def test_cross_covariance_rejects_non_gene_indices(self):
        field = self.literal_field()
        for gene in (-1, 2, 0.5, True):
            with self.subTest(gene=gene), self.assertRaises(ValueError):
                field.cross_covariance(gene, 0)
            with self.subTest(gene=gene), self.assertRaises(ValueError):
                field.cross_covariance(0, gene)

    def test_normal_cdf_endpoints_have_counted_nearest_float_receipts(self):
        basis = np.zeros((2, 4, 16))
        basis[:, 0, 0] = 1.0
        field = FieldLaw(np.full((2, 2), 2.0), np.ones(2),
                         np.tile([1.0, 0.0, 0.0, 0.0], (2, 1)),
                         basis, np.tile(np.eye(2), (4, 1, 1)), gamma=0.0)

        class ExtremeNormals:
            def standard_normal(self, shape):
                if shape == (2, 2):
                    return np.array([[-50.0, -50.0], [50.0, 50.0]])
                return np.zeros(shape)

        # Mock only the external randomness seam, and assert public results.
        with patch("field_core.np.random.Generator", return_value=ExtremeNormals()):
            totals, receipt = field.sample_gene_region_totals([0, 1], 3, "synthetic/endpoints", chunk_size=2)
        np.testing.assert_array_equal(totals, [[[0, 0], [90, 90]]] * 3)
        self.assertEqual(receipt["phi_endpoint_zero_count"], 6)
        self.assertEqual(receipt["phi_endpoint_one_count"], 6)
        self.assertEqual(receipt["extra_worlds"], 0)

    def test_2048_single_gene_worlds_share_the_complete_generator_recipe(self):
        basis = np.zeros((2, 4, 16))
        basis[:, 0, 0] = 1.0
        inputs = dict(mu7=np.array([[0.0], [2.0]]), alpha7=np.ones(1),
                      state_weights=np.tile([1.0, 0.0, 0.0, 0.0], (2, 1)),
                      H=basis, corr_bank=np.ones((4, 1, 1)), gamma=0.25)
        expected, first_receipt = FieldLaw(**inputs).sample_gene_region_totals(
            [0, 1], 2048, "synthetic/G1-all-laws", chunk_size=64)
        for chunk in (1, 67, 2048):
            actual, receipt = FieldLaw(**inputs).sample_gene_region_totals(
                [0, 1], 2048, "synthetic/G1-all-laws", chunk_size=chunk)
            np.testing.assert_array_equal(actual, expected)
            self.assertEqual(receipt["world_seed_sha256"], first_receipt["world_seed_sha256"])
        np.testing.assert_array_equal(expected[:, 0, 0], np.zeros(2048, dtype=np.int64))
        self.assertTrue(np.any(expected[:, 1, 0] > 0))


if __name__ == "__main__":
    unittest.main()
