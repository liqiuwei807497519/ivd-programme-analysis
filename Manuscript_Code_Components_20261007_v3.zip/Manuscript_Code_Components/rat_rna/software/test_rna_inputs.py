"""Source-RNA prepare CLI/public seam tests on fresh artificial CSV files only."""

import csv
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from rna_inputs import prepare


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
WORKSPACE = PROJECT.parents[1]
PINNED_PYTHON = WORKSPACE / "IVD_Nonlinear_Baseline_20261002/preflight_v2/environment/venv/Scripts/python.exe"
GENES = ["TBXT", "KRT8", "KRT18", "KRT19", "ACAN", "COL2A1", "SOX9"]
PARENTS = ["Control", "Day_1", "Day_3", "Day_28"]


def binding(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding="utf8")


def write_csv(path, fields, rows):
    with Path(path).open("w", encoding="utf8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def synthetic_fixture(root):
    """All8 source sections/4parent groups; raw values are constructed here."""
    root = Path(root)
    roles = [{"ordered_role_index": index + 1, "role": "anchor", "frozen_symbol": f"SYN_A{index:03d}",
              "rat_feature": f"SynA{index:03d}"} for index in range(126)]
    roles += [{"ordered_role_index": 127 + index, "role": "member", "frozen_symbol": gene,
               "rat_feature": token} for index, (gene, token) in enumerate(zip(GENES, ["Tbxt", "Krt8", "Krt18", "Krt19", "Acan", "Col2a1", "Sox9"]))]
    columns = [role["frozen_symbol"] for role in roles]
    sections = []
    counts_order = ["B3", "B1", "B4", "B2"]
    positions = {"B1": (0, 0), "B2": (0, 12), "B3": (6, 0), "B4": (6, 12)}
    for parent_index, parent in enumerate(PARENTS):
        for section_index in range(2):
            section_id = parent + "-" + str(section_index + 1)
            folder_name = "SYN_" + parent + "_" + str(section_index + 1)
            folder = root / folder_name
            folder.mkdir()
            count_rows, coordinates = [], []
            for barcode in counts_order:
                ordinal = int(barcode[1:])
                row = {"barcode": barcode}
                row.update({column: int((ordinal + index + parent_index) % 4) for index, column in enumerate(columns[:126])})
                row.update({gene: int((ordinal + index + parent_index + section_index) % 5) for index, gene in enumerate(GENES)})
                count_rows.append(row)
                array_row, array_col = positions[barcode]
                coordinates.append({"barcode": barcode, "section": section_id, "sampleid": parent,
                                    "array_row": array_row, "array_col": array_col,
                                    "partition": "IGNORED_HIDDEN_LABEL", "batchid": str(parent_index),
                                    "library_total": "DO_NOT_PARSE_AS_INPUT", "image_x": "DO_NOT_PARSE_AS_INPUT"})
            counts, coord, feature, export = (folder / name for name in ["counts.csv", "spots.csv", "FEATURE_MAP.csv", "EXPORT.json"])
            write_csv(counts, ["barcode", *columns], count_rows)
            write_csv(coord, list(coordinates[0]), coordinates[::-1])
            write_csv(feature, ["request", "rat_feature", "present", "role"],
                      [{"request": role["frozen_symbol"], "rat_feature": role["rat_feature"], "present": "TRUE", "role": role["role"]} for role in roles])
            write_json(export, {"section": section_id, "sampleid": parent, "spots": 4, "normalization_denominator": "all Spatial raw-count genes"})
            sections.append({"section_folder": folder_name, "section_id": section_id, "parent": parent, "expected_rows": 4,
                             "counts": binding(counts), "coordinates": binding(coord), "features": binding(feature), "exports": binding(export)})
    names = ["rna_inputs.py", "rna_score.py", "rna_mean.py", "rna_fold.py", "rna_supervisor.py", "rna_audit.py"]
    code = [binding(HERE / name) for name in names if (HERE / name).exists()]
    config = {"mode": "SYNTHETIC_SOURCE_ONLY_RNA_MEAN", "sections": sections, "ordered_roles": roles,
              "outer_groups": PARENTS, "expected_total_rows": 32, "expected_section_count": 8,
              "selection_grid": {"member_ridge_L2": [.01, .1, 1.0], "count_Poisson_L2": [.0001, .01, 1.0], "composition_L2": [.001, .1, 10.0]},
              "plan_binding": binding(PROJECT / "PLAN.json"), "authorization_binding": binding(PROJECT / "IMPLEMENTATION_AUTHORITY.json"),
              "code_binding": code, "python_executable": str(PINNED_PYTHON),
              "resource_contract": {"CPU": 2, "RSS_bytes": 4294967296, "wall_seconds": 180, "output_bytes": 2147483648, "GPU": False}}
    config_path = root / "SYN_CONFIG.json"
    write_json(config_path, config)
    return config_path, config


class RNAInputsTests(unittest.TestCase):
    def test_prepare_preserves_all133_counts_with_separate_labels_and_canonical_coordinates(self):
        with tempfile.TemporaryDirectory(prefix="source_RNA_SYN_prepare_") as temporary:
            root = Path(temporary)
            config_path, config = synthetic_fixture(root)
            output = root / "prepared"
            commit = prepare(config_path, output)
            self.assertEqual(commit["observations"], 32)
            self.assertEqual(len(commit["sections"]), 8)
            record = commit["sections"][config["sections"][0]["section_folder"]]
            with np.load(record["artifacts"]["INPUTS.npz"]["path"], allow_pickle=False) as archive:
                self.assertEqual(archive["x_counts"].shape, (4, 126))
                self.assertEqual(archive["x_counts"].dtype, np.int64)
                self.assertNotIn("y_counts", archive.files)
                np.testing.assert_array_equal(archive["barcode"], ["B1", "B2", "B3", "B4"])
                np.testing.assert_allclose(archive["coords_um"], [[0, 0], [600, 0], [0, 300*np.sqrt(3)], [600, 300*np.sqrt(3)]])
            with np.load(record["artifacts"]["SOURCE_LABELS.npz"]["path"], allow_pickle=False) as archive:
                self.assertEqual(archive["y_counts"].shape, (4, 7))
                np.testing.assert_array_equal(archive["y_counts"][:, 0], [1, 2, 3, 4])
            self.assertTrue(commit["hidden_fields_not_parsed_as_predictive_values"])

    def test_prepare_refuses_unsafe_section_output_paths_before_writing(self):
        with tempfile.TemporaryDirectory(prefix="source_RNA_SYN_unsafe_") as temporary:
            root = Path(temporary)
            config_path, config = synthetic_fixture(root)
            config["sections"][0]["section_folder"] = "SYN_/../../../escaped"
            write_json(config_path, config)
            with self.assertRaises(ValueError):
                prepare(config_path, root / "prepared")
            self.assertFalse((root / "escaped").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
