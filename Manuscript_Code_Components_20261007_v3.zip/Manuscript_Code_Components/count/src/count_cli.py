"""Portable interface to the unchanged capture-count baseline core.

Prediction-only replay is not a new validation. Training accepts only training
targets; evaluation-target arrays are rejected by the input schema.
"""
import os
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '2'
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from baseline_core import (ContractError, GENES, METHODS, N_INPUTS, input_features,
                           predict_ridge, fit_predict, _finite_positive)
from count_metrics import reconcile_to_total


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def json_value(value):
    if isinstance(value, dict):
        return {k: json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_value(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def dump(path, value):
    Path(path).write_text(json.dumps(json_value(value), indent=2, ensure_ascii=False,
                                   allow_nan=False) + '\n', encoding='utf-8')


def load_inputs(path, training=False):
    allowed = {'region_id', 'x_counts', 'y_counts'} if training else {'region_id', 'x_counts'}
    with np.load(path, allow_pickle=False) as data:
        if set(data.files) != allowed:
            raise ContractError('Input keys do not match the role schema',
                                {'required': sorted(allowed), 'observed': sorted(data.files)})
        result = {k: data[k].copy() for k in data.files}
    ids = result['region_id']
    if ids.ndim != 1 or len(ids) != len(result['x_counts']) or len(set(ids.tolist())) != len(ids):
        raise ContractError('Region IDs must be unique and row aligned')
    return result


def replay(models, counts):
    """Reapply all four means from a frozen checkpoint without optimization."""
    if set(models) != {'ridge', 'total', 'anchor_rates', 'fixed_composition', 'standardizer'}:
        raise ContractError('Unsupported parameter schema')
    if models['ridge'].get('alpha') != 1.0 or models['total'].get('alpha') != 0.01:
        raise ContractError('Frozen version requires alpha=1.0 and 0.01')
    raw, exposure = input_features(counts)
    mean = np.asarray(models['standardizer']['mean'], dtype=float)
    sd = np.asarray(models['standardizer']['sd'], dtype=float)
    if (mean.shape != (N_INPUTS + 2,) or sd.shape != mean.shape
            or not np.isfinite(mean).all() or not np.isfinite(sd).all() or np.any(sd < 0.1)):
        raise ContractError('Invalid frozen training standardizer')
    x = np.column_stack((np.ones(len(raw)), (raw - mean) / sd))
    ridge, diagnostics = predict_ridge(models['ridge'], x, exposure)
    rates = np.asarray(models['anchor_rates'], dtype=float)
    composition = np.asarray(models['fixed_composition'], dtype=float)
    coefficient = np.asarray(models['total']['coef'], dtype=float)
    if (rates.shape != (7,) or composition.shape != (7,) or coefficient.shape != (129,)
            or not np.isfinite(rates).all() or not np.isfinite(composition).all()
            or not np.isfinite(coefficient).all() or np.any(rates <= 0)
            or np.any(composition <= 0) or not np.isclose(composition.sum(), 1, rtol=1e-12, atol=0)):
        raise ContractError('Invalid frozen count parameters')
    with np.errstate(over='ignore', under='ignore', invalid='ignore'):
        total = np.exp(np.log(exposure) + x @ coefficient)
    _finite_positive(total, 'total_prediction')
    predictions = {
        'AnchorRate': exposure[:, None] * rates,
        'RidgeRate': ridge,
        'TotalFixed': total[:, None] * composition,
        'TotalRidge': reconcile_to_total(ridge, total),
    }
    for method, mu in predictions.items():
        _finite_positive(mu, method + '_prediction')
    for method in ('TotalFixed', 'TotalRidge'):
        if not np.allclose(predictions[method].sum(axis=1), total, rtol=1e-12, atol=0):
            raise ContractError('Common total conservation failed')
    return predictions, total, diagnostics


def compare(path, ids, predictions, total, rtol, atol):
    with np.load(path, allow_pickle=False) as committed:
        if not np.array_equal(ids, committed['region_id']):
            raise ContractError('Replay and committed region keys differ')
        expected_total = committed['common_total']
        results = {}
        for name in METHODS:
            expected = committed[name]
            observed = predictions[name]
            if expected.shape != observed.shape:
                raise ContractError('Replay and committed mean shapes differ')
            absolute = np.abs(observed - expected)
            relative = absolute / np.maximum(np.abs(expected), np.finfo(float).tiny)
            passed = bool(np.allclose(observed, expected, rtol=rtol, atol=atol))
            results[name] = {'regions': len(ids), 'member_means': observed.size,
                             'max_abs_error': float(absolute.max()),
                             'max_relative_error': float(relative.max()), 'passed': passed}
        results['common_total'] = {
            'max_abs_error': float(np.abs(total - expected_total).max()),
            'passed': bool(np.allclose(total, expected_total, rtol=rtol, atol=atol)),
        }
    return {'status': 'PASS' if all(v['passed'] for v in results.values()) else 'FAIL',
            'meaning': 'Numerical replay of existing forecasts; no refit or new validation',
            'rtol': rtol, 'atol': atol, 'results': results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    prediction = commands.add_parser('predict', help='Replay frozen parameters; no fitting')
    prediction.add_argument('--parameters', type=Path, required=True)
    prediction.add_argument('--eval-input', type=Path, required=True)
    prediction.add_argument('--compare-committed', type=Path)
    prediction.add_argument('--rtol', type=float, default=1e-12)
    prediction.add_argument('--atol', type=float, default=1e-12)
    prediction.add_argument('--output', type=Path, required=True)
    training = commands.add_parser('fit-predict', help='Fit legal training input; evaluation inputs contain no targets')
    training.add_argument('--train-input', type=Path, required=True)
    training.add_argument('--eval-input', type=Path, required=True)
    training.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    # Never overwrite an existing experiment or a source file.
    args.output.mkdir(parents=True, exist_ok=False)
    evaluation = load_inputs(args.eval_input)
    report = {'command': args.command, 'genes': list(GENES), 'methods': list(METHODS),
              'evaluation_regions': len(evaluation['region_id']), 'evaluation_targets_read': False,
              'input_sha256': {'eval_input': sha(args.eval_input)}, 'prediction_repairs': 0}
    if args.command == 'predict':
        models = json.loads(args.parameters.read_text(encoding='utf-8'))
        predictions, total, diagnostics = replay(models, evaluation['x_counts'])
        report['input_sha256']['parameters'] = sha(args.parameters)
        report['new_fits'] = 0
        report['diagnostics'] = diagnostics
        if args.compare_committed:
            report['input_sha256']['committed_forecasts'] = sha(args.compare_committed)
            report['comparison'] = compare(args.compare_committed, evaluation['region_id'],
                                            predictions, total, args.rtol, args.atol)
    else:
        train = load_inputs(args.train_input, training=True)
        if set(train['region_id'].tolist()) & set(evaluation['region_id'].tolist()):
            raise ContractError('Training and evaluation IDs overlap')
        result = fit_predict(train['x_counts'], train['y_counts'], evaluation['x_counts'])
        predictions = result['predictions']
        total = predictions['TotalFixed'].sum(axis=1)
        report['input_sha256']['train_input'] = sha(args.train_input)
        report['new_fits'] = result['diagnostics']['fit_objects']
        report['fit_ledger'] = result['fit_ledger']
        dump(args.output / 'PARAMETERS.json', result['models'])
    np.savez_compressed(args.output / 'PREDICTIONS.npz', region_id=evaluation['region_id'],
                        common_total=total, **predictions)
    report['status'] = 'COMPLETE'
    if report.get('comparison', {}).get('status') == 'FAIL':
        report['status'] = 'REPLAY_MISMATCH'
    report['forecast_sha256'] = sha(args.output / 'PREDICTIONS.npz')
    dump(args.output / 'RECEIPT.json', report)
    print(json.dumps({'status': report['status'], 'regions': len(evaluation['region_id']),
                      'new_fits': report['new_fits']}))
    if report['status'] != 'COMPLETE':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
