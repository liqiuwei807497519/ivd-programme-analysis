# Explicit path-only adaptation. Help/description precedes scientific imports.
import argparse as _public_argparse
import json as _public_json
from pathlib import Path as _PublicPath
_public_description = {'required_bindings': ['project_root', 'output_root', 'source_root'], 'data_reads': 0, 'heavy_imports': 0, 'scope': 'Figure7/S12 rendering from complete frozen outputs; no training/scenarios', 'expected_source_layout': ['score_audit_v1/actual_run_v2/INDEPENDENT_SCORE_AUDIT.json', 'target_scores_run_v2/{SCORES.json,COUNT_ROWS.tsv}', 'assessment_v2/{PRIMARY_LAWS.tsv,ALL_FUNCTIONALS.tsv}', 'source_calibration_run_v1/SOURCE_PARAMS.json', 'target_inputs_run_v1/', 'target_truth_run_v1/', 'target_forecasts_run_v1/'], 'output_layout': ['work/external_probability', 'Source_Data/External_RNA_Probability', 'Figures', 'Supplementary_Figures'], 'style_dependency_sha256': 'c39acae7a57abf46b0d0a577648c1f85c1398d55522eb6478fd2dfdfdb90f841', 'style_default': 'multiomics_style.py', 'style_bundled': True}
_public_parser = _public_argparse.ArgumentParser(description='Figure7/S12 original plotting logic with explicit paths and exact bundled style; data are not bundled.')
_public_parser.add_argument('--describe-inputs', action='store_true')
for _public_key in _public_description['required_bindings']:
    _public_parser.add_argument('--'+_public_key.replace('_','-'))
_public_parser.add_argument('--style-file', default=str(_PublicPath(__file__).resolve().parent/'multiomics_style.py'), help='Optional explicit style override; defaults to the exact bundled helper')
_public_args = _public_parser.parse_args()
if _public_args.describe_inputs:
    print(_public_json.dumps(_public_description))
    raise SystemExit(0)
for _public_key in _public_description['required_bindings']:
    if getattr(_public_args,_public_key) is None:
        _public_parser.error('Required binding: --'+_public_key.replace('_','-'))
def _public_binding(_public_key):
    return _PublicPath(getattr(_public_args,_public_key)).expanduser().resolve()
# Begin original body with only four path-assignment values adapted.
"""Figure 7/S12 from the complete, independently audited frozen forecasts.

Rendering and descriptive tabulation only. No training, raw-file decoding,
new scenarios, target calibration or selection of favourable regions.
"""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import Normalize, TwoSlopeNorm
from matplotlib.ticker import FuncFormatter
from PIL import Image
import pymupdf as fitz

ROOT = _public_binding('project_root')
OUT = _public_binding('output_root')
BASE = _public_binding('source_root')
WORK = OUT / 'work/external_probability'
DATA = OUT / 'Source_Data/External_RNA_Probability'
FIG = OUT / 'Figures'
SUPP = OUT / 'Supplementary_Figures'
for p in (WORK, DATA, FIG, SUPP):
    p.mkdir(parents=True, exist_ok=True)
STYLE = _public_binding('style_file')
spec = importlib.util.spec_from_file_location('multiomics_style', STYLE)
style = importlib.util.module_from_spec(spec)
spec.loader.exec_module(style)
style.configure_matplotlib(8)
plt.rcParams.update({'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
                     'axes.labelsize':7.5,'savefig.bbox':None,'savefig.dpi':300})

LAWS = ['FULLY_FACTORIZED_ATOMS', 'TRUE_ALL_ATOM_GLOBAL_FACTOR_RHO025',
        'RBF_INDEPENDENT_GENE_FIELDS', 'RBF_FIXED_GENE_RHO025', 'RBF_POOLED_SOURCE_PIT_CORR']
CODES = ['F','G','S','S25','SRC']
NAMES = ['F  Independent atoms', 'G  Global factor', 'S  Spatial independent genes',
         'S25  Spatial fixed correlation', 'SRC  Spatial source correlation']
COLORS = ['#89939F','#008D92','#366BA6','#DF9B24','#6D4CA4']
GENES = ['TBXT','KRT8','KRT18','KRT19','ACAN','COL2A1','SOX9']
FUNCS = ['ALL7','ACAN_COL2A1','OTHER5']+GENES
F_LABELS = ['All seven','ACAN + COL2A1','Other five']+GENES
W,H = 183,220
bindings = {}
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readj(p):
    bindings[str(p)] = sha(p)
    return json.loads(Path(p).read_text(encoding='utf-8'))
def npz(p):
    bindings[str(p)] = sha(p)
    with np.load(p,allow_pickle=False) as a:
        return {k:a[k] for k in a.files}
def table(p):
    bindings[str(p)] = sha(p)
    with Path(p).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f,delimiter='\t'))
def write_tsv(name, rows):
    if not rows: raise ValueError(name)
    p=DATA/name
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
    return p

audit=readj(BASE/'score_audit_v1/actual_run_v2/INDEPENDENT_SCORE_AUDIT.json')
assert audit['status']=='INDEPENDENT_FULL_JOINT_SCORE_AUDIT_PASS'
scores=readj(BASE/'target_scores_run_v2/SCORES.json')
primary=table(BASE/'assessment_v2/PRIMARY_LAWS.tsv')
functional=table(BASE/'assessment_v2/ALL_FUNCTIONALS.tsv')
countrows=table(BASE/'target_scores_run_v2/COUNT_ROWS.tsv')
assert len(countrows)==55500 and len(primary)==15 and len(functional)==150
countrows=[r for r in countrows if r['functional']=='ALL7']
params=readj(BASE/'source_calibration_run_v1/SOURCE_PARAMS.json')
alpha=np.asarray(params['alpha7'],dtype=float) if 'alpha7' in params else None
if alpha is None:
    # Inspect only explicit source parameter fields, never infer from target data.
    alpha=np.asarray(params['alpha'],dtype=float)
assert alpha.shape==(7,)
P={(r['law'],r['scope']):r for r in primary}
def val(l, m, scope='MACRO_E1_E3'):
    return float(P[(l,scope)][m])

captures = [f'GSM{x}' for x in range(7605361,7605375)]
sections={}
native_rows=[]; roi_rows=[]
for c in captures:
    x=npz(BASE/'target_inputs_run_v1'/f'{c}.npz')
    y=npz(BASE/'target_truth_run_v1'/c/'TRUTH.npz')
    mu=npz(BASE/'target_forecasts_run_v1'/c/'NATIVE_MEANS.npz')
    assert np.array_equal(x['canonical_ids'],y['canonical_ids'])
    assert np.array_equal(x['canonical_ids'],mu['canonical_ids'])
    assert np.array_equal(x['roi_keys'],y['roi_keys'])
    d={'x':x,'y':y,'mu':mu,'parent':str(x['parent']), 'section':str(x['section'])}
    sections[c]=d
    for i,xy in enumerate(x['coords_um']):
        rec={'capture':c,'parent':d['parent'],'section':d['section'],
             'native_id':str(x['canonical_ids'][i]),'x_um':xy[0],'y_um':xy[1],
             'roi_index':int(x['roi_indices'][i])}
        for j,g in enumerate(GENES):
            rec[g+'_observed']=int(y['spot_member_counts'][i,j])
            rec[g+'_predicted_mean']=float(mu['gene_means'][i,j])
        native_rows.append(rec)
    ns=np.bincount(x['roi_indices'],minlength=len(x['roi_keys']))
    for i,key in enumerate(x['roi_keys']):
        roi_rows.append({'capture':c,'parent':d['parent'],'roi_x':int(key[0]),
                         'roi_y':int(key[1]),'native_observations':int(ns[i])})
assert len(native_rows)==22821 and len(roi_rows)==1110
write_tsv('native_measured_predicted.tsv',native_rows)
write_tsv('ROI_native_support.tsv',roi_rows)
write_tsv('primary_laws.tsv',primary)
write_tsv('all_functionals.tsv',functional)

# Representative sections are selected by median published native N within
# embryo. Ties use accession order. This depends on geometry, not scores/genes.
reps={}
for p in ['E1','E3']:
    pool=[c for c in captures if sections[c]['parent']==p]
    middle=float(np.median([len(sections[c]['x']['coords_um']) for c in pool]))
    reps[p]=min(pool,key=lambda c:(abs(len(sections[c]['x']['coords_um'])-middle),c))

def panel(fig, letter, box):
    x,y,w,h=box
    fig.text((x-8)/W,(H-y+2)/H,letter,weight='bold',fontsize=9,
             ha='left',va='bottom')
    return fig.add_axes([x/W,(H-y-h)/H,w/W,h/H])
def letter(fig,l,x,y):
    fig.text(x/W,(H-y)/H,l,fontsize=9,weight='bold',ha='left',va='top')
def tidy(ax, xlabel=None, ylabel=None):
    if xlabel:ax.set_xlabel(xlabel,labelpad=2)
    if ylabel:ax.set_ylabel(ylabel,labelpad=2)
    ax.tick_params(length=2,pad=2)
def spatial(ax,d,values,vmax,scale=False):
    xy=d['x']['coords_um']; z=np.log1p(values)
    ax.scatter(xy[:,0],xy[:,1],c=z,s=3.5,cmap='magma',vmin=0,vmax=vmax,
               linewidths=0,rasterized=True)
    lo=xy.min(axis=0);hi=xy.max(axis=0);pad=(hi-lo)*.025
    ax.set_xlim(lo[0]-pad[0],hi[0]+pad[0]);ax.set_ylim(hi[1]+pad[1],lo[1]-pad[1])
    ax.set_aspect('equal');ax.set_axis_off()
    if scale:
        # Dedicated outside-data corner; no text laid over measured spots.
        xx=lo[0];yy=hi[1]+.09*(hi[1]-lo[1])
        ax.plot([xx,xx+500],[yy,yy],color='black',lw=1.5,clip_on=False)
        ax.text(xx+250,yy+60,'500 µm',ha='center',va='top',fontsize=7)
def legend(fig):
    handles=[Line2D([0],[0],color=c,lw=1.8,label=n) for c,n in zip(COLORS,NAMES)]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.004),
               ncol=3,columnspacing=1.1,handlelength=1.3,handletextpad=.4)

fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
letter(fig,'A',4,4)
vmax=max(float(np.quantile(np.log1p(sections[reps[p]]['y']['spot_member_counts'].sum(1)),.995)) for p in reps)
vmax=max(vmax,max(float(np.quantile(np.log1p(sections[reps[p]]['mu']['gene_means'].sum(1)),.995)) for p in reps))
scale_axes=[]
for row,p in enumerate(['E1','E3']):
    d=sections[reps[p]]
    for col,kind in enumerate(['measured','predicted']):
        ax=fig.add_axes([(6+51*col)/W,(H-(12+37*row)-33)/H,47/W,33/H])
        values=d['y']['spot_member_counts'].sum(1) if kind=='measured' else d['mu']['gene_means'].sum(1)
        spatial(ax,d,values,vmax,scale=False)
        if col==0:scale_axes.append(ax)
    fig.text(4/W,(H-(17+37*row))/H,p,fontsize=7.5,weight='bold',rotation=90,va='top')
fig.text(29/W,(H-8)/H,'Measured',ha='center',fontsize=7.5)
fig.text(81/W,(H-8)/H,'Predicted',ha='center',fontsize=7.5)
fig.canvas.draw()
for row,ax in enumerate(scale_axes):
    length=500/(ax.get_xlim()[1]-ax.get_xlim()[0])*ax.get_position().width
    xx=100/W;yy=(H-[46,81][row])/H
    fig.add_artist(Line2D([xx,xx+length],[yy,yy],transform=fig.transFigure,color='black',lw=1.3))
    fig.text(xx+length/2,yy+1.3/H,'500 µm',ha='center',va='bottom',fontsize=7)
cax=fig.add_axes([14/W,(H-84)/H,80/W,2/H])
cb=fig.colorbar(plt.cm.ScalarMappable(norm=Normalize(0,vmax),cmap='magma'),cax=cax,orientation='horizontal')
cb.set_label('log(1 + seven-member counts per native spot)',fontsize=7,labelpad=1)
cb.ax.tick_params(labelsize=7,length=2,pad=1)

# B: member means and detection, all fourteen sections, equal-section within embryo.
ax=panel(fig,'B',(121,12,47,63))
dotrows=[];cols=[];sizes=[]
for k,(p,typ) in enumerate([(p,t) for p in ['E1','E3'] for t in ['measured','predicted']]):
    pool=[d for d in sections.values() if d['parent']==p]
    vals=[];pos=[]
    for d in pool:
        a=d['y']['spot_member_counts'] if typ=='measured' else d['mu']['gene_means']
        vals.append(a.mean(0))
        pos.append((a>0).mean(0) if typ=='measured' else (-np.expm1(-np.log1p(a*alpha)/alpha)).mean(0))
    means=np.mean(vals,0);detection=np.mean(pos,0)
    for j,g in enumerate(GENES):
        dotrows.append({'parent':p,'kind':typ,'gene':g,'mean_counts':means[j],
                        'observed_or_marginal_predicted_detection':detection[j]})
        cols.append(np.log1p(means[j]));sizes.append(8+75*detection[j])
sc=ax.scatter(np.repeat(np.arange(4),7),np.tile(np.arange(7),4),c=cols,s=sizes,
              cmap='viridis',linewidths=.35,edgecolors='white')
ax.set_xticks(range(4),['E1\nmeas.','E1\npred.','E3\nmeas.','E3\npred.']);ax.set_yticks(range(7),GENES)
ax.set_ylim(6.6,-.6);ax.set_xlim(-.5,3.5);ax.spines[['bottom','left']].set_visible(False)
ax.tick_params(length=0,pad=3);ax.grid(axis='y',lw=.3,color='#eeeeee');ax.set_axisbelow(True)
cax=fig.add_axes([173/W,(H-78)/H,2/W,61/H]);cb=fig.colorbar(sc,cax=cax)
cb.set_label('log(1 + mean counts)',fontsize=7,labelpad=3);cb.ax.tick_params(labelsize=7,length=2,pad=1)
for i,pct in enumerate([.1,.5,.9]):
    ax.scatter(.25+i*1.2,7.8,s=8+75*pct,c='black',clip_on=False)
    ax.text(.25+i*1.2,8.35,f'{100*pct:.0f}%',ha='center',fontsize=7)
write_tsv('B_member_means_and_detection.tsv',dotrows)

# C: independent embryo contrasts without population error bars.
ax=panel(fig,'C',(14,104,40,25))
for i,l in enumerate(LAWS):
    points=[val(l,'scaled_fair_rps',p) for p in ['E1','E3']]
    ax.plot(points,[i,i],color=COLORS[i],lw=.8)
    for x,mark in zip(points,['o','^']):ax.scatter(x,i,marker=mark,s=20,c=COLORS[i])
    ax.scatter(val(l,'scaled_fair_rps'),i,c=COLORS[i],marker='D',s=15)
ax.set_yticks(range(5),CODES);ax.set_ylim(4.6,-.6);tidy(ax,'Scaled RPS')
ax.set_xticks([.1,.15,.2]);ax.set_xlim(.075,.217)
ax.legend(handles=[Line2D([],[],marker=m,linestyle='none',color='black',markersize=3,label=n)
                   for m,n in [('o','E1'),('^','E3'),('D','mean')]],
          loc='lower left',bbox_to_anchor=(-.04,1.03),ncol=3,handletextpad=.2,columnspacing=.4,borderaxespad=0)

# D: interval coverage across all prespecified probability levels.
ax=panel(fig,'D',(74,104,41,25))
levels=[50,80,90,95]
ax.plot([45,100],[45,100],'--',lw=.6,c='#777777')
for i,l in enumerate(LAWS):ax.plot(levels,[100*val(l,'coverage'+str(q)) for q in levels],'-o',c=COLORS[i],lw=1,ms=2.5)
ax.set_xlim(45,100);ax.set_ylim(0,100);ax.set_xticks([50,70,90]);ax.set_yticks([0,50,100])
tidy(ax,'Nominal coverage (%)','Observed coverage (%)')

# E: complete functional effects, not just the favourable primary total.
ax=panel(fig,'E',(143,99,30,32))
matrix=np.array([[100*(scores['laws'][LAWS[0]][f]['scaled_fair_rps']['macro']-
                       scores['laws'][l][f]['scaled_fair_rps']['macro'])/
                       scores['laws'][LAWS[0]][f]['scaled_fair_rps']['macro'] for l in LAWS[1:]] for f in FUNCS])
lim=max(5,np.max(np.abs(matrix)))
im=ax.imshow(matrix,cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim),aspect='auto')
ax.set_yticks(range(10),F_LABELS);ax.set_xticks(range(4),CODES[1:]);ax.tick_params(length=0,pad=2)
for sp in ax.spines.values():sp.set_visible(False)
cax=fig.add_axes([144/W,(H-139)/H,27/W,1.7/H]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',ticks=[-20,0,20])
cb.ax.tick_params(labelsize=7,length=2,pad=1);cb.set_label('RPS decrease vs F (%)',fontsize=7,labelpad=1)
write_tsv('E_functional_RPS_effects.tsv',[{'functional':f,'law':l,'RPS_decrease_vs_factorized_percent':matrix[j,i]} for j,f in enumerate(FUNCS) for i,l in enumerate(LAWS[1:])])

# F: proper interval utility vs breadth; width alone is not ranked as failure.
ax=panel(fig,'F',(14,153,40,23))
for i,l in enumerate(LAWS):
    ax.scatter(val(l,'width90'),val(l,'scaled_WIS'),s=30,color=COLORS[i])
ax.set_xlim(320,960);ax.set_ylim(.091,.124);ax.set_xticks([400,800]);ax.set_yticks([.10,.12])
tidy(ax,'90% interval width (counts)','Scaled WIS')

# G/H: unchanged 2048-scenario CDFs from geometry-selected ROIs.
cdf_rows=[];roi_selection={}
for letter_,p,box in [('G','E1',(74,153,41,23)),('H','E3',(137,153,39,23))]:
    d=sections[reps[p]];c=reps[p];keys=d['x']['roi_keys']
    centre=d['x']['coords_um'].mean(0)
    centres=(keys+.5)*500
    ix=int(np.argmin(((centres-centre)**2).sum(1)))
    roi_selection[p]={'capture':c,'roi_index':ix,'roi_key':keys[ix].tolist(),
                      'rule':'ROI centre closest to centroid of all native coordinates; no target outcome used'}
    truth=int(d['y']['gene_region_truth'][ix].sum())
    ax=panel(fig,letter_,box);mx=truth
    for i,l in enumerate(LAWS):
        a=npz(BASE/'target_forecasts_run_v1'/c/f'{l}.npz')['gene_region_totals'][:,ix,:].sum(1)
        a=np.sort(a);mx=max(mx,float(np.quantile(a,.995)))
        ax.step(a,np.arange(1,2049)/2048,where='post',lw=1,c=COLORS[i])
        for rank,s in enumerate(a):cdf_rows.append({'parent':p,'capture':c,'roi_x':keys[ix,0],'roi_y':keys[ix,1],
                                                  'law':l,'rank':rank+1,'scenario_total':int(s),'truth_count':truth})
    ax.axvline(truth,c='black',lw=.8,ls='--');ax.set_xlim(0,mx*1.05+1);ax.set_ylim(0,1.02)
    ax.set_yticks([0,.5,1]);ax.xaxis.set_major_formatter(FuncFormatter(lambda x,pos,lim=mx: f'{x/1000:g}k' if lim>1000 else f'{x:g}'))
    tidy(ax,'Seven-member counts','CDF')
write_tsv('GH_example_CDF_scenarios.tsv',cdf_rows)

# I: all seven mass ratios, not an apparent change in means across dependence laws.
ax=panel(fig,'I',(14,193,27,20))
mass=[]
for j,g in enumerate(GENES):
    for p,mark in [('E1','o'),('E3','^')]:
        pool=[d for d in sections.values() if d['parent']==p]
        obs=sum(int(d['y']['spot_member_counts'][:,j].sum()) for d in pool)
        pred=sum(float(d['mu']['gene_means'][:,j].sum()) for d in pool)
        assert obs>0
        ratio=pred/obs
        mass.append({'gene':g,'parent':p,'observed_mass':obs,'predicted_mass':pred,'predicted_over_observed':ratio})
        ax.scatter(math.log2(ratio),j,s=13,marker=mark,c='#202020' if p=='E1' else '#A1A1AA')
ax.axvline(0,c='#888888',ls='--',lw=.5);ax.set_yticks(range(7),GENES);ax.set_ylim(6.7,-.7)
tidy(ax,r'$\log_2$(pred. / meas.)');ax.tick_params(axis='y',pad=1)
write_tsv('I_member_mass_ratios.tsv',mass)

# J: complete-member positivity is a different event from total abundance.
ax=panel(fig,'J',(58,193,27,20))
for i,l in enumerate(LAWS):
    ax.scatter(val(l,'all7_positive_event_predicted_probability'),
               val(l,'all7_positive_event_empirical_brier'),s=20,c=COLORS[i])
tidy(ax,'Event probability','Event Brier')
ax.set_xlim(.04,.43);ax.set_ylim(.068,.213);ax.set_xticks([.1,.3]);ax.set_yticks([.1,.2])

# K: retain both sides of nominal-90% misses.
ax=panel(fig,'K',(103,193,26,20))
for i,l in enumerate(LAWS):
    ax.scatter(i,100*val(l,'lower_miss90'),s=18,c=COLORS[i])
    ax.scatter(i,100*val(l,'upper_miss90'),s=18,facecolors='white',edgecolors=COLORS[i],lw=.8)
ax.set_xticks(range(5),CODES);ax.set_ylim(-3,65);ax.set_yticks([0,30,60]);tidy(ax,None,'90% misses (%)')
ax.legend(handles=[Line2D([],[],marker='o',linestyle='none',color='black',markersize=3,label='lower'),
                   Line2D([],[],marker='o',linestyle='none',markerfacecolor='white',color='black',markersize=3,label='upper')],
          loc='lower center',bbox_to_anchor=(.5,1.03),ncol=2,columnspacing=.5,handletextpad=.2,borderaxespad=0)

# L: post hoc support-size description, bins defined from native N only.
ax=panel(fig,'L',(151,193,25,20))
ns=np.array([r['native_observations'] for r in roi_rows])
edges=np.unique(np.quantile(ns,[0,.25,.5,.75,1],method='nearest'))
support={(r['capture'],r['roi_x'],r['roi_y']):r['native_observations'] for r in roi_rows}
size_rows=[]
for i,l in enumerate(LAWS[1:],1):
    changes=[]
    for b in range(len(edges)-1):
        vals_={}
        for law in [LAWS[0],l]:
            embryo=[]
            for p in ['E1','E3']:
                ss=[]
                for c,d in sections.items():
                    if d['parent']!=p:continue
                    rr=[r for r in countrows if r['section_capture']==c and r['law']==law and r['functional']=='ALL7'
                        and edges[b]<=support[(c,int(r['roi_x']),int(r['roi_y']))]
                        and (support[(c,int(r['roi_x']),int(r['roi_y']))]<=edges[b+1] if b==len(edges)-2
                             else support[(c,int(r['roi_x']),int(r['roi_y']))]<edges[b+1])]
                    if rr:ss.append(np.mean([float(r['scaled_fair_rps']) for r in rr]))
                if ss:embryo.append(np.mean(ss))
            assert len(embryo)==2
            vals_[law]=np.mean(embryo)
        change=100*(vals_[LAWS[0]]-vals_[l])/vals_[LAWS[0]]
        changes.append(change)
        size_rows.append({'law':l,'lower_native_N':edges[b],'upper_native_N':edges[b+1],
                          'last_bin_right_closed':b==len(edges)-2,'RPS_decrease_vs_factorized_percent':change,
                          'analysis':'post hoc metadata quartiles; equal retained section then embryo, not independent replicates'})
    ax.plot(np.arange(len(changes))+1,changes,'-o',c=COLORS[i],ms=2,lw=.8)
ax.axhline(0,c='#888888',lw=.5);ax.set_xticks(range(1,len(edges)),[str(i+1) for i in range(len(edges)-1)])
tidy(ax,'Native-N bin','RPS decrease (%)')
write_tsv('L_support_size_description.tsv',size_rows)
# One method legend in its own inter-row strip, not across axes or neighbours.
handles=[Line2D([0],[0],color=c,lw=1.8,label=n) for c,n in zip(COLORS,NAMES)]
fig.legend(handles=handles,loc='center',bbox_to_anchor=(.49,(H-94)/H),
           ncol=3,columnspacing=.9,handlelength=1.1,handletextpad=.3)
outputs=style.save_figure(fig,FIG/'Figure7',png_dpi=600,journal_page=True)
plt.close(fig)

# Full-section supplement: all fourteen sections, no best-section display.
sf=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
svmax=max(float(np.quantile(np.log1p(d['y']['spot_member_counts'].sum(1)),.995)) for d in sections.values())
svmax=max(svmax,max(float(np.quantile(np.log1p(d['mu']['gene_means'].sum(1)),.995)) for d in sections.values()))
for k,c in enumerate(captures):
    row,col=divmod(k,2);x=4+col*89;y=5+row*29
    letter(sf,chr(65+k),x,y)
    sf.text((x+8)/W,(H-y)/H,f"{sections[c]['parent']}  {sections[c]['section']}",fontsize=7.5,va='top')
    for j,typ in enumerate(['measured','predicted']):
        ax=sf.add_axes([(x+3+42*j)/W,(H-y-24)/H,39/W,22/H])
        d=sections[c];v=d['y']['spot_member_counts'].sum(1) if typ=='measured' else d['mu']['gene_means'].sum(1)
        spatial(ax,d,v,svmax,scale=k==0 and j==0)
sf.text(.25,.997,'Measured      Predicted',ha='center',fontsize=7,va='top')
sf.text(.74,.997,'Measured      Predicted',ha='center',fontsize=7,va='top')
cax=sf.add_axes([.2,.050,.6,.008]);cb=sf.colorbar(plt.cm.ScalarMappable(norm=Normalize(0,svmax),cmap='magma'),cax=cax,orientation='horizontal')
cb.set_label('log(1 + seven-member counts per native spot)',fontsize=7,labelpad=1);cb.ax.tick_params(labelsize=7,pad=1,length=2)
outputs+=style.save_figure(sf,SUPP/'FigureS12',png_dpi=600,journal_page=True)
plt.close(sf)

# Independent PDF renderer and panels/gutters, not an automatic visual PASS.
boxes={'A':(0,0,110,93),'B':(109,0,183,98),'C':(0,97,63,142),'D':(63,97,123,143),
       'E':(122,91,183,151),'F':(0,145,63,184),'G':(63,145,124,184),'H':(124,145,183,184),
       'I':(0,186,47,220),'J':(47,186,92,220),'K':(92,186,139,220),'L':(139,186,183,220)}
qa=WORK/'visual_review';qa.mkdir(exist_ok=True)
for stem in [FIG/'Figure7',SUPP/'FigureS12']:
    pdf=fitz.open(stem.with_suffix('.pdf'));page=pdf[0]
    assert abs(page.rect.width/72*25.4-W)<.02 and abs(page.rect.height/72*25.4-H)<.02
    page.get_pixmap(matrix=fitz.Matrix(3,3),alpha=False).save(qa/f'{stem.name}_PDF.png');pdf.close()
    with Image.open(stem.with_suffix('.png')) as im:
        if stem.name=='Figure7':
            for l,box in boxes.items():
                b=tuple(round(v*im.width/W if k%2==0 else v*im.height/H) for k,v in enumerate(box))
                im.crop(b).save(qa/f'Figure7_{l}.png')
            for n,lo,hi in [('gutter_AB',104,124),('gutter_CD',53,76),('gutter_DE',113,144),
                            ('gutter_FG',53,75),('gutter_GH',114,138)]:
                im.crop((round(lo/W*im.width),0,round(hi/W*im.width),im.height)).save(qa/f'{n}.png')
        else:
            for row in range(7):
                lo=max(0,1+row*29);hi=min(220,37+row*29)
                im.crop((0,round(lo/H*im.height),im.width,round(hi/H*im.height))).save(qa/f'FigureS12_row{row+1}.png')

manifest={'status':'GENERATED_TECHNICAL_CHECKS_ONLY_VISUAL_REVIEW_PENDING','canvas_mm':[W,H],
          'source_bindings':bindings,'representative_sections':reps,'example_ROIs':roi_selection,
          'count_saturation':'Colour capped at max of section99.5thpercentiles; all points retained; no analytical filter',
          'support':'All published native spots; nominal geometrical coordinates/500umROIs',
          'new_training':0,'new_scenarios':0,'new_raw_file_reads':0,
          'outputs':{str(p):sha(p) for p in outputs},'original_V1_failure_retained':True,
          'statistical_units':'2embryos/14nestedsections; MC precision is computational not biological'}
(WORK/'FIGURE_GENERATION.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({'status':manifest['status'],'representative_sections':reps,'output_paths':[str(p) for p in outputs]}))
