#!/usr/bin/env python3
"""Small Matplotlib style helpers for consistent multi-omics figures."""

from __future__ import annotations

import math
from pathlib import Path


OKABE_ITO = (
    "#E69F00",
    "#56B4E9",
    "#009E73",
    "#F0E442",
    "#0072B2",
    "#D55E00",
    "#CC79A7",
    "#000000",
)

DEFAULT_CONDITIONS = {"control": "#0072B2", "case": "#D55E00"}


def configure_matplotlib(base_font_size: float = 8.0) -> None:
    import matplotlib as mpl

    mpl.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": base_font_size,
            "axes.titlesize": 0,
            "axes.titlepad": 0,
            "axes.labelsize": base_font_size,
            "axes.linewidth": 0.6,
            "xtick.labelsize": base_font_size - 1,
            "ytick.labelsize": base_font_size - 1,
            "xtick.major.width": 0.5,
            "ytick.major.width": 0.5,
            "legend.fontsize": base_font_size - 1,
            "legend.frameon": False,
            "figure.dpi": 120,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "savefig.dpi": 600,
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.02,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def categorical_palette(n: int) -> list[str]:
    """Return deterministic colors; direct labels are still needed for large n."""
    if n < 1:
        return []
    if n <= len(OKABE_ITO):
        return list(OKABE_ITO[:n])
    import matplotlib.pyplot as plt
    from matplotlib.colors import to_hex

    cmap = plt.get_cmap("tab20")
    return [to_hex(cmap(index / max(n - 1, 1))) for index in range(n)]


def symmetric_limits(values) -> tuple[float, float]:
    """Return zero-centered finite limits for signed effects."""
    finite = [
        abs(float(value))
        for value in values
        if value is not None and math.isfinite(float(value))
    ]
    if not finite:
        raise ValueError("No finite values available for color limits")
    maximum = max(finite)
    return (-maximum, maximum)


def save_figure(fig, output_stem: str | Path, *, png_dpi: int = 600, journal_page: bool = False) -> list[Path]:
    """Save PDF/SVG/PNG. journal_page keeps the exact figure size (no bbox tight)."""
    stem = Path(output_stem).expanduser().resolve()
    if stem.suffix:
        stem = stem.with_suffix("")
    stem.parent.mkdir(parents=True, exist_ok=True)
    outputs = [stem.with_suffix(ext) for ext in (".pdf", ".svg", ".png")]
    kw = {"facecolor": "white", "edgecolor": "none"}
    if journal_page:
        kw["bbox_inches"] = None
        kw["pad_inches"] = 0
    else:
        kw["bbox_inches"] = "tight"
        kw["pad_inches"] = 0.02
    fig.savefig(outputs[0], **kw)
    fig.savefig(outputs[1], **kw)
    fig.savefig(outputs[2], dpi=png_dpi, **kw)
    return outputs
