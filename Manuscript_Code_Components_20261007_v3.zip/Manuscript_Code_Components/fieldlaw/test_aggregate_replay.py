import json
import tempfile
import unittest
import shutil
from pathlib import Path
import numpy as np

from aggregate_replay import scoring_replay


class PublicReplayTests(unittest.TestCase):
    def test_committed_integer_worlds_reproduce_literal_rps_without_new_scenarios(self):
        with tempfile.TemporaryDirectory(prefix='SYN_FieldLaw_release_') as name:
            root = Path(name)
            (root/'software').mkdir()
            source=Path(__file__).with_name('software')
            if not source.is_dir():source=Path(__file__).resolve().parents[3]/'Independent_Validation_20261006_FieldLaw'/'software_v2'
            for module in source.glob('*.py'):
                if not module.name.startswith('test_'):
                    shutil.copyfile(module, root/'software'/module.name)
            values = np.zeros((32, 1, 7), dtype=np.int64)
            values[:, 0, 0] = np.tile([0, 2, 4, 6], 8)
            truth = np.zeros((1, 7), dtype=np.int64)
            truth[0, 0] = 3
            np.savez_compressed(root/'SYN_AGGREGATES.npz', values=values, truth=truth, region_keys=np.array([[0,0]],dtype=np.int64))
            spec = {'schema':'FIELDLAW_AGGREGATE_REPLAY_V1', 'synthetic':True,
                    'scales':{'ALL7':2.0,'ACAN_COL2A1':1.0,'OTHER5':2.0},
                    'captures':[{'capture':'SYN_CAPTURE','capsule':'SYN_AGGREGATES.npz'}]}
            (root/'REPLAY_CONFIG.json').write_text(json.dumps(spec),encoding='utf8')
            receipt = scoring_replay(root, root/'output')
            self.assertEqual(receipt['new_scenarios'],0)
            import csv
            with (root/'output'/'SYN_CAPTURE'/'ROWS.tsv').open(encoding='utf8') as stream:
                rows = list(csv.DictReader(stream,delimiter='\t'))
            row = next(r for r in rows if r['functional']=='ALL7' and r['diagnostic']=='NONE')
            self.assertEqual(float(row['empirical_rps']),0.75)
            # With 32 worlds: (32 * 3/4 - mean absolute error 2) /31 =22/31.
            self.assertAlmostEqual(float(row['fair_rps']),22/31)
            self.assertEqual(float(row['scaled_empirical_rps']),0.375)

    def test_independent_checker_accepts_complete_rows_and_rejects_rehashed_wrong_score(self):
        from aggregate_replay import verify_outputs
        with tempfile.TemporaryDirectory(prefix='SYN_FieldLaw_release_') as name:
            root=Path(name);(root/'software').mkdir()
            source=Path(__file__).with_name('software')
            if not source.is_dir():source=Path(__file__).resolve().parents[3]/'Independent_Validation_20261006_FieldLaw'/'software_v2'
            for module in source.glob('*.py'):
                if not module.name.startswith('test_'):shutil.copyfile(module,root/'software'/module.name)
            values=np.zeros((32,1,7),dtype=np.int64);values[:,0,0]=np.tile([0,2,4,6],8)
            truth=np.zeros((1,7),dtype=np.int64);truth[0,0]=3
            np.savez_compressed(root/'SYN_AGGREGATES.npz',values=values,truth=truth,region_keys=np.array([[0,0]],dtype=np.int64))
            spec={'schema':'FIELDLAW_AGGREGATE_REPLAY_V1','synthetic':True,
                  'scales':{'ALL7':2.0,'ACAN_COL2A1':1.0,'OTHER5':2.0},
                  'captures':[{'capture':'SYN_CAPTURE','capsule':'SYN_AGGREGATES.npz'}]}
            (root/'REPLAY_CONFIG.json').write_text(json.dumps(spec),encoding='utf8')
            scoring_replay(root,root/'output')
            good=verify_outputs(root,root/'output')
            self.assertEqual(good['rows'],32)
            import csv
            path=root/'output'/'SYN_CAPTURE'/'ROWS.tsv'
            with path.open(encoding='utf8',newline='') as stream:reader=csv.DictReader(stream,delimiter='\t');fields=reader.fieldnames;rows=list(reader)
            rows[0]['empirical_rps']='1.75'
            with path.open('w',encoding='utf8',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=fields,delimiter='\t',lineterminator='\n');writer.writeheader();writer.writerows(rows)
            with self.assertRaisesRegex(ValueError,'[Mm]ismatch'):
                verify_outputs(root,root/'output')


if __name__ == '__main__':
    unittest.main()
