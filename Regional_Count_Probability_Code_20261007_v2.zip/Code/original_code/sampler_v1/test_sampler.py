"""Literal count law/covariance and complete-field public behavior tests."""
import unittest
import numpy as np

class FiveAtomicSampler(unittest.TestCase):
    def fixture(self):
        return (np.full((3,7),2.),np.ones(7),['SYN_SECTION|A','SYN_SECTION|B','SYN_SECTION|C'],
                np.array([[0.,0.],[0.,0.],[100.,100.]]),np.array([0,0,1]),np.eye(7))
    def test_geometric_counts_true_global_is_not_fixed_RBF(self):
        from sampler import CountMarginal,sample_five_atomic_laws
        m=CountMarginal(2.,1.)
        self.assertAlmostEqual(m.cdf(0),1/3,places=15)
        self.assertAlmostEqual(m.cdf(1),5/9,places=15)
        np.testing.assert_array_equal(m.quantile([0.,.25,.32,.5,.54,.8]),[0,0,0,1,1,3])
        totals,receipt=sample_five_atomic_laws(*self.fixture(),M=16,domain='SYN_SECTION')
        self.assertEqual(len(totals),5)
        for v in totals.values():
            self.assertEqual(v.shape,(16,2,7));self.assertEqual(v.dtype,np.int64);self.assertTrue(np.all(v>=0))
        # Worked independently from SHA/PCG64 raw draws and the closed-form
        # geometric inverse ceil(log(1-u)/log(2/3))-1; no sampler call supplied it.
        np.testing.assert_array_equal(totals['FULLY_FACTORIZED_ATOMS'][0],[[11,4,2,4,1,2,6],[1,0,0,3,0,0,0]])
        np.testing.assert_array_equal(totals['TRUE_ALL_ATOM_GLOBAL_FACTOR_RHO025'][0],[[11,4,3,4,2,2,7],[1,0,0,3,1,0,0]])
        witness=receipt['first_pair_latent_covariance']
        self.assertAlmostEqual(witness['TRUE_ALL_ATOM_GLOBAL_FACTOR_RHO025']['cross_gene_0_1'],.25,places=15)
        self.assertAlmostEqual(witness['RBF_FIXED_GENE_RHO025']['cross_gene_0_1'],.0625,places=15)
        for law in ('RBF_INDEPENDENT_GENE_FIELDS','RBF_FIXED_GENE_RHO025','RBF_POOLED_SOURCE_PIT_CORR'):
            self.assertEqual(receipt['laws'][law]['one_gene_K_sha256'],receipt['laws']['RBF_INDEPENDENT_GENE_FIELDS']['one_gene_K_sha256'])
        self.assertEqual(receipt['world_ids'],list(range(16)))
        self.assertEqual(receipt['extra_worlds'],0)
        self.assertTrue(receipt['optional_conditional_disabled'])

    def test_chunks_split_worlds_and_overlapping_ROIs_project_same_complete_field(self):
        from sampler import sample_five_atomic_laws
        args=list(self.fixture())
        ordinary,receipt=sample_five_atomic_laws(*args,M=32,domain='SYN_SECTION',chunk_size=1,scenario_start=11)
        chunked,chunk_receipt=sample_five_atomic_laws(*args,M=32,domain='SYN_SECTION',chunk_size=7,scenario_start=11)
        args[4]=np.array([[True,False,True,False],[True,True,True,True],[False,True,True,False]])
        overlap,overlap_receipt=sample_five_atomic_laws(*args,M=32,domain='SYN_SECTION',chunk_size=5,scenario_start=11)
        early,_=sample_five_atomic_laws(*args,M=13,domain='SYN_SECTION',chunk_size=3,scenario_start=11)
        late,_=sample_five_atomic_laws(*args,M=19,domain='SYN_SECTION',chunk_size=4,scenario_start=24)
        for law in ordinary:
            np.testing.assert_array_equal(ordinary[law],chunked[law])
            np.testing.assert_array_equal(overlap[law],np.concatenate((early[law],late[law])))
            np.testing.assert_array_equal(overlap[law][:,0],ordinary[law][:,0])
            np.testing.assert_array_equal(overlap[law][:,2],ordinary[law][:,0]+ordinary[law][:,1])
            np.testing.assert_array_equal(overlap[law][:,0]+overlap[law][:,1]-overlap[law][:,3],overlap[law][:,2])
        for key in ('raw_common_draws_sha256','world_seed_sha256','H_sha256','marginal_parameters_sha256'):
            self.assertEqual(receipt[key],chunk_receipt[key]);self.assertEqual(receipt[key],overlap_receipt[key])
        self.assertNotEqual(receipt['roi_incidence_sha256'],overlap_receipt['roi_incidence_sha256'])

if __name__=='__main__':unittest.main()
