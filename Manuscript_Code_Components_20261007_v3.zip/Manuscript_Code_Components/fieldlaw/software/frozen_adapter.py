"""Replay two immutable source forecasts with their original feature semantics.

Native target support belongs in the external protocol. The frozen source
design retains its legacy log-nine-bin reference; it is not a target size
measurement or a fitted size adaptation. No labels, fit option or data-file
path is accepted by this module's public interface.
"""
from pathlib import Path
import sys

import numpy as np

sys.dont_write_bytecode = True
LEGACY_ROOT = Path(__file__).resolve().parents[2] / "IVD_Nonlinear_Baseline_20261005_V2_Real" / "run_source"
sys.path.insert(0, str(LEGACY_ROOT))
import xgb_offset_core as legacy_heads
from vendor import baseline_core as legacy_features

if (Path(legacy_heads.__file__).resolve() != (LEGACY_ROOT / "xgb_offset_core.py").resolve()
        or Path(legacy_features.__file__).resolve() != (LEGACY_ROOT / "vendor" / "baseline_core.py").resolve()):
    raise ImportError("Frozen adapter must import the original V2 source modules")


class FrozenMeanPredictor:
    """Two serialized head capsules paired with two saved baseline parameters."""

    def __init__(self, head_capsules, total_parameters):
        head_capsules, total_parameters = tuple(head_capsules), tuple(total_parameters)
        if len(head_capsules) != 2 or len(total_parameters) != 2:
            raise ValueError("Frozen replay requires exactly two complete head/total pairs")
        role_keys = ("input_ids", "member_ids")
        if any(head_capsules[0][key] != head_capsules[1][key] for key in role_keys):
            raise ValueError("Both source heads must have identical ordered input/member roles")
        self._heads = tuple(legacy_heads.deserialize_model(capsule) for capsule in head_capsules)
        self._totals = tuple({
            "mean": np.asarray(parameters["standardizer"]["mean"], dtype=float).copy(),
            "sd": np.asarray(parameters["standardizer"]["sd"], dtype=float).copy(),
            "coef": np.asarray(parameters["total"]["coef"], dtype=float).copy(),
        } for parameters in total_parameters)
        for head, total in zip(self._heads, self._totals):
            if (total["mean"].shape != (128,) or total["sd"].shape != (128,) or total["coef"].shape != (129,)
                    or not np.isfinite(total["coef"]).all()
                    or not np.array_equal(total["mean"], head["standardizer"]["mean"])
                    or not np.array_equal(total["sd"], head["standardizer"]["sd"])):
                raise ValueError("Frozen total and member heads must share the exact full source scaler")
        self.input_ids = tuple(self._heads[0]["input_ids"])
        self.member_ids = tuple(self._heads[0]["member_ids"])

    def predict(self, x126, ids):
        """Return averaged count means and legal-input prediction provenance."""
        raw, exposure = legacy_features.input_features(x126)
        predictions = []
        totals = []
        for head, parameters in zip(self._heads, self._totals):
            design = np.column_stack((np.ones(len(raw)), (raw - parameters["mean"]) / parameters["sd"]))
            with np.errstate(over="ignore", under="ignore", invalid="ignore"):
                total = np.exp(np.log(exposure) + design @ parameters["coef"])
            legacy_features._finite_positive(total, "frozen_source_total")
            predicted = legacy_heads.predict_from_fitted(head, x126, total, eval_ids=ids)["TotalXGB"]
            predictions.append(predicted)
            totals.append(total)
        mean = 0.5 * predictions[0] + 0.5 * predictions[1]
        averaged_total = 0.5 * totals[0] + 0.5 * totals[1]
        legacy_features._finite_positive(mean, "averaged_frozen_mean")
        consistent = np.allclose(mean.sum(axis=1), averaged_total, rtol=1e-12, atol=0)
        if not consistent:
            raise ValueError("Average source forecasts do not conserve their expected total")
        return mean, {
            "schema": "FROZEN_MEAN_REPLAY_RECEIPT_V1",
            "source_totals": np.stack(totals).tolist(),
            "averaged_total": averaged_total.tolist(),
            "count_mean_total_consistent": bool(consistent),
            "legacy_size_reference_bins": 9,
            "target_native_support_used_as_predictive_feature": False,
            "new_point_fits": 0,
            "repairs": 0,
            "prediction_rule": "reconcile_each_source_then_arithmetic_mean",
        }
