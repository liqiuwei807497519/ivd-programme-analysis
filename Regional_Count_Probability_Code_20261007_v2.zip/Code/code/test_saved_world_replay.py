import csv,gzip,hashlib,json,tempfile,unittest
from pathlib import Path
import numpy as np
from replay_saved_worlds import replay_saved_worlds
LAWS=['FULLY_FACTORIZED_ATOMS','TRUE_ALL_ATOM_GLOBAL_FACTOR_RHO025','RBF_INDEPENDENT_GENE_FIELDS','RBF_FIXED_GENE_RHO025','RBF_POOLED_SOURCE_PIT_CORR']
class SavedWorldReplayTests(unittest.TestCase):
    def fixture(self):
        tmp=tempfile.TemporaryDirectory(prefix='SYN_saved_worlds_');self.addCleanup(tmp.cleanup);root=Path(tmp.name)
        (root/'data').mkdir();members=['SYN_G'+str(i) for i in range(7)]
        def bound(path):return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        truth=root/'data'/'TRUTH.npz';np.savez_compressed(truth,gene_region_truth=np.asarray([[1,0,0,0,0,0,0]],dtype=np.int64),roi_keys=np.asarray([[0,0]]),member_uids=np.asarray(members))
        bank=np.zeros((2,1,7),dtype=np.int64);bank[1,0,0]=2;laws={}
        for law in LAWS:
            path=root/'data'/(law+'.npz');np.savez_compressed(path,gene_region_totals=bank,roi_keys=np.asarray([[0,0]]),member_uids=np.asarray(members));laws[law]=bound(path)
        rows=[];events=[]
        for law in LAWS:
            row={'section_capture':'SYN_CAP','parent':'SYN_PARENT','roi_x':0,'roi_y':0,'law':law,'functional':'ALL7','scale':1,'truth_count':1,
                'fair_rps':0,'scaled_fair_rps':0,'empirical_rps':.5,'scaled_empirical_rps':.5,'fair_numerator':0,'fair_denominator':2,
                'empirical_numerator':2,'empirical_denominator':4,'scaled_IS90':2,'WIS':.3,'scaled_WIS':.3}
            for level in (50,80,90,95):row.update({f'lower{level}':0,f'upper{level}':2,f'coverage{level}':1,f'lower_miss{level}':0,f'upper_miss{level}':0,f'width{level}':2,f'IS{level}':2})
            rows.append(row);events.append({'section_capture':'SYN_CAP','parent':'SYN_PARENT','roi_x':0,'roi_y':0,'law':law,'observed_event':0,'positive_scenarios':0,'worlds':2,
                'probability':0,'fair_brier':0,'empirical_brier':0,'fair_brier_numerator':0,'fair_brier_denominator':2,'empirical_brier_numerator':0,'empirical_brier_denominator':4})
        count=root/'COUNT_ROWS.tsv'
        with count.open('w',encoding='utf8',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)
        compressed=root/'COUNT_ROWS.tsv.gz'
        with count.open('rb') as source,compressed.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as out:out.write(source.read())
        event=root/'EVENT_ROWS.tsv'
        with event.open('w',encoding='utf8',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(events[0]),delimiter='\t');writer.writeheader();writer.writerows(events)
        index={'schema':'SAVED_WORLD_ALL7_EVENT_REPLAY_INDEX_V1','mode':'SYNTHETIC','M':2,'member_uids':members,
            'sections':[{'capture':'SYN_CAP','parent':'SYN_PARENT','regions':1,'truth':bound(truth),'laws':laws}],
            'count_rows':{**bound(compressed),'uncompressed_sha256':hashlib.sha256(count.read_bytes()).hexdigest()},'event_rows':bound(event),
            'expected_count_keys':5,'expected_event_keys':5,'expected_full_count_rows':5}
        (root/'REPLAY_INDEX.json').write_text(json.dumps(index),encoding='utf8');return root,index
    def test_literal_two_saved_worlds_reproduce_rps_intervals_wis_and_event(self):
        root,_=self.fixture();report=replay_saved_worlds(root,root/'SYN_REPLAY')
        self.assertEqual(report['status'],'SAVED_WORLD_ALL7_EVENT_REPLAY_PASS')
        self.assertEqual((report['ALL7_count_keys_checked'],report['event_keys_checked']),(5,5))
        with (root/'SYN_REPLAY'/'COUNT_ALL7_REPLAY.tsv').open(encoding='utf8') as stream:row=next(csv.DictReader(stream,delimiter='\t'))
        self.assertEqual((float(row['fair_rps']),float(row['empirical_rps']),float(row['WIS'])),(0.,.5,.3))
        self.assertEqual(report['new_draws_or_fits'],0)
    def test_incomplete_law_packet_refuses_without_output(self):
        root,index=self.fixture();index['sections'][0]['laws'].pop(LAWS[-1]);(root/'REPLAY_INDEX.json').write_text(json.dumps(index),encoding='utf8')
        with self.assertRaisesRegex(ValueError,'All five saved banks'):replay_saved_worlds(root,root/'SYN_REFUSED')
        self.assertFalse((root/'SYN_REFUSED').exists())
    def test_relative_packet_cannot_reach_absolute_or_parent_paths(self):
        root,index=self.fixture();index['sections'][0]['truth']['path']='../SYN_DO_NOT_OPEN.npz';(root/'REPLAY_INDEX.json').write_text(json.dumps(index),encoding='utf8')
        with self.assertRaisesRegex(ValueError,'relative without traversal'):replay_saved_worlds(root,root/'SYN_REFUSED')
        self.assertFalse((root/'SYN_REFUSED').exists())
if __name__=='__main__':unittest.main()
