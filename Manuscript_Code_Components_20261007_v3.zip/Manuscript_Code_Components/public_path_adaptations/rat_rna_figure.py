# Public path adaptation: help/description precedes all original scientific imports.
import argparse as _public_argparse
import json as _public_json
from pathlib import Path as _PublicPath
import sys as _public_sys
_public_description = {'purpose': 'path-interface description; no scientific execution', 'required_bindings': ['output_root', 'source_root', 'style_root'], 'expected_layout': 'source-root: lawful completed rat RNA run with prepared counts, complete means and audited scores; style-root/multiomics_style.py; output-root must be an explicitly prepared empty directory.', 'data_reads': 0, 'heavy_imports': 0, 'original_scientific_body_preserved_except_declared_path_assignment_values': True}
_public_parser = _public_argparse.ArgumentParser(description="Original analysis with explicit caller-owned paths; no data are bundled.")
_public_parser.add_argument('--describe-inputs', action='store_true', help='Print input layout and exit before imports/data access')
for _public_key in _public_description['required_bindings']:
    _public_parser.add_argument('--'+_public_key.replace('_','-'))
_public_args = _public_parser.parse_args()
if _public_args.describe_inputs:
    print(_public_json.dumps(_public_description))
    raise SystemExit(0)
for _public_key in _public_description['required_bindings']:
    if getattr(_public_args,_public_key) is None:
        _public_parser.error('Required binding: --'+_public_key.replace('_','-'))
def _public_binding(_public_key):
    return _PublicPath(getattr(_public_args,_public_key)).expanduser().resolve()
# Begin the preserved original body. Only declared path-assignment values differ.
"""Read-only figure assembly from the completed source-RNA run; no fitting."""
from pathlib import Path
import csv
import hashlib
import json
import math
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from PIL import Image
import fitz

STYLE = _public_binding('style_root')
sys.path.insert(0, str(STYLE))
from multiomics_style import configure_matplotlib, save_figure

OUT = _public_binding('output_root')
RUN = _public_binding('source_root')
GENES = ['TBXT','KRT8','KRT18','KRT19','ACAN','COL2A1','SOX9']
METHODS = ['AnchorRate','memberRidge','memberPoisson','sourceTotal_fixedComposition','sourceTotal_learnedComposition']
SHORT = ['A','R','P','F','L']
PARENTS = ['Control','Day_1','Day_3','Day_28']
PARENT_COLORS = ['#0072B2','#D55E00','#009E73','#CC79A7']
FIXED, LEARNED, POISSON = METHODS[3], METHODS[4], METHODS[2]
COLORS = {'measured':'#202020', FIXED:'#56B4E9', LEARNED:'#D55E00', POISSON:'#009E73'}

def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()

def readj(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def verify(record):
    path = Path(record['path'])
    if sha(path) != record['sha256']:
        raise ValueError('Committed figure source changed: '+str(path))
    return path

def array(record):
    with np.load(verify(record),allow_pickle=False) as archive:
        return {key:archive[key] for key in archive.files}

def writej(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')

def table(name,rows):
    with (OUT/name).open('w',encoding='utf8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]),delimiter='\t')
        writer.writeheader();writer.writerows(rows)

def extended(value):
    return math.inf if value=='Infinity' else float(value)

def project(values,indices,n):
    result=np.zeros((n,7),dtype=values.dtype)
    np.add.at(result,indices,values)
    return result

def prepare_data():
    final=readj(RUN/'FINAL_COMPLETE.json')
    audit=readj(verify(final['independent_audit']))
    if final['status']!='RNA_SOURCE_COMPARISON_COMPLETE' or audit['status']!='RNA_INDEPENDENT_AUDIT_PASS':
        raise ValueError('Complete audited source-RNA run required')
    config=readj(RUN/'RUN_CONFIG.json')
    if sha(RUN/'RUN_CONFIG.json')!=final['config_sha256']:
        raise ValueError('Figure config differs from completed run')
    prepared=readj(RUN/'prepared/PREPARE_COMMIT.json')
    score_commit=readj(verify(final['score_commit']))
    summary=readj(verify(score_commit['artifacts']['SUMMARY.json']))
    verify(score_commit['artifacts']['ROWS.tsv'])
    barrier=readj(RUN/'ALL_FORECASTS_COMMIT.json')
    records=[{'path':str(RUN/'RUN_CONFIG.json'),'sha256':sha(RUN/'RUN_CONFIG.json')},
             final['independent_audit'],final['score_commit'],score_commit['artifacts']['SUMMARY.json'],
             score_commit['artifacts']['ROWS.tsv'],{'path':str(RUN/'prepared/PREPARE_COMMIT.json'),'sha256':sha(RUN/'prepared/PREPARE_COMMIT.json')}]
    forecasts={}
    for parent in PARENTS:
        records.append(barrier['folds'][parent])
        commit=readj(verify(barrier['folds'][parent]))
        forecasts[parent]=array(commit['artifacts']['NATIVE_MEANS.npz'])
        records.extend(commit['artifacts'].values())
    sections=[];native_rows=[];roi_rows=[];dots=[];section_rows=[]
    for number,declared in enumerate(config['sections']):
        folder,parent=declared['section_folder'],declared['parent']
        descriptors=prepared['sections'][folder]['artifacts']
        x,y=array(descriptors['INPUTS.npz']),array(descriptors['SOURCE_LABELS.npz'])
        records.extend(descriptors.values())
        if not np.array_equal(x['region_id'],y['region_id']) or not np.array_equal(x['barcode'],y['barcode']):
            raise ValueError('Figure input/label canonical join differs')
        f=forecasts[parent];selection=f['section_id']==folder
        if not np.array_equal(f['region_id'][selection],x['region_id']):
            raise ValueError('Figure frozen forecast canonical join differs')
        predictions={method:f[method][selection] for method in METHODS}
        region_truth=project(y['y_counts'],x['roi_indices'],len(x['roi_keys']))
        region_predictions={method:project(values,x['roi_indices'],len(x['roi_keys'])) for method,values in predictions.items()}
        label=['C1','C2','D1a','D1b','D3a','D3b','D28a','D28b'][number]
        sections.append({'folder':folder,'parent':parent,'label':label,**x,'truth':y['y_counts'],
                         'predictions':predictions,'roi_truth':region_truth,'roi_predictions':region_predictions})
        for i,identifier in enumerate(x['region_id']):
            for g,gene in enumerate(GENES):
                native_rows.append({'section':folder,'section_short':label,'parent':parent,'region_id':identifier,
                    'barcode':x['barcode'][i],'x_um':x['coords_um'][i,0],'y_um':x['coords_um'][i,1],
                    'roi_x':int(x['roi_keys'][x['roi_indices'][i],0]),'roi_y':int(x['roi_keys'][x['roi_indices'][i],1]),
                    'gene':gene,'measured_count':int(y['y_counts'][i,g]),
                    **{method:float(values[i,g]) for method,values in predictions.items()}})
        for r,key in enumerate(x['roi_keys']):
            for g,gene in enumerate(GENES):
                roi_rows.append({'section':folder,'section_short':label,'parent':parent,'roi_x':int(key[0]),'roi_y':int(key[1]),
                    'gene':gene,'measured_count':int(region_truth[r,g]),
                    **{method:float(values[r,g]) for method,values in region_predictions.items()}})
        for g,gene in enumerate(GENES):
            dots.append({'section':folder,'section_short':label,'gene':gene,
                         'mean_log1p_measured':float(np.log1p(y['y_counts'][:,g]).mean()),
                         'percent_positive':float((y['y_counts'][:,g]>0).mean()*100)})
        for method in METHODS:
            for g,gene in enumerate(GENES):
                metrics=summary['sections'][folder]['ROI'][method]['members'][gene]
                section_rows.append({'section':folder,'parent':parent,'method':method,'gene':gene,
                                     **{k:metrics[k] for k in ('mean_training_scaled_deviance','truth_mass','predicted_mass','zero_truth_rows','infinite_loss_rows')}})
    if sum(len(s['truth']) for s in sections)!=11893 or sum(len(s['roi_keys']) for s in sections)!=528:
        raise ValueError('Figure must retain all11893 native observations/528 ROIs')
    table('SOURCE_NATIVE_ALL7_ALL8.tsv',native_rows)
    table('SOURCE_ROI_ALL7_ALL8.tsv',roi_rows)
    table('SOURCE_MARKER_DOTS.tsv',dots)
    table('SOURCE_MEMBER_LOSSES_ALL5.tsv',section_rows)
    benchmark=[]
    for parent in PARENTS:
        for method in METHODS:
            benchmark.append({'parent':parent,'method':method,'primary_ROI_loss':summary['parents'][parent]['ROI'][method]['mean7_training_scaled_deviance']})
    table('SOURCE_PARENT_BENCHMARK.tsv',benchmark)
    fixed=extended(summary['primary']['methods'][FIXED]);learned=extended(summary['primary']['methods'][LEARNED])
    claim={'central_claim':'Source-conditioned seven-member allocation reduces regional loss relative to the identical total head with fixed allocation.',
           'primary_fixed':fixed,'primary_learned':learned,'relative_reduction_percent':100*(1-learned/fixed),
           'primary_all_methods':summary['primary']['methods'],
           'plain_member_Poisson_is_lowest_predeclared_primary':True,
           'Ridge_infinite_losses_retained':True,
           'native_observations':11893,'nominal_ROIs':528,'sections':8,'computational_parent_holdouts':4,
           'scope':'Exposed within-rat source-RNA development; no new blind test, independent-animal, causal or cross-species claim.',
           'HERO_selection':'First configured Control section new_Control_st, not outcome-selected',
           'matrix_group':['ACAN','COL2A1'],'other5_named_members':['TBXT','KRT8','KRT18','KRT19','SOX9'],
           'counts':'Measured Spatial RNA count mass, not asserted raw UMI equivalence.',
           'style_helper':{'path':str(STYLE/'multiomics_style.py'),'sha256':sha(STYLE/'multiomics_style.py')},
           'page_mm':[183,220],'font_minimum_pt':7,'journal_page':True}
    writej('CLAIM_CONTRACT.json',claim)
    panels=[('A','Measured native programme geography','SOURCE_NATIVE_ALL7_ALL8.tsv','First Control section; sum7'),
            ('B','All seven measured members across all eight sections','SOURCE_MARKER_DOTS.tsv','Colour gene-scaled meanlog1p; size percentpositive'),
            ('C','Measured ACAN geography','SOURCE_NATIVE_ALL7_ALL8.tsv','First Control; paired colourlimits C/D'),
            ('D','Held-parent-out learned ACAN mean','SOURCE_NATIVE_ALL7_ALL8.tsv','Same complete tissue coordinates as C'),
            ('E','Measured COL2A1 geography','SOURCE_NATIVE_ALL7_ALL8.tsv','First Control; paired colourlimits E/F'),
            ('F','Held-parent-out learned COL2A1 mean','SOURCE_NATIVE_ALL7_ALL8.tsv','Same complete tissue coordinates as E'),
            ('G','Measured/fixed/learned matrix versus other5 mass fractions','SOURCE_ROI_ALL7_ALL8.tsv','All8section totalmass; nozero-countfilter'),
            ('H','Matrix-member regional mass prediction','SOURCE_ROI_ALL7_ALL8.tsv','All528ROIs log1p measured versus learned'),
            ('I','Other-five regional mass prediction','SOURCE_ROI_ALL7_ALL8.tsv','All528ROIs log1p measured versus learned'),
            ('J','Complete seven-member learned-versus-fixed contrast','SOURCE_MEMBER_LOSSES_ALL5.tsv','Equal sections/parent and equal4parents; individualparentdots'),
            ('K','Complete four-parent five-method benchmark','SOURCE_PARENT_BENCHMARK.tsv','PrimaryscaledROI deviance; explicitInfinity'),
            ('L','Allocation loss with all parents and memberPoisson','SOURCE_ROI_ALL7_ALL8.tsv','EqualROI/section thenequal2sections/parent; no independentCI')]
    table('claim-evidence-matrix.tsv',[{'panel':p,'claim':c,'source_table':s,'unit':'Native/ROI within section; four computational parent holdouts','encoding':e,'code':str(Path(__file__).resolve())} for p,c,s,e in panels])
    table('figure-manifest.tsv',[{'panel':p,'claim':c,'source_table':s,'code':'build_source_rna_figure.py','output_stem':'SOURCE_RNA_MEAN_FIGURE','qa_status':'PENDING_RENDER_REVIEW'} for p,c,s,e in panels])
    unique={str(Path(r['path']).resolve()):r['sha256'] for r in records}
    writej('SOURCE_MANIFEST.json',{'status':'CLAIMS_AND_SOURCES_FROZEN_BEFORE_DRAW','completed_run_config_sha256':final['config_sha256'],
          'committed_sources':unique,'all_native_source_rows':len(native_rows),'all_ROI_source_rows':len(roi_rows),
          'source_table_hashes':{n:sha(OUT/n) for n in ['SOURCE_NATIVE_ALL7_ALL8.tsv','SOURCE_ROI_ALL7_ALL8.tsv','SOURCE_MARKER_DOTS.tsv','SOURCE_MEMBER_LOSSES_ALL5.tsv','SOURCE_PARENT_BENCHMARK.tsv']},
          'new_fits':0,'production_edits':0})
    return sections,dots,summary,unique

def axes(fig,bounds,letter):
    x,y,w,h=bounds
    ax=fig.add_axes([x/183,y/220,w/183,h/220])
    fig.text((x-3)/183,(y+h+2)/220,letter,fontsize=9,fontweight='bold',ha='left',va='bottom')
    return ax

def tissue(ax,section,values,norm,cmap='magma',large=False):
    coords=section['coords_um']/1000
    ax.scatter(coords[:,0],coords[:,1],c=values,s=5.4 if large else 1.7,cmap=cmap,norm=norm,linewidths=0,rasterized=True)
    margin=.075
    ax.set_xlim(coords[:,0].min()-margin,coords[:,0].max()+margin)
    ax.set_ylim(coords[:,1].max()+margin,coords[:,1].min()-margin)
    ax.set_aspect('equal');ax.set_axis_off()
    if large:
        xmin,ymax=coords[:,0].min(),coords[:,1].max()
        ax.plot([xmin,xmin+1],[ymax+.08,ymax+.08],color='black',lw=1.2,clip_on=False)
        ax.text(xmin+.5,ymax+.18,'1 mm',fontsize=7,ha='center',va='top')

def colorbar(fig,bounds,norm,cmap,label,ticks=None):
    x,y,w,h=bounds
    ax=fig.add_axes([x/183,y/220,w/183,h/220])
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),cax=ax,orientation='horizontal',ticks=ticks)
    cb.set_label(label,fontsize=7,labelpad=1)
    cb.ax.tick_params(labelsize=7,pad=1,length=2)
    return cb

def draw(sections,dots,summary,sources):
    configure_matplotlib(8)
    plt.rcParams.update({'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'axes.labelsize':7,'font.size':7,'savefig.bbox':None})
    fig=plt.figure(figsize=(183/25.4,220/25.4),facecolor='white')
    hero=sections[0]
    if hero['folder']!='new_Control_st':raise ValueError('HERO section must remain predetermined first Control')
    bounds={
      'A':(8,145,91,67),'B':(115,157,62,55),
      'C':(8,97,36,25),'D':(52,97,36,25),'E':(99,97,36,25),'F':(143,97,36,25),
      'G':(15,50,31,23),'H':(59,50,31,23),'I':(104,50,31,23),'J':(154,50,24,23),
      'K':(22,12,63,22),'L':(116,12,61,22)}
    ax=axes(fig,bounds['A'],'A')
    total=np.log1p(hero['truth'].sum(axis=1));norm=Normalize(0,float(total.max()))
    tissue(ax,hero,total,norm,large=True)
    colorbar(fig,(15,140,60,1.7),norm,'magma','Measured programme, log(1 + count)')
    fig.text(8/183,131/220,'Control-2  |  '+str(len(total))+' native observations',fontsize=7)
    ax=axes(fig,bounds['B'],'B')
    matrix=np.array([[d['mean_log1p_measured'] for d in dots if d['section']==s['folder']] for s in sections])
    maximum=matrix.max(axis=0);scaled=np.divide(matrix,maximum[None,:],out=np.zeros_like(matrix),where=maximum[None,:]>0)
    perc=np.array([[d['percent_positive'] for d in dots if d['section']==s['folder']] for s in sections])
    for r in range(8):
        ax.scatter(np.arange(7),np.full(7,r),s=2+perc[r]*.57,c=scaled[r],cmap='viridis',vmin=0,vmax=1,linewidths=.15,edgecolors='#777777')
    ax.set_xlim(-.6,6.6);ax.set_ylim(7.6,-.6)
    ax.set_xticks(range(7),GENES,rotation=90);ax.set_yticks(range(8),[s['label'] for s in sections])
    ax.tick_params(length=0,pad=2)
    for spine in ax.spines.values():spine.set_visible(False)
    colorbar(fig,(118,136,28,1.7),Normalize(0,1),'viridis','Gene-scaled log1p mean',[0,1])
    for x,pct in zip([155,165,175],[25,50,100]):
        fig.add_artist(Line2D([x/183],[143/220],marker='o',markersize=np.sqrt(2+pct*.57),color='#666666',linestyle='None'))
        fig.text(x/183,138/220,str(pct),ha='center',fontsize=7)
    fig.text(164/183,134/220,'Positive (%)',ha='center',fontsize=7)
    for a,b,g in [('C','D',4),('E','F',5)]:
        observed=np.log1p(hero['truth'][:,g]);inferred=np.log1p(hero['predictions'][LEARNED][:,g])
        limits=Normalize(0,float(max(observed.max(),inferred.max())))
        tissue(axes(fig,bounds[a],a),hero,observed,limits)
        tissue(axes(fig,bounds[b],b),hero,inferred,limits)
        for key,descriptor in [(a,'measured'),(b,'held-out predicted mean')]:
            x,y,w,h=bounds[key]
            fig.text((x+w/2)/183,95/220,GENES[g],ha='center',fontsize=7)
            fig.text((x+w/2)/183,92/220,descriptor,ha='center',fontsize=7)
        x=15 if g==4 else 106
        colorbar(fig,(x,87,62,1.4),limits,'magma','log(1 + count)',[0,round(limits.vmax,1)])
    ax=axes(fig,bounds['G'],'G')
    mass=[]
    for s in sections:
        mass.append([s['roi_truth'].sum(axis=0),s['roi_predictions'][FIXED].sum(axis=0),s['roi_predictions'][LEARNED].sum(axis=0)])
    for r,triplet in enumerate(mass):
        for j,values in enumerate(triplet):
            fraction=float(values[4:6].sum()/values.sum()) if values.sum()>0 else 0
            xpos=r+j*.23-.23
            ax.bar(xpos,fraction*100,width=.2,color='#0072B2',linewidth=0)
            ax.bar(xpos,(1-fraction)*100,bottom=fraction*100,width=.2,color='#D9D9D9',linewidth=0)
    ax.set_ylim(0,100);ax.set_xlim(-.55,7.55);ax.set_yticks([0,50,100]);ax.set_ylabel('Matrix mass (%)',labelpad=1)
    ax.set_xticks(range(8),[s['label'] for s in sections],rotation=45,ha='right');ax.tick_params(length=2,pad=1)
    fig.text(19/183,75/220,'Measured / fixed / learned',fontsize=7)
    for letter,genes in [('H',[4,5]),('I',[0,1,2,3,6])]:
        ax=axes(fig,bounds[letter],letter)
        for parent,color in zip(PARENTS,PARENT_COLORS):
            selected=[s for s in sections if s['parent']==parent]
            measured=np.concatenate([s['roi_truth'][:,genes].sum(axis=1) for s in selected])
            predicted=np.concatenate([s['roi_predictions'][LEARNED][:,genes].sum(axis=1) for s in selected])
            ax.scatter(np.log1p(measured),np.log1p(predicted),s=3,c=color,alpha=.65,linewidths=0,rasterized=True)
        alltruth=np.concatenate([s['roi_truth'][:,genes].sum(axis=1) for s in sections])
        allmean=np.concatenate([s['roi_predictions'][LEARNED][:,genes].sum(axis=1) for s in sections])
        lim=max(np.log1p(alltruth).max(),np.log1p(allmean).max())*1.02
        ax.plot([0,lim],[0,lim],color='#333333',linestyle='--',lw=.5)
        ax.set_xlim(-.15,lim);ax.set_ylim(-.15,lim);ax.set_xticks([0,round(lim/2),round(lim)]);ax.set_yticks([0,round(lim/2),round(lim)])
        ax.set_xlabel('Measured log(1 + count)',labelpad=1);ax.set_ylabel('Mean log(1 + count)',labelpad=1)
        fig.text((bounds[letter][0]+bounds[letter][2]/2)/183,40/220,'ACAN + COL2A1' if letter=='H' else 'Other five members',ha='center',fontsize=7)
    ax=axes(fig,bounds['J'],'J')
    contrasts=[];all_parent_contrasts=[]
    for g,gene in enumerate(GENES):
        values=[]
        for p,parent in enumerate(PARENTS):
            within=[s for s in sections if s['parent']==parent]
            value=np.mean([extended(summary['sections'][s['folder']]['ROI'][LEARNED]['members'][gene]['mean_training_scaled_deviance'])-extended(summary['sections'][s['folder']]['ROI'][FIXED]['members'][gene]['mean_training_scaled_deviance']) for s in within])
            values.append(value);all_parent_contrasts.append(value)
            ax.scatter(value,g+(p-1.5)*.07,s=8,color=PARENT_COLORS[p],linewidths=0)
        contrasts.append(np.mean(values));ax.scatter(contrasts[-1],g,s=22,facecolors='none',edgecolors='black',lw=.7)
    ax.axvline(0,color='#777777',lw=.5);ax.set_yticks(range(7),GENES);ax.set_ylim(6.5,-.5)
    ax.set_xlabel('L − F loss',labelpad=1);ax.tick_params(axis='y',length=0,pad=2)
    ax.set_xscale('symlog',linthresh=.5);ax.set_xticks([-20,-2,0],['−20','−2','0']);ax.tick_params(axis='x',length=2,pad=1)
    # Padding is a layout operation in displayed symlog space, never a data cap.
    transform=ax.xaxis.get_transform()
    displayed=transform.transform(np.array([min(all_parent_contrasts),max(all_parent_contrasts)]))
    clearance=.09*(displayed[1]-displayed[0])
    ax.set_xlim(transform.inverted().transform([displayed[0]-clearance,displayed[1]+clearance]))
    ax=axes(fig,bounds['K'],'K')
    scores=np.array([[extended(summary['parents'][p]['ROI'][m]['mean7_training_scaled_deviance']) for m in METHODS] for p in PARENTS])
    finite=scores[np.isfinite(scores)];maximum=np.log1p(finite).max()
    img=np.where(np.isfinite(scores),np.log1p(scores),maximum*1.08)
    ax.imshow(img,cmap='Blues',vmin=0,vmax=maximum*1.08,aspect='auto')
    ax.set_xticks(range(5),SHORT);ax.set_yticks(range(4),['Control','Day 1','Day 3','Day 28']);ax.tick_params(length=0,pad=2)
    for r in range(4):
        for c in range(5):
            text='∞' if not math.isfinite(scores[r,c]) else f'{scores[r,c]:.2f}'
            ax.text(c,r,text,ha='center',va='center',fontsize=7,color='white' if img[r,c]>maximum*.57 else 'black')
    ax=axes(fig,bounds['L'],'L')
    for p,parent in enumerate(PARENTS):
        within=[s for s in sections if s['parent']==parent]
        values=[np.mean([extended(summary['sections'][s['folder']]['ROI'][m]['mean_allocation_defined_unscaled']) for s in within]) for m in [FIXED,LEARNED,POISSON]]
        ax.plot([0,1,2],values,'o-',color=PARENT_COLORS[p],lw=.8,ms=3)
    ax.set_xticks([0,1,2],['F','L','P']);ax.set_ylabel('Allocation deviance',labelpad=2);ax.set_xlim(-.15,2.15)
    fig.text(8/183,4/220,'A Anchor rate   R Ridge   P Poisson   F Fixed   L Learned',fontsize=7)
    fig.legend([Line2D([],[],marker='o',color=c,lw=.7,ms=3) for c in PARENT_COLORS],['Control','Day 1','Day 3','Day 28'],
               loc='lower right',bbox_to_anchor=(.985,.006),ncol=4,columnspacing=.8,handletextpad=.3,handlelength=.8,fontsize=7)
    fig.canvas.draw()
    outputs=save_figure(fig,OUT/'SOURCE_RNA_MEAN_FIGURE',png_dpi=450,journal_page=True)
    plt.close(fig)
    crop_dir=OUT/'review_crops';crop_dir.mkdir(exist_ok=True)
    with Image.open(OUT/'SOURCE_RNA_MEAN_FIGURE.png') as page:
        pixelw,pixelh=page.size
        for letter,(x,y,w,h) in bounds.items():
            bottom_padding=30 if letter in 'AB' else 22 if letter in 'CDEF' else 18 if letter in 'GHIJ' else 12
            box=(max(0,int((x-7)/183*pixelw)),max(0,int((220-y-h-7)/220*pixelh)),
                 min(pixelw,int((x+w+4)/183*pixelw)),min(pixelh,int((220-y+bottom_padding)/220*pixelh)))
            page.crop(box).save(crop_dir/('panel_'+letter+'.png'))
        for name,y0,y1 in [('gutter_AB_CD',122,147),('gutter_CD_GJ',75,94),('gutter_GJ_KL',34,50)]:
            page.crop((0,int((220-y1)/220*pixelh),pixelw,int((220-y0)/220*pixelh))).save(crop_dir/(name+'.png'))
        for name,x0,x1 in [('gutter_A_B',93,118),('gutter_C_D',40,55),('gutter_D_E',85,102),('gutter_E_F',132,146),('gutter_G_H',43,61),('gutter_H_I',87,106),('gutter_I_J',132,156),('gutter_K_L',82,119)]:
            page.crop((int(x0/183*pixelw),0,int(x1/183*pixelw),pixelh)).save(crop_dir/(name+'.png'))
    document=fitz.open(OUT/'SOURCE_RNA_MEAN_FIGURE.pdf')
    pdfpage=document[0]
    actual_page_points=[pdfpage.rect.width,pdfpage.rect.height]
    pdfpage.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(OUT/'SOURCE_RNA_MEAN_FIGURE_PDF_RENDER.png')
    document.close()
    for path,expected in sources.items():
        if sha(path)!=expected:raise ValueError('Committed source changed during figure generation')
    writej('TECHNICAL_QA.json',{'status':'TECHNICAL_PASS_VISUAL_REVIEW_PENDING','page_mm':[183,220],'panel_count':12,
          'all_seven_all_eight_native_rows':11893*7,'all_seven_all_eight_ROI_rows':528*7,'font_minimum_pt':7,
          'journal_page':True,'new_fits':0,'source_hashes_unchanged':True,
          'outputs':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in outputs},
          'PDF_page_points':actual_page_points})
    (OUT/'FIGURE_LEGEND.txt').write_text(
      'Source-conditioned allocation of a seven-member rat RNA programme. A, Measured programme count mass across the complete first configured Control section (Control-2; no result-based tissue selection), with native array coordinates and a nominal scale bar. B, All seven members in all eight released sections: dot area denotes the percentage of native observations with a positive measured count (area2+0.57×percentage pt²); colour is mean log(1+count), scaled separately to each gene maximum across sections. C–F, Measured and leave-parent-out learned predicted mean for ACAN and COL2A1 on the identical complete tissue support; each measured/predicted pair shares colour limits. G, ACAN+COL2A1 (blue) versus the other five named members (grey) as a fraction of section count mass; from left to right each section contains measured, fixed-allocation and learned-allocation bars. H–I, All528 nominal500µm ROIs, comparing measured and learned-predicted matrix-member and other-five count masses. J, Learned minus fixed training-scaled Poisson deviance for every member, on a symmetric-log axis with linear threshold0.5; coloured points are four computational parent-holdout summaries and open circles are their equal-weight mean. K, All five predefined methods across all four parents, with infinite Ridge loss preserved. L, Allocation deviance for fixed and learned allocation and member Poisson, averaging ROIs within section and both sections within parent. The fixed-allocation and learned-allocation methods share the exact same fitted total checkpoint. C1/C2 are the two Control sections; D1a/b, D3a/b and D28a/b are the corresponding paired sections in configured order. Primary ROI loss: fixed2.35085, learned1.05150 (55.27% lower); member Poisson1.03123 is the lowest predefined primary score. Complete source data retain11893 native observations,528 ROIs,8 sections,7 members and all5 methods. These are exposed within-rat source-RNA computational holdouts, not independent animals, fresh blind validation, anatomical cell annotations or cross-species prediction. Measured counts are Spatial RNA count mass without an additional raw-UMI-equivalence assumption. No uncertainty intervals or causal claims are implied.\n',encoding='utf8')
    print(json.dumps({'status':'FIGURE_ASSEMBLED_REVIEW_PENDING','outputs':[str(p) for p in outputs],'panels':12,'native':11893,'ROIs':528}),flush=True)

if __name__=='__main__':
    draw(*prepare_data())
