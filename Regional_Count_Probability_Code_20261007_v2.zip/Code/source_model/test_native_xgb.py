import copy,json,unittest
import numpy as np
from native_xgb import fit_native_xgb,predict_native_xgb

class NativeXGBTests(unittest.TestCase):
    def test_zero_update_heads_replay_count_offsets_not_exposure_squared(self):
        x=np.zeros((3,126),dtype=np.int64)
        y=np.array([[2,3,4,5,6,7,8]]*3,dtype=np.int64)
        roles={'input_uids':['UID'+str(i) for i in range(126)],'member_uids':['UID'+str(i) for i in range(126,133)]}
        frozen=fit_native_xgb(x,y,['A','A','B'],roles)
        json.dumps(frozen,allow_nan=False)
        before=copy.deepcopy(frozen)
        query=np.zeros((2,126),dtype=np.int64);query[0,0]=1;query[1,0]=4
        means=predict_native_xgb(frozen,query,roles)
        np.testing.assert_allclose(means,[[4,6,8,10,12,14,16],[10,15,20,25,30,35,40]],rtol=2e-6,atol=2e-6)
        self.assertEqual(frozen,before)
        self.assertEqual(len(frozen['standardizer']['mean127']),127)
        self.assertEqual(frozen['training_weights'],[.75,.75,1.5])
        self.assertEqual(frozen['rate_prior_b'],[2.,3.,4.,5.,6.,7.,8.])

    def test_wrong_ordered_roles_reject_and_zero_gene_stays_exact_zero(self):
        x=np.zeros((3,126),dtype=np.int64);y=np.array([[2,3,4,5,6,7,8]]*3,dtype=np.int64)
        roles={'input_uids':['UID'+str(i) for i in range(126)],'member_uids':['UID'+str(i) for i in range(126,133)]}
        frozen=fit_native_xgb(x,y,['A','A','B'],roles)
        wrong=copy.deepcopy(roles);wrong['input_uids']=list(reversed(wrong['input_uids']))
        with self.subTest(case='reordered_inputs'):
            with self.assertRaises(ValueError):predict_native_xgb(frozen,x,wrong)
        overlap=copy.deepcopy(roles);overlap['input_uids'][0]=overlap['member_uids'][0]
        with self.subTest(case='target_overlap'):
            with self.assertRaises(ValueError):fit_native_xgb(x,y,['A','A','B'],overlap)
        y[:,2]=0
        with self.subTest(case='all_zero_training_gene'):
            zero=fit_native_xgb(x,y,['A','A','B'],roles)
            query=np.zeros((1,126),dtype=np.int64);query[0,0]=4
            np.testing.assert_allclose(predict_native_xgb(zero,query,roles),[[10,15,0,25,30,35,40]],rtol=2e-6,atol=2e-6)
            self.assertEqual(zero['heads'][2]['kind'],'zero')
            self.assertEqual(zero['rate_prior_b'][2],0.)

if __name__=='__main__':unittest.main()
