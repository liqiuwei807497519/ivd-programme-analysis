"""Only the two author-approved public count/result seams are exercised."""
import csv
import hashlib
import json
from pathlib import Path
import sys
import shutil
import tempfile
import subprocess
import unittest
import numpy as np

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "src"))
CAPSULE = PACKAGE / "inputs" / "ALL_GENE_DATA.npz"
META = PACKAGE / "inputs" / "PSEUDOBULK_META.json"


class PublicInterfaces(unittest.TestCase):
    def test_capsule_boundary_rejects_corruption_missing_member_and_changed_metadata(self):
        from reproduce import run
        with tempfile.TemporaryDirectory(prefix="human_bad_input_") as temporary:
            temporary = Path(temporary)
            corrupt = temporary / "corrupt.npz"
            corrupt.write_bytes(CAPSULE.read_bytes() + b"altered")
            with self.assertRaisesRegex(ValueError, "capsule SHA"):
                run(corrupt, META, temporary / "corrupt_output")
            with np.load(CAPSULE, allow_pickle=False) as data:
                filtered = {key: data[key] for key in data.files}
            removed = filtered["genes"].tolist().index("TBXT")
            for key in ("counts", "log2_cpm_all", "z_natural"):
                filtered[key] = np.delete(filtered[key], removed, axis=1)
            for key in ("genes", "available_natural"):
                filtered[key] = np.delete(filtered[key], removed)
            missing = temporary / "missing_member.npz"
            np.savez_compressed(missing, **filtered)
            with self.assertRaisesRegex(ValueError, "capsule SHA"):
                run(missing, META, temporary / "missing_output")
            meta = temporary / "changed.json"
            meta.write_bytes(META.read_bytes() + b"\n")
            with self.assertRaisesRegex(ValueError, "metadata SHA"):
                run(CAPSULE, meta, temporary / "meta_output")
            self.assertFalse(any(temporary.glob("*_output")))

    def test_checker_rejects_missing_and_changed_results_after_manifest_refresh(self):
        from check_prepared import run
        with tempfile.TemporaryDirectory(prefix="human_bad_results_") as temporary:
            temporary = Path(temporary)
            for case in ("numeric", "member", "payload"):
                with self.subTest(case=case):
                    root = temporary / case
                    shutil.copytree(PACKAGE / "reference", root)
                    if case == "numeric":
                        target = root / "statistics" / "PROGRAMME_TESTS.tsv"
                        lines = target.read_text(encoding="utf8").splitlines()
                        cells = lines[1].split("\t")
                        cells[2] = "0.913608617886898"
                        lines[1] = "\t".join(cells)
                        target.write_text("\n".join(lines) + "\n", encoding="utf8")
                        self.refresh_manifest(root, target.name)
                    elif case == "member":
                        target = root / "statistics" / "PROGRAMME_MEMBERS.tsv"
                        lines = target.read_text(encoding="utf8").splitlines()
                        target.write_text("\n".join(lines[:-1]) + "\n", encoding="utf8")
                        self.refresh_manifest(root, target.name)
                    else:
                        (root / "statistics" / "CULTURED_PAIR_SCORES.tsv").unlink()
                        target = root / "statistics" / "ANALYSIS_COMMIT.json"
                        commit = json.loads(target.read_text(encoding="utf8"))
                        commit["artifacts"] = [item for item in commit["artifacts"] if item["relative_path"] != "CULTURED_PAIR_SCORES.tsv"]
                        target.write_text(json.dumps(commit), encoding="utf8")
                    with self.assertRaises(ValueError):
                        run(CAPSULE, META, root, temporary / (case + "_check"))
                    self.assertFalse((temporary / (case + "_check")).exists())

    def test_both_public_outputs_are_one_shot(self):
        from reproduce import run as reproduce
        from check_prepared import run as check
        with tempfile.TemporaryDirectory(prefix="human_no_overwrite_") as temporary:
            output = Path(temporary) / "existing"
            output.mkdir()
            sentinel = output / "owned.txt"
            sentinel.write_text("retain", encoding="utf8")
            with self.assertRaises(FileExistsError):
                reproduce(CAPSULE, META, output)
            with self.assertRaises(FileExistsError):
                check(CAPSULE, META, PACKAGE / "reference", output)
            self.assertEqual(sentinel.read_text(encoding="utf8"), "retain")

    def test_both_clis_replay_from_relocated_unicode_and_space_paths(self):
        with tempfile.TemporaryDirectory(prefix="human_relocation_") as temporary:
            root = Path(temporary) / "九样本 移位胶囊"
            shutil.copytree(PACKAGE / "src", root / "src")
            shutil.copytree(PACKAGE / "inputs", root / "inputs")
            first = subprocess.run([sys.executable, "src/reproduce.py", "--capsule", "inputs/ALL_GENE_DATA.npz",
                                    "--metadata", "inputs/PSEUDOBULK_META.json", "--output", "实际 结果"],
                                   cwd=root, capture_output=True, text=True, encoding="utf8")
            self.assertEqual(first.returncode, 0, first.stderr)
            receipt = json.loads(first.stdout)
            self.assertEqual(receipt["gene_count"], 36591)
            second = subprocess.run([sys.executable, "src/check_prepared.py", "--capsule", "inputs/ALL_GENE_DATA.npz",
                                     "--metadata", "inputs/PSEUDOBULK_META.json", "--results", "实际 结果", "--output", "独立 检查"],
                                    cwd=root, capture_output=True, text=True, encoding="utf8")
            self.assertEqual(second.returncode, 0, second.stderr)
            self.assertEqual(json.loads(second.stdout)["matched_null_sets_checked"], 10000)

    def test_checker_rejects_an_added_programme_even_after_manifest_refresh(self):
        from check_prepared import run
        with tempfile.TemporaryDirectory(prefix="human_family_seam_") as temporary:
            root = Path(temporary) / "changed"
            shutil.copytree(PACKAGE / "reference", root)
            target = root / "statistics" / "NATURAL_ANALYSIS.json"
            value = json.loads(target.read_text(encoding="utf8"))
            value["programme_tests"]["Unapproved_seventh_programme"] = value["programme_tests"]["Resident_identity"].copy()
            target.write_text(json.dumps(value), encoding="utf8")
            self.refresh_manifest(root, target.name)
            with self.assertRaisesRegex(ValueError, "schema|key"):
                run(CAPSULE, META, root, Path(temporary) / "check")

    def test_checker_rejects_changed_count_precision_even_after_manifest_refresh(self):
        from check_prepared import run
        with tempfile.TemporaryDirectory(prefix="human_precision_seam_") as temporary:
            root = Path(temporary) / "changed"
            shutil.copytree(PACKAGE / "reference", root)
            target = root / "statistics" / "ALL_GENE_DATA.npz"
            with np.load(target, allow_pickle=False) as data:
                arrays = {key: data[key] for key in data.files}
            arrays["counts"] = arrays["counts"].astype(np.float32)
            np.savez_compressed(target, **arrays)
            self.refresh_manifest(root, target.name)
            with self.assertRaisesRegex(ValueError, "dtype|precision"):
                run(CAPSULE, META, root, Path(temporary) / "check")

    @staticmethod
    def refresh_manifest(root, filename):
        target = root / "statistics" / filename
        commit_path = root / "statistics" / "ANALYSIS_COMMIT.json"
        commit = json.loads(commit_path.read_text(encoding="utf8"))
        for item in commit["artifacts"]:
            if item["relative_path"] == filename:
                item["sha256"] = hashlib.sha256(target.read_bytes()).hexdigest()
                item["bytes"] = target.stat().st_size
        commit_path.write_text(json.dumps(commit), encoding="utf8")

    def test_independent_prepared_count_checker_accepts_the_original_complete_family(self):
        from check_prepared import run
        with tempfile.TemporaryDirectory(prefix="human_check_seam_") as temporary:
            receipt = run(CAPSULE, META, PACKAGE / "reference", Path(temporary) / "check")
            self.assertEqual(receipt["status"], "PASS_PREPARED_COUNT_RESULTS")
            self.assertEqual(receipt["statistics_payloads_checked"], 12)
            self.assertEqual(receipt["member_measurements_checked"], 423)
            self.assertEqual(receipt["matched_null_sets_checked"], 10000)
            self.assertEqual(receipt["gene_LOO_states_checked"] + receipt["sample_LOO_states_checked"], 14)
            self.assertEqual(receipt["frozen_core_math_functions_called"], 0)
            self.assertTrue(receipt["matched_rng_draw_sequence_independently_rebuilt"])

    def test_complete_submitted_capsule_reproduces_the_six_programme_family(self):
        from reproduce import run
        with tempfile.TemporaryDirectory(prefix="human_count_seam_") as temporary:
            root = Path(temporary) / "output"
            receipt = run(CAPSULE, META, root)
            self.assertEqual(receipt["gene_count"], 36591)
            self.assertEqual(receipt["statistics_payload_count"], 12)
            with (root / "statistics" / "PROGRAMME_TESTS.tsv").open(encoding="utf8") as handle:
                rows = list(csv.DictReader(handle, delimiter="\t"))
            # Independent source of truth: the original submitted programme table.
            expected = [
                ("Resident_identity", -0.08639138211310204, 13),
                ("Fibrosis", 0.2362814924769718, 14),
                ("ECM_degradation", -0.13097910083529457, 20),
                ("Stress_senescence", -0.20731961060998777, 23),
                ("JAK_STAT_NFkB", -0.4364913627224952, 28),
                ("Myeloid_signature", -0.32469710320654477, 20),
            ]
            self.assertEqual([row["programme"] for row in rows], [row[0] for row in expected])
            for row, (name, effect, extremes) in zip(rows, expected):
                self.assertAlmostEqual(float(row["effect"]), effect, places=13)
                self.assertEqual(float(row["p_exact"]), extremes / 35)
                self.assertEqual(float(row["p_holm6"]), 1.0)
            analysis = json.loads((root / "statistics" / "NATURAL_ANALYSIS.json").read_text())
            self.assertEqual(analysis["terminal_state"], "DIRECTIONAL_NOT_SIGNIFICANT")
            self.assertEqual(len(analysis["resident_leave_one_gene_out"]), 7)
            self.assertEqual(len(analysis["resident_leave_one_sample_out"]), 7)


if __name__ == "__main__":
    unittest.main()
