"""One saved-world replay child, CPU2/tree4GiB/300s; relative data, no training."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
import psutil
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def ident(process):return {'pid':process.pid,'creation_time':process.create_time(),'command':process.cmdline()}
def matches(process,record):
    try:return ident(process)==record
    except (psutil.NoSuchProcess,psutil.AccessDenied):return False
def stop(process,record):
    if not matches(process,record):return
    victims=[]
    for child in process.children(recursive=True):
        try:victims.append((child,ident(child)))
        except psutil.NoSuchProcess:pass
    for member,value in reversed(victims+[(process,record)]):
        if matches(member,value):
            try:member.kill()
            except psutil.NoSuchProcess:pass
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--packet-root',required=True);parser.add_argument('--output',required=True);parser.add_argument('--python',default=sys.executable);args=parser.parse_args()
    root=Path(args.packet_root).resolve();out=Path(args.output).resolve();control=out.with_name(out.name+'_execution')
    if out.exists() or control.exists():raise FileExistsError('Fresh saved-world replay only; no retry')
    control.mkdir(parents=True);owner=psutil.Process();affinity=owner.cpu_affinity()[:2];owner.cpu_affinity(affinity)
    command=[args.python,'-B',str(root/'code/replay_saved_worlds.py'),'--packet-root',str(root),'--output',str(out)]
    env=dict(os.environ);env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf8')
    for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[key]='2'
    started=time.monotonic();peak=0;violation=None;observed={};exitcode=None
    with (control/'STDOUT.log').open('xb') as sout,(control/'STDERR.log').open('xb') as serr:
        child=subprocess.Popen(command,stdout=sout,stderr=serr,env=env,cwd=str(root));process=psutil.Process(child.pid);identity=ident(process)
        while child.poll() is None:
            rss=owner.memory_info().rss
            for member in owner.children(recursive=True):
                try:
                    value=ident(member);observed[(value['pid'],value['creation_time'])]=value;member.cpu_affinity(affinity);rss+=member.memory_info().rss
                except psutil.NoSuchProcess:pass
            peak=max(peak,rss)
            if time.monotonic()-started>=300:violation='300s wall exceeded'
            if rss>4294967296:violation='4GiB process-tree RSS exceeded'
            if violation:stop(process,identity);break
            time.sleep(.1)
        exitcode=child.wait()
    report=out/'REPLAY_REPORT.json';complete=exitcode==0 and violation is None and report.is_file()
    packet={'status':'ACTUAL_SAVED_WORLD_REPLAY_COMPLETE' if complete else 'FAILED_RETAINED_NO_RETRY','actual_child_external_exit_code':exitcode,'resource_violation':violation,
        'command':command,'process_identity':identity,'observed_descendants':list(observed.values()),'elapsed_seconds':time.monotonic()-started,'peak_process_tree_RSS_bytes':peak,'CPU_affinity':affinity,
        'resource_contract':{'CPU':2,'RSS_bytes':4294967296,'wall_seconds':300},'replay_report_sha256':sha(report) if report.is_file() else None,
        'new_draws_or_fits':0,'fresh_extracted_packet_root':str(root)}
    with (control/'ACTUAL_REPLAY_EXTERNAL_EXIT.json').open('x',encoding='utf8') as stream:json.dump(packet,stream,ensure_ascii=False,indent=2)
    print(json.dumps({key:packet[key] for key in ('status','actual_child_external_exit_code','resource_violation','elapsed_seconds','peak_process_tree_RSS_bytes')}))
    return 0 if complete else 1
if __name__=='__main__':raise SystemExit(main())
