from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent;source=R/'results_v2/spot_measurements.tsv.gz';df=pd.read_csv(source,sep='\t')
df['zone']=df.partition.str.replace(r'_\d+$','',regex=True)
zones=['NP','Inner_AF','Outer_AF'];metrics=['Resident_identity','Matrix2','Other5','Fibrosis']
rows=[];coverage=[];group={}
for sample,x in df.groupby('sampleid'):
    sections=sorted(x.section.unique());assert len(sections)==2
    work=x[x.zone.isin(zones)]
    for s,g in x.groupby('section'):
        n=int(g.zone.isin(zones).sum());coverage.append({'sampleid':sample,'section':s,'retained_spots':n,'whole_section_spots':len(g),'retained_fraction':n/len(g)})
    for metric in metrics:
        ps=[];ms=[];actual=[]
        for s in sections:
            sub=work[work.section==s];assert set(sub.zone.unique())==set(zones)
            ps.append(sub.zone.value_counts().reindex(zones).to_numpy()/len(sub))
            ms.append(sub.groupby('zone')[metric].mean().reindex(zones).to_numpy());actual.append(sub[metric].mean())
        ps=np.array(ps);ms=np.array(ms);p=ps.mean(axis=0);m=(ps*ms).mean(axis=0)/p
        assert np.isclose(p@m,np.mean(actual),atol=1e-12,rtol=0)
        group[sample,metric]=(p,m,float(np.mean(actual)))
        for z,pz,mz in zip(zones,p,m):rows.append({'sampleid':sample,'metric':metric,'legacy_zone':z,'section_equal_zone_fraction':pz,'weighted_within_zone_mean':mz,'restricted_mean':np.mean(actual)})
contrasts=[];pieces=[];errs=[]
for sample in ['Day_1','Day_3','Day_28']:
    for metric in metrics:
        p0,m0,a0=group['Control',metric];p1,m1,a1=group[sample,metric]
        mix=(p1-p0)*(m1+m0)/2;within=(m1-m0)*(p1+p0)/2
        err=abs((a1-a0)-sum(mix+within));assert err<1e-12;errs.append(err)
        contrasts.append({'sampleid':sample,'reference':'Control','metric':metric,'mean_difference':a1-a0,'annotation_mixture_component':mix.sum(),'within_annotation_component':within.sum(),'identity_error':err,'causal_interpretation':False})
        for i,z in enumerate(zones):pieces.append({'sampleid':sample,'metric':metric,'legacy_zone':z,'mixture_component':mix[i],'within_component':within[i]})
for name,data in [('annotation_decomposition',contrasts),('annotation_decomposition_by_zone',pieces),('annotation_group_means',rows),('annotation_support_coverage',coverage)]:pd.DataFrame(data).to_csv(R/'results_v2'/f'{name}.tsv',sep='\t',index=False)
report={'status':'PASS_EXACT_DESCRIPTIVE_IDENTITY_ALL12_CONTRASTS','max_identity_error':max(errs),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'plan_sha256':hashlib.sha256((R/'POSTHOC_DECOMPOSITION_PLAN.md').read_bytes()).hexdigest(),'posthoc':True,'strata':zones,'independent_anatomy':False,'causal_fraction':False}
(R/'DECOMPOSITION_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(pd.DataFrame(contrasts).to_string(index=False))
