# Public path adaptation: help/description precedes all original scientific imports.
import argparse as _public_argparse
import json as _public_json
from pathlib import Path as _PublicPath
import sys as _public_sys
_public_description = {'purpose': 'path-interface description; no scientific execution', 'required_bindings': ['programme_file', 'project_root', 'source_root'], 'expected_layout': 'project-root/REPORT.json and run.py provenance; source-root/IVD_CATALOGUE_REPORT.json and derived_structure/*.loom. Original ASSESSMENT.json remains under project-root.', 'data_reads': 0, 'heavy_imports': 0, 'original_scientific_body_preserved_except_declared_path_assignment_values': True}
_public_parser = _public_argparse.ArgumentParser(description="Original analysis with explicit caller-owned paths; no data are bundled.")
_public_parser.add_argument('--describe-inputs', action='store_true', help='Print input layout and exit before imports/data access')
for _public_key in _public_description['required_bindings']:
    _public_parser.add_argument('--'+_public_key.replace('_','-'))
_public_args = _public_parser.parse_args()
if _public_args.describe_inputs:
    print(_public_json.dumps(_public_description))
    raise SystemExit(0)
for _public_key in _public_description['required_bindings']:
    if getattr(_public_args,_public_key) is None:
        _public_parser.error('Required binding: --'+_public_key.replace('_','-'))
def _public_binding(_public_key):
    return _PublicPath(getattr(_public_args,_public_key)).expanduser().resolve()
# Begin the preserved original body. Only declared path-assignment values differ.
import csv
from decimal import Decimal, localcontext
import hashlib
import json
import math
from pathlib import Path
import re
import h5py

here=_public_binding('project_root')
old=_public_binding('source_root')
report=json.loads((here/'REPORT.json').read_text(encoding='utf-8'))
catalogue=json.loads((old/'IVD_CATALOGUE_REPORT.json').read_text(encoding='utf-8'))
source=next(x for x in catalogue if x['name']=='GSE300462_family.soft.gz')
gsm=None;mapping={}
for line in source['selected_metadata']:
    if line.startswith('^SAMPLE = '):gsm=line.split(' = ')[1]
    if line.startswith('!Sample_supplementary_file'):
        filename=line.split(' = ')[1].rsplit('/',1)[1]
        mapping.setdefault(gsm,[]).append(filename)
frozen=_public_binding('programme_file')
with frozen.open(encoding='utf-8-sig') as stream:programmes={r['programme']:r['genes'].split(';') for r in csv.DictReader(stream,delimiter='\t')}
targets=set().union(*map(set,programmes.values()))
result=[];maxdiff=0
for rec in report['records']:
    gsm=rec['file'].split('_')[0]
    rnatracks=[x for x in mapping[gsm] if re.fullmatch(gsm+r'_Donor\d+_RNA.bam.1kb.bw',x)]
    assert len(rnatracks)==1
    donor=int(re.search(r'_Donor(\d+)_',rnatracks[0])[1])
    assert f'{gsm}_PZ-human-NPCs{donor}.loom.gz' in mapping[gsm]
    assert f'{gsm}_NPCs{donor}_ChIC_1kb.bw' in mapping[gsm]
    assert donor==rec['source_assigned_donor']
    with h5py.File(old/'derived_structure'/rec['file'],'r') as h:
        genes=[x.decode() if isinstance(x,bytes) else str(x) for x in h['row_attrs/Gene'][:]]
        sums={};member={}
        for layer in ('spliced','unspliced','ambiguous'):
            matrix=h['layers'][layer][:].tolist()
            total=0;targetsums={}
            for gene,row in zip(genes,matrix):
                assert all(math.isfinite(v) and v>=0 and float(v).is_integer() for v in row)
                s=sum(int(v) for v in row);total+=s
                if gene in targets:targetsums[gene]=s
            assert total==rec['layer_totals'][layer]
            sums[layer]=total;member[layer]=targetsums
    for name,layers in {'assigned_S_U':['spliced','unspliced'],'spliced_only':['spliced'],'inclusive_S_U_A':['spliced','unspliced','ambiguous']}.items():
        denominator=sum(sums[x] for x in layers)
        assert denominator==rec['views'][name]['library_total']
        values={}
        with localcontext() as ctx:
            ctx.prec=40
            for gene in targets:
                count=sum(member[x][gene] for x in layers)
                assert count==rec['views'][name]['target_counts'][gene]
                values[gene]=(Decimal(1)+Decimal(10000)*Decimal(count)/Decimal(denominator)).ln()
                diff=abs(float(values[gene])-rec['views'][name]['target_log1p_CP10K'][gene]);maxdiff=max(diff,maxdiff)
                assert diff<1e-12
            for p,gs in programmes.items():
                value=sum(values[g] for g in gs)/Decimal(len(gs))
                diff=abs(float(value)-rec['views'][name]['programmes'][p]);maxdiff=max(diff,maxdiff)
                assert diff<1e-12
    values=rec['views']['assigned_S_U']['target_log1p_CP10K']
    gs=programmes['Resident_identity'];den=sum(values[g] for g in gs)
    result.append({'gsm':gsm,'donor_from_explicit_RNA_track_name':donor,'same_GSM_RNA_ChIC_loom_binding':True,
                   'Resident_log_score_member_fractions':{g:None if den==0 else values[g]/den for g in gs},
                   'RNA_TBXT_count':rec['views']['assigned_S_U']['target_counts']['TBXT']})
out={'status':'PASS_INTEGER_SUMS_DECIMAL_SCORES_AND_SOURCE_FILE_BINDING','donors':result,
     'count_checks':5*3*47,'programme_checks':5*3*6,'max_abs_float_vs_decimal':maxdiff,
     'new_model_fits':0,'genome_origin_not_proven_by_file_names':True,
     'run_source_sha256':hashlib.sha256((here/'run.py').read_bytes()).hexdigest()}
(here/'ASSESSMENT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=True))
