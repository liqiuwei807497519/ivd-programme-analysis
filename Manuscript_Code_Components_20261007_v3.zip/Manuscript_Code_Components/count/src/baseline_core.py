"""Fixed four-baseline capture task; numerical arrays only, no file I/O.

Exposure uses exactly 126 permitted inputs. All statistical fitting uses the
training capture only. Invalid predictions raise an explicit contract failure;
there is no clipping, positive floor, target deletion, or alternative fitting.
"""
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp


GENES = ('TBXT', 'KRT8', 'KRT18', 'KRT19', 'ACAN', 'COL2A1', 'SOX9')
METHODS = ('AnchorRate', 'RidgeRate', 'TotalFixed', 'TotalRidge')
N_INPUTS = 126
N_BINS = 9


class ContractError(RuntimeError):
    def __init__(self, message, details=None):
        super().__init__(message)
        self.details = dict(details or {})


def _fail(message, stage, **details):
    raise ContractError(message, {'stage': stage, **details})


def _counts(value, columns, stage):
    try:
        result = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError) as exc:
        _fail('Count array is not numeric', stage, cause=str(exc))
    if result.ndim != 2 or result.shape[1] != columns or result.shape[0] < 1:
        _fail('Count array has the wrong shape', stage, shape=list(result.shape), required_columns=columns)
    if not np.isfinite(result).all() or np.any(result < 0) or np.any(result != np.floor(result)):
        _fail('Raw counts must be finite nonnegative integers', stage)
    return result


def _finite_positive(means, stage):
    value = np.asarray(means, dtype=np.float64)
    view = value[:, None] if value.ndim == 1 else value
    bad_finite = ~np.isfinite(view)
    bad_positive = np.isfinite(view) & (view <= 0)
    bad = bad_finite | bad_positive
    if bad.any():
        minima = []
        for column in view.T:
            finite = column[np.isfinite(column)]
            minima.append(float(finite.min()) if finite.size else None)
        finite = view[np.isfinite(view)]
        _fail(
            'Prediction must be strictly positive and finite', stage,
            per_gene_counts=bad.sum(axis=0).astype(int).tolist(),
            per_gene_nonpositive_counts=bad_positive.sum(axis=0).astype(int).tolist(),
            per_gene_nonfinite_counts=bad_finite.sum(axis=0).astype(int).tolist(),
            minimum_per_gene=minima,
            minimum=float(finite.min()) if finite.size else None,
            first_10_eval_indices=np.flatnonzero(bad.any(axis=1))[:10].astype(int).tolist(),
            invalid_elements=int(bad.sum()),
        )


def input_features(counts126):
    """Return target-free raw features and exposure for fixed nine-bin regions."""
    counts = _counts(counts126, N_INPUTS, 'input_features')
    with np.errstate(over='ignore', invalid='ignore'):
        exposure = 1.0 + counts.sum(axis=1)
        features = np.column_stack((
            np.log1p(1000.0 * (counts / exposure[:, None])),
            np.log(exposure),
            np.full(len(counts), np.log(float(N_BINS))),
        ))
    if not np.isfinite(exposure).all() or np.any(exposure <= 0) or not np.isfinite(features).all():
        _fail('Nonfinite input feature or exposure', 'input_features')
    return features, exposure


def _standardize(train, evaluation, weights):
    mean = weights @ train
    sd = np.maximum(np.sqrt(weights @ ((train - mean) ** 2)), 0.1)
    train_x = np.column_stack((np.ones(len(train)), (train - mean) / sd))
    evaluation_x = np.column_stack((np.ones(len(evaluation)), (evaluation - mean) / sd))
    if not np.isfinite(train_x).all() or not np.isfinite(evaluation_x).all():
        _fail('Nonfinite standardized feature', 'standardization')
    return train_x, evaluation_x, {'mean': mean, 'sd': sd}


def predict_ridge(model, standardized_x, exposure):
    """Apply the original smeared inverse transform without clipping/floors.

    Returns (means, diagnostics). Equivalent log-domain evaluation prevents
    overflow in intermediate smearing factors from altering the fitted formula.
    """
    x = np.asarray(standardized_x, dtype=float)
    e = np.asarray(exposure, dtype=float)
    coef = np.asarray(model['coef'], dtype=float)
    log_smear = np.asarray(model['log_smear'], dtype=float)
    if (x.ndim != 2 or coef.ndim != 2 or coef.shape != (x.shape[1], 7)
            or e.shape != (len(x),) or log_smear.shape != (7,)
            or not np.isfinite(x).all() or not np.isfinite(coef).all()
            or not np.isfinite(e).all() or np.any(e <= 0)
            or not np.isfinite(log_smear).all()):
        _fail('Invalid ridge prediction inputs/model', 'ridge_prediction')
    with np.errstate(over='ignore', invalid='ignore'):
        z = x @ coef
        a = z + log_smear
    if not np.isfinite(z).all() or not np.isfinite(a).all():
        invalid = ~np.isfinite(a)
        finite_minima = []
        for column in a.T:
            finite = column[np.isfinite(column)]
            finite_minima.append(float(finite.min()) if finite.size else None)
        finite_values = a[np.isfinite(a)]
        _fail('Nonfinite ridge linear predictor', 'ridge_prediction',
              per_gene_counts=invalid.sum(axis=0).astype(int).tolist(),
              per_gene_nonfinite_counts=invalid.sum(axis=0).astype(int).tolist(),
              minimum_per_gene=finite_minima,
              minimum=float(finite_values.min()) if finite_values.size else None,
              first_10_eval_indices=np.flatnonzero(invalid.any(axis=1))[:10].tolist())
    mu = np.empty_like(a)
    positive = a > 0
    small = positive & (a <= np.log(2.0))
    large = positive & ~small
    log_difference = np.zeros_like(a)
    with np.errstate(over='ignore', under='ignore', invalid='ignore', divide='ignore'):
        log_difference[small] = np.log(np.expm1(a[small]))
        log_difference[large] = a[large] + np.log1p(-np.exp(-a[large]))
        log_mu = np.log(e)[:, None] - np.log(1000.0) + log_difference
        mu[positive] = np.exp(log_mu[positive])
        multiplier = np.broadcast_to(e[:, None] / 1000.0, a.shape)
        mu[~positive] = multiplier[~positive] * np.expm1(a[~positive])
    _finite_positive(mu, 'ridge_prediction')
    return mu, {
        'old_z_clip_range_exceeded_per_gene': (np.abs(z) > 40).sum(axis=0).astype(int).tolist(),
        'minimum_per_gene': mu.min(axis=0).tolist(),
        'old_range_is_diagnostic_only': True,
        'prediction_repairs': 0,
    }


def poisson_objective(beta, x, y, exposure, weights, alpha=0.01):
    """Original offset-count objective, normalized by mean input exposure."""
    eta = x @ beta
    with np.errstate(over='ignore', under='ignore', invalid='ignore'):
        mu = np.exp(np.log(exposure) + eta)
        den = weights @ exposure
        value = (weights @ (mu - y * eta)) / den + 0.5 * alpha * np.sum(beta[1:] ** 2)
        gradient = x.T @ (weights * (mu - y)) / den
        gradient[1:] += alpha * beta[1:]
    if not np.isfinite(eta).all() or not np.isfinite(value) or not np.isfinite(gradient).all():
        _fail('Nonfinite Poisson optimization evaluation', 'total_optimization')
    if np.any(mu <= 0):
        _finite_positive(mu, 'total_optimization')
    return float(value), gradient


def _fit_total(x, total, e, weights, alpha):
    start = np.zeros(x.shape[1])
    start[0] = np.log(weights @ total) - np.log(weights @ e)
    result = minimize(
        poisson_objective, start, args=(x, total, e, weights, alpha), jac=True,
        method='L-BFGS-B',
        options={'maxiter': 1500, 'gtol': 1e-8, 'ftol': 1e-12, 'maxls': 40},
    )
    if (not result.success or not np.isfinite(result.x).all()
            or not np.isfinite(result.fun) or not np.isfinite(result.jac).all()):
        _fail('Poisson total optimization did not converge', 'total_optimization',
              success=bool(result.success), optimizer_message=str(result.message), iterations=int(result.nit))
    return {
        'kind': 'poisson_total', 'coef': result.x, 'alpha': alpha,
        'success': bool(result.success), 'iterations': int(result.nit),
        'function_evaluations': int(result.nfev), 'message': str(result.message),
        'objective': float(result.fun), 'gradient_max': float(np.abs(result.jac).max()),
    }


def fit_predict(train_counts126, train_y7, eval_counts126, ridge_alpha=1.0, total_alpha=0.01):
    """Fit the locked four baselines on one capture; predict the other capture.

    No evaluation targets are accepted. The caller owns geometry/key checks,
    path isolation, prediction commits, and the later independent scorer.
    """
    if ridge_alpha != 1.0 or total_alpha != 0.01:
        _fail('This version has fixed alpha values', 'parameter_contract',
              ridge_alpha=float(ridge_alpha), total_alpha=float(total_alpha))
    train = _counts(train_counts126, N_INPUTS, 'train_inputs')
    y = _counts(train_y7, 7, 'train_targets')
    evaluation = _counts(eval_counts126, N_INPUTS, 'eval_inputs')
    if len(train) != len(y):
        _fail('Training inputs/targets do not have matching rows', 'train_alignment')
    zero = ~np.any(y > 0, axis=0)
    if zero.any():
        _fail('A training target is entirely zero; direction is not estimable', 'train_target_support',
              zero_gene_indices=np.flatnonzero(zero).astype(int).tolist(),
              zero_genes=[GENES[i] for i in np.flatnonzero(zero)],
              per_gene_counts=(zero.astype(int) * len(y)).tolist(),
              minimum_per_gene=y.min(axis=0).tolist(), minimum=float(y.min()),
              first_10_eval_indices=[],
        )
    weights = np.full(len(train), 1.0 / len(train))
    raw_train, e_train = input_features(train)
    raw_eval, e_eval = input_features(evaluation)
    x_train, x_eval, standardizer = _standardize(raw_train, raw_eval, weights)
    means = weights @ y
    total_train = y.sum(axis=1)
    if not np.isfinite(means).all() or not np.isfinite(total_train).all():
        _fail('Training target aggregation is nonfinite', 'train_target_support')
    member_scales = np.maximum(means, 1.0)
    total_scale = float(max(weights @ total_train, 1.0))
    anchor_rates = means / (weights @ e_train)
    anchor = e_eval[:, None] * anchor_rates
    _finite_positive(anchor, 'anchor_prediction')

    z_train = np.log1p(1000.0 * (y / e_train[:, None]))
    penalty = np.eye(x_train.shape[1]) * ridge_alpha
    penalty[0, 0] = 0.0
    try:
        coef = np.linalg.solve(
            x_train.T @ (weights[:, None] * x_train) + penalty,
            x_train.T @ (weights[:, None] * z_train),
        )
    except np.linalg.LinAlgError as exc:
        _fail('Ridge solve failed', 'ridge_fit', cause=str(exc))
    residual = z_train - x_train @ coef
    log_smear = logsumexp(np.log(weights)[:, None] + residual, axis=0)
    if not np.isfinite(coef).all() or not np.isfinite(residual).all() or not np.isfinite(log_smear).all():
        _fail('Ridge fit or training smearing is nonfinite', 'ridge_fit')
    ridge_model = {'kind': 'ridge', 'coef': coef, 'log_smear': log_smear, 'alpha': ridge_alpha}
    ridge, ridge_diagnostics = predict_ridge(ridge_model, x_eval, e_eval)

    total_model = _fit_total(x_train, total_train, e_train, weights, total_alpha)
    eta_total = x_eval @ total_model['coef']
    with np.errstate(over='ignore', under='ignore', invalid='ignore'):
        total_prediction = np.exp(np.log(e_eval) + eta_total)
    _finite_positive(total_prediction, 'total_prediction')
    fixed_composition = means / means.sum()
    total_fixed = total_prediction[:, None] * fixed_composition
    # Scaling before normalization avoids overflow of a finite RR row sum.
    relative = ridge / ridge.max(axis=1, keepdims=True)
    ridge_composition = relative / relative.sum(axis=1, keepdims=True)
    total_ridge = total_prediction[:, None] * ridge_composition
    predictions = dict(zip(METHODS, (anchor, ridge, total_fixed, total_ridge)))
    for name, prediction in predictions.items():
        if prediction.shape != (len(evaluation), 7):
            _fail('Incorrect prediction shape', 'prediction_invariant', method=name)
        _finite_positive(prediction, name + '_prediction')
    for name in ('TotalFixed', 'TotalRidge'):
        if not np.allclose(predictions[name].sum(axis=1), total_prediction, rtol=1e-12, atol=0):
            _fail('Common total conservation failed', 'prediction_invariant', method=name)
    if not np.allclose(total_ridge / total_ridge.sum(axis=1, keepdims=True),
                       ridge_composition, rtol=1e-12, atol=0):
        _fail('TotalRidge failed to preserve RidgeRate member proportions', 'prediction_invariant')
    return {
        'predictions': predictions,
        'member_scales': member_scales,
        'total_scale': total_scale,
        'models': {
            'ridge': ridge_model, 'total': total_model,
            'anchor_rates': anchor_rates, 'fixed_composition': fixed_composition,
            'standardizer': standardizer,
        },
        'fit_ledger': [
            {'object': 'ridge', 'member_heads': 7, 'alpha': ridge_alpha, 'training_rows': len(train)},
            {'object': 'poisson_total', 'total_heads': 1, 'alpha': total_alpha, 'training_rows': len(train)},
        ],
        'diagnostics': {
            'training_rows': len(train), 'evaluation_rows': len(evaluation),
            'input_columns': N_INPUTS, 'region_bins': N_BINS,
            'train_exposure_min': float(e_train.min()), 'train_exposure_max': float(e_train.max()),
            'eval_exposure_min': float(e_eval.min()), 'eval_exposure_max': float(e_eval.max()),
            'ridge': ridge_diagnostics,
            'old_residual_clip_range_exceeded_per_gene': (np.abs(residual) > 40).sum(axis=0).astype(int).tolist(),
            'old_total_eta_clip_range_exceeded': int((np.abs(eta_total) > 40).sum()),
            'old_range_is_diagnostic_only': True,
            'fit_objects': 2, 'scalar_heads': 8,
            'constant_statistics': ['anchor_rates', 'fixed_composition'],
            'prediction_repairs': 0, 'common_total_conserved': True,
            'ridge_member_proportions_preserved': True,
        },
    }
