"""Independent full-row RNA mean audit; never imports fitted heads or scorer."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np

from rna_numeric_audit import independent_deviance, independent_decomposition

METHODS = ('AnchorRate', 'memberRidge', 'memberPoisson',
           'sourceTotal_fixedComposition', 'sourceTotal_learnedComposition')
GROUPS = ('Control', 'Day_1', 'Day_3', 'Day_28')
GENES = ('TBXT', 'KRT8', 'KRT18', 'KRT19', 'ACAN', 'COL2A1', 'SOX9')


def readj(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify(record):
    path = Path(record['path']).resolve()
    if sha(path) != record['sha256']:
        raise ValueError('Independent immutable hash mismatch: ' + str(path))
    return path


def close(actual, expected, name):
    value = float(actual)
    if math.isnan(value) or (math.isinf(expected) and value != expected):
        raise ValueError(name + ': invalid nonfinite score')
    if math.isfinite(expected) and not math.isclose(value, expected, rel_tol=2e-9, abs_tol=2e-10):
        raise ValueError(name + ': independent value mismatch')


def boolean(value):
    if value in (True, 'true', 'True', '1', 1):
        return True
    if value in (False, 'false', 'False', '0', 0):
        return False
    raise ValueError('Invalid Boolean field: ' + str(value))


def check_numeric_row(row, truth, mean, scale):
    expected = independent_deviance(truth, mean)
    for name, value in (('truth_count', truth), ('predicted_mean', mean),
                        ('source_scale', scale), ('poisson_deviance', expected),
                        ('scaled_poisson_deviance', expected / scale),
                        ('absolute_error', abs(truth - mean))):
        close(row[name], value, name)
    if boolean(row['truth_is_zero']) != (truth == 0):
        raise ValueError('truth_is_zero mismatch')
    status = 'finite' if math.isfinite(expected) else 'positive_truth_zero_mean'
    if row['score_status'] != status:
        raise ValueError('score_status mismatch')
    return 7


def arrays(record):
    with np.load(verify(record), allow_pickle=False) as capsule:
        return {key: capsule[key] for key in capsule.files}


def project_integer(values, inverse, count):
    result = np.zeros((count, 7), dtype=np.int64)
    for roi in range(count):
        for gene in range(7):
            result[roi, gene] = sum(int(v) for v in values[inverse == roi, gene])
    return result


def source_scales(sections, training):
    members, totals = [], []
    for parent in training:
        within = [section for section in sections.values() if section['parent'] == parent]
        members.append(np.mean([s['ROI_truth'].mean(axis=0) for s in within], axis=0))
        totals.append(np.mean([np.mean([sum(map(int, row)) for row in s['ROI_truth']]) for s in within]))
    return np.maximum(1, np.mean(members, axis=0)), max(1., float(np.mean(totals)))


def audit(config_path, run_root, output):
    config_path, root, output = Path(config_path), Path(run_root), Path(output)
    config, config_hash = readj(config_path), sha(config_path)
    barrier = readj(root / 'ALL_FORECASTS_COMMIT.json')
    score_commit = readj(root / 'score/SCORE_COMMIT.json')
    if (barrier['status'] != 'ALL_FOUR_OUTER_FORECASTS_COMMITTED'
            or set(barrier['folds']) != set(GROUPS)
            or barrier['config_sha256'] != config_hash
            or score_commit['status'] != 'SCORES_COMPLETE'
            or score_commit['config_sha256'] != config_hash):
        raise ValueError('Complete forecast and score barriers required before audit labels')
    for parent in GROUPS:
        entry = barrier['folds'][parent]
        verify(entry)
        receipt = readj(root / 'process_receipts' / ('fold_' + parent + '.json'))
        if entry['external_exit_code'] != 0 or receipt['external_exit_code'] != 0 or receipt['resource_violation'] is not None:
            raise ValueError('Every full outer forecast requires an actual successful external receipt')
    score_receipt = readj(root / 'process_receipts/score.json')
    if score_receipt['external_exit_code'] != 0 or score_receipt['resource_violation'] is not None:
        raise ValueError('Actual complete scorer exit0 required')
    records = list(config['code_binding']) + [config['plan_binding'], config['authorization_binding']]
    for section in config['sections']:
        records.extend(section[name] for name in ('counts', 'coordinates', 'features', 'exports'))
    before = {str(verify(item)): item['sha256'] for item in records}
    prepared_path = root / 'prepared/PREPARE_COMMIT.json'
    prepared = readj(prepared_path)
    if barrier['prepared_commit_sha256'] != sha(prepared_path):
        raise ValueError('Prepared commit changed before scoring')
    sections = {}
    for declared in config['sections']:
        name = declared['section_folder']
        item = prepared['sections'][name]
        x, y = arrays(item['artifacts']['INPUTS.npz']), arrays(item['artifacts']['SOURCE_LABELS.npz'])
        if (not np.array_equal(x['region_id'], y['region_id'])
                or not np.array_equal(x['barcode'], y['barcode'])
                or len(x['region_id']) != declared['expected_rows']
                or y['y_counts'].shape != (declared['expected_rows'], 7)
                or y['y_counts'].dtype.kind not in 'iu' or np.any(y['y_counts'] < 0)):
            raise ValueError('Independent source input-label complete join failed')
        sections[name] = {'parent': declared['parent'], **x, **y,
                          'ROI_truth': project_integer(y['y_counts'], x['roi_indices'], len(x['roi_keys']))}
    expected = {}
    nominal_rois = 0
    for parent in GROUPS:
        commit = readj(verify(barrier['folds'][parent]))
        if commit['heldout_response_reads'] != 0 or commit['training_parents'] != [p for p in GROUPS if p != parent]:
            raise ValueError('Outer training split/held response exclusion mismatch')
        payloads = commit['artifacts']
        params = readj(verify(payloads['FOLD_PARAMS.json']))
        verify(payloads['SELECTION.json'])
        scale7, total_scale = source_scales(sections, [p for p in GROUPS if p != parent])
        np.testing.assert_allclose(params['source_scales7'], scale7, rtol=1e-12, atol=1e-12)
        close(params['source_scale_total'], total_scale, 'training-only total scale')
        fixed = params['bundles'][METHODS[3]]
        learned = params['bundles'][METHODS[4]]
        if (fixed['total_head'] != learned['total_head'] or fixed['scaler'] != learned['scaler']
                or fixed['total_checkpoint_sha256'] != learned['total_checkpoint_sha256']):
            raise ValueError('Paired compositions changed total head/scaler')
        native, roi = arrays(payloads['NATIVE_MEANS.npz']), arrays(payloads['ROI_MEANS.npz'])
        n_cursor, r_cursor = 0, 0
        for declared in (s for s in config['sections'] if s['parent'] == parent):
            name = declared['section_folder']
            section = sections[name]
            n, r = len(section['region_id']), len(section['roi_keys'])
            nominal_rois += r
            ns, rs = slice(n_cursor, n_cursor + n), slice(r_cursor, r_cursor + r)
            if (not np.array_equal(native['region_id'][ns], section['region_id'])
                    or not np.array_equal(native['barcode'][ns], section['barcode'])
                    or not np.all(native['section_id'][ns] == name)
                    or not np.all(native['parent_id'][ns] == parent)
                    or not np.array_equal(roi['roi_keys'][rs], section['roi_keys'])
                    or not np.all(roi['roi_section_id'][rs] == name)):
                raise ValueError('Full canonical forecast keys mismatch')
            for method in METHODS:
                mu_native, mu_roi = native[method][ns], roi[method][rs]
                if mu_native.shape != (n, 7) or mu_roi.shape != (r, 7) or not np.isfinite(mu_native).all() or np.any(mu_native < 0):
                    raise ValueError('Invalid or incomplete7-member means')
                projected = np.zeros((r, 7))
                np.add.at(projected, section['roi_indices'], mu_native)
                np.testing.assert_allclose(mu_roi, projected, rtol=1e-12, atol=1e-12)
                for level, truth, means, ids in (
                        ('native', section['y_counts'], mu_native, section['region_id']),
                        ('ROI', section['ROI_truth'], mu_roi, section['roi_keys'])):
                    for index, (yv, mv, identifier) in enumerate(zip(truth, means, ids)):
                        support = str(identifier) if level == 'native' else tuple(map(int, identifier))
                        for g, endpoint in enumerate(GENES):
                            expected[(level, parent, name, method, endpoint, support)] = (int(yv[g]), float(mv[g]), float(scale7[g]), None)
                        decomposition = independent_decomposition(yv, mv)
                        expected[(level, parent, name, method, 'TOTAL', support)] = (
                            sum(map(int, yv)), float(mv.sum()), total_scale,
                            (decomposition, math.fsum(independent_deviance(int(y), float(m)) / scale for y, m, scale in zip(yv, mv, scale7)) / 7))
            np.testing.assert_allclose(native[METHODS[3]][ns].sum(axis=1), native[METHODS[4]][ns].sum(axis=1), rtol=1e-12, atol=1e-12)
            n_cursor += n
            r_cursor += r
        if len(native['region_id']) != n_cursor or len(roi['roi_keys']) != r_cursor:
            raise ValueError('Extra forecast rows')
    seen, checks, infinite = set(), 0, 0
    rows_path = verify(score_commit['artifacts']['ROWS.tsv'])
    summary_path = verify(score_commit['artifacts']['SUMMARY.json'])
    with rows_path.open(encoding='utf-8-sig', newline='') as stream:
        for row in csv.DictReader(stream, delimiter='\t'):
            support = row['region_id'] if row['level'] == 'native' else (int(row['roi_x']), int(row['roi_y']))
            key = (row['level'], row['holdout_parent'], row['section_id'], row['method'], row['endpoint'], support)
            if key in seen or key not in expected:
                raise ValueError('Duplicate/undeclared complete score key: ' + str(key))
            seen.add(key)
            truth, mean, scale, extra = expected[key]
            checks += check_numeric_row(row, truth, mean, scale)
            infinite += not math.isfinite(independent_deviance(truth, mean))
            if extra is not None:
                decomposition, scaled7 = extra
                close(row['D7_unscaled'], decomposition['D7'], 'D7_unscaled')
                close(row['Dtotal_unscaled'], decomposition['Dtotal'], 'Dtotal_unscaled')
                close(row['mean7_training_scaled_deviance'], scaled7, 'mean7_training_scaled_deviance')
                if truth == 0:
                    # The allocation loss has zero limit even when the
                    # conditional composition itself is undefined atT=0.
                    close(row['allocation_unscaled'], 0., 'allocation zero-truth limit')
                elif decomposition['allocation_defined']:
                    close(row['allocation_unscaled'], decomposition['allocation'], 'allocation_unscaled')
                elif row['allocation_unscaled'] not in ('', 'null', 'None') or boolean(row['allocation_defined']):
                    raise ValueError('Undefined zero-prediction allocation must remain null')
                checks += 4
    if seen != set(expected) or score_commit['rows'] != len(seen):
        raise ValueError('Complete independent score key coverage failed')
    summary = readj(summary_path)
    if summary['status'] != 'RNA_POINT_MEAN_SUMMARY_COMPLETE':
        raise ValueError('Complete hierarchical summary required')
    aggregate_fields = ('mean7_training_scaled_deviance', 'mean_D7_unscaled',
                        'mean_Dtotal_unscaled', 'member_MAE', 'programme_MAE')
    buckets = {}
    for key, value in expected.items():
        buckets.setdefault(key[:5], []).append((key, value))
    independent_sections = {}
    for name, section in sections.items():
        independent_sections[name] = {}
        for level in ('native', 'ROI'):
            independent_sections[name][level] = {}
            for method in METHODS:
                totals = buckets[(level, section['parent'], name, method, 'TOTAL')]
                metrics = {field: [] for field in aggregate_fields}
                for key, (truth, mean, scale, extra) in totals:
                    decomposition, scaled7 = extra
                    metrics['mean7_training_scaled_deviance'].append(scaled7)
                    metrics['mean_D7_unscaled'].append(decomposition['D7'])
                    metrics['mean_Dtotal_unscaled'].append(decomposition['Dtotal'])
                    metrics['programme_MAE'].append(abs(truth - mean))
                    metrics['member_MAE'].append(sum(abs(expected[(*key[:4], gene, key[5])][0]
                                                               - expected[(*key[:4], gene, key[5])][1]) for gene in GENES) / 7)
                averaged = {field: math.fsum(values) / len(values) for field, values in metrics.items()}
                independent_sections[name][level][method] = averaged
                actual = summary['sections'][name][level][method]
                for field, value in averaged.items():
                    close(actual[field], value, 'section summary ' + field)
                    checks += 1
                for gene in GENES:
                    values = [item for _, item in buckets[(level, section['parent'], name, method, gene)]]
                    actual_gene = actual['members'][gene]
                    member_expected = {
                        'mean_deviance': math.fsum(independent_deviance(y, mu) for y, mu, _, _ in values) / len(values),
                        'mean_training_scaled_deviance': math.fsum(independent_deviance(y, mu) / scale for y, mu, scale, _ in values) / len(values),
                        'MAE': math.fsum(abs(y-mu) for y, mu, _, _ in values) / len(values),
                        'truth_mass': sum(y for y, _, _, _ in values),
                        'predicted_mass': math.fsum(mu for _, mu, _, _ in values),
                        'zero_truth_rows': sum(y == 0 for y, _, _, _ in values),
                        'infinite_loss_rows': sum(y > 0 and mu == 0 for y, mu, _, _ in values)}
                    for field, value in member_expected.items():
                        close(actual_gene[field], value, 'member summary ' + field)
                        checks += 1
    independent_parents = {}
    for parent in GROUPS:
        within = [name for name, section in sections.items() if section['parent'] == parent]
        independent_parents[parent] = {}
        for level in ('native', 'ROI'):
            independent_parents[parent][level] = {}
            for method in METHODS:
                averaged = {field: math.fsum(independent_sections[name][level][method][field] for name in within) / 2
                            for field in aggregate_fields}
                independent_parents[parent][level][method] = averaged
                for field, value in averaged.items():
                    close(summary['parents'][parent][level][method][field], value, 'parent summary ' + field)
                    checks += 1
    for level in ('native', 'ROI'):
        for method in METHODS:
            for field in aggregate_fields:
                macro = math.fsum(independent_parents[parent][level][method][field] for parent in GROUPS) / 4
                close(summary['hierarchical_macro'][level][method][field], macro, 'hierarchical macro ' + field)
                if level == 'ROI' and field == 'mean7_training_scaled_deviance':
                    close(summary['primary']['methods'][method], macro, 'primary endpoint')
                checks += 1
    after = {str(verify(item)): item['sha256'] for item in records}
    if before != after:
        raise ValueError('Frozen source/code changed during independent audit')
    report = {'status': 'RNA_INDEPENDENT_AUDIT_PASS', 'config_sha256': config_hash,
              'native_observations': sum(len(s['region_id']) for s in sections.values()),
              'nominal_ROIs': nominal_rois, 'score_rows': len(seen), 'numeric_checks': checks,
              'infinite_endpoint_rows': infinite, 'all_seven_members_retained': True,
              'full_key_set_verified': True, 'training_only_scales_independently_recomputed': True,
              'paired_total_checkpoint_and_native_ROI_projection_verified': True,
              'independent_all_rows_deviance_and_allocation_recomputed': True,
              'all_member_mass_and_hierarchical_summaries_independently_recomputed': True,
              'frozen_before_after_hashes': before, 'summary_sha256': sha(summary_path),
              'summary_schema_keys': sorted(summary), 'new_independent_biological_test': False}
    with output.open('x', encoding='utf8') as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--run-root', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(audit(args.config, args.run_root, args.output), ensure_ascii=False), flush=True)
    except (ValueError, KeyError, OSError, AssertionError) as error:
        print(json.dumps({'status': 'RNA_INDEPENDENT_AUDIT_FAILED', 'reason': str(error)}), flush=True)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
