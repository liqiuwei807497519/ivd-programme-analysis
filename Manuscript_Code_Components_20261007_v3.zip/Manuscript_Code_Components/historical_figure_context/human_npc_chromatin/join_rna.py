import csv
import json
from pathlib import Path
here=Path(__file__).resolve().parent
rna=json.loads((here.parent/'human_npc_rna_descriptive_20260910/REPORT.json').read_text(encoding='utf-8'))
with (here/'REGION_RESULTS.tsv').open(encoding='utf-8') as f:rows=list(csv.DictReader(f,delimiter='\t'))
lookup={(int(r['donor']),r['gene'],r['region']):r for r in rows}
output=[]
for donor in rna['records']:
    n=donor['source_assigned_donor'];v=donor['views']['assigned_S_U']
    for gene in rna['genes']:
        item={'donor':n,'gsm':donor['file'].split('_')[0],'gene':gene,'RNA_assigned_count':v['target_counts'][gene],
              'RNA_log1p_CP10K':v['target_log1p_CP10K'][gene],'ChIC_regions':{}}
        for region in ('TSS_proxy_10kb','left_10kb','right_10kb','gene_body'):
            r=lookup[n,gene,region]
            item['ChIC_regions'][region]={'signal_mean_covered':None if r['mean_covered']=='NA' else float(r['mean_covered']),
                                         'coverage_fraction':float(r['coverage_fraction'])}
        t=item['ChIC_regions']['TSS_proxy_10kb']['signal_mean_covered']
        l=item['ChIC_regions']['left_10kb']['signal_mean_covered'];r=item['ChIC_regions']['right_10kb']['signal_mean_covered']
        # Post-quantification descriptive display, not an inferential enrichment test.
        denominator=None if l is None or r is None else (l+r)/2
        item['local_signal_ratio_not_enrichment']=None if denominator in (None,0) or t is None else t/denominator
        output.append(item)
assert len(output)==235
(here/'JOINT_RESULTS.json').write_text(json.dumps({'records':output,'ratio_definition':'TSS proxy mean / mean of two adjacent equal-width means; descriptive, not input/IgG enrichment','ratio_added_after_quantification':True,'new_pvalues':False,'new_fits':0},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{'donor':r['donor'],'RNA_count':r['RNA_assigned_count'],'TBXT_local_ratio':r['local_signal_ratio_not_enrichment']} for r in output if r['gene']=='TBXT']))
