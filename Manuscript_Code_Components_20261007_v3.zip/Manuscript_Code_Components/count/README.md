# Regional count prediction reproducibility

This package supplies an executable count-prediction module for the seven fixed disc programme members, a synthetic example, and a prediction-only replay interface. The scientific core is copied byte-for-byte from the completed GSE287499 capture comparison. It implements AnchorRate, RidgeRate, TotalFixed and TotalRidge with the frozen alpha values 1.0 and 0.01.

TotalRidge rescales RidgeRate member proportions to the shared total estimate. Reconciliation and the raw Poisson-deviance decomposition are established constructions. This package does not present them as a new algorithm or as a calibrated joint probability law.

## Install and test

Use Python and the package versions recorded in `ENVIRONMENT.json`. Install dependencies in a fresh environment:

```text
python -m pip install -r requirements.txt
python -B tests/run_tests.py
```

`baseline_core.py` is unchanged. `src/count_cli.py` adds configurable file paths and a strict role schema. The original core's tested rules remain in force: 126 input genes in the frozen order; seven targets in `configs/GENES.json`; nine 16-micrometre bins per 48-micrometre region; no clipping, count floor, target deletion or replacement fit. An entirely zero training member stops the direction. Nonpositive or nonfinite predicted means stop computation. Input exposure is one plus the sum of the 126 permitted input counts and is not interpreted as a pure technical sequencing offset.

## Run the synthetic example

```text
python -B examples/synthetic_demo.py --output synthetic_inputs
python -B src/count_cli.py fit-predict --train-input synthetic_inputs/train_input.npz --eval-input synthetic_inputs/eval_input.npz --output synthetic_fit
python -B src/count_cli.py predict --parameters synthetic_fit/PARAMETERS.json --eval-input synthetic_inputs/eval_input.npz --compare-committed synthetic_fit/PREDICTIONS.npz --output synthetic_replay
```

The example contains known-constant artificial counts. Its 24 training rows and five evaluation rows contain no data from the paper. All four methods predict means `[2, 3, 4, 5, 6, 7, 8]` within the recorded floating-point tolerance.

## Predict from a frozen checkpoint

```text
python -B src/count_cli.py predict --parameters PARAMETERS.json --eval-input eval_input.npz --compare-committed PREDICTIONS.npz --output replay_output
```

The parameters file contains the frozen training standardizer, ridge coefficients, log-smearing factors, total coefficients, anchor rates and fixed composition. The evaluation NPZ must contain exactly `region_id` and `x_counts`, shaped N and N-by-126. Evaluation targets are not accepted. No optimization occurs during replay. The optional committed forecast file supplies a numerical comparison, not new validation targets. The output directory must not already exist. The receipt records input hashes and maximum absolute and relative differences for every method.

The two completed mouse directions were replayed across all 30,829 regional objects and all four methods. See `checks/REAL_REPLAY.json` for the measured tolerance and numerical differences. This is a replay of the already evaluated forecasts; it does not add independent validation.

## Fit on a separately specified legal training set

`fit-predict` accepts training NPZ keys `region_id`, `x_counts`, and `y_counts`; target shape is N-by-seven. Evaluation inputs have no target array, and training/evaluation IDs must be disjoint. Training standardization and smearing are fitted only on the training rows. Selecting a new data task, biological split or training permission remains the responsibility of the analysis protocol. This delivery exercised real-data inference only; real-data models were not refitted for packaging.

## Data and provenance

`configs/PROTOCOL.json` specifies the evaluated regional task and numerical rules. `configs/input_features.tsv` records all 126 ordered feature IDs and symbols; `configs/targets.tsv` records all seven members. `Data_sources.csv` points to public study records and describes access conditions. Original matrices, RDS objects, pretrained weights, target arrays and evaluation-input arrays are not bundled. `SOURCE_MANIFEST.json` binds the unchanged count core and selected context scripts to their recorded hashes.

`legacy_context/` contains selected original analysis and figure scripts as provenance. Some retain workstation paths and require the source data and original environment. They are not the portable entry point. `SPATCH_RELEASE_GAPS.csv` identifies the original probability-engine source, frozen model weights, annotation and workflow components requiring a separate portable release. The count module supplied here does not constitute a portable release of the entire probability engine or the entire paper workflow.

## License and release

`LICENSE` is the active MIT licence for original project-owned code, following the user's author-team authorization recorded in `../AUTHORIZATION.json`. `LICENSE.proposed` is retained as the historical pre-approval proposal, not the current licence state. Third-party software, data and images retain their original licences and access conditions; this approval does not create redistribution rights over them. No public repository, immutable public tag or archived DOI is supplied by this local package. The data access conditions in `Data_sources.csv` govern any future data redistribution.
