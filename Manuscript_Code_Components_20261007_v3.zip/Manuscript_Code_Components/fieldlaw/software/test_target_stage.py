"""Fresh-process CLI tests with synthetic fixtures only."""

import json
import csv
import gzip
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def writej(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding="utf8")


def binding(path):
    return {"path": str(Path(path).resolve()), "sha256": sha(path)}


def synthetic_fixture(root, poison_target=False, mouse_member_ids=False, spot_varying_truth=False):
    from test_frozen_adapter import synthetic_parameters, LEGACY_ROOT
    root = Path(root)
    run = root / "RUN"
    (run / "source").mkdir(parents=True)
    (run / "acquired").mkdir()
    metadata = root / "metadata"
    metadata.mkdir()
    code = Path(__file__).parent
    inputs = ["SYN_INPUT_" + str(i) for i in range(126)]
    genes = ["TBXT", "KRT8", "KRT18", "KRT19", "ACAN", "COL2A1", "SOX9"]
    member_features = ["ENSMUSG9000000000" + str(index) for index in range(7)]
    member_symbols = ["T", "Krt8", "Krt18", "Krt19", "Acan", "Col2a1", "Sox9"]
    heads, totals = synthetic_parameters()
    sources = []
    for index in range(2):
        head_path, total_path = root / f"SYN_HEAD{index}.json", root / f"SYN_TOTAL{index}.json"
        writej(head_path, heads[index])
        writej(total_path, totals[index])
        sources.append({"capture": f"SYN_SOURCE_{index}", "head_params": binding(head_path),
                        "total_params": binding(total_path)})
    targets, coordinates = [], []
    barcode_order = ["B3", "B1", "B4", "B2"]
    positions = {"B1": (0, 0), "B2": (6, 0), "B3": (0, 6), "B4": (6, 6)}
    for capture in ("SYN_A", "SYN_B"):
        feature_path, barcode_path = metadata / f"{capture}_features.tsv.gz", metadata / f"{capture}_barcodes.tsv.gz"
        with gzip.open(feature_path, "wt", encoding="utf8") as stream:
            for name in inputs:
                stream.write(name + "\t" + name + "\tGene Expression\n")
            for index, name in enumerate(genes):
                feature, symbol = (member_features[index], member_symbols[index]) if mouse_member_ids else (name, name)
                stream.write(feature + "\t" + symbol + "\tGene Expression\n")
        with gzip.open(barcode_path, "wt", encoding="utf8") as stream:
            stream.write("\n".join(barcode_order) + "\n")
        matrix_path = run / "acquired" / f"{capture}_matrix.mtx.gz"
        records = []
        for spot, barcode in enumerate(barcode_order, 1):
            records.append(f"1 {spot} {int(barcode[1:])}")
            for gene in range(7):
                multiplier = int(barcode[1:]) if spot_varying_truth else 1
                value = "DO_NOT_PARSE_MEMBER_VALUE" if poison_target else str((gene + 1) * multiplier)
                records.append(f"{127 + gene} {spot} {value}")
            x, y = positions[barcode]
            coordinates.append({"sample": capture, "observed_barcode": barcode, "array_row": str(y),
                                "array_col": str(2 * x), "native_relative_lattice_x_pitch": str(x),
                                "native_relative_lattice_y_pitch": str(y * np.sqrt(3.0) / 2.0)})
        with gzip.open(matrix_path, "wt", encoding="utf8") as stream:
            stream.write("%%MatrixMarket matrix coordinate integer general\n133 4 32\n" + "\n".join(records) + "\n")
        targets.append({"capture": capture, "matrix_name": matrix_path.name,
                        "matrix_expected_bytes": matrix_path.stat().st_size, "matrix_url": "https://example.invalid/SYN",
                        "features": binding(feature_path), "barcodes": binding(barcode_path),
                        "gene_rows": 133, "observations": 4})
        if mouse_member_ids:
            targets[-1].update(member_feature_ids=member_features, member_feature_rows=list(range(127, 134)))
    coordinate_path = metadata / "SYN_COORDS.tsv"
    with coordinate_path.open("w", encoding="utf8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(coordinates[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(coordinates)
    spec, authorization = root / "SYN_SPEC.json", root / "SYN_AUTH.json"
    writej(spec, {"worlds": 64, "synthetic": True})
    writej(authorization, {"synthetic": True})
    names = ["target_stage.py", "field_core.py", "source_statistics.py", "matrix_io.py", "scoring.py", "workflow.py", "frozen_adapter.py"]
    code_records = [binding(code / name) for name in names]
    code_records += [binding(LEGACY_ROOT / "xgb_offset_core.py"), binding(LEGACY_ROOT / "vendor" / "baseline_core.py")]
    config = {"mode": "SYNTHETIC_TARGET_STAGES", "worlds": 64, "source_records": sources,
              "targets": targets, "target_coordinates": binding(coordinate_path),
              "linkage": {"input_ids": inputs, "member_ids": genes}, "code_binding": code_records,
              "spec_binding": binding(spec), "authorization_binding": binding(authorization)}
    config_path = root / "CONFIG.json"
    writej(config_path, config)
    params = {"alpha7": [1.0] * 7, "anchor_mean127": [0.0] * 127, "anchor_sd127": [1.0] * 127,
              "state_centroids4x127": [[float(index)] * 127 for index in range(4)],
              "residual_correlations": {"pooled": np.eye(7).tolist(), "states": np.tile(np.eye(7), (4, 1, 1)).tolist()},
              "source_scales": {"ALL7": 10.0, "ACAN_COL2A1": 5.0, "OTHER5": 5.0},
              "linkage": config["linkage"], "source_io_binding": sources}
    params_path = run / "source" / "SOURCE_PARAMS.json"
    writej(params_path, params)
    writej(run / "source" / "SOURCE_COMMIT.json", {"status": "SOURCE_ONLY_PARAMETERS_COMMITTED",
           "mode": "SYNTHETIC_SOURCE_STAGE", "SOURCE_PARAMS_sha256": sha(params_path),
           "config_sha256": sha(config_path), "new_point_model_fits": 0, "target_reads": 0,
           "code_binding": code_records, "spec_binding": binding(spec), "authorization_binding": binding(authorization)})
    return config_path, run


def cli(stage, config, run, capture="SYN_A"):
    return subprocess.run([sys.executable, "-B", str(Path(__file__).with_name("target_stage.py")), stage,
                           "--config", str(config), "--run-root", str(run), "--capture", capture],
                          capture_output=True, text=True, check=False, timeout=180)


def complete_forecasts(config, run):
    for capture in ("SYN_A", "SYN_B"):
        for stage in ("prepare", "forecast"):
            process = cli(stage, config, run, capture)
            if process.returncode:
                raise RuntimeError(process.stdout + process.stderr)


def global_commit(config, run, stage, captures=("SYN_A", "SYN_B")):
    children = {capture: {**binding(run / "targets" / capture / stage / (stage.upper() + "_COMMIT.json")),
                          "external_exit_code": 0} for capture in captures}
    path = run / ("GLOBAL_" + stage.upper() + "_COMMIT.json")
    writej(path, {"status": "ALL_TARGET_" + ("FORECASTS" if stage == "forecast" else "TRUTHS") + "_COMMITTED",
                  "captures": children, "config_sha256": sha(config)})
    return path


class TargetStageTests(unittest.TestCase):
    def test_prepare_requires_source_commit_before_any_target_matrix_read(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_target_") as temporary:
            root = Path(temporary)
            config = root / "CONFIG.json"
            config.write_text(json.dumps({"mode": "SYNTHETIC_TARGET_STAGES"}), encoding="utf8")
            process = subprocess.run([sys.executable, "-B", str(Path(__file__).with_name("target_stage.py")),
                                      "prepare", "--config", str(config), "--run-root", str(root / "RUN"),
                                      "--capture", "SYN_A"], capture_output=True, text=True, check=False)
            self.assertEqual(process.returncode, 2)
            receipt = json.loads(process.stdout)
            self.assertEqual(receipt["status"], "TARGET_STAGE_BLOCKED")
            self.assertIn("SOURCE_COMMIT", receipt["reason"])
            self.assertFalse((root / "RUN" / "targets").exists())

    def test_prepare_parses_only_inputs_and_sorts_the_complete_support(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_prepare_") as temporary:
            config, run = synthetic_fixture(temporary, poison_target=True)
            process = cli("prepare", config, run)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            commit = json.loads((run / "targets" / "SYN_A" / "prepare" / "PREPARE_COMMIT.json").read_text(encoding="utf8"))
            self.assertEqual(commit["target_member_numeric_values_parsed"], 0)
            with np.load(run / "targets" / "SYN_A" / "prepare" / "INPUTS.npz", allow_pickle=False) as archive:
                np.testing.assert_array_equal(archive["region_id"], ["SYN_A|B1", "SYN_A|B2", "SYN_A|B3", "SYN_A|B4"])
                np.testing.assert_array_equal(archive["x_counts"][:, 0], [1, 2, 3, 4])
                y = 300.0 * np.sqrt(3.0)
                np.testing.assert_allclose(archive["coords_um"], [[0, 0], [600, 0], [0, y], [600, y]], rtol=0, atol=1e-12)

    def test_forecast_uses_only_prepared_inputs_and_commits_all_four_laws(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_forecast_") as temporary:
            config, run = synthetic_fixture(temporary, poison_target=True)
            self.assertEqual(cli("prepare", config, run).returncode, 0)
            process = cli("forecast", config, run)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            output = run / "targets" / "SYN_A" / "forecast"
            commit = json.loads((output / "FORECAST_COMMIT.json").read_text(encoding="utf8"))
            self.assertEqual(commit["world_count"], 64)
            self.assertEqual(len(commit["laws"]), 4)
            matrix = str((run / "acquired" / "SYN_A_matrix.mtx.gz").resolve())
            self.assertNotIn(matrix, commit["read_audit"]["read_paths"])
            self.assertIn(matrix, [item["path"] for item in commit["read_audit"]["denied_paths"]])
            for law, artifact in commit["laws"].items():
                self.assertEqual(artifact["sha256"], sha(artifact["path"]))
                with np.load(artifact["path"], allow_pickle=False) as archive:
                    self.assertEqual(archive["gene_region_totals"].shape, (64, 4, 7))
                    np.testing.assert_allclose(archive["mu7"].sum(axis=1), [21, 31.5, 42, 52.5], rtol=1e-12)

    def test_score_requires_all_truths_and_preserves_full_rows_diagnostics_and_mc_precision(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_score_") as temporary:
            config, run = synthetic_fixture(temporary)
            complete_forecasts(config, run)
            global_commit(config, run, "forecast")
            for capture in ("SYN_A", "SYN_B"):
                self.assertEqual(cli("truth", config, run, capture).returncode, 0)
            missing = cli("score", config, run)
            self.assertEqual(missing.returncode, 2)
            self.assertIn("GLOBAL_TRUTH_COMMIT", json.loads(missing.stdout)["reason"])
            global_commit(config, run, "truth")
            process = cli("score", config, run)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            output = run / "targets" / "SYN_A" / "score"
            scores = json.loads((output / "SCORES.json").read_text(encoding="utf8"))
            self.assertEqual(len(scores["generative_laws"]), 4)
            self.assertEqual([item["seed"] for item in scores["permutation_diagnostics"]], list(range(2026100611, 2026100615)))
            for item in scores["permutation_diagnostics"]:
                self.assertFalse(item["IID"])
                self.assertIsNone(item["functionals"]["ALL7"]["fair_rps_mean"])
            for law, precision in scores["mc_precision"].items():
                self.assertEqual(len(precision["two_seed_blocks"]), 2)
                self.assertEqual(precision["shared_world_delete_group"]["group_count"], 16)
                self.assertEqual(len(precision["shared_world_delete_group"]["functionals"]["ALL7"]["delete_group_roi_mean_estimates"]["fair_rps"]), 16)
                self.assertFalse(precision["biological_confidence_interval"])
            with (output / "ROWS.tsv").open(encoding="utf8", newline="") as stream:
                rows = list(csv.DictReader(stream, delimiter="\t"))
            self.assertEqual(len(rows), 128)
            main = [row for row in rows if row["diagnostic"] == "NONE"]
            diagnostic = [row for row in rows if row["diagnostic"] != "NONE"]
            self.assertEqual(len(main), 64)
            self.assertEqual(len(diagnostic), 64)
            self.assertTrue(all(row["fair_rps"] == "" for row in diagnostic))
            self.assertTrue(all(row["IID"] == "false" for row in diagnostic))
            self.assertIn("mcse_scaled_fair_rps", main[0])

    def test_truth_requires_global_all_library_forecast_barrier(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_truth_barrier_") as temporary:
            config, run = synthetic_fixture(temporary)
            self.assertEqual(cli("prepare", config, run).returncode, 0)
            self.assertEqual(cli("forecast", config, run).returncode, 0)
            process = cli("truth", config, run)
            self.assertEqual(process.returncode, 2)
            self.assertIn("GLOBAL_FORECAST_COMMIT", json.loads(process.stdout)["reason"])
            self.assertFalse((run / "targets" / "SYN_A" / "truth").exists())

    def test_truth_deep_verifies_every_library_and_matches_committed_inputs(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_truth_") as temporary:
            config, run = synthetic_fixture(temporary)
            complete_forecasts(config, run)
            global_commit(config, run, "forecast", captures=("SYN_A",))
            partial = cli("truth", config, run)
            self.assertEqual(partial.returncode, 2)
            self.assertIn("complete capture set", json.loads(partial.stdout)["reason"])
            self.assertFalse((run / "targets" / "SYN_A" / "truth").exists())
            global_commit(config, run, "forecast")
            process = cli("truth", config, run)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            output = run / "targets" / "SYN_A" / "truth"
            commit = json.loads((output / "TRUTH_COMMIT.json").read_text(encoding="utf8"))
            self.assertTrue(commit["complete_matrix_all_rows_integer_validated"])
            self.assertTrue(commit["input_capsule_exact_match"])
            with np.load(output / "TRUTH.npz", allow_pickle=False) as archive:
                np.testing.assert_array_equal(archive["gene_region_truth"], [[1, 2, 3, 4, 5, 6, 7]] * 4)

    def test_prepare_maps_frozen_feature_ids_despite_mouse_symbol_aliases(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_mouse_ids_") as temporary:
            config, run = synthetic_fixture(temporary, poison_target=True, mouse_member_ids=True)
            process = cli("prepare", config, run)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            with np.load(run / "targets" / "SYN_A" / "prepare" / "INPUTS.npz", allow_pickle=False) as archive:
                np.testing.assert_array_equal(archive["member_rows"], list(range(127, 134)))

    def test_supervisor_synthetic_mode_keeps_canonical_target_mode_and_64_worlds(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_supervisor_mode_") as temporary:
            config, run = synthetic_fixture(temporary)
            value = json.loads(config.read_text(encoding="utf8"))
            value["mode"] = "SYNTHETIC_SUPERVISOR_TEST"
            writej(config, value)
            source = run / "source" / "SOURCE_COMMIT.json"
            committed = json.loads(source.read_text(encoding="utf8"))
            committed["config_sha256"] = sha(config)
            writej(source, committed)
            for stage in ("prepare", "forecast"):
                process = cli(stage, config, run)
                self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            commit = json.loads((run / "targets" / "SYN_A" / "forecast" / "FORECAST_COMMIT.json").read_text(encoding="utf8"))
            self.assertEqual(commit["mode"], "SYNTHETIC_TARGET_STAGES")
            self.assertEqual(commit["world_count"], 64)

    def test_prepare_rejects_coordinates_that_disagree_with_the_native_array_lattice(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_bad_lattice_") as temporary:
            config, run = synthetic_fixture(temporary)
            value = json.loads(config.read_text(encoding="utf8"))
            coordinate_path = Path(value["target_coordinates"]["path"])
            with coordinate_path.open(encoding="utf8", newline="") as stream:
                coordinates = list(csv.DictReader(stream, delimiter="\t"))
            coordinates[0]["native_relative_lattice_y_pitch"] = "3.14"
            with coordinate_path.open("w", encoding="utf8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(coordinates[0]), delimiter="\t")
                writer.writeheader()
                writer.writerows(coordinates)
            value["target_coordinates"] = binding(coordinate_path)
            writej(config, value)
            source = run / "source" / "SOURCE_COMMIT.json"
            committed = json.loads(source.read_text(encoding="utf8"))
            committed["config_sha256"] = sha(config)
            writej(source, committed)
            process = cli("prepare", config, run)
            self.assertEqual(process.returncode, 2)
            self.assertIn("native relative lattice", json.loads(process.stdout)["reason"])
            self.assertFalse((run / "targets" / "SYN_A" / "prepare").exists())

    def test_truth_rejects_a_tampered_forecast_from_any_other_library(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_tamper_") as temporary:
            config, run = synthetic_fixture(temporary)
            complete_forecasts(config, run)
            global_commit(config, run, "forecast")
            path = run / "targets" / "SYN_B" / "forecast" / "INDEPENDENT_GENE_FIELDS.npz"
            with path.open("ab") as stream:
                stream.write(b"SYNTHETIC_TAMPER")
            process = cli("truth", config, run, "SYN_A")
            self.assertEqual(process.returncode, 2)
            self.assertIn("artifact hash/path mismatch", json.loads(process.stdout)["reason"])
            self.assertFalse((run / "targets" / "SYN_A" / "truth").exists())

    def test_truth_rejects_a_nonzero_external_exit_receipt(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_exit_receipt_") as temporary:
            config, run = synthetic_fixture(temporary)
            complete_forecasts(config, run)
            global_path = global_commit(config, run, "forecast")
            value = json.loads(global_path.read_text(encoding="utf8"))
            value["captures"]["SYN_B"]["external_exit_code"] = 1
            writej(global_path, value)
            process = cli("truth", config, run, "SYN_A")
            self.assertEqual(process.returncode, 2)
            self.assertIn("external exit0", json.loads(process.stdout)["reason"])
            self.assertFalse((run / "targets" / "SYN_A" / "truth").exists())

    def test_truth_retains_canonical_spot_counts_for_later_native_figures(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_SYN_spot_truth_") as temporary:
            config, run = synthetic_fixture(temporary, spot_varying_truth=True)
            complete_forecasts(config, run)
            global_commit(config, run, "forecast")
            process = cli("truth", config, run)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            with np.load(run / "targets" / "SYN_A" / "truth" / "TRUTH.npz", allow_pickle=False) as archive:
                np.testing.assert_array_equal(archive["canonical_ids"], ["SYN_A|B1", "SYN_A|B2", "SYN_A|B3", "SYN_A|B4"])
                np.testing.assert_array_equal(archive["spot_member_counts"],
                    [[1, 2, 3, 4, 5, 6, 7], [2, 4, 6, 8, 10, 12, 14],
                     [3, 6, 9, 12, 15, 18, 21], [4, 8, 12, 16, 20, 24, 28]])
                np.testing.assert_array_equal(archive["gene_region_truth"],
                    [[1, 2, 3, 4, 5, 6, 7], [3, 6, 9, 12, 15, 18, 21],
                     [2, 4, 6, 8, 10, 12, 14], [4, 8, 12, 16, 20, 24, 28]])


if __name__ == "__main__":
    unittest.main()
