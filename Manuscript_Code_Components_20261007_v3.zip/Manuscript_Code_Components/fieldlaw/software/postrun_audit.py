"""All-row independent numerical and commit audit after the external run exits."""
import os
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '2'
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import numpy as np
import psutil
from independent_scores import independent_count_scores
from independent_mc import reconstruct_mc_precision, verify_mc_outputs

LAWS = ('INDEPENDENT_GENE_FIELDS', 'FIXED_RHO025_COMMON_FIELD', 'POOLED_SOURCE_CORR', 'CONDITIONAL_SOURCE_CORR')
FUNCTIONS = {'ALL7': (0, 1, 2, 3, 4, 5, 6), 'ACAN_COL2A1': (4, 5), 'OTHER5': (0, 1, 2, 3, 6)}
EVENT = 'ALL7_REGIONAL_TOTALS_POSITIVE_EVENT'

def readj(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def bound(record):
    if sha(record['path']) != record['sha256']:
        raise ValueError('Committed file changed: ' + record['path'])

def same(actual, expected, label):
    if not np.isfinite(float(actual)) or not np.isclose(float(actual), expected, rtol=1e-10, atol=1e-10):
        raise ValueError('Independent numerical mismatch: ' + label)

def exact_count_array(values, shape, label):
    if (values.shape != shape or values.dtype.kind not in 'iu'
            or np.any(values < 0) or np.any(values > np.iinfo(np.int64).max)):
        raise ValueError('Exact nonnegative int64-compatible count array required: ' + label)

def run_audit(run_root, external_exit, output):
    run = Path(run_root).resolve()
    process = psutil.Process(os.getpid())
    process.cpu_affinity(process.cpu_affinity()[:2])
    external = readj(external_exit)
    if external['status'] != 'ACTUAL_EXTERNAL_SUPERVISOR_EXIT' or external['external_exit_code'] != 0:
        raise ValueError('An actual successful external supervisor receipt is required')
    config_path = run / 'RUN_CONFIG.json'
    config, done = readj(config_path), readj(run / 'RUN_COMPLETE.json')
    config_hash = sha(config_path)
    provenance = external['process']
    if (Path(provenance['run_root']).resolve() != run or provenance['config_sha256'] != config_hash
            or sha(provenance['config_path']) != config_hash
            or provenance['supervisor_sha256'] != sha(Path(__file__).with_name('real_supervisor.py'))):
        raise ValueError('External supervisor receipt does not bind this exact run/config/program')
    if done['status'] != 'BOUNDED_RUN_COMPLETE' or done['config_sha256'] != sha(config_path):
        raise ValueError('Complete matching terminal run is required')
    if not done['external_exits_all_zero'] or done['external_processes'] != 16:
        raise ValueError('All sixteen real stage/transport external exits are required')
    if done['elapsed_seconds'] > config['resource_contract']['wall_seconds']:
        raise ValueError('Original real wall budget exceeded')
    for path in (run / 'process_receipts').glob('*.json'):
        receipt = readj(path)
        if receipt['external_exit_code'] != 0 or receipt['resource_violation'] is not None:
            raise ValueError('Failed process receipt: ' + str(path))
        bound(receipt['stdout']); bound(receipt['stderr'])
    if len(list((run / 'process_receipts').glob('*.json'))) != 16:
        raise ValueError('Missing actual process receipts')
    source = readj(run / 'source' / 'SOURCE_PARAMS.json')
    source_commit = readj(run / 'source' / 'SOURCE_COMMIT.json')
    source_commit_hash = sha(run / 'source' / 'SOURCE_COMMIT.json')
    if sha(run / 'source' / 'SOURCE_PARAMS.json') != source_commit['SOURCE_PARAMS_sha256']:
        raise ValueError('Source parameter hash mismatch')
    for path, expected in readj(run / 'CODE_FINGERPRINTS.json')['bindings'].items():
        if sha(path) != expected:
            raise ValueError('Immutable original binding changed: ' + path)
    worlds = 2048 if config['mode'] == 'AUTHORIZED_REAL_SOURCE_FIT' else 64
    total_rows, numerical_checks, mc_checks, observations, summaries = 0, 0, 0, 0, {}
    for target in config['targets']:
        capture = target['capture']
        folder = run / 'targets' / capture
        for stage in ('prepare', 'forecast', 'truth', 'score'):
            commit = readj(folder / stage / (stage.upper() + '_COMMIT.json'))
            if commit['config_sha256'] != sha(config_path) or commit['capture'] != capture:
                raise ValueError('Stage identity/config drift')
            for record in commit['artifacts'].values():
                bound(record)
        with np.load(folder / 'truth' / 'TRUTH.npz', allow_pickle=False) as data:
            truth, keys, ids = data['gene_region_truth'], data['region_keys'], data['canonical_ids']
        exact_count_array(truth, (len(keys), 7), 'truth')
        if len(ids) != target['observations'] or len(set(ids.tolist())) != len(ids):
            raise ValueError('Complete unique target observation coverage failed')
        observations += len(ids)
        with (folder / 'score' / 'ROWS.tsv').open(encoding='utf8', newline='') as stream:
            rows = list(csv.DictReader(stream, delimiter='\t'))
        if len(rows) != 32 * len(keys):
            raise ValueError('Full 32R score rows required')
        lookup = {}
        for row in rows:
            key = (row['law'], row['diagnostic'], row['permutation_seed'], row['functional'], int(row['roi_x']), int(row['roi_y']))
            if key in lookup or row['capture'] != capture or int(row['scenario_count']) != worlds:
                raise ValueError('Duplicate or mismatched score key')
            lookup[key] = row
        expected_keys = set()
        law_means = {}
        conditional = None
        def check_values(values, law, diagnostic='NONE', seed=''):
            nonlocal numerical_checks
            IID = diagnostic == 'NONE'
            scores = {name: [] for name in FUNCTIONS}
            for region, key in enumerate(keys):
                for name, members in FUNCTIONS.items():
                    row_key = (law, diagnostic, str(seed), name, int(key[0]), int(key[1]))
                    expected_keys.add(row_key)
                    row = lookup[row_key]
                    samples = [sum(int(v) for v in values[world, region, list(members)]) for world in range(worlds)]
                    outcome = sum(int(v) for v in truth[region, list(members)])
                    result = independent_count_scores(samples, outcome, IID=IID)
                    scale = source['source_scales'][name]
                    if row['IID'] != ('true' if IID else 'false'):
                        raise ValueError('Wrong IID role')
                    for metric in ('empirical_rps', 'wis'):
                        same(row[metric], result[metric], metric)
                        same(row['scaled_' + metric], result[metric] / scale, 'scaled_' + metric)
                        numerical_checks += 2
                    same(row['source_scale'], scale, 'source_scale')
                    same(row['median'], result['median'], 'median')
                    same(row['median_absolute_error'], abs(result['median'] - outcome), 'median_absolute_error')
                    same(row['scaled_median_absolute_error'], abs(result['median'] - outcome) / scale, 'scaled_median_absolute_error')
                    numerical_checks += 3
                    if IID:
                        same(row['fair_rps'], result['fair_rps'], 'fair_rps')
                        same(row['scaled_fair_rps'], result['fair_rps'] / scale, 'scaled_fair_rps')
                        scores[name].append(result['fair_rps'] / scale)
                    elif row['fair_rps'] or row['scaled_fair_rps']:
                        raise ValueError('Non-IID diagnostic has fair score')
                    for level, interval in result['intervals'].items():
                        for metric in ('lower', 'upper', 'width', 'left_miss', 'right_miss', 'interval_score'):
                            same(row[metric + '_' + level], interval[metric], metric + '_' + level)
                            numerical_checks += 1
                        same(row['coverage_' + level], not(interval['left_miss'] or interval['right_miss']), 'coverage')
                        same(row['scaled_width_' + level], interval['width'] / scale, 'scaled_width')
                        same(row['scaled_interval_score_' + level], interval['interval_score'] / scale, 'scaled_interval_score')
                event_key = (law, diagnostic, str(seed), EVENT, int(key[0]), int(key[1]))
                expected_keys.add(event_key)
                probability = sum(all(int(v) > 0 for v in values[world, region]) for world in range(worlds)) / worlds
                event_truth = all(int(v) > 0 for v in truth[region])
                same(lookup[event_key]['event_probability'], probability, 'event_probability')
                same(lookup[event_key]['brier'], (probability - event_truth) ** 2, 'brier')
                numerical_checks += 2
            return {name: float(np.mean(values)) for name, values in scores.items()} if IID else None
        scores = readj(folder / 'score' / 'SCORES.json')
        for law in LAWS:
            with np.load(folder / 'forecast' / (law + '.npz'), allow_pickle=False) as data:
                values = data['gene_region_totals']
                exact_count_array(values, (worlds, len(keys), 7), 'forecast')
                if not np.array_equal(data['region_keys'], keys) or not np.array_equal(data['canonical_ids'], ids):
                    raise ValueError('Forecast/truth support mismatch')
            law_means[law] = check_values(values, law)
            precision = reconstruct_mc_precision(values, truth, source['source_scales'])
            mc_checks += verify_mc_outputs(precision, scores['mc_precision'][law], rows, law, keys)
            if law == 'CONDITIONAL_SOURCE_CORR':
                conditional = values
        for seed in range(2026100611, 2026100615):
            rng = np.random.default_rng(seed)
            values = np.empty_like(conditional)
            for gene in range(7):
                values[:, :, gene] = conditional[rng.permutation(worlds), :, gene]
            check_values(values, 'CONDITIONAL_SOURCE_CORR', 'GLOBAL_GENE_WORLD_PERMUTATION', seed)
        if set(lookup) != expected_keys:
            raise ValueError('Complete exact score key coverage failed')
        for law, functions in law_means.items():
            for name, value in functions.items():
                same(scores['generative_laws'][law]['functionals'][name]['scaled_fair_rps_mean'], value, 'JSON mean')
        summaries[capture] = {'observations': len(ids), 'regions': len(keys), 'rows': len(rows), 'source_scaled_fair_rps': law_means}
        total_rows += len(rows)
    if observations != sum(target['observations'] for target in config['targets']):
        raise ValueError('Full library support is incomplete')
    overall = {law: {name: float(np.mean([sample['source_scaled_fair_rps'][law][name] for sample in summaries.values()])) for name in FUNCTIONS} for law in LAWS}
    if sha(config_path) != config_hash or sha(provenance['config_path']) != config_hash:
        raise ValueError('Configuration changed during independent audit')
    if sha(run / 'source' / 'SOURCE_PARAMS.json') != source_commit['SOURCE_PARAMS_sha256'] or sha(run / 'source' / 'SOURCE_COMMIT.json') != source_commit_hash:
        raise ValueError('Source parameters/commit changed during independent audit')
    for path, expected in readj(run / 'CODE_FINGERPRINTS.json')['bindings'].items():
        if sha(path) != expected:
            raise ValueError('Immutable binding changed during independent audit: ' + path)
    start_time = datetime.fromisoformat(readj(run / 'RUN_START.json')['started_utc'])
    elapsed_through_audit = (datetime.now(timezone.utc) - start_time).total_seconds()
    if config['mode'] == 'AUTHORIZED_REAL_SOURCE_FIT' and elapsed_through_audit > config['resource_contract']['wall_seconds']:
        raise ValueError('Full source-fit-through-audit wall budget exceeded')
    result = {'status': 'INDEPENDENT_FULL_ROW_AUDIT_PASS', 'date_utc': datetime.now(timezone.utc).isoformat(),
              'run_root': str(run), 'config_sha256': sha(config_path), 'external_exit_receipt_sha256': sha(external_exit),
              'mode': config['mode'], 'all_three_libraries': True, 'complete_observations': observations,
              'complete_score_rows': total_rows, 'independent_numerical_checks': numerical_checks,
              'independent_mc_numerical_checks': mc_checks,
              'all_mc_packet_and_row_values_reconstructed': True,
              'elapsed_through_audit_seconds': elapsed_through_audit,
              'algorithm': 'Integer support-CDF integration and rational fair correction; independent two-block and16-group MC reconstruction; no production scorer imported',
              'source_weights_and_code_unchanged': True, 'source_config_hashes_rechecked_at_audit_completion': True,
              'summaries': summaries, 'equal_library_macro': overall,
              'no_biological_confidence_interval_or_GB_readiness_claim': True}
    with Path(output).open('x', encoding='utf8') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-root', required=True)
    parser.add_argument('--external-exit', required=True)
    parser.add_argument('--output', required=True)
    arguments = parser.parse_args()
    try:
        value = run_audit(arguments.run_root, arguments.external_exit, arguments.output)
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({'status': 'INDEPENDENT_AUDIT_FAILED', 'reason': str(error)}), flush=True)
        raise SystemExit(2)
    print(json.dumps({'status': value['status'], 'rows': value['complete_score_rows']}), flush=True)
