"""Bounded external score/checker sequence for an extracted aggregate release."""
import argparse
from datetime import datetime,timezone
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import psutil

def main(bundle,output,python):
    bundle,output=Path(bundle).resolve(),Path(output).resolve()
    if output.exists():raise ValueError('Replay root must be fresh; no restart/overwrite')
    output.mkdir(parents=True)
    sys.path.insert(0,str(bundle/'software'))
    from real_supervisor import identity,terminate_tree,tree_bytes
    from aggregate_replay import sha,writej,configuration
    config=configuration(bundle)
    budget={'CPU':2,'RSS_bytes':4294967296,'wall_seconds':1800,'output_bytes':1073741824}
    if not config['synthetic'] and config['resource_contract']!=budget:raise ValueError('Replay budget cannot change')
    for name,wanted in [('numpy','2.5.2'),('scipy','1.18.1'),('psutil','7.2.2')]:
        if importlib.metadata.version(name)!=wanted:raise ValueError('Replay dependency version mismatch: '+name)
    own=psutil.Process();cpus=own.cpu_affinity()[:2];own.cpu_affinity(cpus)
    started=time.monotonic();stamp=datetime.now(timezone.utc).isoformat();peak=0;receipts=[]
    writej(output/'RUN_START.json',{'status':'AGGREGATE_REPLAY_STARTED','date_utc':stamp,'monotonic_start':started,
        'owner':identity(own),'python_launcher':str(Path(python).resolve()),'config_sha256':sha(bundle/'REPLAY_CONFIG.json'),
        'resource_contract':budget,'no_fitting_or_generation':True})
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[name]='2'
    score_output=output/'scores'
    for stage in ('score','verify'):
        cmd=[str(Path(python).resolve()),'-B',str(bundle/'aggregate_replay.py'),stage,'--bundle',str(bundle),'--output',str(score_output)]
        with (output/(stage+'.stdout.log')).open('xb') as stdout,(output/(stage+'.stderr.log')).open('xb') as stderr:
            child=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,env=env)
            process=psutil.Process(child.pid);created=identity(process);seen={};violation=None;stage_peak=0
            while child.poll() is None:
                elapsed=time.monotonic()-started
                if elapsed>budget['wall_seconds']:violation='wall_seconds'
                try:
                    processes=[own,process]+process.children(recursive=True);rss=0
                    for item in {p.pid:p for p in processes}.values():
                        try:
                            rec=identity(item);seen[str(item.pid)]=rec
                            rss+=item.memory_info().rss
                            if item.pid!=own.pid:item.cpu_affinity(cpus)
                        except (psutil.NoSuchProcess,psutil.AccessDenied):pass
                    peak=max(peak,rss);stage_peak=max(stage_peak,rss)
                    if rss>budget['RSS_bytes']:violation='RSS_bytes'
                except psutil.NoSuchProcess:pass
                if tree_bytes(output)>budget['output_bytes']:violation='output_bytes'
                if violation:terminate_tree(process,created);break
                time.sleep(.25)
            code=child.wait()
        receipt={'stage':stage,'status':'ACTUAL_EXTERNAL_REPLAY_CHILD_EXIT','external_exit_code':code,
            'process':created,'observed_process_tree':list(seen.values()),'command':cmd,'elapsed_from_original_start':time.monotonic()-started,
            'peak_process_tree_RSS_bytes':stage_peak,'resource_violation':violation,
            'stdout_sha256':sha(output/(stage+'.stdout.log')),'stderr_sha256':sha(output/(stage+'.stderr.log'))}
        writej(output/(stage+'_EXTERNAL_EXIT.json'),receipt);receipts.append(receipt)
        if code!=0 or violation:raise RuntimeError('Actual replay child failure: '+stage)
    audit=json.loads((score_output/'INDEPENDENT_REPLAY_AUDIT.json').read_text(encoding='utf8'))
    done={'status':'BOUNDED_AGGREGATE_REPLAY_COMPLETE','child_exits':[r['external_exit_code'] for r in receipts],
        'elapsed_seconds':time.monotonic()-started,'peak_process_tree_RSS_bytes':peak,'output_bytes':tree_bytes(output),
        'resource_contract':budget,'complete_rows':audit['rows'],'audit':audit,'new_scenarios':0,'new_fits':0}
    if done['elapsed_seconds']>1800 or done['output_bytes']>1073741824:raise RuntimeError('Final replay budget exceeded')
    writej(output/'FINAL_COMPLETE.json',done);print(json.dumps(done))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--bundle',required=True);parser.add_argument('--output',required=True);parser.add_argument('--python',default=sys.executable)
    args=parser.parse_args();main(args.bundle,args.output,args.python)
