"""ThreebalancedSOURCEcaptures; NB2moments/PITGram, no meanfit or targetI/O."""
import hashlib
import json
import numpy as np
from scipy.special import betainc,betaincc,gammainc,gammaincc,ndtri_exp


def _scores(y,mu,alpha,active):
    rng=np.random.default_rng(2026100602)
    v=rng.random(y.shape)
    while np.any(v==0):
        missing=v==0
        v[missing]=rng.random(np.count_nonzero(missing))
    scores=np.zeros_like(mu)
    log_tail_count=0
    for gene in active:
        observed=y[:,gene]
        mean=mu[:,gene]
        if alpha[gene]==0:
            lower=np.where(observed==0,0.,gammaincc(observed,mean))
            upper=gammaincc(observed+1.,mean)
            sf_lower=np.where(observed==0,1.,gammainc(observed,mean))
            sf_upper=gammainc(observed+1.,mean)
        else:
            shape=1./alpha[gene]
            product=alpha[gene]*mean
            q=product/(1.+product)
            p=1./(1.+product)
            if not np.isfinite(shape) or not np.isfinite(product).all() or np.any(q<=0) or np.any(p<=0):
                raise ValueError("BLOCKED_NUMERIC_SOURCE_NB2_PARAMETER")
            small=q<=.5
            lower=np.where(observed==0,0.,np.where(small,betaincc(observed,shape,q),betainc(shape,observed,p)))
            upper=np.where(small,betaincc(observed+1.,shape,q),betainc(shape,observed+1.,p))
            sf_lower=np.where(observed==0,1.,np.where(small,betainc(observed,shape,q),betaincc(shape,observed,p)))
            sf_upper=np.where(small,betainc(observed+1.,shape,q),betaincc(shape,observed+1.,p))
        if (not np.isfinite(lower).all() or not np.isfinite(upper).all() or not np.isfinite(sf_lower).all() or not np.isfinite(sf_upper).all()
            or np.any(lower<0) or np.any(upper>1) or np.any(upper<lower) or np.any(sf_upper<0) or np.any(sf_lower>1) or np.any(sf_lower<sf_upper)):
            raise ValueError("BLOCKED_NUMERIC_SOURCE_CDF_SF")
        lo=(1-v[:,gene])*lower+v[:,gene]*upper
        hi=(1-v[:,gene])*sf_lower+v[:,gene]*sf_upper
        use_lower=lo<=.5
        tail=np.where(use_lower,lo,hi)
        if np.any(tail<=0) or not np.isfinite(tail).all():
            raise ValueError("BLOCKED_NUMERIC_SOURCE_PIT_TAIL_UNDERFLOW")
        logtail=np.log(tail)
        z=ndtri_exp(logtail)
        z[~use_lower]*=-1.
        if not np.isfinite(z).all():
            raise ValueError("BLOCKED_NUMERIC_SOURCE_NORMAL_SCORE")
        scores[:,gene]=z
    return scores,{"pit_seed":2026100602,"source_tail_policy":"independentCDF/SF smaller tail;logtail ndtri_exp;noclips","log_tail_fallbacks":log_tail_count}


def calibrate_three_capture_nb2(y,OOFmu,captureIDs,canonicalIDs,roles):
    raw=np.asarray(y)
    mu=np.asarray(OOFmu,dtype=float)
    captures=np.asarray(captureIDs,dtype=str)
    ids=np.asarray(canonicalIDs,dtype=str)
    role_ids=list(roles)
    if raw.ndim!=2 or raw.shape[1]!=7 or len(raw)==0 or mu.shape!=raw.shape or captures.shape!=(len(raw),) or ids.shape!=(len(raw),):
        raise ValueError("completealignedN7sourcearraysrequired")
    if raw.dtype.kind not in "iuf" or not np.isfinite(raw).all() or np.any(raw<0) or np.any(raw!=np.trunc(raw)) or np.any(raw>2**53-1):
        raise ValueError("exactfiniteintegernativecountsrequired;nofloor")
    if not np.isfinite(mu).all() or np.any(mu<0):
        raise ValueError("finite nonnegative sourceOOFmeansrequired")
    if len(role_ids)!=7 or len(set(role_ids))!=7 or not all(isinstance(v,str) and v for v in role_ids):
        raise ValueError("allseven orderedUIDsrequired")
    if ids.tolist()!=sorted(set(ids.tolist())) or not all(v for v in captures) or any(not identity.startswith(capture+"|") for identity,capture in zip(ids,captures)):
        raise ValueError("completecanonicalsourceIDs mustbeunique/sorted/aligned")
    labels,inverse,sizes=np.unique(captures,return_inverse=True,return_counts=True)
    if len(labels)!=3:
        raise ValueError("exactlyTHREEsourcecapturesrequired;nomerging/dropping")
    weights=1./(3.*sizes[inverse])
    observed=raw.astype(float)
    incompatible=(mu==0)&(observed>0)
    if np.any(incompatible):
        raise ValueError("BLOCKED_SOURCE_MEAN_SUPPORT_MISMATCH: mu0/Ypositiveatoms="+str(int(incompatible.sum())))
    structural=np.all(mu==0,axis=0)&np.all(observed==0,axis=0)
    active=np.flatnonzero(~structural)
    if np.any(mu[:,active]==0):
        raise ValueError("BLOCKED_SOURCE_UNIDENTIFIED_COPULA_ROWS: partialactive mu0/Y0;no masking/fakePIT")
    with np.errstate(over="raise",invalid="raise",divide="raise"):
        denominator=np.sum(weights[:,None]*mu*mu,axis=0)
        numerator=np.sum(weights[:,None]*((observed-mu)**2-mu),axis=0)
    if not np.isfinite(numerator).all() or not np.isfinite(denominator).all() or np.any(denominator[active]<=0):
        raise ValueError("BLOCKED_NUMERIC_SOURCE_MOMENT_DENOMINATOR")
    alpha=np.zeros(7)
    alpha[active]=np.maximum(0.,numerator[active]/denominator[active])
    if not np.isfinite(alpha).all() or np.any(alpha<0):
        raise ValueError("BLOCKED_NUMERIC_SOURCE_UNCAPPED_ALPHA")
    with np.errstate(over="raise",invalid="raise"):
        variance=mu+alpha[None,:]*mu*mu
    if not np.isfinite(variance).all():
        raise ValueError("BLOCKED_NUMERIC_SOURCE_VARIANCE_UNREPRESENTABLE")
    scores,pit_receipt=_scores(observed,mu,alpha,active)
    R=np.eye(7)
    raw_R=np.eye(7)
    covariance=np.zeros((7,7))
    if len(active):
        z=scores[:,active]
        centre=np.sum(weights[:,None]*z,axis=0)
        weighted=(z-centre)*np.sqrt(weights[:,None])
        cov=weighted.T@weighted
        variances=np.diag(cov)
        if not np.isfinite(cov).all() or np.any(variances<=0):
            raise ValueError("BLOCKED_NUMERIC_SOURCE_ACTIVE_SCORE_VARIANCE")
        corr=cov/np.sqrt(variances[:,None]*variances[None,:])
        np.fill_diagonal(corr,1.)
        shrunk=.9*corr+.1*np.eye(len(active))
        R[np.ix_(active,active)]=shrunk
        raw_R[np.ix_(active,active)]=corr
        covariance[np.ix_(active,active)]=cov
    if not np.isfinite(R).all() or not np.array_equal(R,R.T) or not np.array_equal(np.diag(R),np.ones(7)):
        raise ValueError("BLOCKED_NUMERIC_SOURCE_PSD_CORRELATION")
    np.linalg.cholesky(R)
    fingerprint=hashlib.sha256()
    for value in (observed,mu,weights):
        fingerprint.update(np.asarray(value,dtype="<f8").tobytes())
    fingerprint.update(json.dumps([ids.tolist(),role_ids],separators=(",",":")).encode())
    return {"status":"THREE_CAPTURE_SOURCE_NB2_POOLED_PARAMS","capture_count":3,"capture_ids":labels.tolist(),
            "observation_weights":weights.tolist(),"capture_weight_mass":{label:float(weights[captures==label].sum()) for label in labels},
            "alpha7":alpha.tolist(),"moment_numerator":numerator.tolist(),"moment_denominator":denominator.tolist(),
            "negative_moment_projected_to_alpha0":np.flatnonzero(numerator<0).tolist(),
            "structural_zero_genes":np.flatnonzero(structural).tolist(),"structural_zero_alpha_policy":"fixed0_nonidentified;latentidentityrow;allgenesretained",
            "pooled_correlation":R.tolist(),"raw_correlation":raw_R.tolist(),"weighted_score_covariance":covariance.tolist(),
            "Gaussian_PIT_scores":scores.tolist(),"PIT_receipt":pit_receipt,"source_array_fingerprint":fingerprint.hexdigest(),
            "ordered_member_uids":role_ids,"observations":len(raw),"native_count_replacement":False,
            "source_mean_refitted":False,"target_reads":0,"conditional_state_bank":False}
