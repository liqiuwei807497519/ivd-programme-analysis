"""Localize the portable input contract without reading numerical source values."""
import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def binding(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": digest(path)}


def localize(package_root, authorized_exports, output):
    package, exports, output = Path(package_root).resolve(), Path(authorized_exports).resolve(), Path(output).resolve()
    template = json.loads((package / "reference/INPUT_REQUIREMENTS.json").read_text(encoding="utf8"))
    if output.exists():
        raise ValueError("existing local configuration is preserved")
    sections = []
    for section in template["sections"]:
        item = {key: section[key] for key in ("section_folder", "section_id", "parent", "expected_rows")}
        for role in ("counts", "coordinates", "features", "exports"):
            requirement = section[role]
            path = (exports / requirement["relative_path"]).resolve()
            if exports not in path.parents:
                raise ValueError("source requirement escapes the supplied export directory")
            if not path.is_file():
                raise FileNotFoundError("Obtain authorized original CTM exports separately: " + requirement["relative_path"])
            record = binding(path)
            if record["sha256"] != requirement["sha256"]:
                raise ValueError("Source fingerprint differs from the completed reference: " + requirement["relative_path"])
            item[role] = record
        sections.append(item)
    config = {key: template[key] for key in ("mode", "expected_total_rows", "expected_section_count", "outer_groups", "ordered_roles", "selection_grid", "resource_contract")}
    config.update({"sections": sections, "code_binding": [binding(path) for path in sorted((package / "software").glob("rna_*.py"))],
                   "plan_binding": binding(package / "PLAN.json"), "authorization_binding": binding(package / "IMPLEMENTATION_AUTHORITY.json"),
                   "adapter_contract": "Absolute local paths resolved from package-relative requirements and user-supplied authorized exports; SHA verified without numerical parsing"})
    with output.open("x", encoding="utf8") as stream:
        stream.write(json.dumps(config, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    return config


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-inputs", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    localize(Path(__file__).resolve().parent, args.source_inputs, args.output)
