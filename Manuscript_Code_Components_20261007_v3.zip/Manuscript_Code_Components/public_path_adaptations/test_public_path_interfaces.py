"""Public CLI seam only; no scientific module or dataset import."""
from pathlib import Path
import json, subprocess, sys, unittest

ROOT=Path(__file__).resolve().parent
NAMES=['rat_members.py','rat_sc_context.py','human_rna_description.py','human_rna_verify.py','quantitative_s1.py','rat_rna_figure.py']
class PublicPathInterface(unittest.TestCase):
    def test_describe_and_help_without_third_party_packages_or_data(self):
        for name in NAMES:
            script=ROOT/name
            help_run=subprocess.run([sys.executable,'-I','-S','-B',str(script),'--help'],capture_output=True,text=True,timeout=5)
            self.assertEqual(help_run.returncode,0,(name,help_run.stderr))
            self.assertIn('--describe-inputs',help_run.stdout)
            described=subprocess.run([sys.executable,'-I','-S','-B',str(script),'--describe-inputs'],capture_output=True,text=True,timeout=5)
            self.assertEqual(described.returncode,0,(name,described.stderr))
            payload=json.loads(described.stdout)
            self.assertEqual(payload['data_reads'],0)
            self.assertEqual(payload['purpose'],'path-interface description; no scientific execution')
            self.assertIn('required_bindings',payload)
if __name__=='__main__':unittest.main(verbosity=2)
