"""Real fresh extraction replay; no hidden source/runtime/data-root dependency."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import zipfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    destination = args.destination.resolve()
    if destination.exists():raise FileExistsError("Fresh destination already exists")
    with zipfile.ZipFile(args.archive) as archive:
        for name in archive.namelist():
            if not (destination / name).resolve().is_relative_to(destination):
                raise ValueError("Archive member escapes fresh destination")
        archive.extractall(destination)
    manifest = json.loads((destination / "SOURCE_MANIFEST.json").read_text(encoding="utf8"))
    roster = {item["relative_path"] for item in manifest["files"]}
    actual = {p.relative_to(destination).as_posix() for p in destination.rglob("*") if p.is_file()}
    if actual != roster | {"SOURCE_MANIFEST.json"}:raise ValueError("Extracted complete file roster differs")
    for item in manifest["files"]:
        path = destination / item["relative_path"]
        if path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]:
            raise ValueError("Extracted file checksum differs: " + item["relative_path"])
    run_root = destination / "fresh outputs"
    stages = [
        ("replay", ["src/reproduce.py", "--capsule", "inputs/ALL_GENE_DATA.npz", "--metadata", "inputs/PSEUDOBULK_META.json", "--output", "fresh outputs/replay"]),
        ("checker", ["src/check_prepared.py", "--capsule", "inputs/ALL_GENE_DATA.npz", "--metadata", "inputs/PSEUDOBULK_META.json", "--results", "fresh outputs/replay", "--output", "fresh outputs/check"]),
        ("compare", ["compare_submitted.py", "--original", "reference/statistics", "--replay", "fresh outputs/replay/statistics", "--receipt", "fresh outputs/all12_comparison.json"]),
        ("tests", ["-m", "unittest", "discover", "-s", "tests", "-v"]),
    ]
    exits = []
    for label, command in stages:
        receipt = "fresh outputs/" + label + "_exit.json"
        supervised = [sys.executable, "run_receipted.py", "--receipt", receipt, "--cwd", ".",
                      "--output-root", "fresh outputs", "--", sys.executable, *command]
        completed = subprocess.run(supervised, cwd=destination, capture_output=True, text=True, encoding="utf8")
        if completed.returncode:
            raise RuntimeError(label + " failed: " + completed.stdout + completed.stderr)
        record = json.loads((destination / receipt).read_text(encoding="utf8"))
        exits.append({"stage": label, "exit_code": completed.returncode,
                      "elapsed_seconds": record["elapsed_seconds"],
                      "observed_peak_process_RSS_bytes": record["observed_peak_process_RSS_bytes"],
                      "CPU_affinity_enforced": record["CPU_affinity_enforced"],
                      "resource_limit_exceeded": record["resource_limit_exceeded"]})
    result = {"status": "PASS_FRESH_ARCHIVE_EXTRACTION_REPLAY", "archive_basename": args.archive.name,
              "archive_sha256": sha(args.archive), "extracted_file_count": len(actual),
              "all_extracted_files_hash_verified": True, "source_from_extracted_archive_only": True,
              "existing_runtime_used_no_installation": True, "stages": exits,
              "full_submitted_capsule_replayed": True, "all12_submitted_payloads_exactly_equal": True,
              "independent_prepared_count_checker_passed": True, "eight_public_integration_tests_passed": True,
              "raw27_files_reconstructed": False, "elapsed_seconds": time.monotonic() - started,
              "new_output_bytes": sum(p.stat().st_size for p in run_root.rglob("*") if p.is_file())}
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    with args.receipt.open("x", encoding="utf8") as handle:
        json.dump(result, handle, indent=2);handle.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
