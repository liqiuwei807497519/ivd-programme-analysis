import csv,numpy as np,unittest
from pathlib import Path
from test_joint_scorer import JointScorer,sha,commit_sha
from joint_scorer import score_committed_joint_forecasts

class RationalQuantileContract(unittest.TestCase):
    def test_declared_95percent_rank_and_WIS_at_delete_group_world_count_1920(self):
        fixture=JointScorer();self.addCleanup(fixture.doCleanups)
        root,cfg,forecast,truth=fixture.fixture()
        cfg.update(M=1920,mc_precision=False);forecast['M']=1920
        for record in forecast['sections'].values():
            for bound in record['laws'].values():
                path=Path(bound['path'])
                samples=np.repeat(np.arange(1920,dtype=np.int64)[:,None,None],7,axis=2)
                np.savez_compressed(path,gene_region_totals=samples,gene_region_means=np.ones((1,7)),roi_keys=np.array([[0,0]],dtype=np.int64))
                bound['sha256']=sha(path)
        for bound in truth['sections'].values():
            path=Path(bound['path']);np.savez_compressed(path,gene_region_truth=np.zeros((1,7),dtype=np.int64),roi_keys=np.array([[0,0]],dtype=np.int64))
            bound['sha256']=sha(path)
        truth['forecast_commit_sha256']=commit_sha(forecast)
        score_committed_joint_forecasts(cfg,forecast,truth,root/'scores')
        with (root/'scores/COUNT_ROWS.tsv').open(encoding='utf-8') as stream:
            row=next(r for r in csv.DictReader(stream,delimiter='\t') if r['functional']=='TBXT')
        # Frozen inverse-empirical-CDF ranks:48th/1872nd values of0..1919.
        self.assertEqual(int(row['lower95']),47)
        self.assertEqual(int(row['upper95']),1871)
        self.assertEqual(float(row['IS95']),3704.)
        self.assertAlmostEqual(float(row['WIS']),403.8,places=12)

if __name__=='__main__':unittest.main()
