# Code and data conditions

The current MIT grant applies to original project-owned code. Third-party libraries and vendored code retain their own notices and licences. `LICENSE.proposed` and pending author forms retained in explicitly historical archive members describe earlier preparation, not the current accepted author-team code approval.

`checks/PACKAGE_CHECK.json` is an unchanged pre-approval build receipt. Its `active_license_grant: false` field records that earlier check, not the current licence state; it is retained to preserve the original verification evidence. Current permission is recorded by `LICENSE` and the parent `AUTHORIZATION.json`, not inferred from a historical build result.

Public GEO-derived inputs, FinnGen outputs, source imaging and on-request CTM material retain their original acquisition, citation and redistribution conditions. The code licence does not relicense data, images, clinical records or pretrained third-party assets. No raw source RDS/full expression matrix is released by this notice.

Additional18 supplies the actually checked nine-sample prepared-count reproduction and its source conditions. Additional19 supplies the actually checked portable derived-table figure replay; it does not reconstruct source acquisition, original training or a new methodological validation.

Current author metadata and local attachments are R6; no public repository URL, DOI, journal receipt or APC payment is asserted. The user's approval does not create independent individual signatures or a fact about consideration at another journal.
