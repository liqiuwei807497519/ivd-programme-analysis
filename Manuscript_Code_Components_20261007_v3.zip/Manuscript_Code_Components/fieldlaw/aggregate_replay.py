"""Replay scores from stored aggregate worlds, without fitting or sampling."""
import argparse
import csv
import gzip
import hashlib
import importlib
import json
from pathlib import Path
import sys
import numpy as np

LAWS=('INDEPENDENT_GENE_FIELDS','FIXED_RHO025_COMMON_FIELD','POOLED_SOURCE_CORR','CONDITIONAL_SOURCE_CORR')
GENES=['TBXT','KRT8','KRT18','KRT19','ACAN','COL2A1','SOX9']
FUNCTIONS={'ALL7':(0,1,2,3,4,5,6),'ACAN_COL2A1':(4,5),'OTHER5':(0,1,2,3,6)}
EVENT='ALL7_REGIONAL_TOTALS_POSITIVE_EVENT'

def readj(path):
    return json.loads(Path(path).read_text(encoding='utf8'))

def writej(path,value):
    with Path(path).open('x',encoding='utf8') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False,
                  default=lambda v:v.tolist() if isinstance(v,np.ndarray) else v.item())
        stream.write('\n')

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def science(bundle):
    sys.path.insert(0,str(Path(bundle)/'software'))
    return importlib.import_module('target_stage')

def configuration(bundle):
    config=readj(bundle/'REPLAY_CONFIG.json')
    if config['schema']!='FIELDLAW_AGGREGATE_REPLAY_V1':raise ValueError('Wrong aggregate replay schema')
    if (bundle/'FILE_MANIFEST.json').exists():
        for record in readj(bundle/'FILE_MANIFEST.json')['files']:
            path=(bundle/record['path']).resolve()
            if not path.is_relative_to(bundle) or sha(path)!=record['sha256']:
                raise ValueError('Release file hash mismatch: '+record['path'])
    captures=config['captures']
    if len({c['capture'] for c in captures})!=len(captures):raise ValueError('Duplicate library')
    if config['synthetic']:
        if any(not c['capture'].startswith('SYN_') for c in captures):raise ValueError('Synthetic capture required')
    elif ([c['capture'] for c in captures]!=['GSM6675529','GSM6675530','GSM6675531']
          or config['expected_rows']!=6656 or config['worlds']!=2048 or config['members']!=GENES):
        raise ValueError('Complete committed three-library population required')
    return config

def capsule(bundle,capture):
    path=(bundle/capture['capsule']).resolve()
    if not path.is_relative_to(bundle):raise ValueError('Capsule outside release')
    if 'sha256' in capture and sha(path)!=capture['sha256']:raise ValueError('Aggregate capsule hash mismatch')
    with np.load(path,allow_pickle=False) as data:
        names=set(data.files)
        if names=={'values','truth','region_keys'}:
            law_values={law:data['values'] for law in LAWS}
        elif names=={'truth','region_keys','member_ids',*LAWS}:
            if data['member_ids'].astype(str).tolist()!=GENES:raise ValueError('Seven member order mismatch')
            law_values={law:data[law] for law in LAWS}
        else:raise ValueError('Only complete aggregate fields admitted; native data excluded')
        truth,keys=data['truth'],data['region_keys']
    if truth.shape!=(len(keys),7) or truth.dtype.kind not in 'iu' or np.any(truth<0):raise ValueError('Exact aggregate truth required')
    if keys.shape!=(len(truth),2) or len(set(map(tuple,keys.tolist())))!=len(keys):raise ValueError('Unique ordered ROI keys required')
    worlds=None
    for values in law_values.values():
        if values.ndim!=3 or values.shape[1:]!=truth.shape or values.dtype.kind not in 'iu' or np.any(values<0):raise ValueError('Exact committed integer worlds required')
        if worlds is None:worlds=len(values)
        if len(values)!=worlds or worlds<32 or worlds%16:raise ValueError('Complete common world axis required')
    return law_values,truth,keys

def permute(conditional,seed):
    rng=np.random.default_rng(seed);values=np.empty_like(conditional);hashes=[]
    for gene in range(7):
        ids=rng.permutation(len(conditional));values[:,:,gene]=conditional[ids,:,gene]
        hashes.append(hashlib.sha256(ids.astype('<i8').tobytes()).hexdigest())
    return values,hashes

def scoring_replay(bundle,fresh_output):
    bundle,output=Path(bundle).resolve(),Path(fresh_output).resolve()
    config=configuration(bundle)
    stage=science(bundle)
    output.mkdir(parents=True,exist_ok=False)
    row_count=0
    for capture in config['captures']:
        law_values,truth,keys=capsule(bundle,capture)
        if not config['synthetic'] and (len(truth)!=capture['regions'] or len(law_values[LAWS[0]])!=config['worlds']):raise ValueError('Frozen support size mismatch')
        default={'date_utc':'SYNTHETIC','mode':'SYNTHETIC_AGGREGATE_REPLAY','capture':capture['capture'],
                'source_params_sha256':'SYNTHETIC','global_forecast_sha256':'SYNTHETIC',
                'global_truth_sha256':'SYNTHETIC','count_support_shift':stage.SUPPORT_SHIFT}
        frozen_header=capture.get('header',default)
        header={key:frozen_header[key] for key in default}
        rows,summaries,precision=[],{},{}
        for law in LAWS:
            values=law_values[law]
            results,event,summaries[law]=stage._evaluate(values,truth,config['scales'])
            precision[law]=stage._precision(values,truth,config['scales'])
            stage._append_rows(rows,header,law,results,event,keys,config['scales'],precision=precision[law])
        diagnostics=[]
        for seed in range(2026100611,2026100615):
            values,hashes=permute(law_values['CONDITIONAL_SOURCE_CORR'],seed)
            results,event,summary=stage._evaluate(values,truth,config['scales'],IID=False)
            diagnostic='GLOBAL_GENE_WORLD_PERMUTATION'
            diagnostics.append({'seed':seed,'law':'CONDITIONAL_SOURCE_CORR','diagnostic':diagnostic,'IID':False,
                'world_count':len(values),'per_gene_world_permutation_sha256':hashes,**summary})
            stage._append_rows(rows,header,'CONDITIONAL_SOURCE_CORR',results,event,keys,config['scales'],diagnostic=diagnostic,seed=seed)
        folder=output/capture['capture'];folder.mkdir()
        columns=list(dict.fromkeys(key for row in rows for key in row))
        with (folder/'ROWS.tsv').open('x',encoding='utf8',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=columns,delimiter='\t',lineterminator='\n')
            writer.writeheader();writer.writerows(rows)
        stage._write_json(folder/'SCORES.json',{'status':'TARGET_SCORES_COMPLETE',**header,'world_count':len(values),
            'region_count':len(keys),'source_scales':config['scales'],'generative_laws':summaries,
            'permutation_diagnostics':diagnostics,'mc_precision':precision,'row_count':len(rows),
            'primary_functional':'ALL7','primary_score':'IID-fair RPS','all_results_retained':True,
            'equal_roi_within_library':True,'equal_library_aggregation_is_parent_responsibility':True,
            'IID_fair_only_for_generative_laws':True,'extra_worlds':0,'new_point_model_fits':0})
        row_count+=len(rows)
    result={'status':'AGGREGATE_SCORING_REPLAY_COMPLETE','rows':row_count,'new_scenarios':0,'new_model_fits':0}
    writej(output/'REPLAY_COMPLETE.json',result)
    return result

def verify_outputs(bundle,replay_output):
    """Check every replay row/MC packet by the preserved independent CDF oracle."""
    bundle,output=Path(bundle).resolve(),Path(replay_output).resolve()
    config=configuration(bundle);sys.path.insert(0,str(bundle/'software'))
    from independent_scores import independent_count_scores
    from independent_mc import reconstruct_mc_precision,verify_mc_outputs
    checks=mc_checks=total_rows=0
    def same(actual,expected,label):
        nonlocal checks
        checks+=1
        if not np.isfinite(float(actual)) or not np.isclose(float(actual),expected,rtol=1e-10,atol=1e-10):
            raise ValueError('Independent numerical mismatch: '+label)
    for capture in config['captures']:
        law_values,truth,keys=capsule(bundle,capture);folder=output/capture['capture']
        with (folder/'ROWS.tsv').open(encoding='utf8',newline='') as stream:rows=list(csv.DictReader(stream,delimiter='\t'))
        scores=readj(folder/'SCORES.json');lookup={};expected_keys=set();worlds=len(law_values[LAWS[0]])
        for row in rows:
            key=(row['law'],row['diagnostic'],row['permutation_seed'],row['functional'],int(row['roi_x']),int(row['roi_y']))
            if key in lookup or row['capture']!=capture['capture'] or int(row['scenario_count'])!=worlds:raise ValueError('Duplicate or mismatched score key')
            lookup[key]=row
        def check_values(values,law,diagnostic='NONE',seed=''):
            IID=diagnostic=='NONE';means={name:[] for name in FUNCTIONS}
            for region,key in enumerate(keys):
                for name,members in FUNCTIONS.items():
                    row_key=(law,diagnostic,str(seed),name,int(key[0]),int(key[1]));expected_keys.add(row_key)
                    if row_key not in lookup:raise ValueError('Missing complete score key')
                    row=lookup[row_key];samples=[sum(int(values[w,region,g]) for g in members) for w in range(worlds)]
                    outcome=sum(int(truth[region,g]) for g in members);result=independent_count_scores(samples,outcome,IID=IID);scale=config['scales'][name]
                    if row['IID']!=('true' if IID else 'false'):raise ValueError('IID role mismatch')
                    for metric in ('empirical_rps','wis'):
                        same(row[metric],result[metric],metric);same(row['scaled_'+metric],result[metric]/scale,'scaled_'+metric)
                    same(row['source_scale'],scale,'scale');same(row['median'],result['median'],'median')
                    same(row['median_absolute_error'],abs(result['median']-outcome),'median AE')
                    same(row['scaled_median_absolute_error'],abs(result['median']-outcome)/scale,'scaled median AE')
                    if IID:
                        same(row['fair_rps'],result['fair_rps'],'fair');same(row['scaled_fair_rps'],result['fair_rps']/scale,'scaled fair')
                        means[name].append(result['fair_rps']/scale)
                    elif row['fair_rps'] or row['scaled_fair_rps'] or any(v for k,v in row.items() if k.startswith('mcse_')):
                        raise ValueError('Non-IID diagnostic contains fair/MCSE result')
                    for level,interval in result['intervals'].items():
                        for metric in ('lower','upper','width','left_miss','right_miss','interval_score'):same(row[metric+'_'+level],interval[metric],metric+'_'+level)
                        same(row['coverage_'+level],not(interval['left_miss'] or interval['right_miss']),'coverage')
                        same(row['scaled_width_'+level],interval['width']/scale,'scaled width')
                        same(row['scaled_interval_score_'+level],interval['interval_score']/scale,'scaled interval score')
                event_key=(law,diagnostic,str(seed),EVENT,int(key[0]),int(key[1]));expected_keys.add(event_key)
                if event_key not in lookup:raise ValueError('Missing complete event key')
                probability=sum(all(int(v)>0 for v in values[w,region]) for w in range(worlds))/worlds
                observed=all(int(v)>0 for v in truth[region])
                same(lookup[event_key]['event_probability'],probability,'event probability');same(lookup[event_key]['brier'],(probability-observed)**2,'Brier')
            if IID:
                for name,v in means.items():same(scores['generative_laws'][law]['functionals'][name]['scaled_fair_rps_mean'],float(np.mean(v)),'JSON mean')
        for law in LAWS:
            values=law_values[law];check_values(values,law)
            packet=reconstruct_mc_precision(values,truth,config['scales'])
            mc_checks+=verify_mc_outputs(packet,scores['mc_precision'][law],rows,law,keys)
        for seed in range(2026100611,2026100615):
            values,_=permute(law_values['CONDITIONAL_SOURCE_CORR'],seed)
            check_values(values,'CONDITIONAL_SOURCE_CORR','GLOBAL_GENE_WORLD_PERMUTATION',seed)
        if len(rows)!=32*len(keys) or set(lookup)!=expected_keys:raise ValueError('Complete exact row-key coverage mismatch')
        if not config['synthetic']:
            with gzip.open(bundle/capture['reference_rows'],'rb') as stream:reference=stream.read()
            if (folder/'ROWS.tsv').read_bytes()!=reference:raise ValueError('Original full ROWS byte mismatch')
            with gzip.open(bundle/capture['reference_scores'],'rt',encoding='utf8') as stream:original=json.load(stream)
            def compare(actual,expected,label):
                if isinstance(expected,dict):
                    if not isinstance(actual,dict) or set(actual)!=set(expected):raise ValueError('Original JSON schema mismatch '+label)
                    for k,v in expected.items():compare(actual[k],v,label+'/'+k)
                elif isinstance(expected,list):
                    if not isinstance(actual,list) or len(actual)!=len(expected):raise ValueError('Original JSON list mismatch '+label)
                    for i,v in enumerate(expected):compare(actual[i],v,label+'/'+str(i))
                elif isinstance(expected,(float,int)) and not isinstance(expected,bool):same(actual,expected,label)
                elif actual!=expected:raise ValueError('Original JSON value mismatch '+label)
            compare(scores,original,'SCORES')
        total_rows+=len(rows)
    if not config['synthetic'] and total_rows!=config['expected_rows']:raise ValueError('Incomplete original population')
    return {'status':'INDEPENDENT_AGGREGATE_REPLAY_PASS','rows':total_rows,'independent_row_numeric_checks':checks,
            'independent_MC_numeric_checks':mc_checks,'new_scenarios':0,'new_model_fits':0,'native_expression_reads':0}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=('score','verify'));parser.add_argument('--bundle',required=True);parser.add_argument('--output',required=True)
    args=parser.parse_args()
    if args.stage=='score':result=scoring_replay(args.bundle,args.output)
    else:
        result=verify_outputs(args.bundle,args.output);writej(Path(args.output)/'INDEPENDENT_REPLAY_AUDIT.json',result)
    print(json.dumps(result))
