"""Fresh-process CLI checks using temporary synthetic source capsules only."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np


HERE = Path(__file__).resolve().parent
PINNED_PYTHON = HERE.parents[1] / "IVD_Nonlinear_Baseline_20261002/preflight_v2/environment/venv/Scripts/python.exe"
GENES = ["TBXT", "KRT8", "KRT18", "KRT19", "ACAN", "COL2A1", "SOX9"]


def binding(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def synthetic_fixture(root):
    root = Path(root)
    input_ids = ["SYN_INPUT_" + str(i) for i in range(126)]
    records = []
    for capture_index, capture in enumerate(["SYN_A", "SYN_B"]):
        ids = np.array([capture + "|R" + str(i) + "_C0" for i in range(8)])
        x = np.zeros((8, 126), dtype=np.int64)
        x[np.arange(8), np.arange(8) // 2] = 10
        y = np.tile(np.arange(8, dtype=np.int64)[:, None], (1, 7))
        y[:, 1] = [1, 2, 1, 2, 1, 2, 1, 2]
        row = np.r_[np.arange(4), np.arange(12, 16)] if capture_index == 0 else np.arange(8)
        inputs = root / (capture + "_input.npz")
        np.savez(inputs, region_id=ids, x_counts=x, y_counts=y, row=row, col=np.zeros(8, dtype=int))
        predictions = root / (capture + "_predictions.npz")
        np.savez(predictions, region_id=ids[::-1], TotalXGB=np.full((8, 7), 2.0), member_ids=np.array(GENES))
        head = root / (capture + "_head.json")
        head.write_text(json.dumps({"input_ids": input_ids, "member_ids": GENES}), encoding="utf8")
        total = root / (capture + "_total.json")
        total.write_text(json.dumps({"synthetic_metadata_only": True}), encoding="utf8")
        commits = []
        for label in ["V2", "OLD_TOTAL"]:
            path = root / (capture + "_" + label + "_commit.json")
            path.write_text(json.dumps({"synthetic_source_commit": label}), encoding="utf8")
            commits.append(binding(path))
        records.append({"capture": capture, "input": binding(inputs), "predictions": binding(predictions),
                        "head_params": binding(head), "total_params": binding(total), "commits": commits})
    spec = root / "SYNTHETIC_SPEC.json"
    spec.write_text(json.dumps({"synthetic_only": True}), encoding="utf8")
    auth = root / "SYNTHETIC_AUTHORIZATION.json"
    auth.write_text(json.dumps({"synthetic_only": True}), encoding="utf8")
    code = [binding(HERE / "source_statistics.py")]
    if (HERE / "source_stage.py").exists():
        code.append(binding(HERE / "source_stage.py"))
    config = {"mode": "SYNTHETIC_SOURCE_STAGE", "source_records": records,
              "expected_source_observations": 16,
              "linkage": {"input_ids": input_ids, "member_ids": GENES,
                          "source_prediction_key": "TotalXGB", "source_region_id_key": "region_id"},
              "code_binding": code, "spec_binding": binding(spec), "authorization_binding": binding(auth)}
    config_path = root / "SYNTHETIC_CONFIG.json"
    config_path.write_text(json.dumps(config), encoding="utf8")
    return config_path, config


def run_cli(config, output):
    return subprocess.run([str(PINNED_PYTHON), "-B", str(HERE / "source_stage.py"),
                           "--config", str(config), "--output", str(output)],
                          text=True, capture_output=True, timeout=45)


class SourceStageTests(unittest.TestCase):
    def test_synthetic_cli_commits_literal_capture_balanced_source_roi_scales(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
            root = Path(temporary)
            config_path, _ = synthetic_fixture(root)
            output = root / "fresh_source_commit"
            completed = run_cli(config_path, output)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            parameters = json.loads((output / "SOURCE_PARAMS.json").read_text(encoding="utf8"))
            self.assertEqual(parameters["source_scales"], {"ALL7": 135.0, "ACAN_COL2A1": 42.0, "OTHER5": 93.0})
            self.assertEqual(parameters["alpha7"][0], 1.375)
            commit = json.loads((output / "SOURCE_COMMIT.json").read_text(encoding="utf8"))
            self.assertEqual(commit["source_observations"], 16)
            self.assertEqual(commit["SOURCE_PARAMS_sha256"], binding(output / "SOURCE_PARAMS.json")["sha256"])

    def test_every_bound_file_hash_is_verified_before_source_commit(self):
        for role in ["input", "predictions", "head_params", "total_params", "commits", "code_binding",
                     "spec_binding", "authorization_binding"]:
            with self.subTest(role=role), tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
                root = Path(temporary)
                config_path, config = synthetic_fixture(root)
                if role == "code_binding":
                    descriptor = config[role][0]
                elif role in ["spec_binding", "authorization_binding"]:
                    descriptor = config[role]
                elif role == "commits":
                    descriptor = config["source_records"][0][role][0]
                else:
                    descriptor = config["source_records"][0][role]
                descriptor["sha256"] = "0" * 64
                config_path.write_text(json.dumps(config), encoding="utf8")
                output = root / "fresh_source_commit"
                completed = run_cli(config_path, output)
                self.assertEqual(completed.returncode, 2, completed.stdout + completed.stderr)
                self.assertIn("hash", completed.stdout.lower())
                self.assertFalse(output.exists())

    def test_source_cli_audits_and_denies_target_raw_source_and_unlisted_reads(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
            root = Path(temporary)
            config_path, config = synthetic_fixture(root)
            output = root / "fresh_source_commit"
            completed = run_cli(config_path, output)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            commit = json.loads((output / "SOURCE_COMMIT.json").read_text(encoding="utf8"))
            audit = commit["read_audit"]
            self.assertEqual(len(audit["denied_read_probes"]), 3)
            self.assertTrue(all(item["denied"] for item in audit["denied_read_probes"]))
            self.assertEqual(audit["target_reads"], 0)
            self.assertIn("Python open", audit["scope"])
            self.assertTrue(set(item["input"]["path"] for item in config["source_records"]).issubset(audit["read_paths"]))

    def test_prediction_means_join_by_id_and_canonicalize_with_source_counts(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
            root = Path(temporary)
            config_path, config = synthetic_fixture(root)
            for record in config["source_records"]:
                path = Path(record["predictions"]["path"])
                ids = np.array([record["capture"] + "|R" + str(i) + "_C0" for i in range(8)])
                means = np.full((8, 7), 2.0)
                means[:, 0] = [2, 3, 2, 3, 2, 3, 2, 3]
                np.savez(path, region_id=ids[::-1], TotalXGB=means[::-1], member_ids=np.array(GENES))
                record["predictions"] = binding(path)
            config_path.write_text(json.dumps(config), encoding="utf8")
            first, second = root / "canonical_first", root / "canonical_second"
            completed = run_cli(config_path, first)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            params = json.loads((first / "SOURCE_PARAMS.json").read_text(encoding="utf8"))
            # Hand numerator terms [2,1,-2,-3,2,1,14,13] sum to28;
            # sum(mu^2)=52, hence28/52=7/13.
            self.assertAlmostEqual(params["alpha7"][0], 0.5384615384615384, places=14)
            for record in config["source_records"]:
                path = Path(record["input"]["path"])
                with np.load(path, allow_pickle=False) as archive:
                    arrays = {key: archive[key][::-1] for key in archive.files}
                np.savez(path, **arrays)
                record["input"] = binding(path)
            config_path.write_text(json.dumps(config), encoding="utf8")
            completed = run_cli(config_path, second)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            reordered = json.loads((second / "SOURCE_PARAMS.json").read_text(encoding="utf8"))
            fit_keys = ["seed", "pit_seed", "alpha7", "anchor_mean127", "anchor_sd127", "state_centroids4x127",
                        "state_weights", "state_fit", "capture_ids", "observation_weights", "residual_correlations"]
            self.assertEqual({key: params[key] for key in fit_keys}, {key: reordered[key] for key in fit_keys})
            self.assertEqual(params["source_scales"], reordered["source_scales"])
            self.assertEqual([item["canonical_region_ids_sha256"] for item in params["source_io_binding"]],
                             [item["canonical_region_ids_sha256"] for item in reordered["source_io_binding"]])

    def test_invalid_identity_roles_modes_and_observation_expectations_block(self):
        for invalid in ["duplicate_prediction", "missing_prediction", "head_roles", "forecast_roles",
                        "observation_count", "real_mode_count", "missing_code_binding"]:
            with self.subTest(invalid=invalid), tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
                root = Path(temporary)
                config_path, config = synthetic_fixture(root)
                record = config["source_records"][0]
                if invalid in ["duplicate_prediction", "missing_prediction", "forecast_roles"]:
                    path = Path(record["predictions"]["path"])
                    with np.load(path, allow_pickle=False) as archive:
                        arrays = {key: archive[key] for key in archive.files}
                    if invalid == "duplicate_prediction":
                        arrays["region_id"][0] = arrays["region_id"][1]
                    elif invalid == "missing_prediction":
                        arrays["region_id"] = arrays["region_id"][:-1]
                        arrays["TotalXGB"] = arrays["TotalXGB"][:-1]
                    else:
                        arrays["member_ids"] = arrays["member_ids"][::-1]
                    np.savez(path, **arrays)
                    record["predictions"] = binding(path)
                elif invalid == "head_roles":
                    path = Path(record["head_params"]["path"])
                    head = json.loads(path.read_text(encoding="utf8"))
                    head["input_ids"] = head["input_ids"][::-1]
                    path.write_text(json.dumps(head), encoding="utf8")
                    record["head_params"] = binding(path)
                elif invalid == "observation_count":
                    config["expected_source_observations"] = 17
                elif invalid == "real_mode_count":
                    config["mode"] = "AUTHORIZED_REAL_SOURCE_FIT"
                else:
                    config["code_binding"] = config["code_binding"][:1]
                config_path.write_text(json.dumps(config), encoding="utf8")
                output = root / "fresh_source_commit"
                completed = run_cli(config_path, output)
                self.assertEqual(completed.returncode, 2, completed.stdout + completed.stderr)
                self.assertFalse(output.exists())

    def test_forbidden_paths_remain_blocked_when_listed_in_config(self):
        for name in ["GSE216511", "target", "RAW_SOURCE_CAPSULE.rds"]:
            with self.subTest(name=name), tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
                root = Path(temporary)
                config_path, config = synthetic_fixture(root)
                original = Path(config["source_records"][0]["total_params"]["path"])
                if name.endswith(".rds"):
                    forbidden = root / name
                else:
                    directory = root / name
                    directory.mkdir()
                    forbidden = directory / "synthetic_metadata.json"
                original.rename(forbidden)
                config["source_records"][0]["total_params"] = binding(forbidden)
                config_path.write_text(json.dumps(config), encoding="utf8")
                output = root / "fresh_source_commit"
                completed = run_cli(config_path, output)
                self.assertEqual(completed.returncode, 2, completed.stdout + completed.stderr)
                self.assertIn("forbid", completed.stdout.lower())
                self.assertFalse(output.exists())

    def test_existing_source_output_is_preserved_and_not_overwritten(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
            root = Path(temporary)
            config_path, _ = synthetic_fixture(root)
            output = root / "fresh_source_commit"
            completed = run_cli(config_path, output)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            before = {path.name: binding(path)["sha256"] for path in output.iterdir()}
            completed = run_cli(config_path, output)
            self.assertEqual(completed.returncode, 2, completed.stdout + completed.stderr)
            self.assertIn("fresh", completed.stdout.lower())
            self.assertEqual(before, {path.name: binding(path)["sha256"] for path in output.iterdir()})

    def test_zero_source_roi_truths_produce_only_the_declared_scale_floor(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
            root = Path(temporary)
            config_path, config = synthetic_fixture(root)
            for record in config["source_records"]:
                path = Path(record["input"]["path"])
                with np.load(path, allow_pickle=False) as archive:
                    arrays = {key: archive[key] for key in archive.files}
                arrays["y_counts"] = np.zeros((8, 7), dtype=np.int64)
                np.savez(path, **arrays)
                record["input"] = binding(path)
            config_path.write_text(json.dumps(config), encoding="utf8")
            output = root / "fresh_source_commit"
            completed = run_cli(config_path, output)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            params = json.loads((output / "SOURCE_PARAMS.json").read_text(encoding="utf8"))
            self.assertEqual(params["source_scales"], {"ALL7": 1.0, "ACAN_COL2A1": 1.0, "OTHER5": 1.0})

    def test_each_capture_requires_two_distinct_original_commit_bindings(self):
        for incomplete in ["one_commit", "duplicated_commit"]:
            with self.subTest(incomplete=incomplete), tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
                root = Path(temporary)
                config_path, config = synthetic_fixture(root)
                first = config["source_records"][0]["commits"][0]
                config["source_records"][0]["commits"] = [first] if incomplete == "one_commit" else [first, dict(first)]
                config_path.write_text(json.dumps(config), encoding="utf8")
                output = root / "fresh_source_commit"
                completed = run_cli(config_path, output)
                self.assertEqual(completed.returncode, 2, completed.stdout + completed.stderr)
                self.assertIn("commit", completed.stdout.lower())
                self.assertFalse(output.exists())

    def test_manifest_can_bind_target_stage_code_without_executing_it(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
            root = Path(temporary)
            config_path, config = synthetic_fixture(root)
            code = root / "target_stage.py"
            code.write_text("raise RuntimeError('source stage must never execute this code')\n", encoding="utf8")
            config["code_binding"].append(binding(code))
            config_path.write_text(json.dumps(config), encoding="utf8")
            output = root / "fresh_source_commit"
            completed = run_cli(config_path, output)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            commit = json.loads((output / "SOURCE_COMMIT.json").read_text(encoding="utf8"))
            self.assertEqual(commit["bindings_before"][str(code)], binding(code)["sha256"])

    def test_supervisor_synthetic_mode_produces_the_canonical_source_commit_mode(self):
        with tempfile.TemporaryDirectory(prefix="fieldlaw_source_stage_synthetic_") as temporary:
            root = Path(temporary)
            config_path, config = synthetic_fixture(root)
            config["mode"] = "SYNTHETIC_SUPERVISOR_TEST"
            config_path.write_text(json.dumps(config), encoding="utf8")
            output = root / "fresh_source_commit"
            completed = run_cli(config_path, output)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            commit = json.loads((output / "SOURCE_COMMIT.json").read_text(encoding="utf8"))
            self.assertEqual(commit["mode"], "SYNTHETIC_SOURCE_STAGE")


if __name__ == "__main__":
    unittest.main(verbosity=2)
