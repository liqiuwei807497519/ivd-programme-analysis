"""Exact source-RNA input/label preparation, without target-dependent features."""

import argparse
import csv
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import sys

import numpy as np


GENES = ["TBXT", "KRT8", "KRT18", "KRT19", "ACAN", "COL2A1", "SOX9"]
PARENTS = ["Control", "Day_1", "Day_3", "Day_28"]
SYNTHETIC_MODE = "SYNTHETIC_SOURCE_ONLY_RNA_MEAN"
REAL_MODE = "AUTHORIZED_SOURCE_ONLY_RNA_MEAN"
MAX_COUNT = np.iinfo(np.int64).max


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def record(path):
    return {"path": str(Path(path).resolve()), "sha256": sha(path)}


def write_json(path, value):
    with Path(path).open("x", encoding="utf8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def exact_count(token, label):
    """Parse an integer-valued numeric token exactly, without rounding."""
    try:
        value = Decimal(str(token))
    except InvalidOperation as error:
        raise ValueError(label + " is not a numeric count") from error
    if not value.is_finite() or value < 0 or value != value.to_integral_value() or value > MAX_COUNT:
        raise ValueError(label + " must be an exact nonnegative int64 count")
    return int(value)


def config_bindings(config):
    values = list(config["code_binding"]) + [config["plan_binding"], config["authorization_binding"]]
    for section in config["sections"]:
        values.extend(section[key] for key in ("counts", "coordinates", "features", "exports"))
    return values


def verify_bindings(bindings):
    verified = {}
    for binding in bindings:
        path = Path(binding["path"]).resolve()
        actual = sha(path)
        if actual != binding["sha256"]:
            raise ValueError("source/code/authority hash mismatch: " + str(path))
        verified[str(path)] = actual
    return verified


def role_columns(config, section):
    roles = config["ordered_roles"]
    if len(roles) != 133 or [item["role"] for item in roles] != ["anchor"] * 126 + ["member"] * 7:
        raise ValueError("all126 anchor and7member roles must retain exact order")
    requested = [item["frozen_symbol"] for item in roles]
    tokens = [item["rat_feature"] for item in roles]
    if len(set(requested)) != 133 or len(set(tokens)) != 133 or requested[-7:] != GENES:
        raise ValueError("source gene roles must be unique, disjoint and preserve7members")
    with Path(section["features"]["path"]).open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    for role in roles:
        matched = [row for row in rows if row["request"] == role["frozen_symbol"]]
        if len(matched) != 1 or matched[0]["present"].upper() != "TRUE" or matched[0]["rat_feature"] != role["rat_feature"]:
            raise ValueError("required rat feature role is missing, ambiguous or changed: " + role["frozen_symbol"])
    return requested


def _section_arrays(config, section):
    columns = role_columns(config, section)
    with Path(section["counts"]["path"]).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        header = reader.fieldnames or []
        if len(header) != len(set(header)) or "barcode" not in header or any(column not in header for column in columns):
            raise ValueError("all133 count columns and unique barcode header required; no fill/drop")
        rows = list(reader)
    expected = section["expected_rows"]
    if len(rows) != expected or len({row["barcode"] for row in rows}) != expected or any(not row["barcode"] for row in rows):
        raise ValueError("source count barcodes must preserve every expected observation uniquely")
    with Path(section["coordinates"]["path"]).open(encoding="utf-8-sig", newline="") as stream:
        metadata = list(csv.DictReader(stream))
    if len(metadata) != expected or len({row["barcode"] for row in metadata}) != expected or {row["barcode"] for row in metadata} != {row["barcode"] for row in rows}:
        raise ValueError("coordinates and source count barcode sets must match exactly")
    lookup = {row["barcode"]: row for row in metadata}
    ordered = sorted(rows, key=lambda row: row["barcode"])
    barcodes = np.array([row["barcode"] for row in ordered])
    counts = np.array([[exact_count(row[column], section["section_folder"] + "/" + column) for column in columns] for row in ordered], dtype=np.int64)
    coordinate_rows = []
    for barcode in barcodes:
        meta = lookup[barcode]
        if meta["section"] != section["section_id"] or meta["sampleid"] != section["parent"]:
            raise ValueError("source section/parent metadata identity differs from config")
        row, col = exact_count(meta["array_row"], "array_row"), exact_count(meta["array_col"], "array_col")
        if (row + col) % 2:
            raise ValueError("native Visium row/column parity is invalid")
        coordinate_rows.append([col / 2.0 * 100.0, row * np.sqrt(3.0) / 2.0 * 100.0])
    coords = np.asarray(coordinate_rows)
    if not np.isfinite(coords).all():
        raise ValueError("native coordinates are not finite")
    roi_keys, inverse = np.unique(np.floor(coords / 500.0).astype(np.int64), axis=0, return_inverse=True)
    exported = read_json(section["exports"]["path"])
    if exported["spots"] != expected or exported["section"] != section["section_id"] or exported["sampleid"] != section["parent"]:
        raise ValueError("source export metadata differs from complete section identity")
    ids = np.array([section["section_folder"] + "|" + barcode for barcode in barcodes])
    return {"x_counts": counts[:, :126], "y_counts": counts[:, 126:], "region_id": ids,
            "barcode": barcodes, "coords_um": coords, "roi_indices": inverse.astype(np.int64), "roi_keys": roi_keys}


def prepare(config, fresh_output):
    """Prepare every source observation, with X-only and separate source-label files."""
    config_path = Path(config).resolve() if not isinstance(config, dict) else None
    specification = read_json(config_path) if config_path is not None else config
    output = Path(fresh_output).resolve()
    if output.exists():
        raise ValueError("RNA preparation output must be fresh")
    mode = specification["mode"]
    if mode not in (SYNTHETIC_MODE, REAL_MODE):
        raise ValueError("RNA source mode is not authorized")
    sections = specification["sections"]
    if any(not isinstance(row.get("section_folder"), str) or re.fullmatch(r"[A-Za-z0-9_-]+", row["section_folder"]) is None for row in sections):
        raise ValueError("section folders must be safe plain identifiers, never paths")
    if len(sections) != 8 or len({row["section_folder"] for row in sections}) != 8 or len({row["section_id"] for row in sections}) != 8:
        raise ValueError("all8 distinct source sections required")
    if sorted(specification["outer_groups"]) != sorted(PARENTS) or any(sum(row["parent"] == parent for row in sections) != 2 for parent in PARENTS):
        raise ValueError("four fixed parents must each contain both sections")
    if mode == SYNTHETIC_MODE and any(not row["section_folder"].startswith("SYN_") for row in sections):
        raise ValueError("synthetic source sections must use SYN_ folders")
    if mode == REAL_MODE and specification["expected_total_rows"] != 11893:
        raise ValueError("real source must preserve all11893 cached observations")
    bindings = config_bindings(specification)
    before = verify_bindings(bindings)
    config_hash = sha(config_path) if config_path is not None else hashlib.sha256(json.dumps(specification, sort_keys=True).encode()).hexdigest()
    arrays = {section["section_folder"]: _section_arrays(specification, section) for section in sections}
    observations = sum(len(value["region_id"]) for value in arrays.values())
    if observations != specification["expected_total_rows"]:
        raise ValueError("RNA preparation must retain the complete fixed observation total")
    after = verify_bindings(bindings)
    if before != after or config_path is not None and sha(config_path) != config_hash:
        raise ValueError("source/code/config changed during preparation")
    output.mkdir(parents=True, exist_ok=False)
    output_sections = {}
    for section in sections:
        folder = output / "sections" / section["section_folder"]
        folder.mkdir(parents=True)
        value = arrays[section["section_folder"]]
        input_path, labels_path = folder / "INPUTS.npz", folder / "SOURCE_LABELS.npz"
        np.savez_compressed(input_path, **{key: value[key] for key in ("x_counts", "region_id", "barcode", "coords_um", "roi_indices", "roi_keys")})
        np.savez_compressed(labels_path, **{key: value[key] for key in ("y_counts", "region_id", "barcode")})
        output_sections[section["section_folder"]] = {"section_id": section["section_id"], "parent": section["parent"],
            "observations": len(value["region_id"]), "regions": len(value["roi_keys"]),
            "artifacts": {"INPUTS.npz": record(input_path), "SOURCE_LABELS.npz": record(labels_path)}}
    commit = {"status": "RNA_INPUTS_PREPARED", "mode": mode, "config_sha256": config_hash,
              "observations": observations, "sections": output_sections, "ordered_roles": specification["ordered_roles"],
              "bindings_before": before, "bindings_after": after, "hidden_fields_not_parsed_as_predictive_values": True,
              "all_source_labels_validated_during_prepare": True, "labels_already_exposed_not_fresh_blind": True,
              "no_target_dependent_filter_or_parameters": True, "new_fits": 0, "all_observations_retained": True,
              "nominal_coordinates": "x=array_col/2*100;y=array_row*sqrt(3)/2*100; origin0 nominal500um persection; no image registration"}
    write_json(output / "PREPARE_COMMIT.json", commit)
    return commit


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["prepare"])
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        result = prepare(args.config, args.output)
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({"status": "RNA_PREPARE_BLOCKED", "reason": str(error)}), flush=True)
        sys.exit(2)
    print(json.dumps({"status": result["status"], "observations": result["observations"], "sections": len(result["sections"])}), flush=True)
