"""Create a code/input/proof-only archive and verify a fresh extracted replay."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import time
import zipfile

HERE = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def archive(path):
    files = [HERE / name for name in ['run_replay.py', 'figure_style.py', 'README.md',
             'package_replay.py', 'review_render.py']]
    files += sorted(p for p in (HERE / 'inputs').rglob('*') if p.is_file())
    if (HERE / 'proof').exists():
        files += sorted(p for p in (HERE / 'proof').rglob('*') if p.is_file())
    assert all(p.suffix.lower() not in ['.pdf', '.png', '.svg'] for p in files)
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for item in files:
            bundle.write(item, item.relative_to(HERE).as_posix())
    assert path.stat().st_size <= 20 * 1024**2
    return {item.relative_to(HERE).as_posix(): sha(item) for item in files}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['archive', 'fresh-run'])
    parser.add_argument('--archive', type=Path, default=HERE / 'portable_source_input_pack.zip')
    parser.add_argument('--extract-dir', type=Path, default=HERE / 'fresh_extracted')
    args = parser.parse_args()
    members = archive(args.archive)
    if args.mode == 'fresh-run':
        assert not args.extract_dir.exists(), 'Choose a new extraction directory; do not overwrite a prior run'
        args.extract_dir.mkdir(parents=True)
        with zipfile.ZipFile(args.archive) as bundle:
            bundle.extractall(args.extract_dir)
        assert members == {name: sha(args.extract_dir / name) for name in members}
        started = time.monotonic()
        result = subprocess.run([sys.executable, '-B', 'run_replay.py'], cwd=args.extract_dir,
            capture_output=True, text=True, encoding='utf8', errors='replace', timeout=900)
        proof = {'status': 'FRESH_EXTRACTED_REPLAY_EXIT_ZERO' if result.returncode == 0 else 'FRESH_EXTRACTED_REPLAY_EXIT_NONZERO',
            'actual_process_returncode': result.returncode, 'archive_sha256': sha(args.archive),
            'archive_bytes': args.archive.stat().st_size, 'archive_members_sha256': members,
            'fresh_directory': args.extract_dir.name, 'command': 'python -B run_replay.py',
            'elapsed_seconds': time.monotonic() - started, 'installs': 0,
            'source_population': 'Two packaged full spatial-value TSV.GZ tables; 30829 regions, seven members, four methods',
            'historical_workspace_or_absolute_skill_dependency': False}
        (args.extract_dir / 'FRESH_EXTRACTION_RECEIPT.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf8')
        print(json.dumps(proof, indent=2))
        print(result.stdout.rstrip())
        if result.stderr:
            print(result.stderr.rstrip(), file=sys.stderr)
        return result.returncode
    print(json.dumps({'archive': args.archive.name, 'sha256': sha(args.archive),
        'bytes': args.archive.stat().st_size, 'members': len(members),
        'figure_assets_included': False, 'maximum_archive_MiB': 20}, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
