"""Sample-level GSE222182 statistics on the new authorized pseudobulk seam.

This module does not acquire raw files, authorize source access, train models or
claim an outer completion. The caller owns authority and resource supervision.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
import gzip
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

from vendor import frozen_core as core

CORE_SHA256 = "515f3d6cf382327717dfcd9691e962bc487a61a1976659ea79dcdc8e4a19b368"
SAMPLES = [f"GSM{i}" for i in range(6917305, 6917314)]
GROUPS = ["asymptomatic"] * 4 + ["back_pain"] * 3 + ["stress", "no_stress"]
LAYERS = ["natural_IVD"] * 7 + ["cultured_pair"] * 2


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, (float, np.floating)):
        if math.isnan(float(value)):
            return None
        if math.isinf(float(value)):
            return "Infinity" if value > 0 else "-Infinity"
        return float(value)
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def _write_json(path: Path, payload: Any) -> None:
    with path.open("x", encoding="utf-8") as handle:
        json.dump(_json_safe(payload), handle, ensure_ascii=False, indent=2,
                  sort_keys=True, allow_nan=False)
        handle.write("\n")


def _write_tsv(path: Path, rows: list[dict], fields: list[str]) -> None:
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: "NA" if row.get(k) is None else row.get(k, "NA")
                             for k in fields})


def _natural(counts: np.ndarray, genes: list[str], names: list[str]) -> tuple[dict, np.ndarray, np.ndarray, dict]:
    programmes = core.FROZEN_PROGRAMMES
    core.validate_frozen_programmes(programmes)
    expression = core.log2_cpm(counts)
    z, available = core.standardize_across_samples(expression)
    scores, coverage = core.score_programmes(z, genes, programmes)
    tests, raw_p = {}, {}
    for programme in programmes:
        if programme.name in scores:
            result = core.exact_welch_permutation(scores[programme.name], [4, 5, 6],
                                                  programme.expected_direction)
            tests[programme.name] = {"status": "ANALYZED", **asdict(result)}
        else:
            tests[programme.name] = {
                "status": "MAPPING_COVERAGE_FAIL", "effect": None,
                "statistic": None, "p_exact": 1.0, "allocations": 35,
                "direction": programme.expected_direction, "extreme_allocations": None,
            }
        raw_p[programme.name] = tests[programme.name]["p_exact"]
    for name, p_holm in core.holm_adjust(raw_p).items():
        tests[name]["p_holm6"] = p_holm
    resident = tests["Resident_identity"]
    if resident["status"] != "ANALYZED":
        terminal = "NO_GO_MAPPING_OR_SCHEMA"
    elif resident["effect"] < 0 and resident["p_exact"] <= 0.05:
        terminal = "SUPPORTED_BOUNDED_PRIMARY"
    elif resident["effect"] < 0:
        terminal = "DIRECTIONAL_NOT_SIGNIFICANT"
    else:
        terminal = "OPPOSITE_OR_NULL"

    gene_loo = []
    resident_genes = programmes[0].genes
    for omitted in resident_genes:
        row = {"omitted_gene": omitted, "status": "NOT_ESTIMABLE",
               "effect": None, "statistic": None, "p_exact": None, "allocations": None}
        if resident["status"] == "ANALYZED":
            kept = [genes.index(gene) for gene in resident_genes if gene != omitted]
            result = core.exact_welch_permutation(z[:, kept].mean(axis=1), [4, 5, 6], "lower")
            row.update(status="ANALYZED", **asdict(result))
        else:
            row["reason"] = "PRIMARY_RESIDENT_NOT_ESTIMABLE"
        gene_loo.append(row)

    sample_loo = []
    for omitted, sample in enumerate(names):
        keep = np.arange(7) != omitted
        kept_names = [name for i, name in enumerate(names) if keep[i]]
        positive = [i for i, name in enumerate(kept_names) if name in names[4:]]
        row = {"omitted_sample": sample, "omitted_group": GROUPS[omitted],
               "remaining_back_pain": len(positive), "remaining_asymptomatic": 6 - len(positive),
               "status": "NOT_ESTIMABLE", "effect": None, "statistic": None,
               "p_exact": None, "allocations": None, "coverage": None}
        if resident["status"] == "ANALYZED":
            loo_log = core.log2_cpm(counts[keep])
            loo_z, _ = core.standardize_across_samples(loo_log)
            loo_scores, loo_coverage = core.score_programmes(loo_z, genes, [programmes[0]])
            row["coverage"] = loo_coverage[0]
            if "Resident_identity" in loo_scores:
                result = core.exact_welch_permutation(loo_scores["Resident_identity"], positive, "lower")
                row.update(status="ANALYZED", **asdict(result))
            else:
                row["reason"] = "LOO_RESIDENT_MISSING_OR_ZERO_SD"
        else:
            row["reason"] = "PRIMARY_RESIDENT_NOT_ESTIMABLE"
        sample_loo.append(row)
    analysis = {
        "terminal_state": terminal, "sample_count": 7, "back_pain_count": 3,
        "asymptomatic_count": 4, "available_gene_count": int(available.sum()),
        "coverage": coverage, "programme_tests": tests,
        "resident_leave_one_gene_out": gene_loo,
        "resident_leave_one_sample_out": sample_loo,
        "cell_level_inference_used": False, "exact_allocation_count": 35,
        "frozen_programme_family_size": 6,
        "frozen_programmes_source_sha256": core.FROZEN_PROGRAMMES_SOURCE_SHA256,
        "secondary_family_resolution_ceiling": "minimum_raw_p_1_over_35;Holm6_cannot_reach_0.05",
        "evidence_scope": "SOURCE_CONFOUNDED_SAMPLE_LEVEL_ASSOCIATION_NOT_CONFIRMATORY",
        "exchangeability_assumption": "Labels exchangeable across7donors for the reference exact test; tissue origin may violate this assumption.",
        "tissue_source_confounding": "2of4asymptomaticcadaver;remaining2asymptomatic+3backpainsurgical;GSMsourcecrosswalkunavailable",
        "source_stratified_sensitivity": "NOT_IDENTIFIABLE_NO_OFFICIAL_GSM_SOURCE_MAPPING",
        "spatial_method_validation": False,
    }
    return analysis, z, available, scores


def run(root: str | Path) -> dict:
    root = Path(root).resolve()
    output = root / "statistics"
    if output.exists():
        raise FileExistsError("Statistics one-shot output already exists; no resume or overwrite")
    if _sha(Path(core.__file__)) != CORE_SHA256:
        raise RuntimeError("Frozen numerical core SHA changed")
    input_path, meta_path = root / "PSEUDOBULK.npz", root / "PSEUDOBULK_META.json"
    metadata = json.loads(meta_path.read_text(encoding="utf-8"))
    if not isinstance(metadata.get("authorization_sha256"), str) or len(metadata["authorization_sha256"]) != 64:
        raise ValueError("New authorization SHA binding absent")
    qc = metadata.get("qc")
    if not isinstance(qc, list) or [row.get("sample_accession") for row in qc] != SAMPLES:
        raise ValueError("Nine-sample QC roster mismatch")
    with np.load(input_path, allow_pickle=False) as data:
        if set(data.files) != {"counts", "genes", "samples", "groups", "layers"}:
            raise ValueError("Pseudobulk array contract differs")
        counts = data["counts"].copy()
        text_arrays = {name: data[name].copy() for name in ("genes", "samples", "groups", "layers")}
    if counts.dtype != np.float64 or counts.ndim != 2 or counts.shape[0] != 9 or counts.shape[1] == 0:
        raise ValueError("Expected float64 integer-count array9xG")
    if not np.isfinite(counts).all() or (counts < 0).any() or (counts != np.floor(counts)).any():
        raise ValueError("Pseudobulk counts must be finite nonnegative integers")
    sums = counts.astype(np.longdouble).sum(axis=1)
    if (sums <= 0).any() or (sums > 2**53).any():
        raise ValueError("Zero library or aggregate outside exact float64 integer support")
    for name, array in text_arrays.items():
        expected = counts.shape[1] if name == "genes" else 9
        if array.ndim != 1 or array.dtype.kind != "U" or array.size != expected:
            raise ValueError(f"Unicode vector shape mismatch: {name}")
    genes = text_arrays["genes"].tolist()
    if any(not gene or gene != gene.strip().upper() for gene in genes) or len(set(genes)) != len(genes):
        raise ValueError("Gene schema must be nonempty canonical unique symbols")
    if text_arrays["samples"].tolist() != SAMPLES or text_arrays["groups"].tolist() != GROUPS or text_arrays["layers"].tolist() != LAYERS:
        raise ValueError("Frozen natural/cultured roster or order differs")

    output.mkdir(exist_ok=False)
    analysis, z, available, scores = _natural(counts[:7], genes, SAMPLES[:7])
    log_all = core.log2_cpm(counts)
    np.savez_compressed(output / "ALL_GENE_DATA.npz", counts=counts,
        **text_arrays, log2_cpm_all=log_all, z_natural=z,
        natural_indices=np.arange(7), cultured_indices=np.array([7, 8]),
        available_natural=available)
    _write_json(output / "NATURAL_ANALYSIS.json", analysis)

    tests = [{"programme": programme.name, **analysis["programme_tests"][programme.name]}
             for programme in core.FROZEN_PROGRAMMES]
    _write_tsv(output / "PROGRAMME_TESTS.tsv", tests,
               ["programme", "status", "effect", "statistic", "direction", "p_exact", "p_holm6", "allocations", "extreme_allocations"])
    coverage_rows = [{**row, "available_genes": ";".join(row["available_genes"]),
                      "missing_or_zero_sd_genes": ";".join(row["missing_or_zero_sd_genes"])}
                     for row in analysis["coverage"]]
    _write_tsv(output / "PROGRAMME_COVERAGE.tsv", coverage_rows,
               ["programme", "declared_n", "required_n", "available_n", "available_genes", "missing_or_zero_sd_genes", "coverage_pass"])
    score_rows = [{"sample_accession": name, "group": GROUPS[i], "programme": programme.name,
                   "score": float(scores[programme.name][i]) if programme.name in scores else None,
                   "status": "ANALYZED" if programme.name in scores else "MAPPING_COVERAGE_FAIL"}
                  for programme in core.FROZEN_PROGRAMMES for i, name in enumerate(SAMPLES[:7])]
    _write_tsv(output / "SAMPLE_PROGRAMME_SCORES.tsv", score_rows,
               ["sample_accession", "group", "programme", "score", "status"])
    qc_rows = [{**row, "layer": LAYERS[i], "group": GROUPS[i], "library_count_sum": float(counts[i].sum())}
               for i, row in enumerate(qc)]
    _write_tsv(output / "SAMPLE_PSEUDOBULK_QC.tsv", qc_rows,
               ["sample_accession", "layer", "group", "released_barcodes", "zero_library_barcodes_removed", "retained_barcodes", "released_feature_rows", "collapsed_symbols", "library_count_sum"])
    all_members = list(dict.fromkeys(g for programme in core.FROZEN_PROGRAMMES for g in programme.genes))
    index = {gene: i for i, gene in enumerate(genes)}
    member_rows = []
    for sample_i, sample in enumerate(SAMPLES):
        for gene in all_members:
            j = index.get(gene)
            member_rows.append({"sample_accession": sample, "layer": LAYERS[sample_i],
                "group": GROUPS[sample_i], "gene": gene, "measured": j is not None,
                "raw_count": float(counts[sample_i, j]) if j is not None else None,
                "log2_cpm": float(log_all[sample_i, j]) if j is not None else None,
                "available_natural": bool(available[j]) if j is not None else False,
                "z_natural": float(z[sample_i, j]) if sample_i < 7 and j is not None and available[j] else None})
    _write_tsv(output / "PROGRAMME_MEMBERS.tsv", member_rows,
               ["sample_accession", "layer", "group", "gene", "measured", "raw_count", "log2_cpm", "available_natural", "z_natural"])
    _write_tsv(output / "RESIDENT_LEAVE_ONE_GENE_OUT.tsv", analysis["resident_leave_one_gene_out"],
               ["omitted_gene", "status", "reason", "effect", "statistic", "p_exact", "allocations"])
    _write_tsv(output / "RESIDENT_LEAVE_ONE_SAMPLE_OUT.tsv", analysis["resident_leave_one_sample_out"],
               ["omitted_sample", "omitted_group", "remaining_back_pain", "remaining_asymptomatic", "status", "reason", "effect", "statistic", "p_exact", "allocations"])
    cultured_rows = []
    for programme in core.FROZEN_PROGRAMMES:
        used = [index[gene] for gene in programme.genes if gene in index]
        required = len(programme.genes) if programme.name == "Resident_identity" else max(3, math.ceil(0.8 * len(programme.genes)))
        ok = len(used) >= required
        stress = float(log_all[7, used].mean()) if ok else None
        no_stress = float(log_all[8, used].mean()) if ok else None
        cultured_rows.append({"programme": programme.name, "available_n": len(used),
            "required_n": required, "stressed_score": stress, "nonstressed_score": no_stress,
            "difference_stressed_minus_nonstressed": stress - no_stress if ok else None,
            "inferential_status": "DESCRIPTIVE_SINGLE_PAIR_NO_P_VALUE" if ok else "DESCRIPTIVE_MAPPING_COVERAGE_FAIL"})
    _write_tsv(output / "CULTURED_PAIR_SCORES.tsv", cultured_rows,
               ["programme", "available_n", "required_n", "stressed_score", "nonstressed_score", "difference_stressed_minus_nonstressed", "inferential_status"])

    excluded = set(all_members)
    eligible = sum(gene not in excluded and bool(available[i]) for i, gene in enumerate(genes))
    matched = {"status": "NOT_ESTIMABLE", "replicates": 0, "pool_size_per_resident_gene": 200,
               "seed": 222182, "eligible_gene_count": eligible, "minimum_eligible_gene_count": 207}
    sets = []
    if analysis["terminal_state"] == "NO_GO_MAPPING_OR_SCHEMA":
        matched.update(status="NOT_RUN_PRIMARY_NO_GO", reason="PRIMARY_RESIDENT_NOT_ESTIMABLE")
    elif eligible < 207:
        matched["reason"] = "FROZEN_IMPLEMENTATION_ELIGIBLE_BELOW207"
    else:
        calculated = core.matched_resident_null(log_all[:7], z, genes, all_members,
                                               core.FROZEN_PROGRAMMES[0].genes, [4, 5, 6])
        sets = calculated.pop("sets")
        matched.update(calculated, status="COMPUTED")
    _write_json(output / "MATCHED_NULL_SUMMARY.json", matched)
    with (output / "MATCHED_NULL_SETS.tsv.gz").open("xb") as handle:
        with gzip.GzipFile(fileobj=handle, mode="wb", mtime=0, filename="") as compressed:
            compressed.write(b"replicate\tgenes\tmatch_squared_distances\teffect\tstatistic\n")
            for row in sets:
                line = f"{row['replicate']}\t{';'.join(row['genes'])}\t{';'.join(map(str,row['match_squared_distances']))}\t{row['effect']}\t{row['statistic']}\n"
                compressed.write(line.encode("utf-8"))
    artifacts = [{"relative_path": file.name, "bytes": file.stat().st_size, "sha256": _sha(file)}
                 for file in sorted(output.iterdir()) if file.is_file()]
    commit = {"status": "GSE222182_ANALYSIS_COMMITTED", "terminal_state": analysis["terminal_state"],
        "primary_test_status": "NOT_ESTIMABLE" if analysis["terminal_state"] == "NO_GO_MAPPING_OR_SCHEMA" else "ANALYZED",
        "resident_sample_loo_status": "ANALYZED" if all(row["status"] == "ANALYZED" for row in analysis["resident_leave_one_sample_out"]) else "PARTIALLY_NOT_ESTIMABLE" if any(row["status"] == "ANALYZED" for row in analysis["resident_leave_one_sample_out"]) else "NOT_ESTIMABLE",
        "sample_count": 9, "natural_sample_count": 7, "cultured_sample_count": 2,
        "programme_count": 6, "member_identity_count": 47, "sample_score_rows": 42,
        "member_measurement_rows": 423, "matched_null_status": matched["status"],
        "matched_null_replicates": matched["replicates"], "artifacts": artifacts,
        "pseudobulk_sha256": _sha(input_path), "pseudobulk_meta_sha256": _sha(meta_path),
        "authorization_sha256": metadata["authorization_sha256"], "source_hashes": metadata.get("source_hashes"),
        "frozen_core_sha256": CORE_SHA256, "completion_is_last_statistics_write": True,
        "outer_completion_claimed": False, "cell_level_inference_used": False,
        "spatial_method_validation": False, "evidence_scope": analysis["evidence_scope"]}
    _write_json(output / "ANALYSIS_COMMIT.json", commit)
    return commit


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.root), ensure_ascii=False, allow_nan=False))
