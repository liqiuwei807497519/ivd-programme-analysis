"""Five count-copula references on one complete section; caller arrays only."""
import hashlib,json
import numpy as np
from scipy.special import ndtr
from count_marginal_v2 import CountMarginal

LAWS=('FULLY_FACTORIZED_ATOMS','TRUE_ALL_ATOM_GLOBAL_FACTOR_RHO025','RBF_INDEPENDENT_GENE_FIELDS',
      'RBF_FIXED_GENE_RHO025','RBF_POOLED_SOURCE_PIT_CORR')
ADDRESS='RNA_TransferProbability/v1'
LAYOUT='whole-epsilon-N7_then-U4x16x7_then-one-global-scalar/v1'
COUNT_MARGINAL_COPY_SHA256='7825e3958a44a52acf4fd6e38eafeccb1f802c5213e76a67fe5b2a2b40b9677c'
COUNT_MARGINAL_CLASS_LF_SHA256='2678f8865c3cdb7914d641c4508f7810247816f3bb5051fc8e437aaee0c111ed'

def _integer(value,label,minimum):
    if isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,np.integer)) or value<minimum:
        raise ValueError(label+' must be an integer >= '+str(minimum))
    return int(value)
def _hash(*arrays):
    h=hashlib.sha256()
    for value in arrays:
        a=np.asarray(value)
        if a.dtype.kind in 'USO':
            h.update(json.dumps(a.tolist(),ensure_ascii=False,separators=(',',':')).encode('utf-8'))
        else:
            a=np.asarray(a,dtype='<i8' if a.dtype.kind in 'iub' else '<f8');h.update(json.dumps(a.shape).encode('ascii'));h.update(a.tobytes())
    return h.hexdigest()
def _factor(R):
    values,vectors=np.linalg.eigh(R)
    if values.min() < -1e-12:raise ValueError('sourceR7 must be positive semidefinite')
    # Same documented tiny eigendecomposition roundoff policy as frozen FieldLaw.
    return vectors*np.sqrt(np.maximum(values,0.))[None,:],{'minimum_eigenvalue':float(values.min()),'roundoff_negative_eigenvalues':int(np.sum(values<0))}

def sample_five_atomic_laws(mu7,alpha7,canonical_ids,coords_um,roi,source_R7,M,domain,*,chunk_size=64,scenario_start=0):
    """Return all five M×ROI×7 int64 totals and auditable common-world receipts.

    Full canonical support, marginal arrays and basis are frozen before batching.
    ``M``/``scenario_start`` are execution controls; actual protocol freezes2048/0.
    No files, fitting, target adaptation, conditional banks or extra worlds.
    """
    mu=np.asarray(mu7,dtype=float).copy();alpha=np.asarray(alpha7,dtype=float).copy()
    if mu.ndim!=2 or len(mu)==0 or mu.shape[1]!=7 or alpha.shape!=(7,):raise ValueError('complete muN7/alpha7 required')
    marginal=CountMarginal(mu,alpha);n=len(mu);ids=list(canonical_ids);coords=np.asarray(coords_um,dtype=float).copy()
    if len(ids)!=n or not all(isinstance(i,str) and i for i in ids) or ids!=sorted(set(ids)):
        raise ValueError('complete sorted unique canonical IDs required')
    if coords.shape!=(n,2) or not np.isfinite(coords).all():raise ValueError('complete finite coordsN2 required')
    minimum=coords.min(axis=0);span=coords.max(axis=0)-minimum
    if not np.isfinite(span).all() or np.any(span<=0):raise ValueError('complete-support bbox needs positive spans on both axes')
    unit=(coords-minimum)/span
    centres=np.asarray([(x,y) for y in np.linspace(0,1,4) for x in np.linspace(0,1,4)])
    phi=np.exp(-np.sum((unit[:,None,:]-centres[None,:,:])**2,axis=2)/(2*.35**2))
    H=np.tile((.5*phi)[:,None,:],(1,4,1));norm=np.sqrt(np.sum(H**2,axis=(1,2)))
    if not np.isfinite(norm).all() or np.any(norm<=0):raise ValueError('complete-support H unrepresentable')
    H/=norm[:,None,None]
    if not np.allclose(np.sum(H**2,axis=(1,2)),1.,rtol=0,atol=1e-12):raise ValueError('H normalization failed')
    R=np.asarray(source_R7,dtype=float).copy()
    if R.shape!=(7,7) or not np.isfinite(R).all() or not np.allclose(R,R.T,rtol=0,atol=1e-12) or not np.allclose(np.diag(R),1.,rtol=0,atol=1e-12):
        raise ValueError('sourceR7 finite symmetric diag1 correlation required')
    fixed=.75*np.eye(7)+.25*np.ones((7,7))
    factors={};factor_receipts={}
    for name,corr in zip(LAWS[2:],(np.eye(7),fixed,R)):
        factors[name],factor_receipts[name]=_factor(corr)
    M=_integer(M,'M',1);chunk_size=_integer(chunk_size,'chunk_size',1);scenario_start=_integer(scenario_start,'scenario_start',0)
    if not isinstance(domain,str) or not domain:raise ValueError('one complete-section nonempty seed domain required')
    labels=np.asarray(roi)
    if labels.ndim==2 and labels.dtype.kind=='b' and labels.shape[0]==n and labels.shape[1]>0:
        incidence=labels.copy()
        if not np.all(incidence.any(axis=0)):raise ValueError('all declared ROI columns must be nonempty')
        projection='full-support Boolean incidence; overlap allowed'
    elif (labels.shape==(n,) and labels.dtype.kind in 'iu' and not np.any(labels<0)
            and np.array_equal(np.unique(labels),np.arange(len(np.unique(labels))))):
        incidence=labels[:,None]==np.arange(int(labels.max())+1)[None,:]
        projection='complete contiguous integer ROI partition'
    else:raise ValueError('ROI contiguous labels or full-support Boolean incidence required')
    nr=incidence.shape[1];sizes=incidence.sum(axis=0);safe=np.iinfo(np.int64).max//int(sizes.max())
    totals={name:np.zeros((M,nr,7),dtype=np.int64) for name in LAWS}
    endpoints={name:{'zero':0,'one':0} for name in LAWS};seed_hash=hashlib.sha256();raw_hash=hashlib.sha256()
    for start in range(0,M,chunk_size):
        for offset in range(start,min(start+chunk_size,M)):
            world=scenario_start+offset;address=json.dumps([ADDRESS,domain,world],ensure_ascii=False,separators=(',',':')).encode('utf-8')
            digest=hashlib.sha256(address).digest();seed_hash.update(digest)
            rng=np.random.Generator(np.random.PCG64(int.from_bytes(digest,'big')))
            epsilon=rng.standard_normal((n,7));U=rng.standard_normal((4,16,7));global_scalar=float(rng.standard_normal())
            raw_hash.update(epsilon.astype('<f8').tobytes());raw_hash.update(U.astype('<f8').tobytes());raw_hash.update(np.asarray(global_scalar,dtype='<f8').tobytes())
            latents={LAWS[0]:epsilon,LAWS[1]:.5*global_scalar+np.sqrt(.75)*epsilon}
            for name in LAWS[2:]:
                L=factors[name];local=epsilon@L.T;global_correlated=U@L.T
                shared=np.einsum('nmd,mdg->ng',H,global_correlated)
                latents[name]=np.sqrt(.75)*local+.5*shared
            for name in LAWS:
                u=ndtr(latents[name]);zero=u==0.;one=u==1.
                endpoints[name]['zero']+=int(zero.sum());endpoints[name]['one']+=int(one.sum())
                u[zero]=np.nextafter(0.,1.);u[one]=np.nextafter(1.,0.)
                counts=marginal.quantile(u)
                if int(counts.max())<=safe:
                    for region in range(nr):totals[name][offset,region]=counts[incidence[:,region]].sum(axis=0,dtype=np.int64)
                else:
                    for region in range(nr):
                        for gene in range(7):
                            total=sum(int(v) for v in counts[incidence[:,region],gene])
                            if total>np.iinfo(np.int64).max:raise ValueError('ROI count sum exceeds int64; no forecast returned')
                            totals[name][offset,region,gene]=total
    hhash=_hash(H);kh=hashlib.sha256(('K_RBF=.75I+.25HHt|'+hhash).encode()).hexdigest()
    witness={}
    if n>1:
        inner=float(np.sum(H[0]*H[1]));kr=.25*inner
        for name,same,cross in ((LAWS[0],0.,0.),(LAWS[1],.25,.25),(LAWS[2],kr,0.),(LAWS[3],kr,kr*.25),(LAWS[4],kr,kr*R[0,1])):
            witness[name]={'same_gene_0':float(same),'cross_gene_0_1':float(cross)}
    receipt={'schema':'RNA_FIVE_ATOMIC_COUNT_LAWS_SAMPLER_V1','laws':{},'complete_support_size':n,'region_count':nr,'gene_count':7,
        'world_ids':list(range(scenario_start,scenario_start+M)),'M':M,'scenario_start':scenario_start,'chunk_size':chunk_size,'seed_domain':domain,
        'seed_address_scheme':'SHA256 UTF8 compact JSON [RNA_TransferProbability/v1,sectionID,worldID]; full digest big-endian PCG64seed',
        'draw_layout':LAYOUT,'generator':'NumPy-PCG64','numpy_version':np.__version__,'world_seed_sha256':seed_hash.hexdigest(),
        'count_marginal_verbatim_module_sha256':COUNT_MARGINAL_COPY_SHA256,'count_marginal_class_LF_sha256':COUNT_MARGINAL_CLASS_LF_SHA256,
        'raw_common_draws_sha256':raw_hash.hexdigest(),'complete_support_ids_sha256':_hash(np.asarray(ids)),'coords_sha256':_hash(coords),
        'marginal_parameters_sha256':_hash(mu,alpha),'roi_incidence_sha256':_hash(incidence),'H_sha256':hhash,
        'ROI_projection':projection,'projection_covers_complete_support':bool(np.all(incidence.any(axis=1))),
        'geometry':{'bbox_min':minimum.tolist(),'bbox_span':span.tolist(),'bandwidth':.35,'centres_order':'y-major4x4linspace','q_all_four_states':.25,
            'H_shape':list(H.shape),'H_unit_norm_max_abs_error':float(np.max(np.abs(np.sum(H**2,axis=(1,2))-1)))},
        'first_pair_support_ids':ids[:2],'first_pair_latent_covariance':witness,'extra_worlds':0,'optional_conditional_disabled':True,
        'common_raw_draws_all_five':True,'global_scalar_once_per_complete_section_world':True,'H_once_before_chunks_or_ROI_projection':True,
        'endpoint_policy':'only exact ndtr u0/1 nextafter-to-interior; floating roundoff substitutions, not analytic exact-sampling proof',
        'integer_policy':'complete native nonnegative int64 inverse counts then exact ROI sums; overflow blocks, no cap/floor/mask',
        'matched_K_attribution_set':list(LAWS[2:]),'global_or_factorized_vs_RBF_is_not_pure_gene_correlation_attribution':True}
    for name in LAWS:
        oneK='I' if name==LAWS[0] else '.75I+.25J' if name==LAWS[1] else 'K_RBF=.75I+.25HHt'
        receipt['laws'][name]={'one_gene_K':oneK,'one_gene_K_sha256':hashlib.sha256((oneK+'|N='+str(n)).encode()).hexdigest() if name in LAWS[:2] else kh,
            'marginal_parameters_sha256':receipt['marginal_parameters_sha256'],'endpoint_zero_count':endpoints[name]['zero'],
            'endpoint_one_count':endpoints[name]['one'],'totals_sha256':_hash(totals[name]),
            'sourceR_sha256':_hash(R) if name==LAWS[4] else None,'factor_numeric_receipt':factor_receipts.get(name)}
    return totals,receipt
