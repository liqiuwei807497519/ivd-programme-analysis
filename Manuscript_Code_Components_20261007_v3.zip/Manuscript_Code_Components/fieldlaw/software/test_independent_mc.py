"""Independent Monte Carlo reconstruction tests with literal synthetic inputs."""

import unittest
import copy
import math

import numpy as np

from independent_mc import reconstruct_mc_precision, verify_mc_outputs


class IndependentMCTests(unittest.TestCase):
    def test_zero_ensemble_has_literal_metrics_and_fixed_shared_world_groups(self):
        values = np.zeros((32, 2, 7), dtype=np.int64)
        truth = np.zeros((2, 7), dtype=np.int64)
        packet = reconstruct_mc_precision(values, truth, {"ALL7": 10.0, "ACAN_COL2A1": 5.0, "OTHER5": 5.0})
        self.assertEqual([(block["scenario_start"], block["world_count"]) for block in packet["two_seed_blocks"]], [(0, 16), (16, 16)])
        groups = packet["shared_world_delete_group"]
        self.assertEqual(groups["group_count"], 16)
        self.assertEqual(groups["group_size"], 2)
        for functional in ("ALL7", "ACAN_COL2A1", "OTHER5"):
            estimates = groups["functionals"][functional]
            np.testing.assert_array_equal(estimates["delete_group_region_metric_arrays"]["fair_rps"], np.zeros((16, 2)))
            np.testing.assert_array_equal(estimates["delete_group_region_metric_arrays"]["coverage_95"], np.ones((16, 2)))
            for metric, errors in estimates["mcse_region_metrics"].items():
                np.testing.assert_array_equal(errors, [0.0, 0.0], err_msg=metric)
        np.testing.assert_array_equal(groups["event"]["delete_group_region_metric_arrays"]["event_probability"], np.zeros((16, 2)))
        self.assertFalse(packet["biological_confidence_interval"])

    def test_tampered_packet_and_row_mcse_are_rejected(self):
        expected = reconstruct_mc_precision(np.zeros((32, 2, 7), dtype=np.int64), np.zeros((2, 7), dtype=np.int64),
                                            {"ALL7": 10.0, "ACAN_COL2A1": 5.0, "OTHER5": 5.0})
        keys = np.asarray([[0, 0], [1, 0]])
        rows = []
        groups = expected["shared_world_delete_group"]
        for functional in ("ALL7", "ACAN_COL2A1", "OTHER5", "ALL7_REGIONAL_TOTALS_POSITIVE_EVENT"):
            packet = groups["event"] if functional.startswith("ALL7_REGIONAL") else groups["functionals"][functional]
            for region, key in enumerate(keys):
                rows.append({"law": "INDEPENDENT_GENE_FIELDS", "diagnostic": "NONE", "permutation_seed": "",
                             "functional": functional, "roi_x": str(key[0]), "roi_y": str(key[1]),
                             **{"mcse_" + metric: str(errors[region]) for metric, errors in packet["mcse_region_metrics"].items()}})
        self.assertGreater(verify_mc_outputs(expected, copy.deepcopy(expected), rows, "INDEPENDENT_GENE_FIELDS", keys), 0)
        altered = copy.deepcopy(expected)
        altered["shared_world_delete_group"]["functionals"]["ALL7"]["mcse_region_metrics"]["fair_rps"][0] = 1.0
        with self.assertRaisesRegex(ValueError, "Independent MC numerical mismatch"):
            verify_mc_outputs(expected, altered, rows, "INDEPENDENT_GENE_FIELDS", keys)
        altered = copy.deepcopy(expected)
        altered["two_seed_blocks"][0]["functionals"]["ALL7"]["wis_mean"] = 1.0
        with self.assertRaisesRegex(ValueError, "Independent MC numerical mismatch"):
            verify_mc_outputs(expected, altered, rows, "INDEPENDENT_GENE_FIELDS", keys)
        bad_rows = copy.deepcopy(rows)
        bad_rows[0]["mcse_fair_rps"] = "1.0"
        with self.assertRaisesRegex(ValueError, "Independent MC numerical mismatch"):
            verify_mc_outputs(expected, expected, bad_rows, "INDEPENDENT_GENE_FIELDS", keys)

    def test_bernoulli_worlds_have_worked_rational_group_scores_and_nonzero_mcse(self):
        values = np.zeros((32, 1, 7), dtype=np.int64)
        values[:16, :, :] = 1
        packet = reconstruct_mc_precision(values, np.zeros((1, 7), dtype=np.int64),
                                          {"ALL7": 7.0, "ACAN_COL2A1": 2.0, "OTHER5": 5.0})
        estimates = packet["shared_world_delete_group"]["functionals"]["ALL7"]
        np.testing.assert_allclose(estimates["delete_group_roi_mean_estimates"]["scaled_fair_rps"],
                                   [91.0 / 435.0] * 8 + [8.0 / 29.0] * 8, rtol=0, atol=1e-15)
        self.assertAlmostEqual(estimates["mcse_roi_means"]["scaled_fair_rps"], math.sqrt(15.0) / 30.0, places=14)
        self.assertAlmostEqual(estimates["mcse_roi_means"]["scaled_wis"], math.sqrt(15.0) / 18.0, places=14)
        event = packet["shared_world_delete_group"]["event"]
        np.testing.assert_allclose(event["delete_group_roi_mean_estimates"]["event_probability"],
                                   [7.0 / 15.0] * 8 + [8.0 / 15.0] * 8, rtol=0, atol=1e-15)
        self.assertAlmostEqual(event["mcse_roi_means"]["brier"], math.sqrt(15.0) / 30.0, places=14)
        self.assertEqual(packet["two_seed_blocks"][0]["functionals"]["ALL7"]["scaled_fair_rps_mean"], 1.0)
        self.assertEqual(packet["two_seed_blocks"][1]["functionals"]["ALL7"]["scaled_fair_rps_mean"], 0.0)


if __name__ == "__main__":
    unittest.main()
