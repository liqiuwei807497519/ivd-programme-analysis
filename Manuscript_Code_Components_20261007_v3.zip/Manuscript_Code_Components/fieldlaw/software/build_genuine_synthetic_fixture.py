"""Create only artificial source/target capsules for actual three-stage preflight.

No empirical source or target count/parameter file is read. Two zero-tree
source capsules are constructed from the existing artificial adapter fixture.
The supervisor transports local gzip fixtures; example.invalid is never used
as a network endpoint in SYNTHETIC_SUPERVISOR_TEST mode.
"""

import argparse
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path

for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "2"

import numpy as np


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
PINNED_PYTHON = WORKSPACE / "IVD_Nonlinear_Baseline_20261002/preflight_v2/environment/venv/Scripts/python.exe"
GENES = ["TBXT", "KRT8", "KRT18", "KRT19", "ACAN", "COL2A1", "SOX9"]


def _write(path, value):
    with Path(path).open("x", encoding="utf8") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def _binding(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        sha = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": sha}


def build_fixture(destination):
    """Return config and fresh run path for the actual staged supervisor CLI."""
    from test_frozen_adapter import synthetic_parameters, LEGACY_ROOT
    from xgb_offset_core import deserialize_model, predict_from_fitted

    root = Path(destination).resolve()
    root.mkdir(parents=True, exist_ok=True)
    if list(root.iterdir()):
        raise ValueError("genuine synthetic fixture destination must be empty")
    metadata = root / "metadata"
    metadata.mkdir()
    inputs = ["SYN_INPUT_" + str(i) for i in range(126)]
    heads, totals = synthetic_parameters()
    sources = []
    for index, capture in enumerate(["SYN_SOURCE_A", "SYN_SOURCE_B"]):
        ids = np.array([capture + "|R" + str(i) + "_C0" for i in range(8)])
        x = np.zeros((8, 126), dtype=np.int64)
        x[np.arange(8), np.arange(8) // 2] = 10
        y = np.tile(np.arange(8, dtype=np.int64)[:, None], (1, 7))
        y[:, 1] = [1, 2, 1, 2, 1, 2, 1, 2]
        row = np.r_[np.arange(4), np.arange(12, 16)] if index == 0 else np.arange(8)
        source_input = root / (capture + "_INPUT.npz")
        np.savez(source_input, region_id=ids, x_counts=x, y_counts=y, row=row, col=np.zeros(8, dtype=np.int64))
        # These are the corresponding single saved toy predictor's means,
        # not a new fit and not the later average of both saved predictors.
        exposure = 1.0 + x.sum(axis=1)
        frozen_total = exposure * float(np.exp(totals[index]["total"]["coef"][0]))
        means = predict_from_fitted(deserialize_model(heads[index]), x, frozen_total,
                                    eval_ids=ids)["TotalXGB"]
        prediction = root / (capture + "_PREDICTIONS.npz")
        np.savez(prediction, region_id=ids[::-1], TotalXGB=means[::-1], member_ids=np.array(GENES))
        head, total = root / (capture + "_HEAD.json"), root / (capture + "_TOTAL.json")
        _write(head, heads[index])
        _write(total, totals[index])
        commits = []
        for label in ["V2", "OLD_TOTAL"]:
            path = root / (capture + "_" + label + "_COMMIT.json")
            _write(path, {"scope": "ARTIFICIAL_ZERO_TREE_SOURCE_CAPSULE", "capture": capture,
                          "synthetic": True, "role": label})
            commits.append(_binding(path))
        sources.append({"capture": capture, "input": _binding(source_input), "predictions": _binding(prediction),
                        "head_params": _binding(head), "total_params": _binding(total), "commits": commits})
    targets, coordinates = [], []
    barcodes = ["B3", "B1", "B4", "B2"]
    positions = {"B1": (0, 0), "B2": (0, 12), "B3": (6, 0), "B4": (6, 12)}
    member_features = ["ENSMUSG9000000000" + str(i) for i in range(7)]
    member_symbols = ["T", "Krt8", "Krt18", "Krt19", "Acan", "Col2a1", "Sox9"]
    for capture in ["SYN_A", "SYN_B", "SYN_C"]:
        feature, barcode_path = metadata / (capture + "_features.tsv.gz"), metadata / (capture + "_barcodes.tsv.gz")
        with gzip.open(feature, "wt", encoding="utf8") as stream:
            for name in inputs:
                stream.write(name + "\t" + name + "\tGene Expression\n")
            for feature_id, symbol in zip(member_features, member_symbols):
                stream.write(feature_id + "\t" + symbol + "\tGene Expression\n")
        with gzip.open(barcode_path, "wt", encoding="utf8") as stream:
            stream.write("\n".join(barcodes) + "\n")
        records = []
        for spot, barcode in enumerate(barcodes, 1):
            records.append(f"1 {spot} {int(barcode[1:])}")
            for gene in range(7):
                records.append(f"{127 + gene} {spot} {gene + 1}")
            row, col = positions[barcode]
            coordinates.append({"sample": capture, "observed_barcode": barcode,
                                "array_row": str(row), "array_col": str(col),
                                "native_relative_lattice_x_pitch": str(col / 2.0),
                                "native_relative_lattice_y_pitch": str(row * np.sqrt(3.0) / 2.0)})
        transport = root / (capture + "_ARTIFICIAL_TRANSPORT_matrix.mtx.gz")
        with gzip.open(transport, "wt", encoding="utf8") as stream:
            stream.write("%%MatrixMarket matrix coordinate integer general\n133 4 32\n" + "\n".join(records) + "\n")
        targets.append({"capture": capture, "matrix_name": capture + "_matrix.mtx.gz",
                        "matrix_expected_bytes": transport.stat().st_size, "matrix_url": "https://example.invalid/" + capture,
                        "synthetic_acquisition": _binding(transport), "features": _binding(feature),
                        "barcodes": _binding(barcode_path), "gene_rows": 133, "observations": 4,
                        "member_feature_ids": member_features, "member_feature_rows": list(range(127, 134)),
                        "member_display_ids": GENES})
    coordinate_path = metadata / "SYN_COORDINATES.tsv"
    with coordinate_path.open("x", encoding="utf8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(coordinates[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(coordinates)
    spec, auth = root / "SYN_SPEC.json", root / "SYN_AUTHORIZATION.json"
    _write(spec, {"scope": "SYNTHETIC_GENUINE_STAGE_INTEGRATION", "worlds": 64,
                  "count_support": "artificial source and artificial target only", "no_empirical_validation": True})
    _write(auth, {"scope": "SYNTHETIC_ONLY", "network": False, "real_count_or_parameter_reads": False})
    names = ["source_stage.py", "target_stage.py", "real_supervisor.py", "field_core.py", "source_statistics.py",
             "matrix_io.py", "scoring.py", "workflow.py", "frozen_adapter.py", "build_genuine_synthetic_fixture.py",
             "independent_scores.py", "postrun_audit.py", "audit_guard.py", "independent_mc.py", "test_genuine_synthetic_integration.py"]
    code = [_binding(HERE / name) for name in names]
    code += [_binding(LEGACY_ROOT / "xgb_offset_core.py"), _binding(LEGACY_ROOT / "vendor/baseline_core.py")]
    config = {"mode": "SYNTHETIC_SUPERVISOR_TEST", "source_records": sources, "expected_source_observations": 16,
              "linkage": {"input_ids": inputs, "member_ids": GENES,
                          "source_prediction_key": "TotalXGB", "source_region_id_key": "region_id", "input_role_gene_count": 126},
              "code_binding": code, "spec_binding": _binding(spec), "authorization_binding": _binding(auth),
              "targets": targets, "target_coordinates": _binding(coordinate_path), "worlds": 64,
              "resource_contract": {"CPU": 2, "RSS_bytes": 4294967296, "wall_seconds": 180, "output_bytes": 2147483648},
              "python_executable": str(PINNED_PYTHON), "real_run_root": str(root / "RUN"),
              "no_real_data_or_network": True}
    config_path = root / "SYN_CONFIG.json"
    _write(config_path, config)
    _write(root / "FIXTURE_RECEIPT.json", {"scope": "SYNTHETIC_SOFTWARE_INTEGRATION_ONLY", "source_observations": 16,
           "target_libraries": 3, "target_observations": 12, "worlds": 64, "actual_stage_programs": True,
           "fake_child_programs": 0, "real_count_or_parameter_reads": 0, "network_requests": 0,
           "config": _binding(config_path)})
    return config_path, root / "RUN"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config, run = build_fixture(args.output)
    print(json.dumps({"config": str(config), "run_root": str(run), "synthetic_only": True}), flush=True)
