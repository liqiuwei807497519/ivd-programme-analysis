"""Nested fold public CLI with genuine mean fits and artificial prepared counts."""
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

import numpy as np
from rna_inputs import prepare
from test_rna_inputs import synthetic_fixture, binding, write_json, PINNED_PYTHON

HERE = Path(__file__).resolve().parent


def constant_fixture(root):
    config_path, config = synthetic_fixture(root)
    roles = config["ordered_roles"]
    for section in config["sections"]:
        path = Path(section["counts"]["path"])
        with path.open(encoding="utf8", newline="") as stream:
            reader = csv.DictReader(stream)
            fields, rows = reader.fieldnames, list(reader)
        for row in rows:
            for role in roles[:126]:
                row[role["frozen_symbol"]] = "0"
            for index, role in enumerate(roles[126:], 1):
                row[role["frozen_symbol"]] = str(index)
        with path.open("w", encoding="utf8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
        section["counts"] = binding(path)
        coordinate = Path(section["coordinates"]["path"])
        with coordinate.open(encoding="utf8", newline="") as stream:
            reader = csv.DictReader(stream)
            coord_fields, coord_rows = reader.fieldnames, list(reader)
        for row in coord_rows:
            ordinal = int(row["barcode"][1:]) - 1
            row["array_row"], row["array_col"] = str(2 * (ordinal // 2)), str(2 * (ordinal % 2))
        with coordinate.open("w", encoding="utf8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=coord_fields)
            writer.writeheader()
            writer.writerows(coord_rows)
        section["coordinates"] = binding(coordinate)
    names = ["rna_inputs.py", "rna_score.py", "rna_mean.py", "rna_fold.py", "rna_supervisor.py", "rna_audit.py"]
    config["code_binding"] = [binding(HERE / name) for name in names if (HERE / name).exists()]
    write_json(config_path, config)
    prepared = Path(root) / "prepared"
    prepare(config_path, prepared)
    return config_path, prepared


def cli(config, prepared, output):
    return subprocess.run([str(PINNED_PYTHON), "-B", str(HERE / "rna_fold.py"), "--config", str(config),
                           "--prepared", str(prepared), "--holdout-parent", "Control", "--output", str(output)],
                          capture_output=True, text=True, encoding="utf8", env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"), timeout=90)


class FoldTests(unittest.TestCase):
    def test_all_failed_fit_candidates_block_selection_instead_of_fabricating_a_penalty_winner(self):
        from rna_fold import choose
        records = [{"penalty": penalty, "candidate_status": "FIT_FAILED",
                    "loss": {"status": "INFINITE", "value": None, "extended_value": "+infinity"}}
                   for penalty in (0.01, 0.1, 1.0)]
        with self.assertRaisesRegex(ValueError, "ALL_FITS_FAILED"):
            choose(records)

    def test_fixed_ties_choose_largest_penalties_from_genuine_nested_fits(self):
        with tempfile.TemporaryDirectory(prefix="RNA_SYN_ties_") as temporary:
            config, prepared = constant_fixture(temporary)
            output = Path(temporary) / "fold"
            result = cli(config, prepared, output)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            selection = json.loads((output / "SELECTION.json").read_text(encoding="utf8"))
            self.assertEqual({name: value["chosen_penalty"] for name, value in selection.items()},
                             {"memberRidge": 1.0, "memberPoisson": 1.0, "sourceTotal": 1.0, "learnedComposition": 10.0})
            self.assertTrue(all(len(value["candidates"]) == 3 and all(len(row["inner_folds"]) == 3 for row in value["candidates"]) for value in selection.values()))

    def test_infinite_inner_losses_keep_all_rows_choose_largest_and_use_each_inner_training_scale(self):
        with tempfile.TemporaryDirectory(prefix="RNA_SYN_infinite_") as temporary:
            config, prepared = constant_fixture(temporary)
            commit_path = prepared / "PREPARE_COMMIT.json"
            commit = json.loads(commit_path.read_text(encoding="utf8"))
            for folder, capsule in commit["sections"].items():
                labels = prepared / "sections" / folder / "SOURCE_LABELS.npz"
                with np.load(labels, allow_pickle=False) as archive:
                    values = {name: archive[name] for name in archive.files}
                if capsule["parent"] in ("Day_3", "Day_28"):
                    values["y_counts"][:, 0] = 0
                np.savez_compressed(labels, **values)
                capsule["artifacts"]["SOURCE_LABELS.npz"] = binding(labels)
            write_json(commit_path, commit)
            output = Path(temporary) / "fold"
            result = cli(config, prepared, output)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            selection = json.loads((output / "SELECTION.json").read_text(encoding="utf8"))["memberPoisson"]
            self.assertEqual(selection["chosen_penalty"], 1.0)
            self.assertEqual(selection["selection_status"], "ALL_INFINITE_LOSS_LARGEST_PENALTY_FALLBACK_NOT_WINNER")
            self.assertTrue(all(row["loss"]["status"] == "INFINITE" for row in selection["candidates"]))
            self.assertEqual({row["validation_parent"]: row["source_scales7"][0] for row in selection["candidates"][0]["inner_folds"]},
                             {"Day_1": 1.0, "Day_3": 2.0, "Day_28": 2.0})
            params = json.loads((output / "FOLD_PARAMS.json").read_text(encoding="utf8"))
            self.assertAlmostEqual(params["source_scales7"][0], 4 / 3)
            with np.load(output / "NATIVE_MEANS.npz", allow_pickle=False) as array:
                self.assertEqual(array["memberPoisson"].shape, (8, 7))

    def test_fold_has_literal_training_roi_scales_and_never_opens_holdout_labels(self):
        with tempfile.TemporaryDirectory(prefix="RNA_SYN_fold_") as temporary:
            config, prepared = constant_fixture(temporary)
            specification = json.loads(config.read_text(encoding="utf8"))
            for section in specification["sections"]:
                if section["parent"] == "Control":
                    (prepared / "sections" / section["section_folder"] / "SOURCE_LABELS.npz").write_bytes(b"DO_NOT_OPEN_HELDOUT_RESPONSE")
            output = Path(temporary) / "fold"
            result = cli(config, prepared, output)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            params = json.loads((output / "FOLD_PARAMS.json").read_text(encoding="utf8"))
            self.assertEqual(params["source_scales7"], [4, 8, 12, 16, 20, 24, 28])
            self.assertEqual(params["source_scale_total"], 112)
            self.assertEqual(params["training_parents"], ["Day_1", "Day_3", "Day_28"])
            commit = json.loads((output / "FORECAST_COMMIT.json").read_text(encoding="utf8"))
            self.assertEqual(commit["observations"], 8)
            self.assertEqual(commit["heldout_response_reads"], 0)
            self.assertEqual(len(commit["methods"]), 5)
            with np.load(output / "NATIVE_MEANS.npz", allow_pickle=False) as array:
                for method in commit["methods"]:
                    np.testing.assert_allclose(array[method], np.tile(np.arange(1, 8), (8, 1)), rtol=1e-6, atol=1e-8)


if __name__ == "__main__":
    unittest.main()
