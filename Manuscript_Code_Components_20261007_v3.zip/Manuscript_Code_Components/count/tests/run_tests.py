"""Run the package tests without an externally configured import path."""
import sys
from pathlib import Path
import unittest

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'src'))
tests = unittest.defaultTestLoader.discover(str(root / 'tests'), pattern='test_*.py')
result = unittest.TextTestRunner(verbosity=2).run(tests)
raise SystemExit(0 if result.wasSuccessful() else 1)
