"""Fresh-process artificial forecast barrier and eight-metric score example.

Usage: python -B synthetic_pipeline.py --mode synthetic --out work/synthetic_pipeline_01
Only newly generated, explicitly artificial inputs under this code root's work
directory are supported. This example cannot be used as a real-data launcher.
"""
from __future__ import annotations

import os
for _thread_key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                    "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_thread_key] = "2"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import math
from pathlib import Path
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
CODE_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE_ROOT))
WORK_ROOT = (CODE_ROOT / "work").resolve()
RSS_CAP = 1024 ** 3
WALL_CAP = 600.0
METHODS = ("XGBDirect", "TotalXGB")
VARIANTS = ("constant_rate", "all_zero", "member_reallocation")
SOURCE_FILES = ("synthetic_pipeline.py", "src/xgb_offset_core.py",
                "examples/synthetic_offset_fixture.py", "vendor/baseline_core.py",
                "vendor/count_score_core.py")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    with Path(path).open(encoding="utf-8") as stream:
        return json.load(stream)


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def write_csv(path, fields, rows):
    with Path(path).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def save_npz(path, **arrays):
    """Hash producer bytes without reopening a truth-only artifact."""
    import numpy as np
    buffer = io.BytesIO()
    np.savez_compressed(buffer, **arrays)
    payload = buffer.getvalue()
    with Path(path).open("xb") as stream:
        stream.write(payload)
    return hashlib.sha256(payload).hexdigest()


def load_npz(path):
    import numpy as np
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key] for key in archive.files}


def safe_run_root(value, *, existing):
    value = Path(value)
    root = value.resolve() if value.is_absolute() else (CODE_ROOT / value).resolve()
    require(root.is_relative_to(WORK_ROOT) and root != WORK_ROOT,
            "Synthetic outputs must be below this code root's work directory")
    require(root.name.startswith("synthetic_"), "Synthetic run name must start with synthetic_")
    require(root.exists() == existing, "Run directory presence differs; preserve existing attempts")
    return root


def inside(root, relative):
    path = (root / relative).resolve()
    require(path.is_relative_to(root), "Relative artifact escapes this synthetic run")
    return path


def process_identity(process=None):
    import psutil
    process = process or psutil.Process()
    result = {"pid": process.pid}
    for label, function in (("created_epoch", process.create_time),
                            ("actual_executable", process.exe),
                            ("command", process.cmdline),
                            ("cpu_affinity", process.cpu_affinity)):
        try:
            result[label] = function()
        except (psutil.Error, OSError) as exc:
            result[label + "_unavailable"] = type(exc).__name__
    if process.pid == os.getpid():
        result["python_reported_executable"] = sys.executable
    return result


def bind_cpu2():
    import psutil
    process = psutil.Process()
    permitted = process.cpu_affinity()
    require(len(permitted) >= 1, "No permitted CPU")
    process.cpu_affinity(permitted[:2])
    return process.cpu_affinity()


class ReadGuard:
    """Python audit-hook role guard, explicitly not OS/native-I/O isolation."""
    def __init__(self, *, role, run_root, allowed_reads, output_root):
        self.role = role
        self.run_root = run_root
        self.output_root = output_root.resolve()
        self.allowed = {Path(path).resolve() for path in allowed_reads}
        self.runtime_roots = {Path(sys.prefix).resolve(), Path(sys.base_prefix).resolve()}
        self.data_reads = []
        self.blocked = []
        self.runtime_read_count = 0
        self.code_reads = []
        self.truth_permission = False
        sys.addaudithook(self._hook)

    def add_read(self, path):
        path = Path(path).resolve()
        require(path.is_relative_to(self.run_root), "Only own synthetic artifacts can be granted")
        self.allowed.add(path)

    def _hook(self, event, args):
        if event != "open" or not args or not isinstance(args[0], (str, bytes, os.PathLike)):
            return
        try:
            path = Path(os.fsdecode(args[0])).resolve()
        except (ValueError, OSError):
            raise PermissionError("Unresolvable file in role guard")
        mode = args[1] if len(args) > 1 else None
        flags = args[2] if len(args) > 2 else 0
        writes = (isinstance(mode, str) and any(x in mode for x in "wax+")) or (
            isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_APPEND)))
        if writes:
            if path.is_relative_to(self.output_root):
                return
            self.blocked.append({"path": str(path), "operation": "write", "time": utc_now()})
            raise PermissionError("Role write denied: " + str(path))
        if path in self.allowed:
            self.data_reads.append({"path": str(path), "time": utc_now(),
                                    "truth_permission_active": self.truth_permission})
            return
        if any(path.is_relative_to(base) for base in self.runtime_roots):
            self.runtime_read_count += 1
            return
        if path.is_relative_to(CODE_ROOT) and not path.is_relative_to(WORK_ROOT) and path.suffix in (".py", ".pyc"):
            self.code_reads.append(str(path))
            return
        self.blocked.append({"path": str(path), "operation": "read", "time": utc_now()})
        raise PermissionError("Role read denied: " + str(path))

    def receipt(self):
        return {"role": self.role, "data_reads": self.data_reads,
                "blocked_open_events": self.blocked,
                "code_read_paths": sorted(set(self.code_reads)),
                "runtime_read_events": self.runtime_read_count,
                "scope": "Python open audit events and explicit data paths; not an OS access trace",
                "native_library_IO_fully_covered": False}


def verify_sources(root):
    lock = read_json(root / "CODE_LOCK.json")
    require(set(lock["files"]) == set(SOURCE_FILES), "Source lock universe differs")
    for name, digest in lock["files"].items():
        require(file_hash(CODE_ROOT / name) == digest, "Source changed: " + name)
    return lock


def create_inputs(root):
    import numpy as np
    from examples.synthetic_offset_fixture import fixture, EXPECTED_DIRECT_ZERO_TREE
    inputs = root / "inputs"
    inputs.mkdir()
    records = []
    # Different row counts ensure the macro check tests equal directions, not a pooled-row shortcut.
    for fold, n_eval, permutation in (("SYN_A", 6, [2, 5, 0, 4, 1, 3]),
                                     ("SYN_B", 5, [2, 4, 0, 3, 1])):
        data = fixture()
        folder = inputs / fold
        folder.mkdir()
        train_ids = np.array([f"{fold}_TRAIN_{i:03d}" for i in range(24)])
        canonical_ids = np.array([f"{fold}_EVAL_{i:03d}" for i in range(n_eval)])
        order = np.array(permutation, dtype=int)
        eval_ids = canonical_ids[order]
        hashes = {}
        hashes["train_input.npz"] = save_npz(
            folder / "train_input.npz", X=data["train_x126"], Y=data["train_y7"],
            region_ids=train_ids, input_ids=data["input_ids"], member_ids=data["member_ids"])
        hashes["eval_x.npz"] = save_npz(
            folder / "eval_x.npz", X=data["eval_x126"][:n_eval][order],
            region_ids=eval_ids, input_ids=data["input_ids"], member_ids=data["member_ids"])
        # Deliberately store totals in a different identity order.
        reverse = np.arange(n_eval - 1, -1, -1)
        hashes["frozen_total.npz"] = save_npz(
            folder / "frozen_total.npz", total=data["frozen_total"][:n_eval][reverse],
            region_ids=canonical_ids[reverse])
        truth = np.array(EXPECTED_DIRECT_ZERO_TREE[:n_eval], dtype=np.int64)
        reallocated = truth[:, [6, 1, 2, 3, 4, 5, 0]].copy()
        truths = np.stack((truth, np.zeros_like(truth), reallocated), axis=0)
        hashes["truth_scorer_only.npz"] = save_npz(
            folder / "truth_scorer_only.npz", Y=truths[:, reverse, :],
            region_ids=canonical_ids[reverse], member_ids=data["member_ids"],
            variants=np.array(VARIANTS))
        require(not set(train_ids) & set(eval_ids), "Artificial IDs overlap")
        records.append({"fold": fold, "training_rows": 24, "evaluation_rows": n_eval,
                        "canonical_evaluation_ids": canonical_ids.tolist(),
                        "prediction_evaluation_ids": eval_ids.tolist(),
                        "relative_directory": f"inputs/{fold}", "hashes": hashes})
    spec = {"mode": "synthetic", "real_data": False, "folds": records,
            "methods": list(METHODS), "variants": list(VARIANTS),
            "input_columns": 126, "members": 7, "fixed_rounds": 200,
            "region_variant_rows_per_truth": 22, "score_rows_expected": 66,
            "member_score_rows_expected": 462,
            "CPU_threads": 2, "process_RSS_bytes": RSS_CAP,
            "wall_seconds": WALL_CAP, "original_metric_tolerances": {"rtol": 1e-10, "atol": 1e-7}}
    write_json(root / "SPEC.json", spec)
    return spec


def ids(values, label):
    import numpy as np
    value = np.asarray(values)
    require(value.ndim == 1 and value.dtype.kind in "US", label + " must be string IDs")
    result = value.astype(str).tolist()
    require(len(set(result)) == len(result) and all(x.startswith("SYN_") for x in result),
            label + " must be unique, explicitly synthetic IDs")
    return result


def strict_join(target_ids, other_ids, values, label):
    require(len(set(other_ids)) == len(other_ids) and set(target_ids) == set(other_ids),
            label + " identity coverage differs")
    index = {key: i for i, key in enumerate(other_ids)}
    return values[[index[key] for key in target_ids]]


def check_artificial_arrays(train, evaluation):
    import numpy as np
    require(set(train) == {"X", "Y", "region_ids", "input_ids", "member_ids"}, "Training schema differs")
    require(set(evaluation) == {"X", "region_ids", "input_ids", "member_ids"}, "Evaluation-X schema contains extra fields")
    require(train["X"].shape == (24, 126) and train["Y"].shape == (24, 7), "Synthetic training dimensions differ")
    require(np.array_equal(train["X"][:, 0], np.arange(1, 25) * 100000 - 1)
            and np.count_nonzero(train["X"][:, 1:]) == 0
            and np.array_equal(train["Y"], np.arange(1, 25)[:, None] * np.arange(1, 8)[None, :]),
            "Inputs are not the declared mathematical synthetic fixture")
    require(evaluation["X"].ndim == 2 and evaluation["X"].shape[1] == 126
            and np.count_nonzero(evaluation["X"][:, 1:]) == 0
            and np.all(np.isin(evaluation["X"][:, 0], np.arange(1, 7) * 100000 - 1)),
            "Evaluation inputs are not the declared synthetic fixture")
    for value in (train["X"], train["Y"], evaluation["X"]):
        require(value.dtype.kind in "iu" and np.all(value >= 0), "Artificial count dtype invalid")
    require(np.array_equal(train["input_ids"], evaluation["input_ids"])
            and np.array_equal(train["member_ids"], evaluation["member_ids"]), "Feature identity changed")


def predict_worker(root, fold):
    identity = process_identity()
    output = root / "predictions" / fold
    output.mkdir(parents=True, exist_ok=False)
    folder = root / "inputs" / fold
    reads = [root / "SPEC.json", root / "CODE_LOCK.json",
             folder / "train_input.npz", folder / "eval_x.npz", folder / "frozen_total.npz"]
    guard = ReadGuard(role="predict:" + fold, run_root=root,
                      allowed_reads=reads, output_root=output)
    verify_sources(root)
    spec = read_json(root / "SPEC.json")
    require(spec["mode"] == "synthetic" and spec["real_data"] is False, "Real execution prohibited")
    record = next(row for row in spec["folds"] if row["fold"] == fold)
    require(fold in ("SYN_A", "SYN_B"), "Unknown synthetic direction")
    probe = folder / "truth_scorer_only.npz"
    denied = False
    try:
        with probe.open("rb"):
            pass
    except PermissionError:
        denied = True
    require(denied, "Prediction truth probe was not denied")
    train, evaluation, totals = (load_npz(folder / name)
                                  for name in ("train_input.npz", "eval_x.npz", "frozen_total.npz"))
    check_artificial_arrays(train, evaluation)
    train_ids = ids(train["region_ids"], "train")
    eval_ids = ids(evaluation["region_ids"], "evaluation")
    total_ids = ids(totals["region_ids"], "frozen total")
    require(not set(train_ids) & set(eval_ids), "Train/evaluation identity overlap")
    require(set(eval_ids) == set(record["canonical_evaluation_ids"]), "Expected evaluation keys differ")
    frozen_total = strict_join(eval_ids, total_ids, totals["total"], "frozen total")
    require(total_ids != eval_ids, "Synthetic strict-join negative control was not active")
    from src.xgb_offset_core import fit_predict, serialize_model, deserialize_model, predict_from_fitted
    import numpy as np
    result = fit_predict(train["X"], train["Y"], evaluation["X"], frozen_total,
                         train_ids=train["region_ids"], eval_ids=evaluation["region_ids"],
                         input_ids=train["input_ids"], member_ids=train["member_ids"])
    capsule = serialize_model(result["models"])
    write_json(output / "MODELS.json", capsule)
    guard.add_read(output / "MODELS.json")
    replay_model = deserialize_model(read_json(output / "MODELS.json"))
    replay = predict_from_fitted(replay_model, evaluation["X"], frozen_total,
                                 eval_ids=evaluation["region_ids"])
    for method in METHODS:
        require(np.array_equal(result["predictions"][method], replay[method]), "Reloaded predictions differ")
        require(np.isfinite(replay[method]).all() and (replay[method] > 0).all(), "Nonpositive prediction")
    npz_hash = save_npz(output / "PREDICTIONS.npz", region_ids=evaluation["region_ids"],
                        member_ids=train["member_ids"], common_total=frozen_total,
                        member_scales=result["member_scales"], total_scale=np.array(result["total_scale"]),
                        **result["predictions"])
    for name in ("MODELS.json", "PREDICTIONS.npz"):
        guard.add_read(output / name)
    for name in ("train_input.npz", "eval_x.npz", "frozen_total.npz"):
        require(file_hash(folder / name) == record["hashes"][name], "Predictor input hash differs")
    verify_sources(root)
    receipt = {"status": "SYNTHETIC_PREDICTION_COMPLETE", "mode": "synthetic",
               "fold": fold, "process": identity, "truth_probe_denied": denied,
               "evaluation_targets_in_predictor": False,
               "model_reload_prediction_bit_identity": True,
               "fit_ledger": result["fit_ledger"], "diagnostics": result["diagnostics"],
               "data_access": guard.receipt(), "completed": utc_now()}
    write_json(output / "PREDICTOR_RECEIPT.json", receipt)
    guard.add_read(output / "PREDICTOR_RECEIPT.json")
    payload = {"PREDICTIONS.npz": npz_hash,
               "MODELS.json": file_hash(output / "MODELS.json"),
               "PREDICTOR_RECEIPT.json": file_hash(output / "PREDICTOR_RECEIPT.json")}
    write_json(output / "COMMIT.json", {"status": "SYNTHETIC_FOLD_COMMITTED", "fold": fold,
               "mode": "synthetic", "regions": len(eval_ids), "methods": list(METHODS),
               "member_ids": train["member_ids"].tolist(), "region_ids": eval_ids,
               "input_sha256": {name: record["hashes"][name] for name in
                                  ("train_input.npz", "eval_x.npz", "frozen_total.npz")},
               "payload_hashes": payload, "finished": utc_now()})
    print(json.dumps({"status": "SYNTHETIC_FOLD_COMMITTED", "fold": fold, "regions": len(eval_ids)}))


def validate_barrier(root, spec):
    import numpy as np
    commit = read_json(root / "ALL_PREDICTIONS_COMMIT.json")
    require(commit["status"] == "ALL_SYNTHETIC_FOLDS_COMMITTED" and commit["mode"] == "synthetic",
            "Complete prediction barrier required before truth")
    require(len(commit["folds"]) == 2 and {row["fold"] for row in commit["folds"]} == {"SYN_A", "SYN_B"},
            "Synthetic fold coverage differs")
    forecasts = {}
    for entry in commit["folds"]:
        fold = entry["fold"]
        record = next(row for row in spec["folds"] if row["fold"] == fold)
        directory = root / "predictions" / fold
        require(file_hash(directory / "COMMIT.json") == entry["commit_sha256"], "Fold commit hash changed")
        require(file_hash(root / entry["exit_file"]) == entry["exit_sha256"], "Exit receipt hash changed")
        external = read_json(root / entry["exit_file"])
        require(external["external_exit_code"] == 0 and external["child_handle_confirmed"], "Prediction external exit invalid")
        fc = read_json(directory / "COMMIT.json")
        require(fc["status"] == "SYNTHETIC_FOLD_COMMITTED" and fc["fold"] == fold
                and fc["regions"] == record["evaluation_rows"], "Prediction commit identity differs")
        for name, digest in fc["payload_hashes"].items():
            require(file_hash(directory / name) == digest, "Committed prediction payload changed")
        pr = read_json(directory / "PREDICTOR_RECEIPT.json")
        require(pr["truth_probe_denied"] and pr["evaluation_targets_in_predictor"] is False
                and pr["model_reload_prediction_bit_identity"], "Prediction role or replay check missing")
        read_paths = {Path(row["path"]).resolve() for row in pr["data_access"]["data_reads"]}
        require(not any(path.name == "truth_scorer_only.npz" for path in read_paths), "Predictor truth was read")
        require(len(pr["fit_ledger"]) == 7 and all(row["rounds"] == 200 and not row["early_stopping"]
                                                   and row["watchlist_rows"] == 0 for row in pr["fit_ledger"]),
                "Synthetic candidate fitting contract differs")
        pred = load_npz(directory / "PREDICTIONS.npz")
        region_ids = ids(pred["region_ids"], "committed prediction")
        require(region_ids == fc["region_ids"] and set(region_ids) == set(record["canonical_evaluation_ids"]),
                "Forecast key coverage differs")
        require(len(region_ids) == record["evaluation_rows"] and pred["member_scales"].shape == (7,), "Forecast shape differs")
        require(np.isfinite(pred["member_scales"]).all() and (pred["member_scales"] >= 1).all(), "Member scales invalid")
        require(np.size(pred["total_scale"]) == 1 and float(pred["total_scale"]) >= 1, "Total scale invalid")
        for method in METHODS:
            require(pred[method].shape == (len(region_ids), 7) and np.isfinite(pred[method]).all()
                    and (pred[method] > 0).all(), "Prediction validity differs")
        require(np.allclose(pred["TotalXGB"].sum(axis=1), pred["common_total"], rtol=1e-10, atol=1e-7),
                "Same-total output does not preserve total")
        forecasts[fold] = (record, pred, region_ids)
    return commit, forecasts


def score_worker(root):
    identity = process_identity()
    output = root / "scores"
    output.mkdir(exist_ok=False)
    allowed = [root / "SPEC.json", root / "CODE_LOCK.json", root / "ALL_PREDICTIONS_COMMIT.json"]
    for fold in ("SYN_A", "SYN_B"):
        allowed += [root / "predictions" / fold / name for name in
                    ("COMMIT.json", "PREDICTIONS.npz", "MODELS.json", "PREDICTOR_RECEIPT.json")]
        allowed += [root / ("predict_" + fold + "_EXIT.json")]
    guard = ReadGuard(role="score", run_root=root, allowed_reads=allowed, output_root=output)
    verify_sources(root)
    spec = read_json(root / "SPEC.json")
    require(spec["mode"] == "synthetic" and spec["real_data"] is False, "Real execution prohibited")
    _, forecasts = validate_barrier(root, spec)
    barrier_time = utc_now()
    # The first scoring truth permission is granted only after both complete commits and actual exits.
    for record, _, _ in forecasts.values():
        guard.add_read(inside(root, record["relative_directory"]) / "truth_scorer_only.npz")
    guard.truth_permission = True
    import numpy as np
    from vendor.count_score_core import scalar_metrics, vector_metrics, METRICS, check_close
    rows, gene_rows, directions = [], [], []
    max_errors = {name: 0.0 for name in METRICS}
    max_gene_error = 0.0
    seen = set()
    for fold in sorted(forecasts):
        record, pred, eval_ids = forecasts[fold]
        truth_path = inside(root, record["relative_directory"]) / "truth_scorer_only.npz"
        require(file_hash(truth_path) == record["hashes"]["truth_scorer_only.npz"], "Truth artifact hash changed")
        truth = load_npz(truth_path)
        require(set(truth) == {"Y", "region_ids", "member_ids", "variants"}, "Truth schema differs")
        truth_ids = ids(truth["region_ids"], "scorer truth")
        require(tuple(truth["variants"].tolist()) == VARIANTS and np.array_equal(truth["member_ids"], pred["member_ids"]),
                "Artificial label variant/member identities changed")
        require(truth["Y"].dtype.kind in "iu" and truth["Y"].shape == (3, len(eval_ids), 7)
                and (truth["Y"] >= 0).all(), "Integer artificial labels required")
        member_scales = pred["member_scales"].astype(np.float64)
        total_scale = float(pred["total_scale"])
        for v, variant in enumerate(VARIANTS):
            y = strict_join(eval_ids, truth_ids, truth["Y"][v], "truth").astype(np.float64)
            for method in METHODS:
                mu = pred[method].astype(np.float64)
                vector, vector_dv = vector_metrics(y, mu, member_scales, total_scale)
                scalar_rows = {name: [] for name in METRICS}
                for i, region in enumerate(eval_ids):
                    values, dv, ae, zb, total, mt = scalar_metrics(y[i], mu[i], member_scales, total_scale)
                    key = (fold, variant, method, region)
                    require(key not in seen, "Duplicate artificial scored key")
                    seen.add(key)
                    rows.append({"direction": fold, "variant": variant, "method": method, "region_id": region,
                                 **{name: None if math.isnan(value) else value for name, value in values.items()},
                                 "true_total": int(total), "pred_total": mt})
                    for name, value in values.items():
                        scalar_rows[name].append(value)
                    max_gene_error = max(max_gene_error, check_close(dv, vector_dv[i], "Member scalar/vector mismatch"))
                    for j, member in enumerate(pred["member_ids"]):
                        gene_rows.append({"direction": fold, "variant": variant, "method": method,
                                          "region_id": region, "member_id": str(member),
                                          "observed": int(y[i, j]), "mean": float(mu[i, j]),
                                          "training_scale": float(member_scales[j]), "deviance": dv[j],
                                          "scaled_deviance": dv[j] / member_scales[j],
                                          "absolute_error": ae[j], "zero_Brier": zb[j]})
                summary = {"direction": fold, "variant": variant, "method": method, "regions": len(eval_ids),
                           "JS_valid_regions": int((y.sum(axis=1) > 0).sum())}
                for name in METRICS:
                    max_errors[name] = max(max_errors[name], check_close(scalar_rows[name], vector[name], name + " cross-check"))
                    valid = [value for value in scalar_rows[name] if math.isfinite(value)]
                    summary[name] = math.fsum(valid) / len(valid) if valid else None
                directions.append(summary)
    require(len(rows) == spec["score_rows_expected"] and len(gene_rows) == spec["member_score_rows_expected"],
            "Artificial scoring row coverage differs")
    require(seen == {(fold, variant, method, region) for fold, (_, _, keys) in forecasts.items()
                     for variant in VARIANTS for method in METHODS for region in keys}, "Artificial scored key set differs")
    overall = []
    for variant in VARIANTS:
        for method in METHODS:
            selected = [row for row in directions if row["variant"] == variant and row["method"] == method]
            require(len(selected) == 2, "Two direction summaries required")
            summary = {"variant": variant, "method": method, "directions": 2,
                       "regions": sum(row["regions"] for row in selected)}
            for name in METRICS:
                summary[name] = (None if any(row[name] is None for row in selected)
                                 else math.fsum(row[name] for row in selected) / 2.0)
                # Recompute directly from row data with equal directions, including unequal region counts.
                per_direction = []
                for fold in ("SYN_A", "SYN_B"):
                    values = [row[name] for row in rows if row["direction"] == fold and row["variant"] == variant
                              and row["method"] == method and row[name] is not None]
                    per_direction.append(math.fsum(values) / len(values) if values else None)
                expected = None if any(value is None for value in per_direction) else math.fsum(per_direction) / 2.0
                require((summary[name] is None and expected is None) or math.isclose(summary[name], expected, rel_tol=1e-10, abs_tol=1e-7),
                        "Equal-direction aggregation mismatch")
            overall.append(summary)
    write_csv(output / "REGION_SCORES.csv", ["direction", "variant", "method", "region_id", *METRICS, "true_total", "pred_total"], rows)
    write_csv(output / "GENE_SCORES.csv", ["direction", "variant", "method", "region_id", "member_id", "observed", "mean", "training_scale",
                                         "deviance", "scaled_deviance", "absolute_error", "zero_Brier"], gene_rows)
    write_csv(output / "DIRECTION_SUMMARY.csv", ["direction", "variant", "method", "regions", "JS_valid_regions", *METRICS], directions)
    write_csv(output / "OVERALL_SUMMARY.csv", ["variant", "method", "directions", "regions", *METRICS], overall)
    for name in ("REGION_SCORES.csv", "GENE_SCORES.csv", "DIRECTION_SUMMARY.csv", "OVERALL_SUMMARY.csv"):
        guard.add_read(output / name)
    with (output / "REGION_SCORES.csv").open(newline="", encoding="utf-8") as stream:
        persisted = list(csv.DictReader(stream))
    require({(row["direction"], row["variant"], row["method"], row["region_id"]) for row in persisted} == seen,
            "Persisted scored keys differ")
    verify_sources(root)
    assessment = {"status": "PASS_SYNTHETIC_SCALAR_VECTOR_AND_BARRIER", "mode": "synthetic", "real_data": False,
                  "process": identity, "regions": 11, "label_variants": 3, "new_scoring_rows": len(rows),
                  "member_score_rows": len(gene_rows), "methods": list(METHODS),
                  "all_eight_metrics_full_row_recomputed": True,
                  "scalar_vector_max_abs_errors": max_errors, "member_deviance_max_abs_error": max_gene_error,
                  "macro_weighting": "regions within direction, then two directions equally",
                  "different_artificial_labels_do_not_refit": True, "predictor_fits_total": 14,
                  "barrier_validated_before_truth_permission": barrier_time,
                  "truth_reads_after_prediction_barrier": True, "data_access": guard.receipt(),
                  "scientific_metric_tolerances": {"rtol": 1e-10, "atol": 1e-7},
                  "biological_replication_or_new_method_claim": False, "completed": utc_now()}
    write_json(output / "ASSESSMENT.json", assessment)
    guard.add_read(output / "ASSESSMENT.json")
    payload = {name: file_hash(output / name) for name in
               ("REGION_SCORES.csv", "GENE_SCORES.csv", "DIRECTION_SUMMARY.csv", "OVERALL_SUMMARY.csv", "ASSESSMENT.json")}
    write_json(output / "SCORING_COMPLETE.json", {"status": "SCORING_COMPLETE_SYNTHETIC", "mode": "synthetic",
               "region_rows": len(rows), "member_rows": len(gene_rows), "payload_hashes": payload})
    print(json.dumps({"status": "SCORING_COMPLETE_SYNTHETIC", "region_rows": len(rows), "member_rows": len(gene_rows)}))


def run_child(root, *, stage, fold=None, global_start):
    import psutil
    command = [sys.executable, "-B", str(Path(__file__).resolve()), "--mode", "synthetic",
               "--worker", stage, "--run-root", str(root)]
    if fold:
        command += ["--fold", fold]
    label = "predict_" + fold if fold else "score"
    log_path = root / (label + ".log")
    known = {}
    peak = 0
    sample_count = 0
    violations = []
    launched = utc_now()
    with log_path.open("xb") as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                   cwd=str(CODE_ROOT), env=dict(os.environ), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        parent_handle = psutil.Process(process.pid)
        handle_identity = process_identity(parent_handle)
        confirmed = True
        while process.poll() is None:
            if time.monotonic() - global_start > WALL_CAP:
                violations.append("600-second global synthetic wall budget exceeded")
            try:
                descendants = [parent_handle] + parent_handle.children(recursive=True)
                for child in descendants:
                    try:
                        identity = process_identity(child)
                        child.cpu_affinity(child.cpu_affinity()[:2])
                        rss = int(child.memory_info().rss)
                        peak = max(peak, rss)
                        identity["peak_sampled_RSS_bytes"] = max(rss, known.get(child.pid, {}).get("peak_sampled_RSS_bytes", 0))
                        known[child.pid] = identity
                        if rss > RSS_CAP:
                            violations.append(f"Synthetic own child RSS cap exceeded: PID {child.pid}")
                    except psutil.NoSuchProcess:
                        pass
                sample_count += 1
            except psutil.NoSuchProcess:
                pass
            if violations:
                for pid, identity in sorted(known.items(), reverse=True):
                    try:
                        target = psutil.Process(pid)
                        if abs(target.create_time() - identity["created_epoch"]) < 1e-4:
                            target.terminate()
                    except psutil.NoSuchProcess:
                        pass
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                break
            time.sleep(0.05)
        exit_code = process.wait()
    receipt = {"stage": stage, "fold": fold, "command": command, "launcher": handle_identity,
               "child_handle_confirmed": confirmed, "observed_processes": list(known.values()),
               "external_exit_code": exit_code, "peak_sampled_individual_RSS_bytes": peak,
               "resource_samples": sample_count, "CPU_threads": 2, "cpu_affinity_max": 2,
               "RSS_cap_bytes": RSS_CAP, "global_wall_limit_seconds": WALL_CAP,
               "violations": violations, "launched": launched, "completed": utc_now(),
               "current_elapsed_seconds": time.monotonic() - global_start,
               "native_library_IO_fully_covered": False}
    write_json(root / (label + "_EXIT.json"), receipt)
    require(exit_code == 0 and not violations, label + " child failed; preserve this attempt")
    return label + "_EXIT.json"


def driver(root):
    start = time.monotonic()
    root.mkdir(parents=True, exist_ok=False)
    write_json(root / "START.json", {"mode": "synthetic", "real_data": False,
               "started": utc_now(), "process": process_identity(), "wall_limit_seconds": WALL_CAP,
               "RSS_cap_bytes": RSS_CAP, "CPU_threads": 2})
    write_json(root / "CODE_LOCK.json", {"files": {name: file_hash(CODE_ROOT / name) for name in SOURCE_FILES}})
    spec = create_inputs(root)
    folds = []
    for record in spec["folds"]:
        fold = record["fold"]
        exit_file = run_child(root, stage="predict", fold=fold, global_start=start)
        commit_path = root / "predictions" / fold / "COMMIT.json"
        fc = read_json(commit_path)
        require(fc["status"] == "SYNTHETIC_FOLD_COMMITTED", "Predictor commit absent")
        folds.append({"fold": fold, "commit_sha256": file_hash(commit_path),
                      "exit_file": exit_file, "exit_sha256": file_hash(root / exit_file)})
    write_json(root / "ALL_PREDICTIONS_COMMIT.json", {"status": "ALL_SYNTHETIC_FOLDS_COMMITTED",
               "mode": "synthetic", "folds": folds, "regions": 11,
               "new_region_variant_rows": 22, "new_member_means": 154, "completed": utc_now()})
    score_exit = run_child(root, stage="score", global_start=start)
    complete = read_json(root / "scores" / "SCORING_COMPLETE.json")
    require(complete["status"] == "SCORING_COMPLETE_SYNTHETIC" and complete["region_rows"] == 66
            and complete["member_rows"] == 462, "Scoring terminal or dimensions differ")
    for name, digest in complete["payload_hashes"].items():
        require(file_hash(root / "scores" / name) == digest, "Scoring payload hash differs")
    assessment = read_json(root / "scores" / "ASSESSMENT.json")
    require(assessment["truth_reads_after_prediction_barrier"] and assessment["all_eight_metrics_full_row_recomputed"],
            "Scorer assessment incomplete")
    verify_sources(root)
    elapsed = time.monotonic() - start
    require(elapsed <= WALL_CAP, "Global synthetic wall budget exceeded")
    result = {"status": "EXAMPLE_COMPLETE", "mode": "synthetic", "real_data": False,
              "artificial_directions": 2, "artificial_regions": 11, "fixed_200_round_heads": 14,
              "committed_prediction_rows": 22, "committed_member_means": 154,
              "artificial_label_variants": list(VARIANTS), "scoring_rows": 66, "member_score_rows": 462,
              "all_prediction_commits_before_scoring": True, "scorer_external_exit": 0,
              "score_exit_receipt_sha256": file_hash(root / score_exit),
              "scoring_complete_sha256": file_hash(root / "scores" / "SCORING_COMPLETE.json"),
              "forecast_commit_sha256": file_hash(root / "ALL_PREDICTIONS_COMMIT.json"),
              "all_eight_metrics_independently_recomputed": True,
              "model_reload_prediction_bit_identity": True, "no_real_files_read": True,
              "Python_open_guard_is_OS_proof": False, "native_library_IO_fully_covered": False,
              "no_probability_or_biological_validation_claim": True,
              "elapsed_seconds": elapsed, "CPU_threads": 2, "RSS_cap_bytes": RSS_CAP,
              "real_fitting_authorized": False, "completed": utc_now()}
    write_json(root / "EXAMPLE_COMPLETE.json", result)
    print(json.dumps(result))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=("synthetic",))
    parser.add_argument("--out", type=Path)
    parser.add_argument("--worker", choices=("predict", "score"))
    parser.add_argument("--run-root", type=Path)
    parser.add_argument("--fold", choices=("SYN_A", "SYN_B"))
    args = parser.parse_args()
    bind_cpu2()
    if args.worker:
        require(args.run_root is not None and args.out is None, "Worker requires its existing synthetic run")
        root = safe_run_root(args.run_root, existing=True)
        if args.worker == "predict":
            require(args.fold is not None, "Predictor fold required")
            predict_worker(root, args.fold)
        else:
            require(args.fold is None, "Scorer must cover both synthetic folds")
            score_worker(root)
    else:
        require(args.out is not None and args.run_root is None and args.fold is None, "Driver needs a new output")
        root = safe_run_root(args.out, existing=False)
        try:
            driver(root)
        except Exception as exc:
            if root.exists() and not (root / "FAILURE.json").exists():
                write_json(root / "FAILURE.json", {"status": "SYNTHETIC_FAILURE_PRESERVED", "mode": "synthetic",
                           "error": type(exc).__name__ + ": " + str(exc), "time": utc_now(), "real_data": False})
            raise


if __name__ == "__main__":
    main()
