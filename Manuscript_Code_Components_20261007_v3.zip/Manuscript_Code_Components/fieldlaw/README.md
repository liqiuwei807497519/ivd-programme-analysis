# Complete FieldLaw aggregate-score reproduction

This release reproduces the completed four-law count-probability comparison from stored regional worlds and regional truths. It preserves the complete three-library population, all seven programme members, four global gene-world permutation diagnostics and the numerical Monte Carlo precision packets. The original forecasts are reused without fitting a point model, regenerating worlds or reopening native expression matrices.

The source-conditioned law did not improve the prescribed All7 comparison over the fixed-rho field: equal-library source-scaled fair RPS was 12.9987303 versus 12.9468585. Its nominal-95% coverage was 22.091%. The shared frozen mean mass was 12,959.0022 against 146,739 measured gene-feature counts. The complete tables retain these outcomes, every library and all member-level mass comparisons; the within-rat RNA mean in Additional file 20 was not transferred to this challenge.

## Contents and units

`RESULT_TABLE.tsv` contains 140 rows: 64 generative-law summaries, 64 permutation-diagnostic summaries and 12 paired primary contrasts. `MEMBER_MEASUREMENT_COMPLETE.tsv` contains 35 member-by-capture records from the two source captures and three developmental libraries. The JSON assessment, measurement diagnosis and source-provenance records describe the measurement and interpretation of these results.

`capsules/` contains only regional truth counts, the exact ordered regional keys, member identities and the four original complete aggregate-world arrays. Their shapes are 2,048 × 54 × 7, 2,048 × 76 × 7 and 2,048 × 78 × 7 per law. Original native `mu7`, `spot_member_counts`, `canonical_ids` and prepared inputs are excluded. The 208 regions summarize 3,942 original native observations; regions and worlds are not independent animals. Source scales are frozen in `REPLAY_CONFIG.json`.

`reference/` holds losslessly compressed original score tables and full score/Monte Carlo JSON packets. Replay verifies all 6,656 score rows against those original rows byte for byte, compares the entire original score JSON, and reconstructs row arithmetic and Monte Carlo packets with the separate integer-support-CDF checker. Negative fair RPS values, when present, are retained. Permutation diagnostics use empirical scores, not an IID-fair correction.

`source/` and `proofs/` retain source parameters, frozen configuration, source/code hashes, barriers, actual external stage/parent/audit exits and budgets. Machine paths are replaced with explicit placeholders. `ORIGINAL_ARTIFACT_PROVENANCE.json` preserves each original artifact's SHA-256 and records that sanitation changes the released JSON bytes. A sanitized proof is an archived evidence record, not an instruction to recreate an old process or its elapsed clock.

`software/` preserves the original version-2 scientific modules, synthetic tests and execution logs. The portable aggregate adapters are `aggregate_replay.py` and `run_replay.py`. Original source/target/supervisor CLIs are historical implementations with their original acquisition/checkpoint/runtime prerequisites; they are not the aggregate replay entry point.

## Run the aggregate replay

Extract the entire Additional file 21 directory before running. Use Python with the exact dependency versions in `requirements.txt` (NumPy 2.5.2, SciPy 1.18.1 and psutil 7.2.2). No network access, raw expression download or saved point-model loading is needed for this entry point.

```text
python -B run_replay.py --bundle . --output ../fieldlaw_replay
```

The output directory must be new. The runner binds the released file hashes, records true external exits for the production score child and the independent checker, and limits the complete sequence to 30 minutes, two CPUs, 4 GiB process-tree RSS and 1 GiB output. Budget or child failure stops the sequence; there is no partial restart or altered threshold. `FINAL_COMPLETE.json` is written only after both external exits are zero and the independent full-row check passes.

The literal synthetic public-seam checks can be run with:

```text
python -B -m unittest test_aggregate_replay
```

## Source acquisition and interpretation

The frozen source forecasts came from the two GSE287499 captures, using the earlier owned point-model checkpoints/code supplied with Additional file 6 and the original mouse capture records. Their generation, source-statistical fitting and native source/target acquisition are outside this aggregate arithmetic replay. The entire original point-training pipeline has not been rerun from a fresh public-data acquisition for this release. Additional file 17 concerns the separate human donor programme analysis and is not an aggregate FieldLaw replay dependency. Additional file 20 is the separate rat RNA mean task.

The three target libraries are [GSE216511](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE216511), GSM6675529–GSM6675531, developmental mouse E11.5–E13.5, associated with [the source publication](https://doi.org/10.1002/advs.202206296) ([PMC10190614](https://pmc.ncbi.nlm.nih.gov/articles/PMC10190614/)). They are not adult disc-degeneration or human validation specimens. Original source datasets retain their source access and redistribution conditions.

GSE287499 methods describe mRNA and gDNA probe-ligation events. Gene-feature labels and integer counts do not certify a pure-RNA layer, raw-UMI equivalence or matched physical support. The completed challenge does not distinguish assay, support, input-transfer and biological contributions to the shared mean mismatch. Numerical Monte Carlo bands describe integration precision, not biological confidence intervals or causal uncertainty.

The software is supplied under the included MIT licence. No raw CTM RDS, native expression matrices, full runtime binaries or histological images are redistributed. Public-repository deposition and journal submission have not been performed by this release assembly.
