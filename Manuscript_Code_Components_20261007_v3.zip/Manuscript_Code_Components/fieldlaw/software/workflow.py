"""FieldLaw stage functions and synthetic end-to-end contract."""
import os
for _name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_name] = '2'
from pathlib import Path
import argparse
import hashlib
import json
import time
import numpy as np
from source_statistics import fit_source, source_state_weights, source_state_basis
from field_core import FieldLaw
from scoring import score_ensembles, event_brier

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
LAWS = ('INDEPENDENT_GENE_FIELDS','FIXED_RHO025_COMMON_FIELD','POOLED_SOURCE_CORR','CONDITIONAL_SOURCE_CORR')
GENES = ('TBXT','KRT8','KRT18','KRT19','ACAN','COL2A1','SOX9')

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def writej(path, value):
    def converter(item):
        if isinstance(item,np.ndarray): return item.tolist()
        if isinstance(item,np.generic): return item.item()
        raise TypeError(type(item).__name__)
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=converter)+'\n',encoding='utf8')

def bank_for(law, params):
    if law == LAWS[0]: return np.repeat(np.eye(7)[None,:,:],4,axis=0)
    if law == LAWS[1]: return np.repeat((.75*np.eye(7)+.25*np.ones((7,7)))[None,:,:],4,axis=0)
    if law == LAWS[2]: return np.repeat(np.asarray(params['residual_correlations']['pooled'])[None,:,:],4,axis=0)
    if law == LAWS[3]: return np.asarray(params['residual_correlations']['states'])
    raise ValueError('Unknown fixed law')

def region_indices(coords):
    coords = np.asarray(coords,dtype=float)
    if coords.ndim != 2 or coords.shape[1] != 2 or not np.isfinite(coords).all():
        raise ValueError('Invalid complete support coordinates')
    keys = np.floor(coords/500).astype(np.int64)
    unique, inverse = np.unique(keys,axis=0,return_inverse=True)
    return inverse, unique

def sum_functionals(gene_totals):
    values = np.asarray(gene_totals)
    if values.ndim != 3 or values.shape[-1] != 7:
        raise ValueError('Expected worlds by regions by seven genes')
    # Check Python-integer upper bound before exact int64 summation.
    if int(values.max()) > np.iinfo(np.int64).max//7:
        raise ValueError('Functional count sum could overflow; no repair')
    return {'ALL7':values.sum(axis=2), 'ACAN_COL2A1':values[:,:,4:6].sum(axis=2),
            'OTHER5':values[:,:,[0,1,2,3,6]].sum(axis=2)}

def synthetic(output):
    output = Path(output)
    output.mkdir(parents=True,exist_ok=True)
    if list(output.iterdir()): raise ValueError('Synthetic output must be empty')
    # Worked artificial source, not a reused real measurement or model.
    x = np.repeat(np.array([1.,7.,31.,127.]),8)[:,None]*np.ones((1,126))
    mu_source = np.full((32,7),2.)
    y_source = (np.arange(32)[:,None]+np.arange(7)[None,:])%6
    captures = np.repeat(np.array(['SYN_A','SYN_B']),16)
    params = fit_source(x,y_source,mu_source,captures)
    writej(output/'SOURCE_PARAMS.json',params)
    target_x = np.full((4,126),7.)
    coords = np.array([[0.,0.],[600.,0.],[0.,600.],[600.,600.]])
    weights = source_state_weights(target_x,params)
    h = source_state_basis(coords,weights)
    target_mu = np.full((4,7),2.)
    roi,keys = region_indices(coords)
    outputs = {}
    for law in LAWS:
        field = FieldLaw(target_mu,np.asarray(params['alpha7']),weights,h,bank_for(law,params),gamma=.25)
        totals,receipt = field.sample_gene_region_totals(roi,64,'SYNTHETIC_COMPLETE_LIBRARY',chunk_size=13)
        path = output/(law+'.npz')
        np.savez_compressed(path,gene_region_totals=totals,region_keys=keys)
        writej(output/(law+'_RECEIPT.json'),receipt)
        outputs[law]={'path':path.name,'sha256':sha(path)}
    commit = {'status':'SYNTHETIC_ALL_FOUR_LAWS_COMMITTED','forecasts':outputs,
              'time_ns':time.perf_counter_ns(),'ordering_clock':'monotonic_performance_counter'}
    writej(output/'FORECAST_COMMIT.json',commit)
    # The separate truth/scoring seam is entered only after all four outputs.
    truth = np.array([[1,1,1,1,1,1,1],[0,1,0,1,0,1,0],[3,2,1,2,3,2,1],[0,0,0,0,0,0,0]],dtype=np.int64)
    writej(output/'TRUTH_COMMIT.json',{'time_ns':time.perf_counter_ns(),'truth':truth,
                                    'ordering_clock':'monotonic_performance_counter'})
    scores = {}
    for law,item in outputs.items():
        with np.load(output/item['path'],allow_pickle=False) as array:
            totals = array['gene_region_totals']
        forecast_functions = sum_functionals(totals)
        truth_functions = sum_functionals(truth[None,:,:])
        scores[law] = {name:score_ensembles(values,truth_functions[name][0],1.,IID=True)
                       for name,values in forecast_functions.items()}
        scores[law]['EVENT'] = event_brier(np.all(totals>0,axis=2),np.all(truth>0,axis=1))
    writej(output/'SCORES.json',scores)
    receipt = {'status':'SYNTHETIC_END_TO_END_COMPLETE','generative_laws':4,
               'prediction_barrier_precedes_truth':commit['time_ns'] < json.loads((output/'TRUTH_COMMIT.json').read_text())['time_ns'],
               'real_source_or_target_reads':0,'new_point_model_fits':0,
               'not_empirical_validation':True}
    writej(output/'SYNTHETIC_COMPLETE.json',receipt)
    print(json.dumps(receipt),flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage',choices=['synthetic'])
    parser.add_argument('--output',required=True)
    args = parser.parse_args()
    synthetic(args.output)
