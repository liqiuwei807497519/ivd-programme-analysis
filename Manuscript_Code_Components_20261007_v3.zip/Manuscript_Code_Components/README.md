# Manuscript code components

These original author-owned code modules complement the separately supplied `external_rna_probability` module. This is a code-only release: native counts, real arrays, fitted checkpoints, regional worlds/truths and execution receipts are not included. Exact source hashes and exclusions are in MANIFEST.json.

Folder structures preserve intra-module imports. Tests requiring a lawful prepared data capsule must obtain that capsule separately; prior execution evidence remains in the manuscript Additional files and is not a new test in this release. Modules with original source-runtime prerequisites are labelled as historical provenance. No claim of a complete fresh raw-data rerun is made.

The `vendor` folders contain original project-authored frozen mathematical snapshots, not copies of NumPy/SciPy/XGBoost libraries. Public dependency packages retain their own licenses and are installed separately. Code is under the author-approved MIT license. Third-party biological datasets and images retain source conditions.

The existing count, nonlinear and human prepared-count entry points and FieldLaw aggregate-replay entry point are documented in their original module READMEs. Rat source training still requires separately authorized CTM inputs. The new External-RNA module is separate, not replaced by this bundle.

The six previously path-bound context/figure sources are now supplied under public_path_adaptations/ with explicit CLI bindings. Their scientific AST is unchanged. Their help/describe seam is tested separately; this is not a new real-data pipeline replay. V2 exclusions remain historical documentation of V2 and are superseded for these six files only.
