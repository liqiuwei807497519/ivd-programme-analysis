# Source data and software attribution

The prepared nine-sample count capsule is an aggregation of the publicly released GSE222182 gene-count bundles. The original study is Jiang et al., Science Translational Medicine (2023), 15:eadg7020. Obtain the original files and study information from [the GEO record](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE222182). Cite that study when using these measurements. Preparation, programme definitions and all source fingerprints accompany the capsule.

This archive contains derived sample-level counts and the original committed statistical results, not the original single-cell matrices, the 310 MB acquisition container or new participant data. Seven natural-tissue specimens are the comparison units; the two cultured samples are a descriptive pair. Public sample accessions are not personal identities. Pain labels and tissue-source confounding remain as declared in the original analysis.

The authors have approved release of their original software and derived analysis materials. The MIT licence applies to that software and documentation, including the new prepared-count interfaces. It does not transfer ownership or replace conditions associated with the underlying GEO data, third-party publications or images. No additional licence is asserted over those underlying measurements. Preserve source attribution and applicable access conditions when redistributing or reusing them.

Python, NumPy and SciPy are external dependencies rather than bundled third-party source. They retain their respective PSF and BSD-family licences. Exact versions and observed execution environments are recorded separately; this archive does not claim recreation of every dependency of the original raw research workflow.

The source code, numerical core and historical failures remain attributed to their recorded versions. A successful replay of prepared counts establishes that interface's reproducibility. It does not reproduce raw acquisition, restore unmeasured features, demonstrate a new predictive method, certify independence of the clinical labels, or constitute a Genome Biology acceptance assessment.

Raw rat RDS and histology images, other studies' spatial matrices, FinnGen source files and controlled-access data are not part of this human reproduction archive. Their permissions cannot be granted by its software licence.
