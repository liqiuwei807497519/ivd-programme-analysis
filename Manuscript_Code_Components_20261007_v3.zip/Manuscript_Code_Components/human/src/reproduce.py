"""New wrapper: submitted full-gene counts to the unchanged statistics stage."""
import os
for _variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_variable] = "2"
import argparse
import ctypes
import json
from pathlib import Path
import shutil
import time
import numpy as np
from capsule_contract import CORE_SHA, STATISTICS_SHA, load, sha


def limit_cpu():
    if os.name == "nt":
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GetCurrentProcess.restype = ctypes.c_void_p
        kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
        kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
        process = kernel.GetCurrentProcess()
        allowed, system = ctypes.c_size_t(), ctypes.c_size_t()
        if not kernel.GetProcessAffinityMask(process, ctypes.byref(allowed), ctypes.byref(system)):
            raise OSError("Cannot read process CPU affinity")
        bits = [1 << i for i in range(allowed.value.bit_length()) if allowed.value & (1 << i)][:2]
        if not bits or not kernel.SetProcessAffinityMask(process, sum(bits)):
            raise OSError("Cannot enforce two-CPU affinity")
        return bits
    if hasattr(os, "sched_getaffinity"):
        chosen = sorted(os.sched_getaffinity(0))[:2]
        os.sched_setaffinity(0, chosen)
        return chosen
    return "THREAD_ENVIRONMENT_ONLY"


def run(capsule, metadata, output):
    started = time.monotonic()
    output = Path(output).resolve()
    if output.exists():
        raise FileExistsError("One-shot reproduction output exists; choose a new output path")
    arrays, provenance = load(capsule, metadata)
    source_dir = Path(__file__).resolve().parent
    if sha(source_dir / "statistics_stage.py") != STATISTICS_SHA or sha(source_dir / "vendor" / "frozen_core.py") != CORE_SHA:
        raise ValueError("Byte-preserved submitted statistics source or numerical core differs")
    affinity = limit_cpu()
    import statistics_stage
    output.mkdir(parents=True, exist_ok=False)
    np.savez_compressed(output / "PSEUDOBULK.npz", **arrays)
    shutil.copyfile(metadata, output / "PSEUDOBULK_META.json")
    commit = statistics_stage.run(output)
    receipt = {"status": "PASS_SUBMITTED_COUNT_CAPSULE_REPLAY", "sample_count": 9,
               "natural_sample_count": 7, "cultured_sample_count": 2, "gene_count": 36591,
               "statistics_payload_count": len(commit["artifacts"]), "programme_count": 6,
               "member_identity_count": 47, "matched_null_replicates": commit["matched_null_replicates"],
               "terminal_state": commit["terminal_state"], "capsule_sha256": sha(capsule),
               "historical_metadata_sha256": sha(metadata), "frozen_core_sha256": CORE_SHA,
               "unchanged_statistics_source_sha256": STATISTICS_SHA,
               "historical_source_hash_count": len(provenance["source_hashes"]),
               "CPU_affinity": affinity, "CPU_thread_environment": 2,
               "prepared_count_replay_only": True, "raw_27_files_reconstructed": False,
               "original_research_environment_rebuilt": False, "new_fits": 0,
               "elapsed_seconds": time.monotonic() - started}
    with (output / "REPRODUCTION_RECEIPT.json").open("x", encoding="utf8") as handle:
        json.dump(receipt, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--capsule", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.capsule, args.metadata, args.output), allow_nan=False))
