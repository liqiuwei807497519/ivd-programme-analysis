# Complete human donor programme reproduction

This package reproduces the complete submitted GSE222182 human programme result family from its released nine-sample, 36,591-gene count capsule and checks the results independently. Seven natural samples remain the inferential units: four source-declared asymptomatic and three back-pain samples. The two cultured samples remain a descriptive pair. It retains six frozen programmes, 47 member genes, 423 member measurements, 42 natural programme scores, all 14 Resident leave-one-out states, 35 label allocations per primary/secondary test and all 10,000 matched-background sets.

The prepared-count capsule and historical metadata are immutable inputs. Their original identities and full library denominators are checked before output creation. Statistics use byte-preserved submitted sources. The new independent checker computes log2 CPM, pooled sample standardization, programme scores, scalar Welch allocations, Holm adjustment, every leave-one-out result, matched pools and every seeded null draw without calling the producer's mathematical functions. It also checks complete result schemas and file identities.

Use Python 3.12 with NumPy 2.5.2. No additional Python libraries are required. `requirements.lock` records the actually tested portable dependency. The recorded original research environment remains distinct from this tested prepared-count runtime.

From the extracted package directory:

```text
python src/reproduce.py --capsule inputs/ALL_GENE_DATA.npz --metadata inputs/PSEUDOBULK_META.json --output my_replay
python src/check_prepared.py --capsule inputs/ALL_GENE_DATA.npz --metadata inputs/PSEUDOBULK_META.json --results my_replay --output my_check
python compare_submitted.py --original reference/statistics --replay my_replay/statistics --receipt my_comparison.json
python -m unittest discover -s tests -v
```

Choose new output paths for every run. Existing output directories are rejected. Unicode paths and spaces are supported. The checker can also verify the shipped original family with `--results reference`. It rejects omitted members/results, altered values even after a manifest is refreshed, extra programme endpoints and changed array precision. Independent floating-point calculations use relative/absolute tolerance 1e-10; exact probabilities are compared exactly. Original-versus-replay comparison checks all 12 scientific payloads with zero numerical tolerance; NPZ arrays are compared by key, dtype, shape and array value, rather than ZIP timestamps or container bytes.

`outputs/actual_replay` contains the preserved real replay, `outputs/actual_check` contains its independent verification, and `proofs` holds external exits, red-to-green receipts and original-versus-replay comparison. `fresh_extraction_test.py` builds a fresh standalone extraction, repeats both public CLIs and compares all submitted payloads. `run_receipted.py` supervises commands with a two-CPU affinity/thread cap, a 4 GiB process working-set budget, a two-hour wall budget and a 1 GiB output cap. This release was prepared with existing runtimes; no dependencies were installed or changed.

The reproduced Resident result is effect -0.08639138211310204, exact P=13/35 (0.37142857142857144), Holm-adjusted P=1 and matched-specificity P=0.765023497650235. The recorded conclusion remains `DIRECTIONAL_NOT_SIGNIFICANT`. The natural samples have tissue-source confounding, including cadaver and surgical sources without an official GSM source crosswalk. The labels therefore provide a reference allocation test, and the evidence scope remains a source-confounded sample association. Cells, genes and null draws do not increase donor sample size. The cultured comparison supplies no P value.

The package starts from the already committed full-gene pseudobulk seam. The 27 raw compressed files and their 310,401,515 bytes are absent; their original checksums remain in historical metadata. No raw acquisition, new model fitting, endpoint selection or spatial disease validation is performed. This portable replay does not reconstruct or certify the complete old research environment. Third-party rights and GEO data conditions are described separately in release notices. The package is a locally prepared code/data release; no repository, DOI or upload is implied by these files.
