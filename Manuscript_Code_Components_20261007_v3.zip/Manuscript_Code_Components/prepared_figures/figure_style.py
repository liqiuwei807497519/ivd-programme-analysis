"""Relative, self-contained journal-page style used by the plotting replay."""
from pathlib import Path


def configure_matplotlib(base_font_size=8):
    import matplotlib as mpl
    mpl.rcParams.update({
        'font.family': 'Arial', 'font.size': base_font_size,
        'axes.titlesize': 0, 'axes.titlepad': 0,
        'axes.labelsize': 7, 'axes.linewidth': .6,
        'xtick.labelsize': 7, 'ytick.labelsize': 7,
        'xtick.major.width': .5, 'ytick.major.width': .5,
        'legend.fontsize': 7, 'legend.frameon': False,
        'figure.dpi': 120, 'figure.facecolor': 'white',
        'axes.facecolor': 'white', 'savefig.facecolor': 'white',
        'savefig.dpi': 600, 'savefig.bbox': None,
        'savefig.pad_inches': 0, 'pdf.fonttype': 42,
        'ps.fonttype': 42, 'svg.fonttype': 'none',
        'svg.hashsalt': 'R6-count-mass-portable-replay',
        'axes.spines.top': False, 'axes.spines.right': False,
    })


def save_figure(fig, output_stem, *, png_dpi=400, journal_page=True):
    if not journal_page:
        raise ValueError('This replay requires the exact 183 x 220 mm canvas')
    stem = Path(output_stem)
    stem.parent.mkdir(parents=True, exist_ok=True)
    outputs = [stem.with_suffix(ext) for ext in ('.pdf', '.svg', '.png')]
    shared = {'facecolor': 'white', 'edgecolor': 'none',
              'bbox_inches': None, 'pad_inches': 0}
    fig.savefig(outputs[0], metadata={'CreationDate': None, 'ModDate': None}, **shared)
    fig.savefig(outputs[1], metadata={'Date': None}, **shared)
    fig.savefig(outputs[2], dpi=png_dpi, **shared)
    return outputs
