# Public code coverage decision

## Decision

The new 15-file External-RNA probability release is one executable module, not the complete code release for the seven-figure manuscript. Preserve it as `external_rna_probability/` and retain the earlier method modules separately. Do not publish the entire old Reproducibility directory indiscriminately: it also contains fitted assets, derived measurements, machine-specific harnesses and superseded candidate histories.

This review inspected the current final manuscript figure-title paragraphs, explicit R7 code/README/manifests, small existing execution receipts and the central member lists of Additional files 02–28. It did not read numeric arrays, native expression, target caches or raw counts; it did not fit, replay or test scientific software. `CODE_COVERAGE_METADATA.json` records 70 explicit text-code files and the 27 ZIP member inventories. The current pure-math 15-file module is being prepared by another owner and was not independently re-certified here.

## Coverage to retain

| Manuscript component | Existing source or current addition | Evidence already present | Public release boundary |
| --- | --- | --- | --- |
| Mouse regional count means and shared-total allocation, Figure 3 | R7 `src/baseline_core.py`, `count_cli.py`, `count_metrics.py`; tests, synthetic example, frozen role configurations | 21 synthetic tests, actual external exit 0; complete 30829-region/four-method mean replay, max absolute errors 0 and shared-total rounding at about 1e-14 | Three numerical/CLI files plus the exact three test files, example and configurations are the portable interface. No real evaluation NPZ is required for its synthetic example. |
| Rat native-RNA prediction/allocation, Figure 4 and quantitative rat supplements | Additional 20 `RNA_Analysis/software/`, `same_total_controls/`, configuration/orchestration adapters and figure sources | Preserved direct-array synthetic tests and actual completed four-parent execution/audit receipts | Retain the seven production modules and their seven tests, no-fit control modules/test, requirements and adapter documentation. The portable full source-training adapter has not been run from a fresh public release. CTM native files remain source-author restricted; do not bundle them. |
| Nonlinear count comparison, Figure 5 | Additional 6 `Nonlinear_V2/preflight/src/xgb_offset_core.py`, two vendor cores, fixture, 27-test suite and source orchestration | 27 tests and preserved synthetic external exits; original complete real comparison | Retain the preflight package structure so `vendor` imports resolve. The scientific core uses NumPy and XGBoost; historical real harnesses are provenance, not a clean-machine command. Saved fitted models are a separate asset scope, not code. |
| Human donor programme statistics, Figure 2 | **Additional 18**, rather than only the older Additional 17 research harness | Eight public-interface tests with external exit 0; fresh relocated prepared-count CLIs; all 12 scientific payloads reproduced exactly; independent checker exited 0 | Retain `src/capsule_contract.py`, `src/check_prepared.py`, `src/reproduce.py`, `src/statistics_stage.py`, `src/vendor/frozen_core.py`, public tests and replay/comparison runners. NumPy 2.5.2/Python 3.12. The eight original tests use the complete released prepared-count capsule, so a code-only distribution cannot silently claim that they run with no data. Keep a separate authorized data release or provide genuine synthetic fixtures later. |
| FieldLaw regional probability comparison | **Additional 21**, not old `legacy_context/spatch` September workstation scripts | Actual fresh-copy parent and both children exited 0; independent audit of all 6656 score rows and MC packets; no fits/world regeneration/native reads | Retain `aggregate_replay.py`, `run_replay.py`, `test_aggregate_replay.py`, the exact scientific `software/` modules and synthetic tests, requirements/configuration and README. Complete replay needs the regional-world/truth capsule supplied separately; code-only is not that replay. Source/target acquisition and old runtime harnesses remain historical prerequisite-dependent code. |
| Spatial localization/retrieval supplements S9–S11 | **Additional 19** `run_replay.py`, `figure_style.py`, plus packaging/review helpers | Actual prepared-output and fresh-extraction replays exited 0, about 44 seconds each; no raw matrix/model reads | Keep relative package structure and NumPy/pandas/Matplotlib/Pillow dependencies. Source numeric TSVs and fixed scales are separate data. This does not regenerate all seven main figures. |
| External source-frozen RNA probability challenge, Figure 7/S12 | Current new 15-file module plus original owned source/sampler/scorer/independent-checker provenance in Additional 22–28 | Complete original study and bound score/source audits, separate new pure-math checks being produced | Do not let a lightweight subset stand for XGBoost source fitting, input preparation, complete joint-world production or plotting if it lacks those files. Keep implemented interfaces and original scientific source provenance, distinguishing portable entry points from historical execution code. |
| Atlas/context and genetic panels, Figure 1/parts of Figure 2 | Additional 6 archival rat extraction/annotation/context scripts, human RNA/chromatin scripts; explicit derived source table indexes | Original selected code source hashes are recorded in R7 SOURCE_MANIFEST | Not demonstrated as a standalone portable fresh-source workflow. Preserve original script provenance and data conditions. Supply the actual external-tool commands/versions and own downstream code for genetics; do not invent or label a generic scaffold as the original analysis. |

## Exact code-only source locations

The safe numerical modules can be copied byte-for-byte with their folder structures, not flattened or renamed inside their import trees:

1. `Reproducibility/src/`, `tests/`, `examples/`, `configs/`, root requirements/environment/README from R7; active MIT licence and separate data notice.
2. `Reproducibility/Nonlinear_V2/preflight/{src,vendor,tests,examples}/` and `synthetic_pipeline.py`; exact lock/README/notices. Do not include wheels/venv/model blobs.
3. `Reproducibility/RNA_Analysis/{software,same_total_controls}/`, `configuration_adapter.py`, `portable_execute.py`, `requirements.txt`, input-role requirements and README from Additional 20. No section arrays.
4. Additional 18 `src/`, `tests/`, `compare_submitted.py`, `run_receipted.py`, `fresh_extraction_test.py`, requirements/license/README/capsule schema. Do not copy its `inputs`, `outputs`, `reference` arrays into the code-only tree.
5. Additional 21 `FieldLaw/software/`, `aggregate_replay.py`, `run_replay.py`, `test_aggregate_replay.py`, requirements/license/README. `REPLAY_CONFIG.json` and source fingerprints are task metadata; the actual capsule bytes remain separate. No `capsules`, saved worlds/truths or native input arrays in code-only.
6. Additional 19 four Python sources, README and declared dependencies; numeric inputs remain separate. Figure1/2 exact archival extraction/context code should be explicitly tagged `historical_provenance`, not advertised as a portable entry point.
7. New External-RNA 15 files remain a separate package. A top-level `COVERAGE.md` should map all modules to the manuscript and separate availability, test scope and data prerequisites.

All selected archive code paths and SHA-256 values for Additional 18/19/21, and R7 explicit modules, are recorded in `CODE_COVERAGE_METADATA.json`. This review did not copy them or change another owner's Code tree.

## Representative exact source hashes

| Source | SHA-256 |
| --- | --- |
| Count `baseline_core.py` | `3197cd986f13c807c25f4b9db66d3cebb67eeb07e5d53348f3160d12ecc0f729` |
| Count `count_cli.py` | `ccacc3445bc01a97ba3e4751821294a1befbda99dfbec5f21908756c14f477d4` |
| Count `count_metrics.py` | `0859fdfce72a4abb61287ad3b314f8f5bef79e3ee4018cb4a97c53d372009b99` |
| Rat `rna_mean.py` | `241b435b4871585db9e203b56622b59eb52673dcb2a2c4417ca8244e804ebbce` |
| Rat independent `rna_numeric_audit.py` | `34adcc472e9ceefcd02c85ab204c213160541a2cc8fd3e7c958a87a3d8ddd521` |
| Nonlinear `xgb_offset_core.py` | `be0dba735978277a6fd0c2f633e9fb321da93dbf5fa233dc4c58a74cb80c1426` |
| Human unchanged `statistics_stage.py` | `1238098edba5a9f7f234e60c6364c43286ac03065822ccb48373b84c8b3782bd` |
| Human `vendor/frozen_core.py` | `515f3d6cf382327717dfcd9691e962bc487a61a1976659ea79dcdc8e4a19b368` |

## Statement suitable for availability documentation

“The released code contains separately versioned regional-count, rat RNA, human prepared-count, FieldLaw aggregate-score, prepared-figure and external-RNA probability modules. Each module documents its executed test/replay scope and required source or prepared data. Source-training reproductions requiring non-redistributed CTM counts or historical model assets are distinct from the executable synthetic and prepared-output interfaces.”

This wording must use a real public URL only after repository deposition succeeds. A local archive is not public deposition. Existing technical tests/replays do not add independent biological validation or establish algorithmic novelty. The full custom-code availability requirement remains incomplete if the public repository contains only the new 15 files and omits the prior original methods described above.

## V3 path-source completion

The six context/figure scripts excluded in V2 are now supplied under public_path_adaptations/. Only their declared path-assignment values were replaced and a standard-library early CLI was added. No original scientific function, gene, threshold or plotting encoding changed. V2 original 101 source copies are unchanged. Historical deployment harnesses remain excluded by design. The whole study still requires lawful source/prepared data and external software; code availability is not a new biological validation or full raw-source rerun. The external-RNA probability module is supplied separately.
