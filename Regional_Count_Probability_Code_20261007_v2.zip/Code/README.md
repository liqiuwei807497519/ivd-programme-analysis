# Regional count probability: code-only software release

This repository provides project-authored code for native-count mean prediction, source-only NB2/PIT calibration, five coherent count laws, proper scoring, and saved-world arithmetic replay. It contains synthetic software tests, not study measurements, trained checkpoints, or patient/animal records.

## Environment

Use Python 3.11 or later (`hashlib.file_digest` is required) and the versions in `requirements.txt`. The source mean module enforces XGBoost 3.4.1. Dependencies retain their upstream licenses and are not vendored here. The optional bounded supervisor uses psutil CPU affinity, which is not available on every operating system.

```text
python -m pip install -r requirements.txt
```

Installation in a new environment is a user operation; the local release check used the existing scientific environment without installing or changing packages. No clean-machine installation claim is made.

## Run the original synthetic tests

Execute the following commands from their indicated directories. No real-data files are required. The tests generate artificial arrays or temporary synthetic forecast/truth capsules themselves. Native-XGBoost tests fit three-row artificial training examples; they do not refit any model used in the paper.

| Directory | Command | Distinct test methods |
| --- | --- | ---: |
| `source_model` | `python -B -m unittest test_native_xgb -v` | 2 |
| `original_code/software` | `python -B -m unittest test_calibration_three -v` | 2 |
| `original_code/sampler_v1` | `python -B -m unittest test_sampler -v` | 2 |
| `original_code/scorer_v2` | `python -B -m unittest test_joint_scorer -v` | 3 |
| `original_code/scorer_v2` | `python -B -m unittest test_quantile_contract.RationalQuantileContract -v` | 1 |
| `code` | `python -B -m unittest test_saved_world_replay -v` | 3 |

The explicit quantile test class avoids rerunning the three `JointScorer` tests imported by its module. The suite consists of 13 distinct original test methods. Synthetic checks establish the stated arithmetic and interface behavior, not biological performance, new-algorithm superiority, or independent disease validation.

## Interfaces

* `source_model/native_xgb.py`: source-count fit and frozen prediction from caller arrays. It checks complete ordered, disjoint roles (126 input and seven output identifiers).
* `original_code/software/calibration_three.py`: equally weighted three-capture NB2 moments and PSD PIT correlation from caller-provided source arrays.
* `original_code/sampler_v1/sampler.py`: complete-support sampling and ROI projection. The sibling `count_marginal_v2.py` implements the versioned Poisson/NB2 count marginal. Keep these files together.
* `original_code/scorer_v2/joint_scorer.py`: proper scoring from complete hash-bound forecast/truth capsules. Inverse-empirical-CDF quantiles use the corrected rational-rank contract.
* `code/replay_saved_worlds.py`: relative-path, hash-bound arithmetic replay of saved scenarios. `test_saved_world_replay.py` constructs a minimal synthetic packet. Study replay requires a separately obtained, lawfully accessible result packet; it is not included here.
* `code/run_bounded_replay.py`: optional resource supervisor for that replay. Preserve the `code/` arrangement used by its child command.

The five sampling laws compare atom independence, a true all-atom global factor, and three RBF field constructions. Only the three RBF constructions share the same single-gene spatial kernel. A global-factor versus independent comparison is not purely a gene-correlation ablation. Coherent random-world addresses are independent of computational chunking and ROI projection.

## Provenance and licensing

`SOURCE_MANIFEST.json` records each selected source file's length and SHA256. Scientific source and original test files are copied without edits. `original_code/sampler_v1/PROVENANCE.json` records the project-owned CountMarginal predecessor and independently worked artificial fixture.

`LICENSE_CODE_MIT.txt` grants MIT for original project-owned software. It does not grant rights over upstream data, articles, libraries, images, or excluded private material. No real arrays, checkpoints, process receipts, historical launcher configurations, runtime binaries, credentials, or manuscript personal metadata are in this release.

Public datasets relevant to the separate study include [GSE216511](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE216511) and [GSE237308](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE237308). Their access and redistribution conditions remain separate. No deposited data are copied into this code-only repository.

This is a local software-release artifact until an actual public repository/tag or archive record is created. It supplies neither a public DOI nor a journal-submission receipt.

Procedural release and claim review used guidance from Kassis T, Agarwal V, He Y, Patel D, Brueckner AM (2026), *Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents*, [arXiv](https://doi.org/10.48550/arXiv.2609.00065). This acknowledges research-agent procedure, not the scientific method or experimental results.
