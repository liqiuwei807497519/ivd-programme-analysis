"""Replay published localization figures from released full float64 tables.

This code performs no fitting. It reads no original matrices, NPZ forecasts,
model weights, registration assets, or sealed datasets. All task inputs live in
the input directory; the figure style is imported from this same directory.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import string
import subprocess
import sys
import time

for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
            'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '2'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
GENES = ['TBXT', 'KRT8', 'KRT18', 'KRT19', 'ACAN', 'COL2A1', 'SOX9']
CAPS = {'GSM8746576_CTR': 15483, 'GSM8746577_cKO': 15346}
METHODS = ['RidgeRate', 'TotalRidge', 'XGBDirect', 'TotalXGB']
SHORT = dict(zip(METHODS, ['RR', 'TR', 'XD', 'TX']))
COLORS = dict(zip(METHODS, ['#336BA8', '#007B68', '#8050B0', '#D94B38']))
SHAPES = {'TotalRidge': 'o', 'TotalXGB': '^'}
BUDGETS = [.05, .1, .2, .5, .75, 1.]
LOCAL_TOLERANCE = 2e-12
BUDGET_TOLERANCE = 2e-13


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False,
                                    allow_nan=False) + '\n', encoding='utf8')


def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def set_cpu_affinity():
    if hasattr(os, 'sched_setaffinity'):
        os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2])
        return
    if os.name == 'nt':
        import ctypes
        library = ctypes.WinDLL('kernel32', use_last_error=True)
        library.GetCurrentProcess.restype = ctypes.c_void_p
        library.GetProcessAffinityMask.argtypes = [ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
        library.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
        available, system = ctypes.c_size_t(), ctypes.c_size_t()
        handle = library.GetCurrentProcess()
        assert library.GetProcessAffinityMask(handle, ctypes.byref(available), ctypes.byref(system))
        bits = [1 << i for i in range(64) if available.value & (1 << i)][:2]
        assert library.SetProcessAffinityMask(handle, sum(bits))


def peak_rss():
    if os.name == 'nt':
        import ctypes
        library = ctypes.WinDLL('kernel32', use_last_error=True)
        library.GetCurrentProcess.restype = ctypes.c_void_p
        class Counters(ctypes.Structure):
            _fields_ = [('cb', ctypes.c_ulong), ('PageFaultCount', ctypes.c_ulong)] + [
                (key, ctypes.c_size_t) for key in ['PeakWorkingSetSize', 'WorkingSetSize',
                'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
                'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage']]
        counters = Counters()
        counters.cb = ctypes.sizeof(counters)
        psapi = ctypes.WinDLL('psapi', use_last_error=True)
        psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.POINTER(Counters), ctypes.c_ulong]
        assert psapi.GetProcessMemoryInfo(library.GetCurrentProcess(), ctypes.byref(counters), counters.cb)
        return int(counters.PeakWorkingSetSize)
    import resource
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value if sys.platform == 'darwin' else value * 1024)


def recovery_curve(y, prediction):
    import numpy as np
    order = np.argsort(-prediction, kind='stable')
    p, yy = prediction[order], y[order]
    ends = np.r_[np.flatnonzero(np.diff(p) != 0) + 1, len(p)]
    starts = np.r_[0, ends[:-1]]
    return (np.r_[0., ends / len(p)],
            np.r_[0., np.cumsum(np.add.reduceat(yy, starts)) / y.sum()])


def threshold_budget(y, prediction, q):
    """Independent threshold calculation with exact, proportionally included ties."""
    import numpy as np
    required = q * len(y)
    if q == 1:
        return 1.
    threshold = np.sort(prediction)[::-1][int(np.floor(required))]
    high, tied = prediction > threshold, prediction == threshold
    alpha = (required - int(high.sum())) / int(tied.sum())
    return float((y[high].sum() + alpha * y[tied].sum()) / y.sum())


def spatial_js(y, prediction):
    import numpy as np
    a, b = y / y.sum(), prediction / prediction.sum()
    mid = (a + b) / 2
    def kl(values):
        keep = values > 0
        return np.sum(values[keep] * np.log(values[keep] / mid[keep]))
    return float((kl(a) + kl(b)) / 2)


def compare_tables(pd, submitted, recomputed, keys, tolerance, output):
    submitted = submitted.set_index(keys).sort_index()
    recomputed = recomputed.set_index(keys).sort_index()
    assert submitted.index.is_unique and submitted.index.equals(recomputed.index)
    assert submitted.columns.equals(recomputed.columns)
    records = []
    for col in recomputed.columns:
        if pd.api.types.is_numeric_dtype(recomputed[col]):
            for key, old, new in zip(submitted.index, submitted[col], recomputed[col]):
                error = abs(float(old) - float(new))
                records.append(dict(zip(keys, key if isinstance(key, tuple) else (key,)),
                    field=col, submitted=float(old), replay=float(new),
                    absolute_difference=error, passed=error <= tolerance))
        else:
            assert submitted[col].equals(recomputed[col]), col
    frame = pd.DataFrame(records)
    frame.to_csv(output, sep='\t', index=False)
    assert frame.passed.all(), frame.loc[~frame.passed].to_dict('records')
    return {'rows': len(submitted), 'numeric_comparisons': len(records),
            'maximum_absolute_difference': float(frame.absolute_difference.max()),
            'absolute_tolerance': tolerance, 'all_passed': True}


def worker(input_dir, output_dir):
    set_cpu_affinity()
    started = time.monotonic()
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap, Normalize
    from matplotlib.lines import Line2D
    import PIL
    import figure_style
    figure_style.configure_matplotlib(8)
    output_dir.mkdir(parents=True, exist_ok=True)
    table_dir = output_dir / 'derived_tables'
    table_dir.mkdir(exist_ok=True)
    inputs = sorted(p for p in input_dir.iterdir() if p.is_file())
    before = {p.name: sha(p) for p in inputs}
    expected = json.loads((input_dir / 'INPUT_SHA256.json').read_text(encoding='utf8'))
    assert all(before[name] == value for name, value in expected.items())
    scales = pd.read_csv(input_dir / 'Map_colour_scales_and_clipping.tsv', sep='\t', float_precision='round_trip')
    assert len(scales) == 28
    colour_max = {}
    for gene in GENES:
        limits = scales.loc[scales.gene == gene, 'colour_max'].unique()
        assert len(limits) == 1 and limits[0] >= 1
        colour_max[gene] = float(limits[0])
    data, rows, budgets, curves = {}, [], [], {}
    clipping_rows = []
    for cap, size in CAPS.items():
        frame = pd.read_csv(input_dir / f'{cap}_spatial_values.tsv.gz',
                            sep='\t', float_precision='round_trip')
        assert len(frame) == size and not frame.region_id.duplicated().any()
        assert frame.capture.eq(cap).all()
        y = frame[['measured_' + g for g in GENES]].to_numpy(dtype='float64')
        assert np.isfinite(y).all() and (y >= 0).all() and np.equal(y, np.floor(y)).all()
        prediction = {m: frame[[m + '_' + g for g in GENES]].to_numpy(dtype='float64') for m in METHODS}
        assert all(p.shape == (size, 7) and np.isfinite(p).all() and (p >= 0).all() for p in prediction.values())
        same_total_error = float(np.max(np.abs(prediction['TotalRidge'].sum(1) - prediction['TotalXGB'].sum(1))))
        assert same_total_error <= 2e-12
        xy = frame[['x_image', 'y_image']].to_numpy(dtype='float64')
        assert np.isfinite(xy).all()
        data[cap] = dict(y=y, prediction=prediction, xy=np.column_stack([xy[:, 1], -xy[:, 0]]))
        for gi, gene in enumerate(GENES):
            for method in METHODS:
                p, yy = prediction[method][:, gi], y[:, gi]
                assert yy.sum() > 0 and p.sum() > 0
                x, z = recovery_curve(yy, p)
                curves[cap, gene, method] = x, z
                values = np.interp(BUDGETS, x, z)
                assert np.max(np.abs(values - [threshold_budget(yy, p, q) for q in BUDGETS])) <= BUDGET_TOLERANCE
                rows.append(dict(capture=cap, gene=gene, method=method, regions=size,
                    measured_positive_regions=int((yy > 0).sum()), measured_count_total=float(yy.sum()),
                    predicted_count_total=float(p.sum()), spatial_mass_JS=spatial_js(yy, p),
                    measured_mass_at_10pct=float(values[1]), recovery_curve_area=float(np.trapezoid(z, x))))
                budgets.extend(dict(capture=cap, gene=gene, method=method, region_budget=q,
                    measured_mass_recovered=float(value), tie_handling='proportional') for q, value in zip(BUDGETS, values))
            for method in ['Measured', 'TotalXGB']:
                values = y[:, gi] if method == 'Measured' else prediction[method][:, gi]
                count = int((values > colour_max[gene]).sum())
                old = scales.loc[(scales.capture == cap) & (scales.gene == gene) & (scales.method == method)]
                assert len(old) == 1 and count == int(old.iloc[0].clipped)
                clipping_rows.append(dict(capture=cap, gene=gene, method=method,
                    colour_max=colour_max[gene], clipped=count, regions=size))
    result, budget_frame = pd.DataFrame(rows), pd.DataFrame(budgets)
    assert len(result) == 56 and len(budget_frame) == 336
    result.to_csv(table_dir / 'Spatial_localization_all_members.tsv', sep='\t', index=False)
    budget_frame.to_csv(table_dir / 'Fixed_budget_recovery.tsv', sep='\t', index=False)
    local_audit = compare_tables(pd,
        pd.read_csv(input_dir / 'Spatial_localization_all_members.tsv', sep='\t', float_precision='round_trip'),
        result, ['capture', 'gene', 'method'], LOCAL_TOLERANCE, table_dir / 'LOCALIZATION_NUMERIC_COMPARISONS.tsv')
    budget_audit = compare_tables(pd,
        pd.read_csv(input_dir / 'Fixed_budget_recovery.tsv', sep='\t', float_precision='round_trip'),
        budget_frame, ['capture', 'gene', 'method', 'region_budget'], BUDGET_TOLERANCE,
        table_dir / 'BUDGET_NUMERIC_COMPARISONS.tsv')
    toy = np.array([1., 3., 2., 4.])
    assert spatial_js(toy, toy) == 0
    xx, zz = recovery_curve(toy, np.ones(4))
    assert np.array_equal(xx, [0., 1.]) and np.array_equal(zz, [0., 1.])
    assert abs(threshold_budget(toy, np.ones(4), .1) - .1) < 1e-15
    assert abs(spatial_js(np.array([1., 0.]), np.array([0., 1.])) - np.log(2)) < 1e-15

    def newfig():
        return plt.figure(figsize=(183 / 25.4, 220 / 25.4), facecolor='white')
    def ax_mm(fig, x, y, w, h):
        return fig.add_axes([x / 183, 1 - (y + h) / 220, w / 183, h / 220])
    def text_mm(fig, x, y, text, **kw):
        return fig.text(x / 183, 1 - y / 220, text, **kw)
    outputs = []
    def save(fig, number):
        assert all(text.get_fontsize() >= 7 for text in fig.findobj(matplotlib.text.Text) if text.get_text())
        paths = figure_style.save_figure(fig, output_dir / f'SupplementaryFigure{number}', journal_page=True)
        outputs.extend({'path': p.relative_to(output_dir).as_posix(), 'sha256': sha(p),
                        'bytes': p.stat().st_size} for p in paths)
        plt.close(fig)

    cmap = LinearSegmentedColormap.from_list('counts', ['#EEEEEF', '#33427D', '#237C96', '#39BA7A', '#D5E64C'], N=256)
    for ci, cap in enumerate(CAPS):
        fig, d = newfig(), data[cap]
        for gi, gene in enumerate(GENES):
            top, left = 10 + (gi // 2) * 49, 10 + (gi % 2) * 87
            text_mm(fig, left + 37, top + 1, gene, fontsize=8, va='center', ha='center')
            norm = Normalize(0, np.log1p(colour_max[gene]))
            for mi, method in enumerate(['Measured', 'TotalXGB']):
                xleft = left + mi * 40
                ax = ax_mm(fig, xleft, top + 6, 35, 35)
                values = d['y'][:, gi] if method == 'Measured' else d['prediction'][method][:, gi]
                scatter = ax.scatter(d['xy'][:, 0], d['xy'][:, 1], c=np.log1p(values), cmap=cmap,
                    norm=norm, s=.45, linewidths=0, rasterized=True)
                xx, yy = d['xy'].T
                ax.set_xlim(xx.min() - 5, xx.max() + 5)
                ax.set_ylim(yy.min() - 5, yy.max() + 5)
                ax.set_aspect('equal')
                ax.axis('off')
                text_mm(fig, xleft - 4, top + 6, string.ascii_uppercase[gi * 2 + mi], fontsize=8, fontweight='bold')
                text_mm(fig, xleft + 17, top + 4, 'M' if method == 'Measured' else 'TX', fontsize=7, ha='center')
            color_ax = ax_mm(fig, left + 24, top + 42, 29, 1.1)
            cb = fig.colorbar(scatter, cax=color_ax, orientation='horizontal')
            cb.set_ticks([0, np.log1p(colour_max[gene])])
            cb.set_ticklabels(['0', f'{colour_max[gene]:.2g}'])
            cb.ax.tick_params(labelsize=7, pad=1, length=1)
        text_mm(fig, 96, 161, 'O', fontsize=8, fontweight='bold')
        ax = ax_mm(fig, 106, 171, 24, 29)
        block = result[result.capture == cap].pivot(index='gene', columns='method', values='spatial_mass_JS').reindex(index=GENES)
        for j, gene in enumerate(GENES):
            values = block.loc[gene, ['TotalRidge', 'TotalXGB']].to_numpy(float)
            ax.plot(values, [j, j], color='#AAAAAA', lw=.7)
            for k, method in enumerate(['TotalRidge', 'TotalXGB']):
                ax.scatter(values[k], j, s=11, color=COLORS[method], marker=SHAPES[method], linewidths=0)
        ax.set_yticks(range(7))
        ax.set_yticklabels(GENES, fontsize=7)
        ax.invert_yaxis()
        ax.set_xlim(0, np.log(2))
        ax.set_xticks([0, .69])
        ax.set_xlabel('Mass JS', labelpad=1)
        text_mm(fig, 139, 161, 'P', fontsize=8, fontweight='bold')
        ax = ax_mm(fig, 146, 171, 28, 29)
        block = result[result.capture == cap].pivot(index='gene', columns='method', values='measured_mass_at_10pct').reindex(index=GENES, columns=METHODS)
        image = ax.imshow(block, aspect='auto', cmap='magma', vmin=0, vmax=1)
        ax.set_yticks([])
        ax.set_xticks(range(4))
        ax.set_xticklabels(['RR', 'TR', 'XD', 'TX'], rotation=90, fontsize=7)
        ax.tick_params(length=0, pad=1)
        color_ax = ax_mm(fig, 147, 168, 27, 1)
        cb = fig.colorbar(image, cax=color_ax, orientation='horizontal')
        cb.set_ticks([0, 1])
        cb.ax.tick_params(labelsize=7, pad=1, length=1)
        cb.ax.xaxis.set_ticks_position('top')
        text_mm(fig, 147, 162, 'Count mass, 10% budget', fontsize=7)
        legend_ax = ax_mm(fig, 100, 207, 70, 6)
        legend_ax.axis('off')
        legend_ax.legend(handles=[Line2D([], [], color=COLORS[m], marker=SHAPES[m],
            markersize=3, label=SHORT[m]) for m in ['TotalRidge', 'TotalXGB']],
            loc='center', ncol=2, handlelength=1, columnspacing=1)
        text_mm(fig, 10, 214, 'M measured counts; TX predicted means. Shared per-gene count scales.', fontsize=7)
        save(fig, 9 + ci)

    fig = newfig()
    positions = [(14, 8), (73, 8), (132, 8), (14, 54), (73, 54), (132, 54), (14, 100)]
    for gi, (gene, (left, top)) in enumerate(zip(GENES, positions)):
        ax = ax_mm(fig, left, top + 3, 41, 31)
        ax.plot([0, 1], [0, 1], color='#999999', lw=.7, ls=':')
        for ci, cap in enumerate(CAPS):
            for method in ['TotalRidge', 'TotalXGB']:
                x, z = curves[cap, gene, method]
                ax.plot(x, z, color=COLORS[method], lw=1, ls='-' if ci == 0 else '--')
                marker_budgets = [.1, .5, .75]
                ax.scatter(marker_budgets, np.interp(marker_budgets, x, z), marker=SHAPES[method],
                    s=7, facecolors='none' if ci else COLORS[method], edgecolors=COLORS[method], linewidths=.5)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xticks([0, .5, 1])
        ax.set_yticks([0, .5, 1])
        ax.set_xlabel('Regions prioritized', labelpad=1)
        ax.set_ylabel('Count mass recovered', labelpad=1)
        text_mm(fig, left - 7, top, string.ascii_uppercase[gi], fontsize=9, fontweight='bold')
        text_mm(fig, left + 20.5, top + 1, gene, fontsize=8, ha='center')
    legend_ax = ax_mm(fig, 73, 109, 95, 19)
    legend_ax.axis('off')
    legend_ax.legend(handles=[Line2D([], [], color=COLORS[m], marker=SHAPES[m],
        markersize=3, label=SHORT[m] + ' ' + m) for m in ['TotalRidge', 'TotalXGB']] + [
        Line2D([], [], color='black', ls='-', label='CTR'),
        Line2D([], [], color='black', ls='--', label='cKO')],
        loc='center', ncol=2, handlelength=2, columnspacing=1)
    for kind, top, start, vmax, label in [
        ('spatial_mass_JS', 151, 7, np.log(2), 'Spatial-mass JS (nats)'),
        ('measured_mass_at_10pct', 185, 9, 1., 'Count mass at 10% regions')]:
        for ci, cap in enumerate(CAPS):
            ax = ax_mm(fig, 21 + ci * 81, top, 57, 21)
            block = result[result.capture == cap].pivot(index='gene', columns='method', values=kind).reindex(index=GENES, columns=METHODS)
            image = ax.imshow(block.T, aspect='auto', cmap='viridis' if start == 7 else 'magma', vmin=0, vmax=vmax)
            ax.set_xticks(range(7))
            ax.set_xticklabels(GENES, rotation=35, ha='right', fontsize=7)
            ax.set_yticks(range(4))
            ax.set_yticklabels(['RR', 'TR', 'XD', 'TX'], fontsize=7)
            ax.tick_params(length=0, pad=1)
            text_mm(fig, 7 + ci * 81, top - 2, string.ascii_uppercase[start + ci], fontsize=9, fontweight='bold')
            text_mm(fig, 49 + ci * 81, top - 1, cap.split('_')[-1], fontsize=7, ha='center')
        color_ax = ax_mm(fig, 166, top + 1, 2, 17)
        cb = fig.colorbar(image, cax=color_ax)
        cb.set_ticks([0, vmax])
        cb.set_ticklabels(['0', f'{vmax:.2g}'])
        cb.ax.tick_params(labelsize=7, length=1, pad=1)
        cb.set_label(label, fontsize=7, labelpad=1)
    save(fig, 11)
    assert before == {p.name: sha(p) for p in inputs}, 'Input changed during replay'
    elapsed, memory = time.monotonic() - started, peak_rss()
    output_bytes = sum(p.stat().st_size for p in output_dir.rglob('*') if p.is_file())
    assert elapsed < 900 and memory < 4 * 1024**3 and output_bytes < 300 * 1024**2
    receipt = dict(status='NUMERIC_REPLAY_PASS_VISUAL_REVIEW_PENDING', regions=30829,
        captures=CAPS, members=GENES, methods=METHODS, localization_rows=56, budget_rows=336,
        panels={'SupplementaryFigure9': 16, 'SupplementaryFigure10': 16, 'SupplementaryFigure11': 11},
        localization_audit=local_audit, budget_audit=budget_audit,
        input_sha256=before, all_input_bytes_unchanged=True,
        input_read_scope='Only packaged released full spatial-value tables, frozen limits and small source tables',
        numeric_parse='pandas float_precision=round_trip to full float64',
        original_NPZ_reads=0, raw_matrix_reads=0, model_weight_reads=0, sealed_data_reads=0,
        new_fits=0, new_expression_sources=0, code_style_helper='figure_style.py (relative import)',
        figure_dimensions_mm=[183, 220], minimum_text_font_pt=7, journal_page=True,
        primary_metric_changed=False, region_or_member_filtering=False,
        method_colours=COLORS, method_shapes=SHAPES,
        count_mass_definition='Proportion of released measured gene-feature counts; released events may include RNA/gDNA',
        runtime_versions={'python': sys.version.split()[0], 'numpy': np.__version__, 'pandas': pd.__version__,
                          'matplotlib': matplotlib.__version__, 'Pillow': PIL.__version__},
        resource_limits={'CPU_cores': 2, 'peak_RSS_GiB': 4, 'wall_seconds': 900, 'output_MiB': 300},
        elapsed_seconds=elapsed, peak_process_RSS_bytes=memory, output_bytes=output_bytes,
        outputs=outputs, completed_utc=utc_now())
    write_json(output_dir / 'REPLAY_RECEIPT.json', receipt)
    print(json.dumps({key: receipt[key] for key in ['status', 'regions', 'localization_rows',
          'budget_rows', 'elapsed_seconds', 'peak_process_RSS_bytes', 'output_bytes']}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=HERE / 'inputs')
    parser.add_argument('--output-dir', type=Path, default=HERE / 'output')
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        worker(args.input_dir.resolve(), args.output_dir.resolve())
        return 0
    args.output_dir.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    command = [sys.executable, '-B', str(Path(__file__).resolve()), '--worker',
               '--input-dir', str(args.input_dir.resolve()), '--output-dir', str(args.output_dir.resolve())]
    process = subprocess.run(command, cwd=HERE, capture_output=True, text=True,
                             encoding='utf8', errors='replace', timeout=900)
    (args.output_dir / 'STDOUT.log').write_text(process.stdout, encoding='utf8')
    (args.output_dir / 'STDERR.log').write_text(process.stderr, encoding='utf8')
    write_json(args.output_dir / 'ACTUAL_EXIT_RECEIPT.json', dict(
        status='ACTUAL_WORKER_EXIT_ZERO' if process.returncode == 0 else 'ACTUAL_WORKER_EXIT_NONZERO',
        actual_process_returncode=process.returncode, elapsed_seconds=time.monotonic() - started,
        script_sha256=sha(Path(__file__)), style_helper_sha256=sha(HERE / 'figure_style.py'),
        invocation='python -B run_replay.py --input-dir inputs --output-dir output',
        path_resolution='Relative bundle inputs and style; no historical workspace dependency',
        stdout_sha256=sha(args.output_dir / 'STDOUT.log'), stderr_sha256=sha(args.output_dir / 'STDERR.log'),
        completed_utc=utc_now()))
    print(process.stdout.rstrip())
    if process.stderr:
        print(process.stderr.rstrip(), file=sys.stderr)
    return process.returncode


if __name__ == '__main__':
    sys.exit(main())
