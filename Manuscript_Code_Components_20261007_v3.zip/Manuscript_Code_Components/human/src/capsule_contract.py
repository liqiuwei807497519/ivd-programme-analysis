"""New public prepared-count boundary; immutable submitted capsule identity."""
import hashlib
import json
from pathlib import Path
import numpy as np

CAPSULE_SHA = "f5a0791ae1033c20ba129ab2c6d1d6865ef27247562e7e12a1baf103d0892f94"
META_SHA = "b52c60d0acbfc286ca1de3febd8dde69d5edeb3c062ea540f97a2a7eca3d5ec5"
CORE_SHA = "515f3d6cf382327717dfcd9691e962bc487a61a1976659ea79dcdc8e4a19b368"
STATISTICS_SHA = "1238098edba5a9f7f234e60c6364c43286ac03065822ccb48373b84c8b3782bd"
COUNT_KEYS = ("counts", "genes", "samples", "groups", "layers")
ALL_KEYS = set(COUNT_KEYS) | {"log2_cpm_all", "z_natural", "natural_indices", "cultured_indices", "available_natural"}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(capsule, metadata):
    capsule, metadata = Path(capsule).resolve(), Path(metadata).resolve()
    if sha(capsule) != CAPSULE_SHA:
        raise ValueError("Complete submitted count capsule SHA differs; filtered or changed inputs are rejected")
    if sha(metadata) != META_SHA:
        raise ValueError("Submitted historical metadata SHA differs")
    with np.load(capsule, allow_pickle=False) as source:
        if set(source.files) != ALL_KEYS:
            raise ValueError("Complete ten-array capsule schema differs")
        arrays = {key: source[key].copy() for key in COUNT_KEYS}
    if arrays["counts"].shape != (9, 36591) or arrays["counts"].dtype != np.float64:
        raise ValueError("Complete nine-sample, 36591-gene denominator differs")
    return arrays, json.loads(metadata.read_text(encoding="utf8"))
