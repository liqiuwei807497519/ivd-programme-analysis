"""Nested parent-held-out source RNA mean fitting; held-out Y files are excluded."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys

for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "2"

import numpy as np
from rna_mean import fit_bundle, predict_bundle
from rna_score import poisson_deviance

METHODS = ("AnchorRate", "memberRidge", "memberPoisson", "sourceTotal_fixedComposition", "sourceTotal_learnedComposition")
GROUPS = ("Control", "Day_1", "Day_3", "Day_28")
GRIDS = {"member_ridge_L2": [0.01, 0.1, 1.0], "count_Poisson_L2": [0.0001, 0.01, 1.0], "composition_L2": [0.001, 0.1, 10.0]}


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def readj(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def writej(path, value):
    with Path(path).open("x", encoding="utf8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def record(path):
    return {"path": str(Path(path).resolve()), "sha256": sha(path)}


def verified(records):
    values = {}
    for item in records:
        path = Path(item["path"]).resolve()
        if sha(path) != item["sha256"]:
            raise ValueError("fold immutable binding changed: " + str(path))
        values[str(path)] = item["sha256"]
    return values


def install_guard(allowed, output):
    allowed = {str(Path(path).resolve()).casefold() for path in allowed}
    output = Path(output).resolve()
    runtime = [Path(sys.prefix).resolve(), Path(sys.base_prefix).resolve(), Path(np.__file__).resolve().parents[1]]
    reads, denied = [], []

    def audit(event, args):
        if event != "open" or isinstance(args[0], int):
            return
        path = Path(os.fsdecode(args[0])).resolve()
        mode, flags = args[1] or "", args[2] or 0
        writing = any(letter in mode for letter in "wax+") or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC))
        in_output = path == output or output in path.parents
        permitted = in_output if writing else (in_output or str(path).casefold() in allowed or any(prefix == path or prefix in path.parents for prefix in runtime))
        if not permitted:
            denied.append({"path": str(path), "writing": writing})
            raise PermissionError("outer-fold source response/input guard denied: " + str(path))
        if not writing:
            reads.append(str(path))

    sys.addaudithook(audit)
    return reads, denied


def aggregate(values, inverse, count):
    values = np.asarray(values)
    if values.dtype.kind in "iu" and any(sum(int(value) for value in values[:, gene]) > np.iinfo(np.int64).max for gene in range(values.shape[1])):
        raise ValueError("ROI truth sum cannot be represented exactly in int64")
    result = np.zeros((count, values.shape[1]), dtype=values.dtype)
    np.add.at(result, inverse, values)
    return result


def train_arrays(sections, parents):
    selected = [item for item in sections if item["parent"] in parents]
    x, y, weights = [], [], []
    for parent in parents:
        within = [item for item in selected if item["parent"] == parent]
        for item in within:
            x.append(item["x_counts"])
            y.append(item["y_counts"])
            weights.extend([1.0 / len(parents) / len(within) / len(item["region_id"])] * len(item["region_id"]))
    return {"x_counts": np.concatenate(x), "y_counts": np.concatenate(y)}, np.asarray(weights)


def reference_scales(sections, parents):
    parent_means, parent_totals = [], []
    for parent in parents:
        within = [item for item in sections if item["parent"] == parent]
        means, totals = [], []
        for item in within:
            y_roi = aggregate(item["y_counts"], item["roi_indices"], len(item["roi_keys"]))
            means.append(np.mean(y_roi, axis=0))
            totals.append(float(np.mean([sum(int(value) for value in row) for row in y_roi])))
        parent_means.append(np.mean(means, axis=0))
        parent_totals.append(float(np.mean(totals)))
    return np.maximum(1.0, np.mean(parent_means, axis=0)), max(1.0, float(np.mean(parent_totals)))


def loss_record(value):
    if math.isfinite(value):
        return {"status": "FINITE", "value": float(value), "extended_value": None}
    if value == math.inf:
        return {"status": "INFINITE", "value": None, "extended_value": "+infinity"}
    raise ValueError("loss is undefined rather than a declared infinite zero-mean limit")


def choose(records):
    valid = [row for row in records if row["candidate_status"] != "FIT_FAILED"]
    if not valid:
        raise ValueError("ALL_FITS_FAILED_BLOCKED: no valid inner-fit candidate defines a selected penalty")
    finite = [row for row in valid if row["loss"]["status"] == "FINITE"]
    if not finite:
        return max(row["penalty"] for row in valid), "ALL_INFINITE_LOSS_LARGEST_PENALTY_FALLBACK_NOT_WINNER"
    best = min(row["loss"]["value"] for row in finite)
    tolerance = 1e-10 * max(1.0, abs(best))
    tied = [row["penalty"] for row in finite if abs(row["loss"]["value"] - best) <= tolerance]
    return max(tied), "FINITE_INNER_SELECTION_LARGEST_TIED_PENALTY"


def evaluation_loss(bundle, evaluation, scales7, scale_total, endpoint, all_zero_training):
    sections = []
    positive_rows, zero_total_rows = 0, 0
    for item in evaluation:
        means = predict_bundle(bundle, item["x_counts"])
        y = aggregate(item["y_counts"], item["roi_indices"], len(item["roi_keys"]))
        mu = aggregate(means, item["roi_indices"], len(item["roi_keys"]))
        if endpoint == "members":
            value = float(np.mean(poisson_deviance(y, mu) / scales7[None, :]))
        elif endpoint == "total":
            truth_total = np.asarray([sum(int(v) for v in row) for row in y], dtype=np.int64)
            value = float(np.mean(poisson_deviance(truth_total, mu.sum(axis=1)) / scale_total))
        else:
            totals = np.asarray([sum(int(v) for v in row) for row in y], dtype=np.int64)
            positive = totals > 0
            positive_rows += int(positive.sum())
            zero_total_rows += int((~positive).sum())
            if not np.any(positive):
                sections.append(None)
                continue
            probability = np.full(mu[positive].shape, 1.0 / 7.0) if all_zero_training else np.divide(mu[positive], mu[positive].sum(axis=1, keepdims=True), out=np.zeros_like(mu[positive]), where=mu[positive].sum(axis=1, keepdims=True) > 0)
            fractions = y[positive] / totals[positive, None]
            terms = np.zeros_like(fractions, dtype=float)
            observed = fractions > 0
            if np.any(probability[observed] == 0):
                value = math.inf
            else:
                terms[observed] = -fractions[observed] * np.log(probability[observed])
                value = float(np.mean(terms.sum(axis=1)))
        sections.append(value)
    nonempty = [value for value in sections if value is not None]
    # An all-zero validation programme has no composition information, explicitly.
    value = float(np.mean(nonempty)) if nonempty else 0.0
    return value, {"section_losses": [None if value is None else loss_record(value) for value in sections],
                   "positive_composition_ROIs": positive_rows, "zero_total_composition_ROIs": zero_total_rows,
                   "no_positive_composition_information": endpoint == "composition" and not nonempty}


def run(config, prepared, holdout_parent, fresh_output):
    config_path, prepared, output = Path(config).resolve(), Path(prepared).resolve(), Path(fresh_output).resolve()
    specification = readj(config_path)
    if output.exists() or holdout_parent not in GROUPS or tuple(specification["outer_groups"]) != GROUPS:
        raise ValueError("RNA fold requires a fixed parent and fresh output")
    if specification["selection_grid"] != GRIDS:
        raise ValueError("fixed source-only penalty grids cannot change")
    if specification["mode"] not in ("AUTHORIZED_SOURCE_ONLY_RNA_MEAN", "SYNTHETIC_SOURCE_ONLY_RNA_MEAN"):
        raise ValueError("invalid RNA fold mode")
    config_hash = sha(config_path)
    prepare_path = prepared / "PREPARE_COMMIT.json"
    commit = readj(prepare_path)
    if commit["status"] != "RNA_INPUTS_PREPARED" or commit["config_sha256"] != config_hash or commit["ordered_roles"] != specification["ordered_roles"]:
        raise ValueError("prepared source/config/role identity mismatch")
    training = [parent for parent in GROUPS if parent != holdout_parent]
    bindings = list(specification["code_binding"]) + [specification["plan_binding"], specification["authorization_binding"], record(prepare_path)]
    heldout_label_paths = []
    for item in specification["sections"]:
        capsule = commit["sections"][item["section_folder"]]
        if capsule["parent"] != item["parent"] or capsule["section_id"] != item["section_id"]:
            raise ValueError("prepared section/parent identity drift")
        bindings.append(capsule["artifacts"]["INPUTS.npz"])
        if item["parent"] in training:
            bindings.append(capsule["artifacts"]["SOURCE_LABELS.npz"])
        else:
            heldout_label_paths.append(capsule["artifacts"]["SOURCE_LABELS.npz"]["path"])
    reads, denied = install_guard([config_path, *[item["path"] for item in bindings]], output)
    for path in heldout_label_paths:
        try:
            with Path(path).open("rb"):
                pass
        except PermissionError:
            pass
        else:
            raise ValueError("heldout response guard did not deny its read probe")
    before = verified(bindings)
    sections = []
    for item in specification["sections"]:
        capsule = commit["sections"][item["section_folder"]]
        with np.load(capsule["artifacts"]["INPUTS.npz"]["path"], allow_pickle=False) as archive:
            if set(archive.files) != {"x_counts", "region_id", "barcode", "coords_um", "roi_indices", "roi_keys"}:
                raise ValueError("prepared input capsule must be X-only")
            data = {name: archive[name] for name in archive.files}
        if data["x_counts"].shape != (item["expected_rows"], 126) or len(set(data["region_id"].tolist())) != item["expected_rows"]:
            raise ValueError("fold must retain complete section support")
        if item["parent"] in training:
            with np.load(capsule["artifacts"]["SOURCE_LABELS.npz"]["path"], allow_pickle=False) as archive:
                if not np.array_equal(archive["region_id"], data["region_id"]) or not np.array_equal(archive["barcode"], data["barcode"]):
                    raise ValueError("training source labels/input ID join differs")
                data["y_counts"] = archive["y_counts"]
        sections.append({**data, "parent": item["parent"], "section_folder": item["section_folder"], "section_id": item["section_id"]})
    output.mkdir(parents=True, exist_ok=False)
    selection = {}

    def select(name, method, grid, endpoint, total_penalty=None):
        records = []
        for penalty in grid:
            inner_records, losses, failure = [], [], False
            for inner_holdout in training:
                fit_parents = [parent for parent in training if parent != inner_holdout]
                arrays, weights = train_arrays(sections, fit_parents)
                scales7, total_scale = reference_scales(sections, fit_parents)
                penalties = {"member_ridge_L2": penalty, "count_Poisson_L2": penalty if total_penalty is None else total_penalty, "composition_L2": penalty}
                entry = {"validation_parent": inner_holdout, "fit_parents": fit_parents, "source_scales7": scales7.tolist(), "source_scale_total": total_scale}
                try:
                    if method == "sourceTotal_learnedComposition":
                        penalties["shared_total_bundle"] = fit_bundle(arrays, weights, "sourceTotal_fixedComposition", penalties)
                    bundle = fit_bundle(arrays, weights, method, penalties)
                    loss, detail = evaluation_loss(bundle, [item for item in sections if item["parent"] == inner_holdout], scales7, total_scale, endpoint, not np.any(arrays["y_counts"] > 0))
                    entry.update({"fit_status": "FIT_COMPLETE", "loss": loss_record(loss), "diagnostics": bundle["diagnostics"], **detail})
                    losses.append(loss)
                except ValueError as error:
                    failure = True
                    entry.update({"fit_status": "FIT_FAILED", "reason": str(error), "loss": {"status": "FIT_FAILED", "value": None, "extended_value": None}})
                inner_records.append(entry)
            candidate_loss = math.inf if failure else float(np.mean(losses))
            records.append({"penalty": penalty, "candidate_status": "FIT_FAILED" if failure else "FIT_COMPLETE", "loss": loss_record(candidate_loss), "inner_folds": inner_records})
        try:
            chosen, status = choose(records)
        except ValueError:
            selection[name] = {"grid": grid, "chosen_penalty": None, "selection_status": "ALL_FITS_FAILED_BLOCKED",
                               "endpoint": endpoint, "candidates": records, "tie_tolerance": "1e-10*max(1,abs(best))"}
            writej(output / ("SELECTION_" + name + ".json"), selection[name])
            raise
        selection[name] = {"grid": grid, "chosen_penalty": chosen, "selection_status": status, "endpoint": endpoint, "candidates": records,
                           "tie_tolerance": "1e-10*max(1,abs(best)); choose largest penalty"}
        writej(output / ("SELECTION_" + name + ".json"), selection[name])
        return chosen

    ridge = select("memberRidge", "memberRidge", GRIDS["member_ridge_L2"], "members")
    poisson = select("memberPoisson", "memberPoisson", GRIDS["count_Poisson_L2"], "members")
    total = select("sourceTotal", "sourceTotal_fixedComposition", GRIDS["count_Poisson_L2"], "total")
    composition = select("learnedComposition", "sourceTotal_learnedComposition", GRIDS["composition_L2"], "composition", total)
    arrays, weights = train_arrays(sections, training)
    scales7, total_scale = reference_scales(sections, training)
    penalties = {"member_ridge_L2": ridge, "count_Poisson_L2": poisson, "composition_L2": composition}
    bundles = {method: fit_bundle(arrays, weights, method, penalties) for method in METHODS[:3]}
    fixed_penalty = {**penalties, "count_Poisson_L2": total}
    bundles[METHODS[3]] = fit_bundle(arrays, weights, METHODS[3], fixed_penalty)
    bundles[METHODS[4]] = fit_bundle(arrays, weights, METHODS[4], {**fixed_penalty, "shared_total_bundle": bundles[METHODS[3]]})
    evaluation = [item for item in sections if item["parent"] == holdout_parent]
    native = {"region_id": np.concatenate([item["region_id"] for item in evaluation]), "barcode": np.concatenate([item["barcode"] for item in evaluation]),
              "section_id": np.concatenate([[item["section_folder"]] * len(item["region_id"]) for item in evaluation]),
              "parent_id": np.array([holdout_parent] * sum(len(item["region_id"]) for item in evaluation))}
    rois = {"roi_section_id": np.concatenate([[item["section_folder"]] * len(item["roi_keys"]) for item in evaluation]), "roi_keys": np.concatenate([item["roi_keys"] for item in evaluation])}
    for method in METHODS:
        values = [predict_bundle(bundles[method], item["x_counts"]) for item in evaluation]
        native[method] = np.concatenate(values)
        rois[method] = np.concatenate([aggregate(value, item["roi_indices"], len(item["roi_keys"])) for item, value in zip(evaluation, values)])
    if not np.allclose(native[METHODS[3]].sum(axis=1), native[METHODS[4]].sum(axis=1), rtol=1e-12, atol=1e-12):
        raise ValueError("paired sourceTotal forecasts do not share identical totals")
    np.savez_compressed(output / "NATIVE_MEANS.npz", **native)
    np.savez_compressed(output / "ROI_MEANS.npz", **rois)
    params = {"training_parents": training, "training_sections": [item["section_folder"] for item in sections if item["parent"] in training],
              "source_scales7": scales7.tolist(), "source_scale_total": total_scale, "scale_definition": "max1 training ROI count means: equalROI/section, equal2sections/parent, equaltrainingparents",
              "bundles": bundles, "selected_penalties": {"member_ridge_L2": ridge, "member_Poisson_L2": poisson, "total_Poisson_L2": total, "composition_L2": composition},
              "ordered_roles": specification["ordered_roles"], "heldout_response_reads": 0}
    writej(output / "FOLD_PARAMS.json", params)
    writej(output / "SELECTION.json", selection)
    after = verified(bindings)
    if before != after or sha(config_path) != config_hash:
        raise ValueError("fold source/config/code changed")
    artifacts = {name: record(output / name) for name in ("NATIVE_MEANS.npz", "ROI_MEANS.npz", "FOLD_PARAMS.json", "SELECTION.json")}
    result = {"status": "RNA_OUTER_FORECAST_COMMITTED", "holdout_parent": holdout_parent, "mode": specification["mode"], "config_sha256": config_hash,
              "prepared_commit_sha256": sha(prepare_path), "training_parents": training, "eval_sections": [item["section_folder"] for item in evaluation],
              "observations": len(native["region_id"]), "regions": len(rois["roi_keys"]), "methods": list(METHODS), "source_scales7": scales7.tolist(),
              "source_scale_total": total_scale, "artifacts": artifacts, "bindings_before": before, "bindings_after": after,
              "heldout_response_reads": 0, "read_audit": {"scope": "fresh CLI Python open guard; not an OS sandbox", "read_paths": sorted(set(reads)), "denied_paths": denied},
              "all_spots_and_seven_members_retained": True, "phenotype_time_partition_predictors": False}
    writej(output / "FORECAST_COMMIT.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--prepared", required=True)
    parser.add_argument("--holdout-parent", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        result = run(args.config, args.prepared, args.holdout_parent, args.output)
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({"status": "RNA_FOLD_BLOCKED", "reason": str(error)}), flush=True)
        sys.exit(2)
    print(json.dumps({"status": result["status"], "holdout_parent": result["holdout_parent"], "observations": result["observations"]}), flush=True)
