"""Behavior checks for the portable interface and analytic zero-count rules."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import tempfile
import unittest
import numpy as np
from baseline_core import fit_predict, ContractError
from count_cli import replay, load_inputs
from count_metrics import reconcile_to_total, poisson_deviance, raw_deviance_decomposition


class PortableTests(unittest.TestCase):
    def setUp(self):
        self.x = np.ones((24, 126), dtype=np.int64)
        self.y = np.tile(np.arange(2, 9, dtype=np.int64), (24, 1))

    def test_known_constant_and_replay(self):
        result = fit_predict(self.x, self.y, self.x[:5])
        replayed, total, diagnostics = replay(result['models'], self.x[:5])
        for method, mu in replayed.items():
            np.testing.assert_allclose(mu, result['predictions'][method], rtol=1e-12, atol=1e-12)
            np.testing.assert_allclose(mu, self.y[:5], rtol=1e-10, atol=1e-10)
        np.testing.assert_allclose(total, self.y[:5].sum(axis=1), rtol=1e-10)
        self.assertEqual(diagnostics['prediction_repairs'], 0)

    def test_zero_training_member_stops(self):
        self.y[:, 0] = 0
        with self.assertRaises(ContractError):
            fit_predict(self.x, self.y, self.x[:5])

    def test_noninteger_input_stops(self):
        x = self.x.astype(float)
        x[0, 0] = 0.5
        with self.assertRaises(ContractError):
            fit_predict(x, self.y, self.x[:5])

    def test_fixed_alpha(self):
        with self.assertRaises(ContractError):
            fit_predict(self.x, self.y, self.x[:5], ridge_alpha=0.1)

    def test_evaluation_target_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'input.npz'
            np.savez(path, region_id=np.arange(24), x_counts=self.x, y_counts=self.y)
            with self.assertRaises(ContractError):
                load_inputs(path)

    def test_existing_reconciliation(self):
        mu = np.array([[1., 2., 3., 4., 5., 6., 7.]])
        result = reconcile_to_total(mu, np.array([56.]))
        np.testing.assert_allclose(result, 2 * mu, rtol=0, atol=1e-14)
        np.testing.assert_allclose(result.sum(axis=1), [56.])

    def test_zero_observation_deviance(self):
        mu = np.array([[1., 2., 3., 4., 5., 6., 7.]])
        np.testing.assert_array_equal(poisson_deviance(np.zeros_like(mu), mu), 2 * mu)

    def test_raw_deviance_identity(self):
        y = np.array([[0, 0, 0, 0, 0, 0, 0], [3, 0, 5, 1, 0, 2, 7]])
        mu = np.array([[1., 2., 3., 4., 5., 6., 7.], [2., 3., 4., 5., 6., 7., 8.]])
        d = raw_deviance_decomposition(y, mu)
        np.testing.assert_allclose(d['member_raw_deviance'],
                                   d['total_raw_deviance'] + d['allocation_raw_deviance'],
                                   rtol=1e-13, atol=1e-12)
        self.assertEqual(d['allocation_raw_deviance'][0], 0)


if __name__ == '__main__':
    unittest.main()
