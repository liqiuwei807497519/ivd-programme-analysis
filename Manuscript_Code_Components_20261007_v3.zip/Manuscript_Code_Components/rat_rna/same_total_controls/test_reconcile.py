"""Public no-fit reconciliation seam: worked literal examples only."""
import unittest
import numpy as np


class ReconcileTests(unittest.TestCase):
    def test_zero_member_denominator_uses_saved_training_composition_without_epsilon(self):
        from reconcile_controls import reconcile_means
        values, receipt = reconcile_means([[0, 0, 0, 0]], [10], [0.1, 0.2, 0.3, 0.4])
        np.testing.assert_array_equal(values, [[1, 2, 3, 4]])
        self.assertEqual(receipt["zero_denominator_fallback_rows"], 1)
        self.assertFalse(receipt["epsilon_or_pseudocount"])

    def test_zero_frozen_total_returns_all_zero_members(self):
        from reconcile_controls import reconcile_means
        values, receipt = reconcile_means([[1, 3], [0, 0]], [0, 0], [0.25, 0.75])
        np.testing.assert_array_equal(values, [[0, 0], [0, 0]])
        self.assertEqual(receipt["zero_total_rows"], 2)
        self.assertEqual(receipt["zero_denominator_fallback_rows"], 0)

    def test_literal_two_member_ratio_one_to_three_under_total_eight(self):
        from reconcile_controls import reconcile_means
        values, receipt = reconcile_means([[1, 3]], [8], [0.25, 0.75])
        np.testing.assert_array_equal(values, [[2, 6]])
        self.assertEqual(receipt["zero_denominator_fallback_rows"], 0)


if __name__ == "__main__":
    unittest.main()
