"""Transparent source-only RNA point means; caller arrays only, no file I/O."""

import hashlib
import json
import copy

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp

METHODS = ("AnchorRate", "memberRidge", "memberPoisson", "sourceTotal_fixedComposition", "sourceTotal_learnedComposition")


def _counts(value, columns, label):
    array = np.asarray(value)
    if (array.ndim != 2 or array.shape[1] != columns or len(array) == 0 or array.dtype.kind not in "iuf"
            or not np.isfinite(array).all() or np.any(array < 0) or np.any(array != np.trunc(array))):
        raise ValueError(label + " must be nonempty exact nonnegative integer-valued counts with " + str(columns) + " columns")
    return array.astype(float)


def _penalty(penalties, name):
    try:
        value = float(penalties[name])
    except (KeyError, TypeError, ValueError):
        raise ValueError("Missing or invalid predeclared penalty: " + name) from None
    if isinstance(penalties[name], (bool, np.bool_)) or not np.isfinite(value) or value < 0:
        raise ValueError("Penalty must be finite and nonnegative: " + name)
    return value


def _mean_result(value, rows):
    result = np.asarray(value, dtype=float)
    if result.shape != (rows, 7) or not np.isfinite(result).all() or np.any(result < 0):
        raise ValueError("RNA mean prediction must preserve all rows/seven outputs and finite nonnegative values")
    return result


def _features(x):
    try:
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            exposure = 1.0 + x.sum(axis=1)
            features = np.column_stack((np.log1p(1000.0 * x / exposure[:, None]), np.log(exposure)))
    except FloatingPointError as error:
        raise ValueError("Target-free RNA features/exposure are not numerically representable") from error
    if not np.isfinite(features).all() or not np.isfinite(exposure).all():
        raise ValueError("Target-free RNA features/exposure must be finite")
    return features, exposure


def _fingerprint(x, y, weights):
    value = hashlib.sha256()
    for name, array in (("x_counts", x), ("y_counts", y), ("weights", weights)):
        array = np.asarray(array, dtype="<f8")
        value.update(name.encode("ascii"))
        value.update(json.dumps(array.shape).encode("ascii"))
        value.update(array.tobytes(order="C"))
    return value.hexdigest()


def _design(features, scaler):
    return np.column_stack((np.ones(len(features)),
                            (features - np.asarray(scaler["mean127"])) / np.asarray(scaler["sd127"])))


def _poisson_head(design, response, exposure, weights, penalty):
    if not np.any(response > 0):
        return {"kind": "zero", "coef": [0.0] * 128,
                "diagnostics": {"success": True, "iterations": 0, "reason": "all_zero_training_response"}}
    denominator = float(weights @ exposure)
    start = np.zeros(128)
    start[0] = np.log(float(weights @ response) / denominator)

    def objective(beta):
        try:
            with np.errstate(over="raise", invalid="raise", divide="raise"):
                eta = design @ beta
                mean = exposure * np.exp(eta)
                value = float(weights @ (mean - response * eta) / denominator + penalty / 2.0 * np.sum(beta[1:] ** 2))
                gradient = design.T @ (weights * (mean - response)) / denominator
                gradient[1:] += penalty * beta[1:]
        except FloatingPointError as error:
            raise ValueError("Poisson numerical arithmetic failed; no clipping or rescue") from error
        if not np.isfinite(value) or not np.isfinite(gradient).all():
            raise ValueError("Poisson objective/gradient is nonfinite; no rescue")
        return value, gradient

    result = minimize(objective, start, jac=True, method="L-BFGS-B", tol=1e-8,
                      options={"maxiter": 500, "gtol": 1e-8, "ftol": 1e-8, "maxls": 40})
    diagnostics = {"success": bool(result.success), "status": int(result.status), "iterations": int(result.nit),
                   "function_evaluations": int(result.nfev), "message": str(result.message),
                   "gradient_max_abs": float(np.max(np.abs(result.jac))), "objective": float(result.fun)}
    if not result.success or not np.isfinite(result.x).all():
        raise ValueError("Poisson nonconvergence blocked: " + json.dumps(diagnostics, allow_nan=False))
    return {"kind": "poisson", "coef": result.x.tolist(), "diagnostics": diagnostics}


def _predict_head(head, design, exposure):
    if head["kind"] == "zero":
        return np.zeros(len(design))
    try:
        with np.errstate(over="raise", invalid="raise"):
            value = exposure * np.exp(design @ np.asarray(head["coef"]))
    except FloatingPointError as error:
        raise ValueError("Poisson prediction is nonfinite; no clipping or rescue") from error
    if not np.isfinite(value).all() or np.any(value <= 0):
        raise ValueError("Positive-response Poisson prediction is undefined or underflowed")
    return value


def _composition_head(design, y, weights, penalty):
    mass = weights @ y
    active = np.flatnonzero(mass > 0)
    if len(active) == 0:
        return {"kind": "uniform", "active_indices": list(range(7)), "coef": None,
                "training_all_zero": True, "diagnostics": {"success": True, "iterations": 0}}
    if len(active) == 1:
        return {"kind": "count_multinomial", "active_indices": active.tolist(), "coef": np.zeros((128, 1)).tolist(),
                "training_all_zero": False, "diagnostics": {"success": True, "iterations": 0}}
    response = y[:, active]
    totals = response.sum(axis=1)
    denominator = float(weights @ totals)
    start = np.zeros((128, len(active)))
    initial = mass[active] / mass[active].sum()
    start[0] = np.log(initial) - np.log(initial).mean()

    def objective(flat):
        coefficient = flat.reshape(start.shape)
        try:
            with np.errstate(over="raise", invalid="raise", divide="raise"):
                logits = design @ coefficient
                logprob = logits - logsumexp(logits, axis=1, keepdims=True)
                probability = np.exp(logprob)
                value = float(-np.sum(weights[:, None] * response * logprob) / denominator
                              + penalty / 2.0 * np.sum(coefficient[1:] ** 2))
                gradient = design.T @ (weights[:, None] * (totals[:, None] * probability - response)) / denominator
                gradient[1:] += penalty * coefficient[1:]
        except FloatingPointError as error:
            raise ValueError("Count composition numerical arithmetic failed; no clipping or rescue") from error
        if not np.isfinite(value) or not np.isfinite(gradient).all():
            raise ValueError("Count composition objective/gradient is nonfinite")
        return value, gradient.ravel()

    result = minimize(objective, start.ravel(), jac=True, method="L-BFGS-B", tol=1e-8,
                      options={"maxiter": 500, "gtol": 1e-8, "ftol": 1e-8, "maxls": 40})
    diagnostics = {"success": bool(result.success), "status": int(result.status), "iterations": int(result.nit),
                   "function_evaluations": int(result.nfev), "message": str(result.message),
                   "gradient_max_abs": float(np.max(np.abs(result.jac))), "objective": float(result.fun)}
    if not result.success or not np.isfinite(result.x).all():
        raise ValueError("Count composition nonconvergence blocked: " + json.dumps(diagnostics, allow_nan=False))
    return {"kind": "count_multinomial", "active_indices": active.tolist(), "coef": result.x.reshape(start.shape).tolist(),
            "training_all_zero": False, "diagnostics": diagnostics}


def _total_checkpoint(bundle):
    values = {key: bundle[key] for key in ("total_head", "scaler", "training_fingerprint")}
    values["count_Poisson_L2"] = bundle["penalties"]["count_Poisson_L2"]
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf8")).hexdigest()


def fit_bundle(training_arrays, weights, method, penalties):
    if not isinstance(training_arrays, dict) or set(training_arrays) != {"x_counts", "y_counts"}:
        raise ValueError("Training arrays must contain only x_counts and y_counts")
    x = _counts(training_arrays["x_counts"], 126, "x_counts")
    y = _counts(training_arrays["y_counts"], 7, "y_counts")
    w = np.asarray(weights, dtype=float)
    if (len(x) != len(y) or w.shape != (len(x),) or not np.isfinite(w).all()
            or np.any(w <= 0) or not np.isclose(w.sum(), 1.0, rtol=0, atol=1e-10)):
        raise ValueError("Hierarchical training weights must be positive, finite, aligned and sum to one")
    if method not in METHODS or not isinstance(penalties, dict):
        raise ValueError("Only the five declared RNA mean methods and penalty dictionaries are allowed")
    features, exposure = _features(x)
    mean = w @ features
    sd = np.maximum(0.1, np.sqrt(w @ ((features - mean) ** 2)))
    bundle = {"schema": "RNA_MEAN_BUNDLE_V1", "method": method,
            "scaler": {"mean127": mean.tolist(), "sd127": sd.tolist(), "sd_floor": 0.1},
            "training_fingerprint": _fingerprint(x, y, w), "penalties": {},
            "feature_contract": {"anchor_count": 126, "raw_feature_count": 127, "design_count": 128,
                                 "exposure": "1+sum126", "size_feature": False},
            "diagnostics": {"training_rows": len(x), "all_zero_training_members": np.flatnonzero(np.all(y == 0, axis=0)).tolist()}}
    if method == "AnchorRate":
        bundle["anchor_rates"] = ((w @ y) / (w @ exposure)).tolist()
    elif method == "memberRidge":
        penalty = _penalty(penalties, "member_ridge_L2")
        design = _design(features, bundle["scaler"])
        regularizer = penalty * np.eye(128)
        regularizer[0, 0] = 0.0
        try:
            coefficient = np.linalg.solve(design.T @ (w[:, None] * design) + regularizer,
                                          design.T @ (w[:, None] * (y / exposure[:, None])))
        except np.linalg.LinAlgError as error:
            raise ValueError("Ridge normal equations are singular; no solver substitution") from error
        if not np.isfinite(coefficient).all():
            raise ValueError("Ridge coefficient arithmetic is nonfinite")
        bundle["ridge_coef"] = coefficient.tolist()
        bundle["penalties"] = {"member_ridge_L2": penalty}
    elif method == "memberPoisson":
        penalty = _penalty(penalties, "count_Poisson_L2")
        design = _design(features, bundle["scaler"])
        bundle["member_heads"] = [_poisson_head(design, y[:, gene], exposure, w, penalty) for gene in range(7)]
        bundle["penalties"] = {"count_Poisson_L2": penalty}
        bundle["diagnostics"]["optimizer_limits"] = {"maxiter": 500, "tol": 1e-8}
    elif method in ("sourceTotal_fixedComposition", "sourceTotal_learnedComposition"):
        penalty = _penalty(penalties, "count_Poisson_L2")
        design = _design(features, bundle["scaler"])
        bundle["penalties"] = {"count_Poisson_L2": penalty}
        if method == "sourceTotal_fixedComposition":
            bundle["total_head"] = _poisson_head(design, y.sum(axis=1), exposure, w, penalty)
            masses = w @ y
            probabilities = np.full(7, 1.0 / 7.0) if masses.sum() == 0 else masses / masses.sum()
            bundle["fixed_composition"] = probabilities.tolist()
            bundle["composition"] = {"kind": "fixed", "active_indices": list(range(7)) if masses.sum() == 0 else np.flatnonzero(masses > 0).tolist(),
                                     "coef": None, "training_all_zero": bool(masses.sum() == 0)}
        else:
            shared = penalties.get("shared_total_bundle")
            if (shared is None or shared.get("method") != "sourceTotal_fixedComposition"
                    or shared.get("training_fingerprint") != bundle["training_fingerprint"]
                    or shared.get("scaler") != bundle["scaler"]
                    or shared.get("penalties", {}).get("count_Poisson_L2") != penalty
                    or shared.get("total_checkpoint_sha256") != _total_checkpoint(shared)):
                raise ValueError("Shared total checkpoint requires the exact same training arrays/weights/scaler/penalty")
            bundle["total_head"] = copy.deepcopy(shared["total_head"])
            bundle["fixed_composition"] = list(shared["fixed_composition"])
            composition_penalty = _penalty(penalties, "composition_L2")
            bundle["penalties"]["composition_L2"] = composition_penalty
            bundle["composition"] = _composition_head(design, y, w, composition_penalty)
        bundle["total_checkpoint_sha256"] = _total_checkpoint(bundle)
        bundle["diagnostics"]["optimizer_limits"] = {"maxiter": 500, "tol": 1e-8}
        bundle["diagnostics"]["total_head_reused"] = method == "sourceTotal_learnedComposition"
    else:
        raise ValueError("method is not implemented")
    json.dumps(bundle, allow_nan=False)
    return bundle


def predict_bundle(frozen_bundle, input_counts):
    x = _counts(input_counts, 126, "prediction input_counts")
    features, exposure = _features(x)
    if frozen_bundle["method"] == "AnchorRate":
        return _mean_result(exposure[:, None] * np.asarray(frozen_bundle["anchor_rates"]), len(x))
    if frozen_bundle["method"] == "memberRidge":
        design = _design(features, frozen_bundle["scaler"])
        return _mean_result(exposure[:, None] * np.maximum(0.0, design @ np.asarray(frozen_bundle["ridge_coef"])), len(x))
    if frozen_bundle["method"] == "memberPoisson":
        design = _design(features, frozen_bundle["scaler"])
        return _mean_result(np.column_stack([_predict_head(head, design, exposure) for head in frozen_bundle["member_heads"]]), len(x))
    if frozen_bundle["method"] in ("sourceTotal_fixedComposition", "sourceTotal_learnedComposition"):
        design = _design(features, frozen_bundle["scaler"])
        total = _predict_head(frozen_bundle["total_head"], design, exposure)
        composition = frozen_bundle["composition"]
        if composition["kind"] == "fixed":
            probabilities = np.tile(np.asarray(frozen_bundle["fixed_composition"]), (len(x), 1))
        elif composition["kind"] == "uniform":
            probabilities = np.full((len(x), 7), 1.0 / 7.0)
        else:
            logits = design @ np.asarray(composition["coef"])
            active = np.asarray(composition["active_indices"], dtype=int)
            probabilities = np.zeros((len(x), 7))
            probabilities[:, active] = np.exp(logits - logsumexp(logits, axis=1, keepdims=True))
        result = _mean_result(total[:, None] * probabilities, len(x))
        if not np.allclose(result.sum(axis=1), total, rtol=1e-12, atol=1e-12):
            raise ValueError("RNA paired-total mean identity failed; no mass repair")
        return result
    raise ValueError("method is not implemented")
