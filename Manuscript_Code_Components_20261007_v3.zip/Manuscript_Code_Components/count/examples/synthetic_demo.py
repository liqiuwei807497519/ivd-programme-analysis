"""Generate a small known-constant example containing no real observations."""
import argparse
from pathlib import Path
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    x = np.ones((24, 126), dtype=np.int64)
    y = np.tile(np.arange(2, 9, dtype=np.int64), (24, 1))
    np.savez_compressed(args.output / 'train_input.npz',
                        region_id=np.array(['synthetic_train_' + str(i) for i in range(24)]),
                        x_counts=x, y_counts=y)
    np.savez_compressed(args.output / 'eval_input.npz',
                        region_id=np.array(['synthetic_eval_' + str(i) for i in range(5)]), x_counts=x[:5])
    print('Created 24 synthetic training rows and 5 evaluation rows; all four means should equal [2,3,4,5,6,7,8].')


if __name__ == '__main__':
    main()
