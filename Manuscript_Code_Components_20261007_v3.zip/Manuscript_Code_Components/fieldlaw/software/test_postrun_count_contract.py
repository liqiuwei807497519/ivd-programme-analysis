import unittest
import numpy as np
from postrun_audit import exact_count_array


class PostrunCountContractTests(unittest.TestCase):
    def test_integer_arrays_are_accepted_without_conversion(self):
        values = np.array([[0, 2]], dtype=np.int64)
        self.assertIsNone(exact_count_array(values, (1, 2), 'synthetic'))

    def test_fractional_negative_and_overflowing_values_block_before_integer_cast(self):
        for values in (np.array([[0.5, 2]]), np.array([[-1, 2]], dtype=np.int64),
                       np.array([[2**63, 2]], dtype=np.uint64), np.array([[True, False]])):
            with self.subTest(dtype=values.dtype), self.assertRaises(ValueError):
                exact_count_array(values, (1, 2), 'synthetic')


if __name__ == '__main__':
    unittest.main()
