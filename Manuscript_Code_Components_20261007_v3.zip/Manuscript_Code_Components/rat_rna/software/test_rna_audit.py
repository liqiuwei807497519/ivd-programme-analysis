import unittest

from rna_audit import check_numeric_row


class IndependentRowTests(unittest.TestCase):
    def test_literal_member_values_are_checked_without_production_scorer(self):
        row = {'truth_count': '2', 'predicted_mean': '1', 'source_scale': '2',
               'poisson_deviance': '0.7725887222397811',
               'scaled_poisson_deviance': '0.3862943611198906',
               'absolute_error': '1', 'truth_is_zero': 'False', 'score_status': 'finite'}
        self.assertEqual(check_numeric_row(row, 2, 1, 2), 7)
        row['scaled_poisson_deviance'] = '0.2'
        with self.assertRaisesRegex(ValueError, 'scaled_poisson_deviance'):
            check_numeric_row(row, 2, 1, 2)

    def test_positive_truth_zero_prediction_is_not_finite_or_dropped(self):
        row = {'truth_count': '1', 'predicted_mean': '0', 'source_scale': '1',
               'poisson_deviance': 'Infinity', 'scaled_poisson_deviance': 'Infinity',
               'absolute_error': '1', 'truth_is_zero': 'False',
               'score_status': 'positive_truth_zero_mean'}
        self.assertEqual(check_numeric_row(row, 1, 0, 1), 7)


if __name__ == '__main__':
    unittest.main(verbosity=2)
