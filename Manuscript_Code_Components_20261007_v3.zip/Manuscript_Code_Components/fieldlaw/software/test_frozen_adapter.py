"""Frozen replay tests using only artificial zero-tree source capsules."""
import copy
from pathlib import Path
import sys
import unittest

import numpy as np

from frozen_adapter import FrozenMeanPredictor

LEGACY_ROOT = Path(__file__).resolve().parents[2] / "IVD_Nonlinear_Baseline_20261005_V2_Real" / "run_source"
sys.path.insert(0, str(LEGACY_ROOT))
from xgb_offset_core import serialize_model, synthetic_zero_tree_probe
from vendor.baseline_core import GENES


def synthetic_parameters():
    capsules = []
    totals = []
    x_train = np.zeros((2, 126), dtype=np.int64)
    inputs = np.array(["SYN_INPUT_" + str(i) for i in range(126)])
    for source, members, total in ((1, np.arange(1, 8), 7), (2, np.arange(7, 0, -1), 14)):
        result = synthetic_zero_tree_probe(
            x_train, np.tile(members, (2, 1)), np.zeros((1, 126), dtype=np.int64), np.array([total]),
            train_ids=np.array([f"SYN_SOURCE{source}_TRAIN0", f"SYN_SOURCE{source}_TRAIN1"]),
            eval_ids=np.array([f"SYN_SOURCE{source}_PROBE"]), input_ids=inputs,
            member_ids=np.array(GENES), mode="synthetic")
        capsule = serialize_model(result["models"])
        capsules.append(capsule)
        totals.append({"standardizer": copy.deepcopy(capsule["standardizer"]),
                       "total": {"kind": "poisson_total", "alpha": 0.01, "success": True,
                                 "coef": [float(np.log(total))] + [0.0] * 128}})
    return capsules, totals


class FrozenAdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.capsules, cls.totals = synthetic_parameters()

    def test_reconciles_each_saved_source_then_averages_the_complete_forecasts(self):
        predictor = FrozenMeanPredictor(self.capsules, self.totals)
        mu, receipt = predictor.predict(np.zeros((1, 126), dtype=np.int64), ["SYN_TARGET_ZERO"])
        np.testing.assert_allclose(mu, [[1.875, 1.75, 1.625, 1.5, 1.375, 1.25, 1.125]], rtol=1e-6)
        np.testing.assert_allclose(receipt["source_totals"], [[7], [14]], rtol=1e-14)
        np.testing.assert_allclose(mu.sum(axis=1), [10.5], rtol=1e-14)
        self.assertTrue(receipt["count_mean_total_consistent"])
        self.assertEqual(receipt["new_point_fits"], 0)
        self.assertEqual(receipt["legacy_size_reference_bins"], 9)

    def test_requires_exact_matching_all_128_source_scaler_columns(self):
        for source, field, index in ((0, "mean", 0), (1, "mean", 127), (1, "sd", 126)):
            totals = copy.deepcopy(self.totals)
            totals[source]["standardizer"][field][index] += 1e-12
            with self.subTest(source=source, field=field, column=index), self.assertRaises(ValueError):
                FrozenMeanPredictor(self.capsules, totals)

    def test_requires_two_complete_pairs_with_identical_ordered_roles(self):
        for heads, totals in ((self.capsules[:1], self.totals[:1]),
                              (self.capsules, self.totals[:1])):
            with self.subTest(heads=len(heads), totals=len(totals)), self.assertRaises(ValueError):
                FrozenMeanPredictor(heads, totals)
        heads = copy.deepcopy(self.capsules)
        heads[1]["input_ids"][0], heads[1]["input_ids"][1] = heads[1]["input_ids"][1], heads[1]["input_ids"][0]
        with self.assertRaises(ValueError):
            FrozenMeanPredictor(heads, self.totals)


if __name__ == "__main__":
    unittest.main()
