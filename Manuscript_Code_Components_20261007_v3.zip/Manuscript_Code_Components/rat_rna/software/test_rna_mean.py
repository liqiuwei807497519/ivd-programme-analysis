"""Synthetic public-seam tests for the separate source RNA mean module."""

import unittest
import json
import math
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

from rna_mean import fit_bundle, predict_bundle


class RNAMeanTests(unittest.TestCase):
    def test_literal_anchor_rate_and_allzero_members_are_preserved(self):
        x = np.zeros((2, 126), dtype=np.int64)
        x[:, 0] = [1, 3]
        y = np.zeros((2, 7), dtype=np.int64)
        y[:, 0] = [2, 8]
        bundle = fit_bundle({"x_counts": x, "y_counts": y}, [0.25, 0.75], "AnchorRate", {})
        query = np.zeros((1, 126), dtype=np.int64)
        query[0, 0] = 2
        np.testing.assert_allclose(predict_bundle(bundle, query), [[39.0 / 7.0, 0, 0, 0, 0, 0, 0]], rtol=0, atol=1e-14)
        zero = fit_bundle({"x_counts": x, "y_counts": np.zeros_like(y)}, [0.25, 0.75], "AnchorRate", {})
        np.testing.assert_array_equal(predict_bundle(zero, query), np.zeros((1, 7)))

    def test_scaler_has_127_train_only_features_and_json_safe_frozen_parameters(self):
        x = np.zeros((2, 126), dtype=np.int64)
        x[:, 0] = [1, 3]
        bundle = fit_bundle({"x_counts": x, "y_counts": np.zeros((2, 7), dtype=np.int64)},
                            [0.25, 0.75], "AnchorRate", {})
        self.assertEqual(len(bundle["scaler"]["mean127"]), 127)
        self.assertEqual(len(bundle["scaler"]["sd127"]), 127)
        self.assertAlmostEqual(bundle["scaler"]["mean127"][126], 1.75 * math.log(2), places=14)
        self.assertAlmostEqual(bundle["scaler"]["sd127"][126], math.sqrt(3.0 / 16.0) * math.log(2), places=14)
        self.assertEqual(bundle["scaler"]["sd127"][1], 0.1)
        before = json.dumps(bundle, allow_nan=False, sort_keys=True)
        predict_bundle(bundle, np.full((3, 126), 10000, dtype=np.int64))
        self.assertEqual(json.dumps(bundle, allow_nan=False, sort_keys=True), before)

    def test_penalized_rate_ridge_has_literal_intercept_and_fixed_nonnegative_link(self):
        x = np.zeros((4, 126), dtype=np.int64)
        y = np.zeros((4, 7), dtype=np.int64)
        y[:, 0] = [1, 2, 3, 4]
        bundle = fit_bundle({"x_counts": x, "y_counts": y}, np.full(4, 0.25), "memberRidge", {"member_ridge_L2": 1.0})
        np.testing.assert_allclose(predict_bundle(bundle, x[:1]), [[2.5, 0, 0, 0, 0, 0, 0]], rtol=0, atol=1e-14)
        self.assertEqual(np.asarray(bundle["ridge_coef"]).shape, (128, 7))
        varied = np.zeros((2, 126), dtype=np.int64)
        varied[:, 0] = [1, 3]
        response = np.zeros((2, 7), dtype=np.int64)
        response[1, 0] = 20
        bundle = fit_bundle({"x_counts": varied, "y_counts": response}, [0.5, 0.5], "memberRidge", {"member_ridge_L2": 0.01})
        np.testing.assert_array_equal(predict_bundle(bundle, np.zeros((1, 126), dtype=np.int64)), np.zeros((1, 7)))

    def test_penalized_poisson_heads_satisfy_independent_optimality_and_preserve_zero_heads(self):
        x = np.zeros((8, 126), dtype=np.int64)
        x[:, 0] = np.arange(8)
        y = np.zeros((8, 7), dtype=np.int64)
        y[:, 0] = [1, 2, 6, 8, 15, 18, 28, 32]
        weights = np.full(8, 1.0 / 8)
        penalty = 0.2
        bundle = fit_bundle({"x_counts": x, "y_counts": y}, weights, "memberPoisson", {"count_Poisson_L2": penalty})
        predicted = predict_bundle(bundle, x)
        self.assertTrue(np.all(predicted[:, 0] > 0))
        np.testing.assert_array_equal(predicted[:, 1:], np.zeros((8, 6)))
        self.assertTrue(all(head["kind"] == "zero" for head in bundle["member_heads"][1:]))
        exposure = 1.0 + np.arange(8)
        raw = np.zeros((8, 127))
        raw[:, 0] = np.log1p(1000.0 * np.arange(8) / exposure)
        raw[:, 126] = np.log(exposure)
        design = np.column_stack((np.ones(8), (raw - np.asarray(bundle["scaler"]["mean127"])) / np.asarray(bundle["scaler"]["sd127"])))
        coefficient = np.asarray(bundle["member_heads"][0]["coef"])
        def independent_objective(beta):
            eta = design @ beta
            return float(np.mean(exposure * np.exp(eta) - y[:, 0] * eta) / np.mean(exposure)
                         + penalty / 2 * np.sum(beta[1:] ** 2))
        for column in (0, 1, 127):
            left, right = coefficient.copy(), coefficient.copy()
            left[column] -= 1e-5
            right[column] += 1e-5
            derivative = (independent_objective(right) - independent_objective(left)) / 2e-5
            self.assertLess(abs(derivative), 2e-5)
        self.assertEqual(bundle["diagnostics"]["optimizer_limits"], {"maxiter": 500, "tol": 1e-8})
        json.dumps(bundle, allow_nan=False)

    def test_paired_compositions_reuse_exact_total_checkpoint_and_retain_seven_outputs(self):
        x = np.zeros((4, 126), dtype=np.int64)
        y = np.tile([1, 3, 0, 0, 0, 0, 0], (4, 1))
        arrays, weights = {"x_counts": x, "y_counts": y}, np.full(4, 0.25)
        fixed = fit_bundle(arrays, weights, "sourceTotal_fixedComposition", {"count_Poisson_L2": 0.1})
        learned = fit_bundle(arrays, weights, "sourceTotal_learnedComposition",
                             {"count_Poisson_L2": 0.1, "composition_L2": 0.1, "shared_total_bundle": fixed})
        self.assertEqual(fixed["total_head"], learned["total_head"])
        self.assertEqual(fixed["scaler"], learned["scaler"])
        query = np.zeros((2, 126), dtype=np.int64)
        query[1, 0] = 2
        expected = [[1, 3, 0, 0, 0, 0, 0], [3, 9, 0, 0, 0, 0, 0]]
        for bundle in (fixed, learned):
            np.testing.assert_allclose(predict_bundle(bundle, query), expected, rtol=0, atol=1e-12)
            self.assertEqual(bundle["composition"]["active_indices"], [0, 1])
        zero_arrays = {"x_counts": x, "y_counts": np.zeros((4, 7), dtype=np.int64)}
        zero_fixed = fit_bundle(zero_arrays, weights, "sourceTotal_fixedComposition", {"count_Poisson_L2": 0.1})
        zero_learned = fit_bundle(zero_arrays, weights, "sourceTotal_learnedComposition",
                                  {"count_Poisson_L2": 0.1, "composition_L2": 0.1, "shared_total_bundle": zero_fixed})
        for bundle in (zero_fixed, zero_learned):
            np.testing.assert_array_equal(predict_bundle(bundle, query), np.zeros((2, 7)))
            self.assertTrue(bundle["composition"]["training_all_zero"])
            self.assertEqual(bundle["fixed_composition"], [1.0 / 7.0] * 7)

    def test_invalid_count_weight_penalty_and_prediction_inputs_are_rejected(self):
        x = np.zeros((2, 126), dtype=np.int64)
        y = np.zeros((2, 7), dtype=np.int64)
        for bad in (-1.0, 0.5, math.nan):
            invalid = x.astype(float)
            invalid[0, 0] = bad
            with self.subTest(count=bad), self.assertRaises(ValueError):
                fit_bundle({"x_counts": invalid, "y_counts": y}, [0.5, 0.5], "AnchorRate", {})
        for weights in ([1.0, 1.0], [-0.5, 1.5], [math.nan, 0.5], [1.0]):
            with self.subTest(weights=weights), self.assertRaises(ValueError):
                fit_bundle({"x_counts": x, "y_counts": y}, weights, "AnchorRate", {})
        for penalty in (-1.0, math.nan, math.inf):
            with self.subTest(penalty=penalty), self.assertRaises(ValueError):
                fit_bundle({"x_counts": x, "y_counts": y}, [0.5, 0.5], "memberRidge", {"member_ridge_L2": penalty})
        bundle = fit_bundle({"x_counts": x, "y_counts": y}, [0.5, 0.5], "AnchorRate", {})
        with self.assertRaises(ValueError):
            predict_bundle(bundle, np.zeros((1, 125), dtype=np.int64))

    def test_count_composition_has_independent_optimality_and_shared_training_is_enforced(self):
        x = np.zeros((8, 126), dtype=np.int64)
        x[:, 0] = np.arange(8)
        y = np.zeros((8, 7), dtype=np.int64)
        y[:, 0] = [8, 8, 7, 7, 3, 3, 1, 1]
        y[:, 1] = [1, 1, 3, 3, 7, 7, 8, 8]
        weights, arrays = np.full(8, 0.125), {"x_counts": x, "y_counts": y}
        fixed = fit_bundle(arrays, weights, "sourceTotal_fixedComposition", {"count_Poisson_L2": 0.1})
        penalty = 0.3
        learned = fit_bundle(arrays, weights, "sourceTotal_learnedComposition",
                             {"count_Poisson_L2": 0.1, "composition_L2": penalty, "shared_total_bundle": fixed})
        mu_fixed, mu_learned = predict_bundle(fixed, x), predict_bundle(learned, x)
        np.testing.assert_allclose(mu_fixed.sum(axis=1), mu_learned.sum(axis=1), rtol=1e-14, atol=1e-14)
        self.assertEqual(fixed["total_checkpoint_sha256"], learned["total_checkpoint_sha256"])
        e = 1.0 + np.arange(8)
        raw = np.zeros((8, 127))
        raw[:, 0], raw[:, 126] = np.log1p(1000 * np.arange(8) / e), np.log(e)
        design = np.column_stack((np.ones(8), (raw - np.asarray(learned["scaler"]["mean127"])) / np.asarray(learned["scaler"]["sd127"])))
        coef = np.asarray(learned["composition"]["coef"])
        def independent_count_objective(beta):
            z = design @ beta
            denominator = np.log(np.sum(np.exp(z), axis=1))
            return float(-np.sum(y[:, :2] * (z - denominator[:, None])) / np.sum(y)
                         + penalty / 2.0 * np.sum(beta[1:] ** 2))
        for row, column in ((0, 0), (1, 0), (127, 1)):
            left, right = coef.copy(), coef.copy()
            left[row, column] -= 1e-5
            right[row, column] += 1e-5
            self.assertLess(abs((independent_count_objective(right) - independent_count_objective(left)) / 2e-5), 2e-5)
        wrong = x.copy()
        wrong[0, 1] = 1
        with self.assertRaisesRegex(ValueError, "exact same training"):
            fit_bundle({"x_counts": wrong, "y_counts": y}, weights, "sourceTotal_learnedComposition",
                       {"count_Poisson_L2": 0.1, "composition_L2": penalty, "shared_total_bundle": fixed})

    def test_optimizer_nonconvergence_blocks_instead_of_returning_a_rescue_bundle(self):
        failure = SimpleNamespace(success=False, status=1, nit=500, nfev=501,
                                  message="synthetic declared iteration limit", jac=np.zeros(128), fun=1.0, x=np.zeros(128))
        with patch("rna_mean.minimize", return_value=failure):
            with self.assertRaisesRegex(ValueError, 'Poisson nonconvergence blocked.*"iterations": 500'):
                fit_bundle({"x_counts": np.zeros((2, 126), dtype=np.int64),
                            "y_counts": np.ones((2, 7), dtype=np.int64)}, [0.5, 0.5], "memberPoisson", {"count_Poisson_L2": 0.1})


if __name__ == "__main__":
    unittest.main()
