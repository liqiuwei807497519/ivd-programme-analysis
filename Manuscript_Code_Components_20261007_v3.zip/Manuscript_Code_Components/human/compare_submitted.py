"""Compare the twelve payloads to submitted truth, NPZ by arrays, not ZIP bytes."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((args.original / "ANALYSIS_COMMIT.json").read_text(encoding="utf8"))
    records = []
    for item in manifest["artifacts"]:
        first, second = args.original / item["relative_path"], args.replay / item["relative_path"]
        record = {"payload": item["relative_path"]}
        if first.suffix == ".npz":
            with np.load(first, allow_pickle=False) as a, np.load(second, allow_pickle=False) as b:
                if set(a.files) != set(b.files):raise ValueError("NPZ keys differ")
                for key in a.files:
                    if a[key].dtype != b[key].dtype or a[key].shape != b[key].shape:
                        raise ValueError("NPZ schema differs: " + key)
                    equal = np.array_equal(a[key], b[key], equal_nan=True) if a[key].dtype.kind in "fc" else np.array_equal(a[key], b[key])
                    if not equal:raise ValueError("NPZ exact array values differ: " + key)
                record.update(array_keys=sorted(a.files), exact_array_values_equal=True, ZIP_byte_equality_required=False)
        else:
            a, b = first.read_bytes(), second.read_bytes()
            if first.suffix == ".gz":a, b = gzip.decompress(a), gzip.decompress(b)
            if a != b:raise ValueError("Submitted payload content differs: " + first.name)
            record.update(exact_decoded_content_equal=True)
        records.append(record)
    result = {"status": "PASS_ALL12_SUBMITTED_PAYLOADS", "payload_count": len(records), "payloads": records,
              "numeric_tolerance_in_original_vs_replay_comparison": 0,
              "analysis_commit_compared_as_payload": False,
              "reason": "Commit binds newly extracted prepared-input file bytes; twelve scientific payloads compared in full"}
    with args.receipt.open("x", encoding="utf8") as handle:
        json.dump(result, handle, indent=2, ensure_ascii=False);handle.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
