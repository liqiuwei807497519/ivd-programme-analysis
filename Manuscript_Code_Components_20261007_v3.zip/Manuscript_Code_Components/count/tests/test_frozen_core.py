"""Synthetic public-interface checks. No real data or filesystem fixtures."""
import unittest

import numpy as np

from baseline_core import ContractError, fit_predict, input_features, poisson_objective, predict_ridge


class BaselineContractTests(unittest.TestCase):
    def test_known_constant_training_rates_and_common_total(self):
        counts = np.ones((8, 126), dtype=np.int64)
        truth = np.tile(np.arange(1, 8), (8, 1))
        result = fit_predict(counts, truth, counts[:3])
        expected = np.tile(np.arange(1, 8), (3, 1))
        for method, means in result['predictions'].items():
            np.testing.assert_allclose(means, expected, rtol=1e-9, atol=1e-9, err_msg=method)
        np.testing.assert_allclose(result['predictions']['TotalFixed'].sum(axis=1), 28.0)
        np.testing.assert_allclose(result['predictions']['TotalRidge'].sum(axis=1), 28.0)
        np.testing.assert_array_equal(result['member_scales'], np.arange(1, 8))
        self.assertEqual(result['total_scale'], 28.0)

    def test_nonpositive_smeared_prediction_fails_with_locations(self):
        model = {'coef': np.full((1, 7), -1.0), 'log_smear': np.zeros(7)}
        with self.assertRaises(ContractError) as caught:
            predict_ridge(model, np.ones((3, 1)), np.array([1.0, 2.0, 3.0]))
        details = caught.exception.details
        self.assertEqual(details['per_gene_counts'], [3] * 7)
        self.assertEqual(details['first_10_eval_indices'], [0, 1, 2])
        self.assertLess(details['minimum'], 0)

    def test_entirely_zero_training_member_stops_direction(self):
        counts = np.ones((4, 126), dtype=int)
        truth = np.tile(np.arange(1, 8), (4, 1))
        truth[:, 3] = 0
        with self.assertRaises(ContractError) as caught:
            fit_predict(counts, truth, counts[:1])
        self.assertEqual(caught.exception.details['zero_genes'], ['KRT19'])
        self.assertEqual(caught.exception.details['stage'], 'train_target_support')

    def test_exposure_and_nine_bin_feature_only_use_input_counts(self):
        counts = np.zeros((2, 126), dtype=int)
        counts[0, 0] = 2
        counts[0, 125] = 4
        features, exposure = input_features(counts)
        np.testing.assert_array_equal(exposure, [7.0, 1.0])
        np.testing.assert_allclose(features[:, -1], [np.log(9), np.log(9)])
        np.testing.assert_allclose(features[:, -2], [np.log(7), 0])

    def test_evaluation_shift_does_not_change_training_standardization_or_model(self):
        counts = np.vstack([np.full(126, k) for k in range(1, 9)])
        e = 1 + counts.sum(axis=1)
        truth = e[:, None] * np.arange(1, 8)[None, :]
        first = fit_predict(counts, truth, counts[:2])
        shifted = fit_predict(counts, truth, np.full((2, 126), 1000000))
        for key in ('mean', 'sd'):
            np.testing.assert_array_equal(first['models']['standardizer'][key], shifted['models']['standardizer'][key])
        np.testing.assert_array_equal(first['models']['ridge']['coef'], shifted['models']['ridge']['coef'])
        np.testing.assert_array_equal(first['member_scales'], shifted['member_scales'])

    def test_large_linear_predictor_is_finite_without_old_clip(self):
        model = {'coef': np.full((1, 7), 41.0), 'log_smear': np.zeros(7)}
        means, diagnostics = predict_ridge(model, np.ones((1, 1)), np.ones(1))
        # Decimal worked value of (exp(41)-1)/1000, not the old exp(40) cap.
        np.testing.assert_allclose(means, 639843493530054.9, rtol=1e-14)
        self.assertEqual(diagnostics['old_z_clip_range_exceeded_per_gene'], [1] * 7)
        self.assertEqual(diagnostics['prediction_repairs'], 0)

    def test_smearing_can_cancel_large_predictor_without_intermediate_overflow(self):
        model = {'coef': np.full((1, 7), -1000.0), 'log_smear': np.full(7, 1001.0)}
        means, diagnostics = predict_ridge(model, np.ones((1, 1)), np.array([1000.0]))
        np.testing.assert_allclose(means, 1.718281828459045, rtol=1e-14)
        self.assertEqual(diagnostics['old_z_clip_range_exceeded_per_gene'], [1] * 7)

    def test_actual_prediction_underflow_stops(self):
        model = {'coef': np.full((1, 7), np.nextafter(0.0, 1.0)), 'log_smear': np.zeros(7)}
        with self.assertRaises(ContractError) as caught:
            predict_ridge(model, np.ones((1, 1)), np.ones(1))
        self.assertEqual(caught.exception.details['per_gene_nonpositive_counts'], [1] * 7)

    def test_poisson_gradient_against_finite_difference(self):
        x = np.array([[1.0, -1.0], [1.0, 0.0], [1.0, 2.0]])
        y = np.array([1.0, 2.0, 4.0])
        e = np.array([1.0, 2.0, 3.0])
        weights = np.full(3, 1.0 / 3)
        beta = np.array([0.3, -0.2])
        _, gradient = poisson_objective(beta, x, y, e, weights)
        finite_difference = []
        for j in range(2):
            delta = np.zeros(2)
            delta[j] = 1e-6
            high = poisson_objective(beta + delta, x, y, e, weights)[0]
            low = poisson_objective(beta - delta, x, y, e, weights)[0]
            finite_difference.append((high - low) / 2e-6)
        np.testing.assert_allclose(gradient, finite_difference, rtol=1e-6, atol=1e-9)

    def test_nonfinite_poisson_evaluation_is_explicit_contract_failure(self):
        with self.assertRaises(ContractError) as caught:
            poisson_objective(np.array([1000.0]), np.ones((1, 1)),
                              np.ones(1), np.ones(1), np.ones(1))
        self.assertEqual(caught.exception.details['stage'], 'total_optimization')

    def test_fixed_alphas_cannot_be_changed(self):
        counts = np.ones((4, 126), dtype=int)
        truth = np.tile(np.arange(1, 8), (4, 1))
        for options in ({'ridge_alpha': 0.1}, {'total_alpha': 1.0}):
            with self.assertRaises(ContractError):
                fit_predict(counts, truth, counts[:1], **options)

    def test_fractional_count_input_and_wrong_panel_are_rejected(self):
        with self.assertRaises(ContractError):
            input_features(np.ones((2, 125), dtype=int))
        counts = np.ones((2, 126))
        counts[0, 0] = 0.5
        with self.assertRaises(ContractError):
            input_features(counts)

    def test_zero_evaluation_inputs_remain_valid_population_rows(self):
        counts = np.ones((4, 126), dtype=int)
        truth = np.tile(np.arange(1, 8), (4, 1))
        result = fit_predict(counts, truth, np.zeros((2, 126), dtype=int))
        # Constant training rate: at input exposure one, expected count g/127.
        expected = np.tile(np.arange(1, 8) / 127.0, (2, 1))
        for method, means in result['predictions'].items():
            np.testing.assert_allclose(means, expected, rtol=1e-9, atol=1e-12, err_msg=method)


if __name__ == '__main__':
    unittest.main(verbosity=2)
