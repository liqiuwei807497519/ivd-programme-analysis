"""No-fit forecast, complete scoring and independent audit for shared-total controls."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys

for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_key] = "2"
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "software"))
from rna_score import mean_evaluation
from rna_numeric_audit import independent_deviance, independent_decomposition
from reconcile_controls import reconcile_means

NEW = ("sharedTotal_ridgeAllocation", "sharedTotal_PoissonAllocation")
OLD = ("sourceTotal_fixedComposition", "sourceTotal_learnedComposition")
GROUPS = ("Control", "Day_1", "Day_3", "Day_28")
GENES = ("TBXT", "KRT8", "KRT18", "KRT19", "ACAN", "COL2A1", "SOX9")


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def readj(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rec(path):
    return {"path": str(Path(path).resolve()), "sha256": sha(path)}


def bound(item):
    if sha(item["path"]) != item["sha256"]:
        raise ValueError("immutable control/source artifact changed: " + item["path"])
    return Path(item["path"]).resolve()


def portable(value):
    if isinstance(value, dict):
        return {str(k): portable(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [portable(v) for v in value]
    if isinstance(value, np.generic):
        return portable(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return {"value": None, "status": "INFINITE" if math.isinf(value) else "UNDEFINED"}
    return value


def writej(path, value):
    with Path(path).open("x", encoding="utf8") as stream:
        stream.write(json.dumps(portable(value), ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def arrays(path):
    with np.load(path, allow_pickle=False) as capsule:
        return {name: capsule[name] for name in capsule.files}


def config_values(config):
    value = readj(config)
    for item in value["code_binding"] + [value["plan_binding"], value["authority_binding"]]:
        bound(item)
    if sha(value["original_config"]["path"]) != value["original_config"]["sha256"]:
        raise ValueError("original config drift")
    return value


def forecast(config, run, parent):
    cfg = config_values(config)
    run = Path(run).resolve()
    output = run / "forecasts" / parent
    if output.exists():
        raise ValueError("control forecast output must be fresh")
    item = cfg["parents"][parent]
    old = arrays(bound(item["native_means"]))
    params = readj(bound(item["params"]))
    total = old[OLD[0]].sum(axis=1)
    source_proportions = params["bundles"][OLD[0]]["fixed_composition"]
    result = {key: old[key] for key in ("region_id", "barcode", "section_id", "parent_id")}
    result["frozen_total"] = total
    result["source_proportions"] = np.asarray(source_proportions)
    fallback = {}
    for new, original in zip(NEW, ("memberRidge", "memberPoisson")):
        means, receipt = reconcile_means(old[original], total, source_proportions)
        result[new] = means
        fallback[new] = receipt
    if len(old["region_id"]) != item["observations"] or any(result[name].shape != (item["observations"], 7) for name in NEW):
        raise ValueError("control must preserve complete native and seven-member support")
    output.mkdir(parents=True, exist_ok=False)
    path = output / "CONTROL_MEANS.npz"
    np.savez_compressed(path, **result)
    commit = {"status": "SHARED_TOTAL_CONTROL_FORECAST_COMMITTED", "parent": parent, "config_sha256": sha(config),
              "original_config_sha256": cfg["original_config"]["sha256"], "methods": list(NEW),
              "observations": len(old["region_id"]), "members": 7, "source_scales7": params["source_scales7"],
              "source_scale_total": params["source_scale_total"], "fallback_receipts": fallback,
              "source_native_means": item["native_means"], "source_params": item["params"],
              "artifacts": {"CONTROL_MEANS.npz": rec(path)}, "source_label_reads": 0, "new_fits": 0}
    writej(output / "FORECAST_COMMIT.json", commit)
    return commit


def complete_forecasts(config, run):
    barrier = readj(Path(run) / "ALL_CONTROL_FORECASTS_COMMIT.json")
    if barrier["status"] != "ALL_FOUR_SHARED_TOTAL_CONTROL_FORECASTS_COMMITTED" or barrier["config_sha256"] != sha(config) or set(barrier["parents"]) != set(GROUPS):
        raise ValueError("all four actual-exit0 control forecasts required before source label scoring")
    result = {}
    for parent in GROUPS:
        descriptor = barrier["parents"][parent]
        if type(descriptor["external_exit_code"]) is not int or descriptor["external_exit_code"] != 0:
            raise ValueError("all actual forecast exits must be0")
        commit = readj(bound(descriptor))
        if commit["parent"] != parent or commit["config_sha256"] != sha(config) or tuple(commit["methods"]) != NEW:
            raise ValueError("control forecast identity mismatch")
        result[parent] = arrays(bound(commit["artifacts"]["CONTROL_MEANS.npz"]))
    return result


def section_metrics(level):
    return {"mean7_training_scaled_deviance": float(np.mean(level["mean_seven_scaled_deviance"])),
            "mean_D7_unscaled": float(np.mean(level["sum_member_deviance"])),
            "mean_Dtotal_unscaled": float(np.mean(level["programme_deviance"])),
            "member_MAE": float(np.mean(level["member_absolute_error"])),
            "programme_MAE": float(np.mean(level["programme_absolute_error"])),
            "infinite_member_loss_entries": int(np.isinf(level["member_deviance"]).sum()),
            "measured_member_mass": level["member_truth"].sum(axis=0).tolist(),
            "predicted_member_mass": level["member_mean"].sum(axis=0).tolist()}


def levels_for_section(cfg, source, control, section):
    folder, parent = section["section_folder"], section["parent"]
    prep = cfg["prepared_sections"][folder]
    # This is the first label-reader boundary; complete_forecasts ran above.
    inputs, labels = arrays(bound(prep["inputs"])), arrays(bound(prep["labels"]))
    old = arrays(bound(cfg["parents"][parent]["native_means"]))
    mask = control[parent]["section_id"] == folder
    if not np.array_equal(control[parent]["region_id"][mask], labels["region_id"]) or not np.array_equal(labels["region_id"], inputs["region_id"]):
        raise ValueError("exact source/control/native identity failed")
    params = readj(bound(cfg["parents"][parent]["params"]))
    scales = {"members": params["source_scales7"], "total": params["source_scale_total"]}
    outcomes = {}
    for method in (*NEW, *OLD):
        means = control[parent][method][mask] if method in NEW else old[method][mask]
        outcomes[method] = mean_evaluation(means, labels["y_counts"], inputs["roi_indices"], scales)
    return inputs, scales, outcomes


def score(config, run):
    cfg = config_values(config)
    controls = complete_forecasts(config, run)
    output = Path(run) / "score"
    if output.exists():
        raise ValueError("shared-total scoring must be fresh")
    output.mkdir()
    columns = ["parent", "section", "method", "level", "unit_id", "member", "truth_count", "predicted_mean", "source_scale", "poisson_deviance", "scaled_poisson_deviance", "absolute_error", "score_status", "D7_unscaled", "Dtotal_unscaled", "allocation_unscaled", "allocation_defined", "mean7_training_scaled_deviance"]
    summaries, count = {}, 0
    with (output / "ROWS.tsv").open("x", encoding="utf8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for section in cfg["sections"]:
            inputs, scales, outcomes = levels_for_section(cfg, None, controls, section)
            folder = section["section_folder"]
            summaries[folder] = {"parent": section["parent"], "native": {}, "ROI": {}}
            for method, outcome in outcomes.items():
                for level in ("native", "ROI"):
                    values = outcome[level]
                    summaries[folder][level][method] = section_metrics(values)
                    if method not in NEW:
                        continue
                    for index in range(len(values["programme_truth"])):
                        unit = str(inputs["region_id"][index]) if level == "native" else str(int(inputs["roi_keys"][index, 0])) + "," + str(int(inputs["roi_keys"][index, 1]))
                        for gene in range(8):
                            if gene < 7:
                                y, mu, scale = int(values["member_truth"][index, gene]), float(values["member_mean"][index, gene]), scales["members"][gene]
                                dev = float(values["member_deviance"][index, gene])
                            else:
                                y, mu, scale = int(values["programme_truth"][index]), float(values["programme_mean"][index]), scales["total"]
                                dev = float(values["programme_deviance"][index])
                            row = {"parent": section["parent"], "section": folder, "method": method, "level": level, "unit_id": unit,
                                   "member": GENES[gene] if gene < 7 else "TOTAL", "truth_count": y, "predicted_mean": mu, "source_scale": scale,
                                   "poisson_deviance": dev, "scaled_poisson_deviance": dev / scale, "absolute_error": abs(y - mu),
                                   "score_status": "finite" if math.isfinite(dev) else "positive_truth_zero_mean",
                                   "D7_unscaled": "", "Dtotal_unscaled": "", "allocation_unscaled": "", "allocation_defined": "", "mean7_training_scaled_deviance": ""}
                            if gene == 7:
                                row.update({"D7_unscaled": float(values["sum_member_deviance"][index]), "Dtotal_unscaled": dev,
                                            "allocation_unscaled": float(values["allocation_deviance"][index]) if values["allocation_defined"][index] else "",
                                            "allocation_defined": str(bool(values["allocation_defined"][index])).lower(),
                                            "mean7_training_scaled_deviance": float(values["mean_seven_scaled_deviance"][index])})
                            writer.writerow(row)
                            count += 1
    macro, parents = {}, {}
    for parent in GROUPS:
        within = [value for value in summaries.values() if value["parent"] == parent]
        parents[parent] = {level: {method: {metric: float(np.mean([value[level][method][metric] for value in within])) for metric in ("mean7_training_scaled_deviance", "mean_D7_unscaled", "mean_Dtotal_unscaled", "member_MAE", "programme_MAE")} for method in (*NEW, *OLD)} for level in ("native", "ROI")}
    for level in ("native", "ROI"):
        macro[level] = {method: {metric: float(np.mean([parents[parent][level][method][metric] for parent in GROUPS])) for metric in ("mean7_training_scaled_deviance", "mean_D7_unscaled", "mean_Dtotal_unscaled", "member_MAE", "programme_MAE")} for method in (*NEW, *OLD)}
    summary = {"status": "SHARED_TOTAL_CONTROL_SUMMARY_COMPLETE", "config_sha256": sha(config), "methods": list(NEW), "reference_methods": list(OLD),
               "source_sections": summaries, "parents": parents, "equal_parent_macro": macro, "rows": count,
               "primary": "ROI mean7 training-scaled deviance with original fold scales", "posthoc_control": True, "old_Ridge_results_preserved": True, "new_fits": 0}
    writej(output / "SUMMARY.json", summary)
    commit = {"status": "SHARED_TOTAL_CONTROL_SCORES_COMMITTED", "config_sha256": sha(config), "rows": count,
              "artifacts": {name: rec(output / name) for name in ("ROWS.tsv", "SUMMARY.json")}}
    writej(output / "SCORE_COMMIT.json", commit)
    return commit


def audit(config, run):
    cfg = config_values(config)
    controls = complete_forecasts(config, run)
    score_commit = readj(Path(run) / "score" / "SCORE_COMMIT.json")
    for item in score_commit["artifacts"].values():
        bound(item)
    sections = {item["section_folder"]: item for item in cfg["sections"]}
    expected, fallbacks = {}, {}
    for parent in GROUPS:
        old = arrays(bound(cfg["parents"][parent]["native_means"]))
        params = readj(bound(cfg["parents"][parent]["params"]))
        total = old[OLD[0]].sum(axis=1)
        fallbacks[parent] = {}
        for method, original in zip(NEW, ("memberRidge", "memberPoisson")):
            source = old[original]
            sums = source.sum(axis=1)
            fallback = (sums == 0) & (total > 0)
            fallbacks[parent][method] = int(fallback.sum())
            for row in range(len(source)):
                probability = source[row] / sums[row] if sums[row] > 0 else np.asarray(params["bundles"][OLD[0]]["fixed_composition"])
                wanted = total[row] * probability if total[row] > 0 else np.zeros(7)
                if not np.allclose(controls[parent][method][row], wanted, rtol=1e-12, atol=1e-12):
                    raise ValueError("independent reconciliation/fallback mismatch")
                if not math.isclose(float(controls[parent][method][row].sum()), float(total[row]), rel_tol=1e-12, abs_tol=1e-12):
                    raise ValueError("independent frozen shared-total identity failed")
    for folder, section in sections.items():
        parent = section["parent"]
        inputs = arrays(bound(cfg["prepared_sections"][folder]["inputs"]))
        labels = arrays(bound(cfg["prepared_sections"][folder]["labels"]))
        mask = controls[parent]["section_id"] == folder
        params = readj(bound(cfg["parents"][parent]["params"]))
        y = labels["y_counts"]
        roi_y = np.zeros((len(inputs["roi_keys"]), 7), dtype=np.int64)
        np.add.at(roi_y, inputs["roi_indices"], y)
        for method in NEW:
            mu = controls[parent][method][mask]
            roi_mu = np.zeros((len(inputs["roi_keys"]), 7))
            np.add.at(roi_mu, inputs["roi_indices"], mu)
            for level, truths, means in (("native", y, mu), ("ROI", roi_y, roi_mu)):
                for index in range(len(truths)):
                    unit = str(inputs["region_id"][index]) if level == "native" else str(int(inputs["roi_keys"][index, 0])) + "," + str(int(inputs["roi_keys"][index, 1]))
                    for gene in range(8):
                        truth = int(truths[index, gene]) if gene < 7 else sum(int(value) for value in truths[index])
                        mean = float(means[index, gene]) if gene < 7 else float(means[index].sum())
                        scale = params["source_scales7"][gene] if gene < 7 else params["source_scale_total"]
                        expected[(parent, folder, method, level, unit, GENES[gene] if gene < 7 else "TOTAL")] = (truth, mean, scale, truths[index], means[index])
    checks, infinite, seen = 0, 0, set()
    def close(value, wanted):
        value = float(value)
        if math.isinf(wanted):
            if value != wanted:
                raise ValueError("independent infinity mismatch")
        elif not math.isclose(value, wanted, rel_tol=2e-9, abs_tol=2e-10):
            raise ValueError("independent scalar count metric mismatch")
    with (Path(run) / "score" / "ROWS.tsv").open(encoding="utf8", newline="") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            key = tuple(row[name] for name in ("parent", "section", "method", "level", "unit_id", "member"))
            if key in seen or key not in expected:
                raise ValueError("missing/duplicate complete control row key")
            seen.add(key)
            truth, mean, scale, truths, means = expected[key]
            dev = independent_deviance(truth, mean)
            for name, wanted in (("truth_count", truth), ("predicted_mean", mean), ("source_scale", scale), ("poisson_deviance", dev), ("scaled_poisson_deviance", dev / scale), ("absolute_error", abs(truth - mean))):
                close(row[name], wanted)
                checks += 1
            infinite += math.isinf(dev)
            if row["member"] == "TOTAL":
                decomposition = independent_decomposition(truths, means)
                close(row["D7_unscaled"], decomposition["D7"])
                close(row["Dtotal_unscaled"], decomposition["Dtotal"])
                if truth == 0:
                    close(row["allocation_unscaled"], 0.0)
                elif decomposition["allocation_defined"]:
                    close(row["allocation_unscaled"], decomposition["allocation"])
                elif row["allocation_unscaled"] != "":
                    raise ValueError("undefined allocation must remain blank")
                close(row["mean7_training_scaled_deviance"], float(np.mean([independent_deviance(y, m) / s for y, m, s in zip(truths, means, cfg["parents"][row["parent"]]["source_scales7"])])))
                checks += 4
    if seen != set(expected) or len(seen) != score_commit["rows"] or len(seen) != 198736:
        raise ValueError("complete198736 control rows required")
    result = {"status": "INDEPENDENT_SHARED_TOTAL_CONTROL_AUDIT_PASS", "config_sha256": sha(config), "rows": len(seen), "numeric_checks": checks,
              "native_observations": 11893, "nominal_ROIs": 528, "all_seven_members_retained": True, "full_key_set_verified": True,
              "infinite_endpoint_rows_retained": infinite, "independent_fallback_rows": fallbacks,
              "shared_total_identity_verified": True, "new_fits": 0}
    writej(Path(run) / "INDEPENDENT_AUDIT.json", result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("forecast", "score", "audit"))
    parser.add_argument("--config", required=True)
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--parent")
    args = parser.parse_args()
    try:
        value = forecast(args.config, args.run_root, args.parent) if args.stage == "forecast" else score(args.config, args.run_root) if args.stage == "score" else audit(args.config, args.run_root)
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({"status": "CONTROL_STAGE_FAILED", "reason": str(error)}), flush=True)
        return 2
    print(json.dumps({"status": value["status"], "new_fits": 0}), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
