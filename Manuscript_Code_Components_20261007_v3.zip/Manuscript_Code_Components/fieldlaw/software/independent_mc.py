"""Reconstruct committed numerical MC precision using independent CDF scores.

No production scorer, estimator, sampler or data loader is imported. Inputs
are already committed count ensembles and truths supplied by the audit caller.
"""

import hashlib
import math

import numpy as np

from independent_scores import independent_count_scores

FUNCTIONS = {"ALL7": (0, 1, 2, 3, 4, 5, 6), "ACAN_COL2A1": (4, 5), "OTHER5": (0, 1, 2, 3, 6)}
LEVELS = ("50", "80", "90", "95")
EVENT = "ALL7_REGIONAL_TOTALS_POSITIVE_EVENT"


def _mean(values):
    return math.fsum(float(value) for value in values) / len(values)


def _data(gene_totals, truth, scales):
    values, observed = np.asarray(gene_totals), np.asarray(truth)
    if (values.ndim != 3 or values.shape[2] != 7 or values.shape[1] < 1
            or values.shape[0] < 32 or values.shape[0] % 16
            or observed.shape != (values.shape[1], 7)
            or values.dtype.kind not in "iu" or observed.dtype.kind not in "iu"
            or np.any(values < 0) or np.any(observed < 0)):
        raise ValueError("independent MC requires integer nonnegative M by R by seven counts, M divisible by16")
    if set(scales) != set(FUNCTIONS) or any(not math.isfinite(float(value)) or value <= 0 for value in scales.values()):
        raise ValueError("independent MC requires three fixed positive source scales")
    # Python-integer functional sums avoid an int64 overflow during auditing.
    samples, outcomes = {}, {}
    for functional, genes in FUNCTIONS.items():
        array = np.zeros(values.shape[:2], dtype=object)
        target = np.zeros(values.shape[1], dtype=object)
        for gene in genes:
            array += values[:, :, gene].astype(object)
            target += observed[:, gene].astype(object)
        samples[functional], outcomes[functional] = array, target
    events = np.all(values > 0, axis=2)
    event_truth = np.all(observed > 0, axis=1)
    return samples, outcomes, events, event_truth


def _evaluate(samples, outcomes, events, event_truth, scales, world_ids):
    vectors, summary = {}, {"functionals": {}}
    for functional, array in samples.items():
        scale = float(scales[functional])
        rows = [independent_count_scores(array[world_ids, region].tolist(), int(outcomes[functional][region]))
                for region in range(array.shape[1])]
        metric = {name: np.asarray([row[name] for row in rows], dtype=float)
                  for name in ("empirical_rps", "fair_rps", "wis", "median")}
        for name in ("empirical_rps", "fair_rps", "wis"):
            metric["scaled_" + name] = metric[name] / scale
        metric["median_absolute_error"] = np.asarray([abs(row["median"] - int(outcomes[functional][region])) for region, row in enumerate(rows)], dtype=float)
        metric["scaled_median_absolute_error"] = metric["median_absolute_error"] / scale
        intervals = {}
        for level in LEVELS:
            for name in ("lower", "upper", "left_miss", "right_miss", "width", "interval_score"):
                metric[name + "_" + level] = np.asarray([row["intervals"][level][name] for row in rows], dtype=float)
            metric["scaled_width_" + level] = metric["width_" + level] / scale
            metric["scaled_interval_score_" + level] = metric["interval_score_" + level] / scale
            metric["coverage_" + level] = 1.0 - metric["left_miss_" + level] - metric["right_miss_" + level]
            intervals[level] = {
                "nominal_coverage": int(level) / 100.0,
                "coverage": _mean(metric["coverage_" + level]),
                "left_miss_rate": _mean(metric["left_miss_" + level]),
                "right_miss_rate": _mean(metric["right_miss_" + level]),
                **{name + "_mean": _mean(metric[name + "_" + level]) for name in
                   ("width", "scaled_width", "interval_score", "scaled_interval_score")}}
        vectors[functional] = metric
        summary["functionals"][functional] = {
            **{name + "_mean": _mean(metric[name]) for name in
               ("empirical_rps", "fair_rps", "scaled_empirical_rps", "scaled_fair_rps", "wis", "scaled_wis", "median_absolute_error", "scaled_median_absolute_error")},
            "IID": True, "scenario_count": len(world_ids), "intervals": intervals}
    probability = np.asarray([sum(bool(value) for value in events[world_ids, region]) / len(world_ids)
                              for region in range(events.shape[1])])
    brier = np.asarray([(float(value) - bool(event_truth[region])) ** 2 for region, value in enumerate(probability)])
    vectors[EVENT] = {"event_probability": probability, "brier": brier}
    summary["event"] = {"brier_mean": _mean(brier), "event_probability_mean": _mean(probability),
                        "truth_event_rate": sum(bool(value) for value in event_truth) / len(event_truth)}
    return vectors, summary


def _package(group_vectors):
    stacked = {metric: np.asarray([vectors[metric] for vectors in group_vectors], dtype=float)
               for metric in group_vectors[0]}
    group_means = {metric: np.asarray([_mean(row) for row in values]) for metric, values in stacked.items()}

    def deviation_error(values):
        center = _mean(values)
        return math.sqrt(15.0 / 16.0 * math.fsum((float(value) - center) ** 2 for value in values))

    regional = {metric: np.asarray([deviation_error(values[:, region]) for region in range(values.shape[1])])
                for metric, values in stacked.items()}
    roi_means = {metric: deviation_error(values) for metric, values in group_means.items()}
    return {"delete_group_region_metric_arrays": stacked, "delete_group_roi_mean_estimates": group_means,
            "mcse_region_metrics": regional, "mcse_roi_means": roi_means}


def reconstruct_mc_precision(gene_totals, truth, source_scales):
    """Return every existing MC packet metric from independent CDF integration."""
    samples, outcomes, events, event_truth = _data(gene_totals, truth, source_scales)
    worlds = events.shape[0]
    indices = np.arange(worlds, dtype=np.int64)
    blocks = []
    for start in (0, worlds // 2):
        _, summary = _evaluate(samples, outcomes, events, event_truth, source_scales, indices[start:start + worlds // 2])
        blocks.append({"scenario_start": start, "world_count": worlds // 2, **summary})
    size = worlds // 16
    groups = [indices[start:start + size] for start in range(0, worlds, size)]
    estimates = {name: [] for name in (*FUNCTIONS, EVENT)}
    for group in groups:
        keep = np.concatenate((indices[:int(group[0])], indices[int(group[-1]) + 1:]))
        vectors, _ = _evaluate(samples, outcomes, events, event_truth, source_scales, keep)
        for name, metrics in vectors.items():
            estimates[name].append(metrics)
    return {"interpretation": "numerical Monte Carlo integration uncertainty only", "biological_confidence_interval": False,
            "two_seed_blocks": blocks, "shared_world_delete_group": {
                "group_count": 16, "group_size": size,
                "group_world_ids_sha256": [hashlib.sha256(group.astype("<i8").tobytes()).hexdigest() for group in groups],
                "membership": "consecutive world IDs; same deletion groups across every ROI, functional, law and library",
                "functionals": {name: _package(estimates[name]) for name in FUNCTIONS}, "event": _package(estimates[EVENT])}}


def verify_mc_outputs(expected_packet, actual_packet, rows, law, region_keys):
    """Compare every packet number and every generative MCSE cell; reject drift.

    Returns the number of independently checked scalar numeric values. It
    writes no files and does not modify either packet or any score row.
    """
    checks = 0

    def compare(expected, actual, path):
        nonlocal checks
        if isinstance(expected, dict):
            if not isinstance(actual, dict) or set(expected) != set(actual):
                raise ValueError("Independent MC schema mismatch: " + path)
            for key, value in expected.items():
                compare(value, actual[key], path + "." + key)
        elif isinstance(expected, np.ndarray):
            raw = np.asarray(actual)
            if raw.dtype.kind not in "iuf" or raw.shape != expected.shape:
                raise ValueError("Independent MC array/schema mismatch: " + path)
            numbers = raw.astype(float)
            if not np.isfinite(numbers).all() or not np.allclose(numbers, expected, rtol=1e-10, atol=1e-10):
                raise ValueError("Independent MC numerical mismatch: " + path)
            checks += int(numbers.size)
        elif isinstance(expected, list):
            if not isinstance(actual, list) or len(expected) != len(actual):
                raise ValueError("Independent MC list/schema mismatch: " + path)
            for index, value in enumerate(expected):
                compare(value, actual[index], path + "[" + str(index) + "]")
        elif isinstance(expected, (bool, str)):
            if type(actual) is not type(expected) or actual != expected:
                raise ValueError("Independent MC descriptor mismatch: " + path)
        else:
            if (isinstance(actual, (bool, np.bool_)) or not isinstance(actual, (int, float, np.number))
                    or not math.isfinite(float(actual))
                    or not math.isclose(float(actual), float(expected), rel_tol=1e-10, abs_tol=1e-10)):
                raise ValueError("Independent MC numerical mismatch: " + path)
            checks += 1

    compare(expected_packet, actual_packet, law + ".mc_precision")
    groups = expected_packet["shared_world_delete_group"]
    lookup = {}
    for row in rows:
        if row["law"] != law:
            continue
        if row["diagnostic"] != "NONE":
            if any(key.startswith("mcse_") and value != "" for key, value in row.items()):
                raise ValueError("Independent MC diagnostic rows cannot contain generative MCSE")
            continue
        key = (row["functional"], int(row["roi_x"]), int(row["roi_y"]))
        if key in lookup or row["permutation_seed"] != "":
            raise ValueError("Independent MC row/schema mismatch: duplicated or seeded generative row")
        lookup[key] = row
    expected_keys = set()
    for functional in (*FUNCTIONS, EVENT):
        packet = groups["event"] if functional == EVENT else groups["functionals"][functional]
        for region, key in enumerate(np.asarray(region_keys)):
            row_key = (functional, int(key[0]), int(key[1]))
            expected_keys.add(row_key)
            if row_key not in lookup:
                raise ValueError("Independent MC row/schema mismatch: missing complete ROI")
            row = lookup[row_key]
            for metric, errors in packet["mcse_region_metrics"].items():
                name = "mcse_" + metric
                try:
                    actual = float(row[name])
                except (KeyError, ValueError, TypeError):
                    raise ValueError("Independent MC row/schema mismatch: " + name) from None
                compare(float(errors[region]), actual, law + ".ROWS." + str(row_key) + "." + name)
    if set(lookup) != expected_keys:
        raise ValueError("Independent MC row/schema mismatch: unexpected generative ROI/functional")
    return checks
