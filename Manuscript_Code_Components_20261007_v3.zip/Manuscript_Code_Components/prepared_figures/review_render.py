"""Independent PDF render and padded row/gutter crops; no visual PASS assigned."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
from PIL import Image


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--figure-dir', type=Path, default=Path(__file__).resolve().parent / 'output')
    parser.add_argument('--qa-dir', type=Path, default=Path(__file__).resolve().parent / 'qa')
    parser.add_argument('--pdftoppm', default='pdftoppm')
    args = parser.parse_args()
    args.qa_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for number in [9, 10, 11]:
        name = f'SupplementaryFigure{number}'
        png, pdf = args.figure_dir / (name + '.png'), args.figure_dir / (name + '.pdf')
        with Image.open(png) as img:
            assert img.size == (2881, 3464)
            w, h = img.size
            bands = [(0, 930), (820, 1700), (1580, 2520), (2390, h)] if number < 11 else [(0, 940), (770, 1780), (1470, 2300), (2190, h)]
            for index, (top, bottom) in enumerate(bands):
                crop = args.qa_dir / f'{name}_band{index + 1}.png'
                img.crop((0, top, w, bottom)).save(crop)
                records.append(dict(source=png.name, source_sha256=sha(png), crop=crop.name,
                    crop_sha256=sha(crop), box=[0, top, w, bottom], status='CROP_GENERATED_NOT_VISUALLY_REVIEWED'))
                # Overlap the centre gutter, and keep each width below 2048 px
                # so the inspection interface can display original resolution.
                for side, (left, right) in [('left', (0, 1540)), ('right', (1340, w))]:
                    full_res = args.qa_dir / f'{name}_band{index + 1}_{side}.png'
                    img.crop((left, top, right, bottom)).save(full_res)
                    records.append(dict(source=png.name, source_sha256=sha(png), crop=full_res.name,
                        crop_sha256=sha(full_res), box=[left, top, right, bottom],
                        status='ORIGINAL_RESOLUTION_CROP_GENERATED_NOT_VISUALLY_REVIEWED'))
                if number == 11 and index < 2:
                    middle = args.qa_dir / f'{name}_band{index + 1}_middle.png'
                    img.crop((900, top, 1980, bottom)).save(middle)
                    records.append(dict(source=png.name, source_sha256=sha(png), crop=middle.name,
                        crop_sha256=sha(middle), box=[900, top, 1980, bottom],
                        status='ORIGINAL_RESOLUTION_CROP_GENERATED_NOT_VISUALLY_REVIEWED'))
        command = [args.pdftoppm, '-r', '200', '-png', '-singlefile', str(pdf), str(args.qa_dir / (name + '_PDF'))]
        result = subprocess.run(command, capture_output=True, text=True, timeout=120)
        assert result.returncode == 0, result.stderr
        render = args.qa_dir / (name + '_PDF.png')
        records.append(dict(source=pdf.name, source_sha256=sha(pdf), render=render.name,
            render_sha256=sha(render), external_renderer='Poppler pdftoppm -r 200 -png -singlefile',
            actual_process_returncode=result.returncode, status='TECHNICAL_RENDER_PASS_NOT_VISUAL_PASS'))
    (args.qa_dir / 'REVIEW_WINDOWS.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8')
    print('Generated 12 padded original-resolution PNG bands and three independent Poppler PDF renders. Visual review remains pending.')


if __name__ == '__main__':
    main()
