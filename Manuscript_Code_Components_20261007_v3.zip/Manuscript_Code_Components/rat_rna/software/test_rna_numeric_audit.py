import math
import unittest
from rna_numeric_audit import independent_deviance

class RNAAuditTests(unittest.TestCase):
    def test_nearly_equal_positive_means_have_positive_second_order_loss(self):
        value = independent_deviance(1000, 1000.00001)
        self.assertTrue(math.isclose(value, 9.99999988e-14, rel_tol=1e-6, abs_tol=0))

    def test_literal_poisson_zero_and_equal_mean_limits(self):
        self.assertEqual(independent_deviance(0, 2), 4)
        self.assertEqual(independent_deviance(2, 2), 0)
        self.assertEqual(independent_deviance(0, 0), 0)
        self.assertTrue(math.isinf(independent_deviance(2, 0)))

    def test_full_member_deviance_separates_total_and_allocation_without_zero_floor(self):
        from rna_numeric_audit import independent_decomposition
        result = independent_decomposition([1, 1], [2, 2])
        self.assertAlmostEqual(result['D7'], 4 * (1-math.log(2)))
        self.assertAlmostEqual(result['Dtotal'], result['D7'])
        self.assertEqual(result['allocation'], 0)
        empty = independent_decomposition([0, 0], [0, 0])
        self.assertEqual(empty['D7'], 0)
        self.assertIsNone(empty['allocation'])

if __name__ == '__main__':
    unittest.main()
