"""Committed integer-count ensemble scores; no training or scenario generation."""
import csv
import hashlib
import json
import math
from pathlib import Path
import numpy as np

LAWS=("FULLY_FACTORIZED_ATOMS","TRUE_ALL_ATOM_GLOBAL_FACTOR_RHO025","RBF_INDEPENDENT_GENE_FIELDS","RBF_FIXED_GENE_RHO025","RBF_POOLED_SOURCE_PIT_CORR")
FUNCTIONALS={"TBXT":[0],"KRT8":[1],"KRT18":[2],"KRT19":[3],"ACAN":[4],"COL2A1":[5],"SOX9":[6],
             "ALL7":[0,1,2,3,4,5,6],"ACAN_COL2A1":[4,5],"OTHER5":[0,1,2,3,6]}
LEVELS=(50,80,90,95)
MAX_INT=np.iinfo(np.int64).max


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _load(value):
    if isinstance(value,dict):
        digest=hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":")).encode()).hexdigest()
        return value,digest
    path=Path(value)
    return json.loads(path.read_text(encoding="utf-8-sig")),_sha(path)


def _write(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")


def _counts(value,label):
    array=np.asarray(value)
    if array.dtype.kind not in "iu" or np.any(array<0) or np.any(array>MAX_INT):
        raise ValueError(label+" exactnonnegativeint64countsupportrequired; nofloor")
    return array.astype(np.int64,copy=False)


def _sum_columns(array,columns):
    if len(columns)==1:
        return array[...,columns[0]]
    # Exact integer sums; reject actual overflow, never cap valid count support.
    wide=np.sum(array[...,columns].astype(object),axis=-1)
    if any(int(value)>MAX_INT for value in wide.flat):
        raise ValueError("COUNT_FUNCTIONAL_OVERFLOW")
    return np.asarray(wide,dtype=np.int64)


def _deviance(y,mean):
    if y==0:
        return 2.*mean
    if mean==0:
        return math.inf
    delta=(mean-y)/y
    if abs(delta)<=1e-3:
        term=delta*delta
        value=0.
        for n in range(2,21):
            value+=((-1.)**n)*term/n
            term*=delta
    else:
        value=delta-math.log1p(delta)
    result=2.*y*value
    if result<0 or not math.isfinite(result):
        raise ValueError("COUNT_MEAN_DEVIANCE_NUMERIC_INTEGRITY")
    return result


def _number(value):
    if math.isfinite(value):
        return float(value)
    if value==math.inf:
        return "+infinity"
    raise ValueError("undefinedmetric")


def _count_metrics(samples,y,mean,scale):
    values=sorted(int(value) for value in samples)
    M=len(values)
    if M<2:
        raise ValueError("fairRPSrequiresatleast2worlds")
    A=sum(abs(value-y) for value in values)
    P=sum((2*index-M+1)*value for index,value in enumerate(values))
    fair_numerator=A*(M-1)-P
    empirical_numerator=A*M-P
    if fair_numerator<0 or empirical_numerator<0 or P<0:
        raise ValueError("EXACT_INTEGER_RPS_NEGATIVE_INTEGRITY_FAILURE")
    fair=fair_numerator/(M*(M-1))
    empirical=empirical_numerator/(M*M)
    result={"truth_count":y,"theoretical_mean":mean,"measured_mass":y,"expected_mass":mean,
            "absolute_error":abs(mean-y),"scaled_absolute_error":abs(mean-y)/scale,
            "poisson_deviance":_number(_deviance(y,mean)),"scaled_deviance":_number(_deviance(y,mean)/scale),
            "fair_rps":fair,"scaled_fair_rps":fair/scale,"empirical_rps":empirical,"scaled_empirical_rps":empirical/scale,
            "fair_numerator":str(fair_numerator),"fair_denominator":M*(M-1),
            "empirical_numerator":str(empirical_numerator),"empirical_denominator":M*M}
    def quantile(numerator,denominator):
        index=(M*numerator+denominator-1)//denominator-1
        return values[index]
    median=quantile(1,2)
    wis=.5*abs(y-median)
    for level in LEVELS:
        alpha=(100-level)/100.
        low=quantile(100-level,200)
        high=quantile(100+level,200)
        width=high-low
        lower_miss=int(y<low)
        upper_miss=int(y>high)
        interval_score=width+2/alpha*(low-y)*lower_miss+2/alpha*(y-high)*upper_miss
        result.update({"lower"+str(level):low,"upper"+str(level):high,
                       "coverage"+str(level):int(not lower_miss and not upper_miss),
                       "lower_miss"+str(level):lower_miss,"upper_miss"+str(level):upper_miss,
                       "width"+str(level):width,"IS"+str(level):interval_score})
        wis+=alpha/2*interval_score
    result["IS90"]=result["IS90"]
    result["scaled_IS90"]=result["IS90"]/scale
    result["WIS"]=wis/4.5
    result["scaled_WIS"]=result["WIS"]/scale
    return result


def _event_metrics(events,observed):
    M=len(events)
    k=sum(bool(value) for value in events)
    opposite=k if not observed else M-k
    numerator=opposite*(opposite-1)
    if numerator<0:
        raise ValueError("EXACT_FACTORIAL_BRIER_NEGATIVE_INTEGRITY")
    return {"observed_event":int(observed),"positive_scenarios":k,"worlds":M,"probability":k/M,
            "fair_brier":numerator/(M*(M-1)),"empirical_brier":(opposite*opposite)/(M*M),
            "fair_brier_numerator":str(numerator),"fair_brier_denominator":M*(M-1),
            "empirical_brier_numerator":str(opposite*opposite),"empirical_brier_denominator":M*M}


def _hierarchy(rows,metric):
    sections={}
    parents={}
    for row in rows:
        sections.setdefault((row["parent"],row["section_capture"]),[]).append(row[metric])
    for (parent,capture),values in sections.items():
        if any(value=="+infinity" for value in values):
            average="+infinity"
        else:
            average=float(np.mean(values))
        parents.setdefault(parent,[]).append(average)
    result={}
    for parent,values in parents.items():
        result[parent]="+infinity" if "+infinity" in values else float(np.mean(values))
    macro="+infinity" if "+infinity" in result.values() else float(np.mean(list(result.values())))
    return {"embryos":result,"macro":macro}


def _jackknife_MCSE(values):
    array=np.asarray(values,dtype=float)
    if not np.isfinite(array).all():
        raise ValueError("MC_PACKET_NONFINITE_INTEGRITY")
    differences=array-array[0]
    centred=differences-differences.mean()
    return float(np.sqrt((len(array)-1)/len(array)*np.sum(centred*centred)))


def _precision(data,count_rows,event_rows,M):
    if M%16 or M//2<2:
        raise ValueError("16equaldeletegroups_and_twohalves_require_worldsdivisible16")
    count_metrics=["fair_rps","scaled_fair_rps","empirical_rps","scaled_empirical_rps","IS90","scaled_IS90","WIS","scaled_WIS"]
    count_metrics += [name+str(level) for level in LEVELS for name in ("coverage","lower_miss","upper_miss","width")]
    event_metrics=["probability","fair_brier","empirical_brier"]
    metric_groups={}
    primary_sections={}
    count_lookup={(r["section_capture"],r["law"],r["functional"],r["roi_x"],r["roi_y"]):r for r in count_rows}
    event_lookup={(r["section_capture"],r["law"],r["roi_x"],r["roi_y"]):r for r in event_rows}
    block=M//16
    masks=[]
    for group in range(16):
        keep=np.ones(M,dtype=bool)
        keep[group*block:(group+1)*block]=False
        masks.append(keep)
    halves=[np.arange(0,M//2),np.arange(M//2,M)]
    subsets=masks+halves
    for (capture,law),(samples,measured,means,keys,parent) in data.items():
        for functional,columns in FUNCTIONALS.items():
            values=_sum_columns(samples,columns)
            observed=_sum_columns(measured,columns)
            expected=means[:,columns].sum(axis=1)
            scale=count_lookup[(capture,law,functional,int(keys[0,0]),int(keys[0,1]))]["scale"]
            roi_replicates={metric:np.empty((18,len(keys))) for metric in count_metrics}
            for roi,key in enumerate(keys):
                for index,subset in enumerate(subsets):
                    packet=_count_metrics(values[subset,roi],int(observed[roi]),float(expected[roi]),scale)
                    for metric in count_metrics:
                        roi_replicates[metric][index,roi]=packet[metric]
                row=count_lookup[(capture,law,functional,int(key[0]),int(key[1]))]
                for metric in count_metrics:
                    row["mcse_"+metric]=_jackknife_MCSE(roi_replicates[metric][:16,roi])
            for metric in count_metrics:
                vectors=roi_replicates[metric].mean(axis=1)
                metric_groups.setdefault((law,functional,metric),[]).append((parent,capture,vectors))
                if functional=="ALL7" and metric=="scaled_fair_rps":
                    primary_sections[(capture,law)]=vectors
        events=np.all(samples>0,axis=2)
        observed_events=np.all(measured>0,axis=1)
        event_replicates={metric:np.empty((18,len(keys))) for metric in event_metrics}
        for roi,key in enumerate(keys):
            for index,subset in enumerate(subsets):
                packet=_event_metrics(events[subset,roi],observed_events[roi])
                for metric in event_metrics:
                    event_replicates[metric][index,roi]=packet[metric]
            row=event_lookup[(capture,law,int(key[0]),int(key[1]))]
            for metric in event_metrics:
                row["mcse_"+metric]=_jackknife_MCSE(event_replicates[metric][:16,roi])
        for metric in event_metrics:
            vectors=event_replicates[metric].mean(axis=1)
            metric_groups.setdefault((law,"ALL7_REGIONAL_MEMBERS_POSITIVE_EVENT",metric),[]).append((parent,capture,vectors))
    result={"enabled":True,"delete_groups":16,"group_world_count":block,"delete_group_worlds":M-block,
            "halves":[[0,M//2],[M//2,M]],"paired_common_groups_all_sections_ROIs":True,"biological_CI":False,
            "new_worlds":0,"laws":{law:{} for law in LAWS},"paired_primary":{}}
    for (law,functional,metric),sections in metric_groups.items():
        by_parent={}
        for parent,capture,vector in sections:
            by_parent.setdefault(parent,[]).append(vector)
        parent_vectors={p:np.mean(v,axis=0) for p,v in by_parent.items()}
        macro=np.mean(list(parent_vectors.values()),axis=0)
        result["laws"][law].setdefault(functional,{})[metric]={
            "delete_group_macro":macro[:16].tolist(),"half_world_macro":macro[16:].tolist(),
            "MCSE":_jackknife_MCSE(macro[:16]),
            "embryos":{p:{"delete_group":v[:16].tolist(),"halves":v[16:].tolist(),"MCSE":_jackknife_MCSE(v[:16])}
                       for p,v in parent_vectors.items()}}
    candidate=LAWS[4]
    for reference in (LAWS[1],LAWS[3]):
        candidate_packet=result["laws"][candidate]["ALL7"]["scaled_fair_rps"]
        reference_packet=result["laws"][reference]["ALL7"]["scaled_fair_rps"]
        differences=np.asarray(reference_packet["delete_group_macro"])-np.asarray(candidate_packet["delete_group_macro"])
        base_candidate=_hierarchy([r for r in count_rows if r["law"]==candidate and r["functional"]=="ALL7"],"scaled_fair_rps")
        base_reference=_hierarchy([r for r in count_rows if r["law"]==reference and r["functional"]=="ALL7"],"scaled_fair_rps")
        improvement=base_reference["macro"]-base_candidate["macro"]
        mcse=_jackknife_MCSE(differences)
        embryo_improvement={p:base_reference["embryos"][p]-base_candidate["embryos"][p] for p in base_candidate["embryos"]}
        percent=None if base_reference["macro"]<=0 else 100*improvement/base_reference["macro"]
        result["paired_primary"][reference]={"candidate":candidate,"reference":reference,
            "improvement_scaled_fair_RPS":improvement,"relative_improvement_percent":percent,
            "delete_group_improvement":differences.tolist(),"paired_MCSE":mcse,
            "numerical95_band":[improvement-1.96*mcse,improvement+1.96*mcse],
            "embryo_improvement":embryo_improvement,
            "one_percent_descriptive_positive":percent is not None and percent>=1 and all(v>0 for v in embryo_improvement.values()) and improvement-1.96*mcse>0,
            "gene_correlation_attribution_only":reference==LAWS[3]}
        embryo_packets={}
        for parent in embryo_improvement:
            ref_values=reference_packet["embryos"][parent]["delete_group"]
            cand_values=candidate_packet["embryos"][parent]["delete_group"]
            diff=np.asarray(ref_values)-np.asarray(cand_values)
            error=_jackknife_MCSE(diff)
            effect=embryo_improvement[parent]
            embryo_packets[parent]={"delete_group_improvement":diff.tolist(),"paired_MCSE":error,
                                    "numerical95_band":[effect-1.96*error,effect+1.96*error]}
        result["paired_primary"][reference]["embryo_paired_precision"]=embryo_packets
    result["descriptive_continuation_signal"]=all(packet["one_percent_descriptive_positive"] for packet in result["paired_primary"].values())
    result["signal_not_GB_or_population_test"]=True
    return result

def score_committed_joint_forecasts(frozen_config,forecast_commit,truth_commit,fresh_output):
    config,config_sha=_load(frozen_config)
    forecast,forecast_sha=_load(forecast_commit)
    truth,truth_sha=_load(truth_commit)
    output=Path(fresh_output).resolve()
    if output.exists():
        raise ValueError("newscoreoutputrequired")
    M=int(config["M"])
    if config["mode"] not in ("SYNTHETIC_JOINT_SCORE_V1","FROZEN_JOINT_SCORE_V1") or M<2 or (config["mode"]=="FROZEN_JOINT_SCORE_V1" and M!=2048):
        raise ValueError("frozenworldcount/modeinvalid")
    scales=config["source_scales"]
    if set(scales)!=set(FUNCTIONALS) or any(not math.isfinite(float(s)) or float(s)<1 for s in scales.values()):
        raise ValueError("frozencomplete10sourcecountscalesrequired")
    section_ids=[section["capture"] for section in config["sections"]]
    if len(section_ids)!=len(set(section_ids)) or not section_ids:
        raise ValueError("GLOBAL_COMMIT_INCOMPLETE: uniqueexpectedsectionsrequired")
    if (forecast.get("status")!="GLOBAL_FORECAST_COMMITTED" or truth.get("status")!="GLOBAL_TRUTH_COMMITTED"
        or forecast.get("complete") is not True or truth.get("complete") is not True
        or forecast.get("external_exit_code")!=0 or truth.get("external_exit_code")!=0 or forecast.get("M")!=M
        or set(forecast.get("sections",{}))!=set(section_ids) or set(truth.get("sections",{}))!=set(section_ids)):
        raise ValueError("GLOBAL_COMMIT_INCOMPLETE: allforecast/truth/exitbarriersrequiredbeforearrayaccess")
    for section in config["sections"]:
        capture,parent=section["capture"],section["parent"]
        fsection,tsection=forecast["sections"][capture],truth["sections"][capture]
        if parent not in ("E1","E3") or fsection.get("parent")!=parent or tsection.get("parent")!=parent or set(fsection.get("laws",{}))!=set(LAWS):
            raise ValueError("GLOBAL_COMMIT_INCOMPLETE: fivefull-lawsectionsrequiredbeforearrayaccess")
    if config["mode"]=="FROZEN_JOINT_SCORE_V1":
        expected={"GSM"+str(n) for n in range(7605361,7605375)}
        if set(section_ids)!=expected or sum(s["parent"]=="E1" for s in config["sections"])!=10 or sum(s["parent"]=="E3" for s in config["sections"])!=4 or config.get("mc_precision") is not True:
            raise ValueError("GLOBAL_COMMIT_INCOMPLETE: actual14sections/2embryos/MCcontractrequired")
        scale_binding=config.get("source_scale_binding")
        evaluation_binding=config.get("evaluation_contract_binding")
        if not scale_binding or not evaluation_binding:
            raise ValueError("GLOBAL_COMMIT_INCOMPLETE: frozenSOURCEscale/evaluationbindingsrequired")
        if _sha(scale_binding["path"])!=scale_binding["sha256"] or _sha(evaluation_binding["path"])!=evaluation_binding["sha256"]:
            raise ValueError("frozenSOURCEscale/evaluationhashchanged")
        source_scale_document,_=_load(scale_binding["path"])
        evaluation_document,_=_load(evaluation_binding["path"])
        if source_scale_document.get("status")!="SOURCE_ONLY_SCORE_SCALES_FROZEN" or source_scale_document["scales"]!=scales or source_scale_document["functionals"]!=FUNCTIONALS or evaluation_document["required_laws"]!=list(LAWS) or evaluation_document["count_functionals"]!=FUNCTIONALS:
            raise ValueError("frozenSOURCEscale/law/functionalcontractchanged")
        if any("roi_keys" not in section for section in config["sections"]):
            raise ValueError("GLOBAL_COMMIT_INCOMPLETE: frozencompleteROIkeysetsrequired")
    if truth["forecast_commit_sha256"]!=forecast_sha:
        raise ValueError("truthnotboundtotheforecastcommit")
    count_rows,event_rows=[],[]
    data={}
    for section in config["sections"]:
        capture,parent=section["capture"],section["parent"]
        truth_record=truth["sections"][capture]
        tpath=Path(truth_record["path"])
        if _sha(tpath)!=truth_record["sha256"]:
            raise ValueError("truthhashmismatch")
        with np.load(tpath,allow_pickle=False) as archive:
            measured=_counts(archive["gene_region_truth"],"truth")
            keys=_counts(archive["roi_keys"],"ROIkeys")
        if measured.ndim!=2 or measured.shape[1]!=7 or keys.shape!=(len(measured),2):
            raise ValueError("completetruthROI/sevenshapeinvalid")
        if len({tuple(key) for key in keys.tolist()})!=len(keys) or not np.array_equal(keys,np.asarray(sorted(keys.tolist()),dtype=np.int64)):
            raise ValueError("frozenROIkeysnotunique/canonical")
        if "roi_keys" in section and keys.tolist()!=section["roi_keys"]:
            raise ValueError("frozencompleteROIkeysetchanged;nomasks")
        reference_mean=None
        for law in LAWS:
            record=forecast["sections"][capture]["laws"][law]
            path=Path(record["path"])
            if _sha(path)!=record["sha256"]:
                raise ValueError("forecasthashmismatch")
            with np.load(path,allow_pickle=False) as archive:
                samples=_counts(archive["gene_region_totals"],"samples")
                means=np.asarray(archive["gene_region_means"],dtype=float)
                fkeys=_counts(archive["roi_keys"],"forecastROIkeys")
            if samples.shape!=(M,len(measured),7) or means.shape!=measured.shape or not np.array_equal(keys,fkeys) or not np.isfinite(means).all() or np.any(means<0):
                raise ValueError("frozenwholeROI/world/seven/meanalignmentfailed")
            if reference_mean is None:
                reference_mean=means.copy()
            elif not np.array_equal(reference_mean,means):
                raise ValueError("marginaltheoreticalmeanschangedbetweenlaws")
            data[(capture,law)]=(samples,measured,means,keys,parent)
            for functional,columns in FUNCTIONALS.items():
                values=_sum_columns(samples,columns)
                observed=_sum_columns(measured,columns)
                expectations=means[:,columns].sum(axis=1)
                scale=float(scales[functional])
                for roi,key in enumerate(keys):
                    metrics=_count_metrics(values[:,roi],int(observed[roi]),float(expectations[roi]),scale)
                    count_rows.append({"section_capture":capture,"parent":parent,"roi_x":int(key[0]),"roi_y":int(key[1]),
                                       "law":law,"functional":functional,"scale":scale,**metrics})
            events=np.all(samples>0,axis=2)
            observed_events=np.all(measured>0,axis=1)
            for roi,key in enumerate(keys):
                event_rows.append({"section_capture":capture,"parent":parent,"roi_x":int(key[0]),"roi_y":int(key[1]),
                                   "law":law,**_event_metrics(events[:,roi],observed_events[roi])})
    summary={"mode":config["mode"],"source_scales":scales,"count_score_rows":len(count_rows),"event_score_rows":len(event_rows),
             "laws":{},"MC_precision":{"enabled":False,"reason":"notyetcomputed_for_two_world_literal"},
             "marginal_attribution":"OnlythreeRBFbanks matchedoneGeneK;trueglobal/atomfactorizationbroaderutility"}
    count_keys={(r["section_capture"],r["roi_x"],r["roi_y"],r["law"],r["functional"]) for r in count_rows}
    event_keys={(r["section_capture"],r["roi_x"],r["roi_y"],r["law"]) for r in event_rows}
    if len(count_keys)!=len(count_rows) or len(event_keys)!=len(event_rows):
        raise ValueError("duplicatecomplete-scorekeys")
    if config["mode"]=="FROZEN_JOINT_SCORE_V1" and (len(count_rows)!=55500 or len(event_rows)!=5550):
        raise ValueError("all14/all1110ROI/all5/all10count/eventscorecoveragefailed")
    for law in LAWS:
        summary["laws"][law]={}
        for functional in FUNCTIONALS:
            rows=[r for r in count_rows if r["law"]==law and r["functional"]==functional]
            summary["laws"][law][functional]={metric:_hierarchy(rows,metric) for metric in
                ("fair_rps","scaled_fair_rps","empirical_rps","scaled_empirical_rps","IS90","scaled_IS90","WIS","scaled_WIS",
                 "absolute_error","scaled_absolute_error","poisson_deviance","scaled_deviance")}
            for level in LEVELS:
                for metric in ("coverage","lower_miss","upper_miss","width"):
                    name=metric+str(level)
                    summary["laws"][law][functional][name]=_hierarchy(rows,name)
        summary["laws"][law]["ALL7_REGIONAL_MEMBERS_POSITIVE_EVENT"]={metric:_hierarchy([r for r in event_rows if r["law"]==law],metric)
                                                                       for metric in ("fair_brier","empirical_brier")}
    if config.get("mc_precision"):
        summary["MC_precision"]=_precision(data,count_rows,event_rows,M)
    output.mkdir()
    for name,rows in (("COUNT_ROWS.tsv",count_rows),("EVENT_ROWS.tsv",event_rows)):
        with (output/name).open("w",newline="",encoding="utf-8") as handle:
            writer=csv.DictWriter(handle,fieldnames=list(rows[0]),delimiter="\t")
            writer.writeheader();writer.writerows(rows)
    _write(output/"SCORES.json",summary)
    commit={"status":"COMPLETE_JOINT_COUNT_AND_EVENT_SCORES","count_score_rows":len(count_rows),"event_score_rows":len(event_rows),
            "forecast_commit_sha256":forecast_sha,"truth_commit_sha256":truth_sha,"config_sha256":config_sha,
            "worlds":M,"functionals":list(FUNCTIONALS),"laws":list(LAWS),
            "artifacts":{p.name:{"path":str(p),"sha256":_sha(p)} for p in output.glob("*") if p.is_file()},
            "external_exit_receipt_required_separately":True}
    _write(output/"SCORE_COMMIT.json",commit)
    return commit
