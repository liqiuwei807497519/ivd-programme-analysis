suppressPackageStartupMessages(library(rtracklayer))
base <- "../../human_npc_chic_20260910"
regions <- read.delim(file.path(base,"REGIONS.tsv"),stringsAsFactors=FALSE,check.names=FALSE)
regions$chrom <- as.character(regions$chrom)
tracks <- read.delim(file.path(base,"TRACKS.tsv"),stringsAsFactors=FALSE)
results <- list()
for(k in seq_len(nrow(tracks))) {
  f <- BigWigFile(tracks$name[k])
  lengths <- seqlengths(seqinfo(f))
  stopifnot(all(regions$chrom %in% names(lengths)))
  starts <- pmax(1L,regions$start1_requested)
  ends <- pmin(regions$end1_requested,as.integer(lengths[regions$chrom]))
  stopifnot(all(ends>=starts))
  q <- GRanges(regions$chrom,IRanges(starts,ends))
  z <- import(f,which=reduce(q),as="GRanges")
  stopifnot(all(is.finite(z$score)),!anyDuplicated(paste(seqnames(z),start(z),end(z))))
  hits <- findOverlaps(q,z,ignore.strand=TRUE)
  qi <- queryHits(hits);zi <- subjectHits(hits)
  width_hit <- pmin(end(q)[qi],end(z)[zi])-pmax(start(q)[qi],start(z)[zi])+1L
  stopifnot(all(width_hit>0))
  covered <- numeric(length(q));integral <- numeric(length(q))
  for(i in seq_along(qi)) {
    covered[qi[i]] <- covered[qi[i]]+width_hit[i]
    integral[qi[i]] <- integral[qi[i]]+width_hit[i]*z$score[zi[i]]
  }
  stopifnot(all(covered<=width(q)))
  mean_covered <- ifelse(covered>0,integral/covered,NA_real_)
  res <- data.frame(donor=tracks$donor[k],regions,start1=starts,end1=ends,
                    truncated=starts!=regions$start1_requested|ends!=regions$end1_requested,
                    covered_bases=covered,coverage_fraction=covered/width(q),integral=integral,mean_covered=mean_covered)
  results[[k]]<-res
  raw <- data.frame(chrom=as.character(seqnames(z)),start1=start(z),end1=end(z),score=z$score)
  write.table(raw,file.path(base,paste0("donor",tracks$donor[k],"_intervals.tsv")),sep="\t",row.names=FALSE,quote=FALSE,na="NA")
  write.table(data.frame(chrom=names(lengths),length=as.integer(lengths)),file.path(base,paste0("donor",tracks$donor[k],"_chromosomes.tsv")),sep="\t",row.names=FALSE,quote=FALSE)
  cat("DONOR",tracks$donor[k],"intervals",nrow(raw),"regions",nrow(res),"uncovered",sum(covered==0),"\n")
}
write.table(do.call(rbind,results),file.path(base,"REGION_RESULTS.tsv"),sep="\t",row.names=FALSE,quote=FALSE,na="NA")
writeLines(capture.output(sessionInfo()),file.path(base,"R_SESSION.txt"))
