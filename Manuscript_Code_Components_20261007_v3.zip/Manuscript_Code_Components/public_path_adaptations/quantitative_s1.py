# Public path adaptation: help/description precedes all original scientific imports.
import argparse as _public_argparse
import json as _public_json
from pathlib import Path as _PublicPath
import sys as _public_sys
_public_description = {'purpose': 'path-interface description; no scientific execution', 'required_bindings': ['output_root', 'project_root', 'source_root', 'style_root'], 'expected_layout': 'source-root: lawful complete committed RNA run including FINAL_COMPLETE.json, RUN_CONFIG.json, prepared and audit files. style-root/multiomics_style.py; output-root must be an explicitly prepared empty directory.', 'data_reads': 0, 'heavy_imports': 0, 'original_scientific_body_preserved_except_declared_path_assignment_values': True}
_public_parser = _public_argparse.ArgumentParser(description="Original analysis with explicit caller-owned paths; no data are bundled.")
_public_parser.add_argument('--describe-inputs', action='store_true', help='Print input layout and exit before imports/data access')
for _public_key in _public_description['required_bindings']:
    _public_parser.add_argument('--'+_public_key.replace('_','-'))
_public_args = _public_parser.parse_args()
if _public_args.describe_inputs:
    print(_public_json.dumps(_public_description))
    raise SystemExit(0)
for _public_key in _public_description['required_bindings']:
    if getattr(_public_args,_public_key) is None:
        _public_parser.error('Required binding: --'+_public_key.replace('_','-'))
def _public_binding(_public_key):
    return _PublicPath(getattr(_public_args,_public_key)).expanduser().resolve()
# Begin the preserved original body. Only declared path-assignment values differ.
"""Quantitative-only S1: complete measured seven-member native detectability."""
from pathlib import Path
import csv
import hashlib
import json
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, Normalize
from PIL import Image
import fitz

OUT=_public_binding('output_root')
WORKSPACE=_public_binding('project_root')
RUN=_public_binding('source_root')
STYLE=_public_binding('style_root')
sys.path.insert(0,str(STYLE))
from multiomics_style import configure_matplotlib,save_figure
GENES=['TBXT','KRT8','KRT18','KRT19','ACAN','COL2A1','SOX9']
PAGE_W,PAGE_H=183,220
BOUNDS={'A':(19,166,39,43),'B':(68,166,48,43),'C':(128,166,48,43),
        'D':(8,101,48,43),'E':(68,101,48,43),'F':(128,101,48,43),
        'G':(8,36,48,43),'H':(68,36,48,43),'I':(128,36,48,43)}

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def readj(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def verify(record):
    path=Path(record['path'])
    if sha(path)!=record['sha256']:raise ValueError('Committed source changed: '+str(path))
    return path

def writej(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')

def table(name,rows):
    with (OUT/name).open('w',encoding='utf8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def prepare_sources():
    final=readj(RUN/'FINAL_COMPLETE.json')
    if final['status']!='RNA_SOURCE_COMPARISON_COMPLETE':raise ValueError('Completed audited run required')
    audit=readj(verify(final['independent_audit']))
    if audit['status']!='RNA_INDEPENDENT_AUDIT_PASS':raise ValueError('Independent complete source audit required')
    config_path=RUN/'RUN_CONFIG.json';config=readj(config_path)
    if sha(config_path)!=final['config_sha256']:raise ValueError('Completed config binding differs')
    prepare_path=RUN/'prepared/PREPARE_COMMIT.json';prepared=readj(prepare_path)
    if prepared['config_sha256']!=final['config_sha256'] or prepared['observations']!=11893:
        raise ValueError('Complete prepared source binding required')
    if [r['frozen_symbol'] for r in config['ordered_roles'][-7:]]!=GENES:
        raise ValueError('Fixed seven resident members must retain exact order')
    sources={str(config_path):sha(config_path),str(prepare_path):sha(prepare_path),
             final['independent_audit']['path']:final['independent_audit']['sha256'],
             str(RUN/'FINAL_COMPLETE.json'):sha(RUN/'FINAL_COMPLETE.json')}
    sections=[];native=[];distributions=[];member=[]
    for declared in config['sections']:
        folder=declared['section_folder'];item=prepared['sections'][folder]
        descriptors=item['artifacts'];paths={key:verify(record) for key,record in descriptors.items()}
        sources.update({str(paths[key]):descriptors[key]['sha256'] for key in paths})
        with np.load(paths['INPUTS.npz'],allow_pickle=False) as archive:
            data={key:archive[key] for key in ['region_id','barcode','coords_um']}
        with np.load(paths['SOURCE_LABELS.npz'],allow_pickle=False) as archive:
            if not np.array_equal(archive['region_id'],data['region_id']) or not np.array_equal(archive['barcode'],data['barcode']):
                raise ValueError('Exact canonical source input/label pairing required')
            counts=archive['y_counts']
        n=declared['expected_rows']
        if counts.shape!=(n,7) or counts.dtype.kind not in 'iu' or np.any(counts<0) or len(data['region_id'])!=n:
            raise ValueError('Complete integer seven-member native source required')
        detected=(counts>0).sum(axis=1).astype(np.int64)
        histogram=np.bincount(detected,minlength=8)
        if histogram.sum()!=n or len(histogram)!=8:raise ValueError('No zero or complete native observation may be dropped')
        section={'folder':folder,'section_id':item['section_id'],'parent':item['parent'],**data,
                 'counts':counts,'n_detected':detected,'histogram':histogram,'fraction':histogram/n}
        sections.append(section)
        for i,identifier in enumerate(data['region_id']):
            native.append({'section_folder':folder,'section_id':item['section_id'],'parent_group':item['parent'],
                'region_id':str(identifier),'barcode':str(data['barcode'][i]),'x_um':float(data['coords_um'][i,0]),
                'y_um':float(data['coords_um'][i,1]),**{gene:int(counts[i,g]) for g,gene in enumerate(GENES)},
                'n_positive_members':int(detected[i]),'all_zero_programme':bool(detected[i]==0)})
        for k in range(8):
            distributions.append({'section_folder':folder,'section_id':item['section_id'],'parent_group':item['parent'],
                'n_positive_members':k,'native_observations':int(histogram[k]),'section_total':n,
                'fraction':float(histogram[k]/n),'percent':float(histogram[k]/n*100)})
        for g,gene in enumerate(GENES):
            member.append({'section_folder':folder,'section_id':item['section_id'],'parent_group':item['parent'],
                'gene':gene,'positive_native_observations':int((counts[:,g]>0).sum()),
                'zero_native_observations':int((counts[:,g]==0).sum()),'section_total':n,
                'measured_count_mass':sum(map(int,counts[:,g]))})
    if len(sections)!=8 or len(native)!=11893 or len({r['region_id'] for r in native})!=11893:
        raise ValueError('S1 requires all eight complete sections and11893 unique native observations')
    table('SOURCE_NATIVE_MEMBER_DETECTABILITY.csv',native)
    table('SOURCE_SECTION_DETECTION_DISTRIBUTIONS.csv',distributions)
    table('SOURCE_ALL7_MEMBER_DETECTION.csv',member)
    contract={'figure_id':'Supplementary_Figure1_R7_QUANTITATIVE_ONLY',
       'claim':'The complete native measured observations show the seven-member programme detectability distribution and its spatial organization in every released section.',
       'genes':GENES,'native_observations':11893,'sections':8,'parent_groups':4,
       'all_zero_native_observations':sum(r['all_zero_programme'] for r in native),
       'detectability_definition':'Integer count of the seven fixed members with original committed measured count strictly greater than0; values0..7.',
       'positivity_filter':'NONE; all seven zero values and all-zero observations retained',
       'geometry':'Published native array-lattice centres from committed INPUTS; x=array_col/2*100um and y=array_row*sqrt(3)/2*100um; no image registration or affine transform.',
       'interpretation':'Four parent sample groups with eight nested released rat RNA sections; no eight-animal/independent-animal, cell annotation, causal or new blind-validation claim.',
       'image_backgrounds_used':0,'raw_RDS_reads':0,'new_model_fits':0,'new_expression_derivation_or_normalization':0,
       'rights_scope':'New numerical-data graphics only; no histology raster reuse and no conclusion about rights of old R6 images.',
       'old_R6_files_touched':False,'DOCX_writes':0,'page_mm':[183,220],'minimum_font_pt':7,
       'section_order':[s['folder'] for s in sections],
       'colour_registry':{'section_distribution':'Blues, fixed0..100percent','native_detected_members':'discreteviridis, fixed0..7; zero is visible'},
       'source_tables_written_before_plot':True}
    writej('CLAIM_CONTRACT.json',contract)
    panel_rows=[{'panel':'A','claim':'Complete 0..7 detected-member distribution in all8 sections',
                 'source_table':'SOURCE_SECTION_DETECTION_DISTRIBUTIONS.csv','unit':'Native observations within section','N':11893}]
    panel_rows += [{'panel':letter,'claim':'Complete measured native detected-member spatial support',
                    'source_table':'SOURCE_NATIVE_MEMBER_DETECTABILITY.csv','unit':s['section_id'],'N':len(s['region_id'])}
                   for letter,s in zip('BCDEFGHI',sections)]
    table('claim-evidence-matrix.csv',panel_rows)
    table('figure-manifest.csv',[{**r,'code':'build_s1_quantitative.py','output':'Supplementary_Figure1',
                                  'QA_status':'PENDING_EXACT_RENDER_VISUAL_REVIEW'} for r in panel_rows])
    writej('SOURCE_MANIFEST.json',{'status':'SOURCE_AND_CLAIM_FROZEN_BEFORE_DRAW','sources':sources,
        'source_CSVs':{name:sha(OUT/name) for name in ['SOURCE_NATIVE_MEMBER_DETECTABILITY.csv',
        'SOURCE_SECTION_DETECTION_DISTRIBUTIONS.csv','SOURCE_ALL7_MEMBER_DETECTION.csv']},
        'all_native_rows':11893,'all_member_section_rows':56,'distribution_rows':64,
        'script_sha256':sha(__file__),'style_helper_sha256':sha(STYLE/'multiomics_style.py')})
    return sections,sources,contract

def new_axes(fig,letter):
    x,y,w,h=BOUNDS[letter]
    ax=fig.add_axes([x/PAGE_W,y/PAGE_H,w/PAGE_W,h/PAGE_H])
    fig.text((5 if letter=='A' else x-3)/PAGE_W,(y+h+2)/PAGE_H,letter,fontsize=9,fontweight='bold',va='bottom')
    return ax

def render(sections,sources,contract):
    configure_matplotlib(8)
    plt.rcParams.update({'font.size':7,'axes.labelsize':7,'xtick.labelsize':7,'ytick.labelsize':7,
                         'legend.fontsize':7,'savefig.bbox':None})
    fig=plt.figure(figsize=(PAGE_W/25.4,PAGE_H/25.4),facecolor='white')
    ax=new_axes(fig,'A');matrix=np.array([s['fraction']*100 for s in sections])
    ax.imshow(matrix,cmap='Blues',vmin=0,vmax=100,aspect='auto')
    ax.set_xticks(range(8),range(8));ax.set_yticks(range(8),[s['section_id'].replace('_',' ') for s in sections])
    ax.set_xlabel('Positive members /7',labelpad=2);ax.tick_params(length=0,pad=2)
    for r in range(8):
        for c in range(8):
            value=matrix[r,c]
            label=f'{value:.1f}' if 0<value<1 else str(round(value))
            ax.text(c,r,label,ha='center',va='center',fontsize=7,color='white' if value>45 else '#202020')
    for spine in ax.spines.values():spine.set_visible(False)
    cax=fig.add_axes([20/PAGE_W,157/PAGE_H,36/PAGE_W,1.5/PAGE_H])
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=Normalize(0,100),cmap='Blues'),cax=cax,orientation='horizontal',ticks=[0,50,100])
    cb.set_label('Native observations (%)',fontsize=7,labelpad=1);cb.ax.tick_params(labelsize=7,pad=1,length=2)
    discrete=plt.get_cmap('viridis',8);norm=BoundaryNorm(np.arange(-.5,8.5),8)
    for letter,section in zip('BCDEFGHI',sections):
        ax=new_axes(fig,letter);coords=section['coords_um']/1000
        ax.scatter(coords[:,0],coords[:,1],c=section['n_detected'],cmap=discrete,norm=norm,
                   s=1.8,linewidths=0,rasterized=True)
        xmin,xmax=coords[:,0].min(),coords[:,0].max();ymin,ymax=coords[:,1].min(),coords[:,1].max()
        margin=.075;ax.set_xlim(xmin-margin,xmax+margin);ax.set_ylim(ymax+margin,ymin-margin)
        ax.set_aspect('equal');ax.set_axis_off()
        ax.plot([xmin,xmin+1],[ymax+.11,ymax+.11],color='black',lw=.8,clip_on=False)
        ax.text(xmin+.5,ymax+.25,'1 mm',fontsize=7,ha='center',va='top',clip_on=False)
        x,y,w,h=BOUNDS[letter]
        fig.text((x+w/2)/PAGE_W,(y-12)/PAGE_H,
                 section['section_id'].replace('_',' ')+'  |  n='+str(len(coords)),fontsize=7,ha='center')
    cax=fig.add_axes([49/PAGE_W,12/PAGE_H,105/PAGE_W,2/PAGE_H])
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=discrete),cax=cax,orientation='horizontal',ticks=range(8))
    cb.set_label('Measured positive resident members /7',fontsize=7,labelpad=1)
    cb.ax.tick_params(labelsize=7,pad=1,length=2)
    outputs=save_figure(fig,OUT/'Supplementary_Figure1',png_dpi=450,journal_page=True)
    plt.close(fig)
    with fitz.open(OUT/'Supplementary_Figure1.pdf') as document:
        points=[document[0].rect.width,document[0].rect.height]
        document[0].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(OUT/'Supplementary_Figure1_PDF_RENDER.png')
    crops=OUT/'review_crops';crops.mkdir(exist_ok=True)
    crop_records={}
    with Image.open(OUT/'Supplementary_Figure1.png') as original:
        dpi=original.info.get('dpi');page=original.convert('RGB');pw,ph=page.size
        if abs(pw-PAGE_W/25.4*450)>1 or abs(ph-PAGE_H/25.4*450)>1:raise ValueError('Fixed journal canvas lost')
        def crop(name,x0,y0,x1,y1):
            path=crops/(name+'.png')
            page.crop((max(0,int(x0/PAGE_W*pw)),max(0,int((PAGE_H-y1)/PAGE_H*ph)),
                       min(pw,int(x1/PAGE_W*pw)),min(ph,int((PAGE_H-y0)/PAGE_H*ph)))).save(path)
            with Image.open(path) as image:crop_records[name]={'pixels':list(image.size),'mode':image.mode,'sha256':sha(path)}
        for letter,(x,y,w,h) in BOUNDS.items():
            crop('panel_'+letter,1 if letter=='A' else x-6,y-23,x+w+5,y+h+7)
        for name,y0,y1 in [('gutter_row1_row2',143,168),('gutter_row2_row3',78,103)]:crop(name,0,y0,PAGE_W,y1)
        for row,y0,y1 in [('top',150,216),('middle',85,151),('bottom',20,86)]:
            for name,x0,x1 in [('left_middle',55,72),('middle_right',115,132)]:crop('gutter_'+row+'_'+name,x0,y0,x1,y1)
            crop('row_'+row,0,y0,PAGE_W,y1)
        for number,(x,y) in enumerate([(61,146),(121,146),(61,81),(121,81)],1):
            crop('junction_'+str(number),x-11,y-13,x+11,y+13)
        crop('shared_detectability_legend',40,3,163,19)
    for path,expected in sources.items():
        if sha(path)!=expected:raise ValueError('Committed input changed while drawing S1')
    writej('TECHNICAL_QA.json',{'status':'TECHNICAL_PASS_VISUAL_REVIEW_PENDING','page_mm':[PAGE_W,PAGE_H],
        'PNG_pixels':[pw,ph],'PNG_dpi':dpi,'PDF_points':points,'panel_count':9,'review_crops':crop_records,
        'all_native_observations':11893,'all_sections':8,'all_fixed_members':7,'zero_spots_retained':True,
        'font_min_pt':7,'journal_page':True,'rc_savefig_bbox':None,'committed_sources_unchanged':True,
        'histology_images_used':0,'new_model_fits':0,'production_files_changed':0,
        'outputs':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in outputs}})
    legend=('Supplementary Figure1. Complete native detectability of the fixed seven-member resident RNA programme. '
      'A, Distribution of the number of measured positive members (0–7) in each of the eight released sections. '
      'Cell labels are percentages of all native observations in that section; positive fractions below1% use one decimal and other fractions are rounded to whole percentages. '
      'B–I, All11893 native observations, shown by section in committed configuration order and coloured by the number of the seven members with an original measured count strictly greater than0. '
      'All-zero programme observations remain visible at0, and no positivity or co-detection eligibility filter is applied. '
      'The fixed members are TBXT, KRT8, KRT18, KRT19, ACAN, COL2A1 and SOX9, with their original measured rat feature roles preserved. '
      'All eight maps share the discrete0–7 scale; scale bars are nominal1mm. Coordinates are committed native array-lattice centres, not registered histology: '
      'x=(array_col/2)×100µm and y=(array_row×sqrt(3)/2)×100µm. '
      'n denotes complete native observations, not independent biological replicates. The hierarchy comprises four parent sample groups and eight nested released rat RNA sections, not eight independently verified animals. '
      'This quantitative-only figure uses no histology image, affine image transform, model prediction, newly fitted model, cell annotation or inferential P value.\n')
    (OUT/'S1_LEGEND.txt').write_text(legend,encoding='utf8')
    print(json.dumps({'status':'S1_QUANTITATIVE_STAGED_FOR_VISUAL_REVIEW','PNG':str(OUT/'Supplementary_Figure1.png'),
                      'panels':9,'crops':len(crop_records),'native_observations':11893,'all_zero_native_observations':contract['all_zero_native_observations']}),flush=True)

if __name__=='__main__':render(*prepare_sources())
