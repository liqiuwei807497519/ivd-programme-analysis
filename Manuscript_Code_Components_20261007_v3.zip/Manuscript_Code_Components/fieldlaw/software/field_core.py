"""Complete-support Gaussian fields with count NB2 marginal distributions.

Only caller-supplied arrays are used. This module does not load data or models.
"""

import hashlib
import json

import numpy as np
from scipy.special import betainc, betaincc, gammaincc, ndtr
from scipy.stats import nbinom, poisson


def _integer_argument(value, name, minimum=0):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value < minimum:
        raise ValueError(name + " must be an integer >= " + str(minimum))
    return int(value)


class CountMarginal:
    """Broadcast NB2 marginals, with Poisson/zero-mean limits.

    CDF inputs are exact nonnegative counts. Quantile probabilities are in
    [0, 1), and probability zero returns the lower support endpoint zero.
    Quantiles are int64; unrepresentable values raise rather than being capped.
    """

    def __init__(self, mu, alpha):
        mu, alpha = np.broadcast_arrays(np.asarray(mu, dtype=float), np.asarray(alpha, dtype=float))
        if not np.all(np.isfinite(mu)) or not np.all(np.isfinite(alpha)) or np.any(mu < 0) or np.any(alpha < 0):
            raise ValueError("mu and alpha must be finite and nonnegative")
        self.mu = mu.copy()
        self.alpha = alpha.copy()
        self.mu.setflags(write=False)
        self.alpha.setflags(write=False)
        self._zero_cdf = self.cdf(0)

    @staticmethod
    def _nb_parameters(mu, alpha):
        with np.errstate(over="raise", divide="raise", invalid="raise"):
            try:
                shape = 1.0 / alpha
                probability = 1.0 / (1.0 + alpha * mu)
            except FloatingPointError as error:
                raise ValueError("NB2 parameters are not numerically representable") from error
        if np.any(~np.isfinite(shape)) or np.any(probability <= 0):
            raise ValueError("NB2 parameters are not numerically representable")
        return shape, probability

    @staticmethod
    def _nb_probability(counts, shape, success_probability, failure_probability, survival=False):
        # Use the smaller beta argument. This preserves both tiny alpha*mu
        # and huge alpha*mu without rounding the relevant mass to zero/one.
        use_failure = failure_probability <= 0.5
        result = np.empty(counts.shape, dtype=float)
        failure_function = betainc if survival else betaincc
        success_function = betaincc if survival else betainc
        result[use_failure] = failure_function(counts[use_failure] + 1.0, shape[use_failure], failure_probability[use_failure])
        result[~use_failure] = success_function(shape[~use_failure], counts[~use_failure] + 1.0, success_probability[~use_failure])
        return result

    def _verified_nb_quantile(self, probabilities, mu, alpha):
        shape, probability = self._nb_parameters(mu, alpha)
        candidate = np.zeros(probabilities.shape, dtype=float)
        rounded_success = probability == 1.0
        candidate[~rounded_success] = nbinom.ppf(probabilities[~rounded_success], shape[~rounded_success], probability[~rounded_success])
        # This is only an initial inverse-search candidate. Positive alpha
        # retains the exact NB2 beta CDF/SF for every certification/correction.
        candidate[rounded_success] = poisson.ppf(probabilities[rounded_success], mu[rounded_success])
        if np.any(~np.isfinite(candidate)) or np.any(candidate < 0) or np.any(candidate >= float(2 ** 63)):
            raise ValueError("NB2 quantile is not representable as nonnegative int64")
        candidate = candidate.astype(np.int64)
        failure_probability = alpha * mu / (1.0 + alpha * mu)

        def reached(counts):
            result = np.zeros(counts.shape, dtype=bool)
            valid = counts >= 0
            lower = valid & (probabilities <= 0.5)
            upper = valid & ~lower
            lower_values = self._nb_probability(counts[lower], shape[lower], probability[lower], failure_probability[lower])
            upper_values = self._nb_probability(counts[upper], shape[upper], probability[upper], failure_probability[upper], survival=True)
            if np.any(~np.isfinite(lower_values)) or np.any(~np.isfinite(upper_values)):
                raise ValueError("NB2 inverse verification returned nonfinite probabilities")
            result[lower] = lower_values >= probabilities[lower]
            result[upper] = upper_values <= 1.0 - probabilities[upper]
            return result

        # Verify the discrete inverse in the stable tail, instead of trusting
        # a rounded-CDF ppf candidate near probability one.
        too_high = (candidate > 0) & reached(candidate - 1)
        while np.any(too_high):
            candidate[too_high] -= 1
            too_high = (candidate > 0) & reached(candidate - 1)
        too_low = ~reached(candidate)
        while np.any(too_low):
            if np.any(candidate[too_low] == np.iinfo(np.int64).max):
                raise ValueError("NB2 quantile exceeds int64")
            candidate[too_low] += 1
            too_low = ~reached(candidate)
        return candidate

    def cdf(self, counts):
        counts = np.asarray(counts, dtype=float)
        if np.any(~np.isfinite(counts)) or np.any(counts < 0) or np.any(counts != np.trunc(counts)):
            raise ValueError("CDF counts must be exact finite nonnegative integers")
        mu, alpha, counts = np.broadcast_arrays(self.mu, self.alpha, counts)
        result = np.ones(mu.shape, dtype=float)
        poisson_mask = (mu > 0) & (alpha == 0)
        nb_mask = (mu > 0) & (alpha > 0)
        result[poisson_mask] = gammaincc(counts[poisson_mask] + 1.0, mu[poisson_mask])
        shape, success_probability = self._nb_parameters(mu[nb_mask], alpha[nb_mask])
        failure_probability = alpha[nb_mask] * mu[nb_mask] / (1.0 + alpha[nb_mask] * mu[nb_mask])
        result[nb_mask] = self._nb_probability(counts[nb_mask], shape, success_probability, failure_probability)
        if np.any(~np.isfinite(result)):
            raise ValueError("count CDF returned nonfinite values")
        return result.item() if result.ndim == 0 else result

    def quantile(self, probabilities):
        probabilities = np.asarray(probabilities, dtype=float)
        if np.any(~np.isfinite(probabilities)) or np.any(probabilities < 0) or np.any(probabilities >= 1):
            raise ValueError("quantile probabilities must be finite in [0, 1)")
        mu, alpha, probabilities, zero_cdf = np.broadcast_arrays(self.mu, self.alpha, probabilities, self._zero_cdf)
        result = np.zeros(mu.shape, dtype=np.int64)
        poisson_mask = (mu > 0) & (alpha == 0) & (probabilities > zero_cdf)
        nb_mask = (mu > 0) & (alpha > 0) & (probabilities > zero_cdf)
        poisson_result = poisson.ppf(probabilities[poisson_mask], mu[poisson_mask])
        if np.any(~np.isfinite(poisson_result)) or np.any(poisson_result < 0) or np.any(poisson_result >= float(2 ** 63)):
            raise ValueError("Poisson quantile is not representable as nonnegative int64")
        result[poisson_mask] = poisson_result.astype(np.int64)
        result[nb_mask] = self._verified_nb_quantile(probabilities[nb_mask], mu[nb_mask], alpha[nb_mask])
        if (np.any(~np.isfinite(result)) or np.any(result < 0)
                or np.any(result != np.trunc(result)) or np.any(result >= float(2 ** 63))):
            raise ValueError("count quantile is not representable as nonnegative int64")
        return result.item() if result.ndim == 0 else result


class FieldLaw:
    """A count field on the complete caller-canonical support.

    Constructor row order is fixed. Callers sort support identities and all
    aligned arrays together before constructing the law; no subset is drawn.
    """

    def __init__(self, mu7, alpha7, state_weights, H, corr_bank, gamma=0.25):
        self.mu7 = np.asarray(mu7, dtype=float).copy()
        self.alpha7 = np.asarray(alpha7, dtype=float).copy()
        self.state_weights = np.asarray(state_weights, dtype=float).copy()
        self.H = np.asarray(H, dtype=float).copy()
        self.corr_bank = np.asarray(corr_bank, dtype=float).copy()
        self.gamma = float(gamma)
        if self.mu7.ndim != 2 or 0 in self.mu7.shape:
            raise ValueError("mu7 must be a nonempty complete-support N by G array")
        n, g = self.mu7.shape
        if self.alpha7.shape != (g,):
            raise ValueError("alpha7 must have shape G")
        if self.state_weights.shape != (n, 4) or self.H.shape != (n, 4, 16):
            raise ValueError("state_weights and H must have shapes N by 4 and N by 4 by 16")
        if self.corr_bank.shape != (4, g, g):
            raise ValueError("corr_bank must have shape 4 by G by G")
        for name in ("mu7", "alpha7", "state_weights", "H", "corr_bank"):
            if np.any(~np.isfinite(getattr(self, name))):
                raise ValueError(name + " must contain finite values")
        if np.any(self.mu7 < 0) or np.any(self.alpha7 < 0):
            raise ValueError("mu7 and alpha7 must be nonnegative")
        if np.any(self.state_weights < 0) or not np.allclose(self.state_weights.sum(axis=1), 1.0, rtol=0, atol=1e-12):
            raise ValueError("state weights must be nonnegative and sum to one at every point")
        if not np.allclose(np.sum(self.H ** 2, axis=(1, 2)), 1.0, rtol=0, atol=1e-12):
            raise ValueError("H must have unit row L2 norm across state and basis")
        if not np.isfinite(self.gamma) or not 0 <= self.gamma <= 1:
            raise ValueError("gamma must be finite in [0, 1]")
        if not np.allclose(self.corr_bank, self.corr_bank.swapaxes(1, 2), rtol=0, atol=1e-12):
            raise ValueError("all correlation banks must be symmetric")
        if not np.allclose(np.diagonal(self.corr_bank, axis1=1, axis2=2), 1.0, rtol=0, atol=1e-12):
            raise ValueError("all correlation banks must have diagonal one")
        if np.min(np.linalg.eigvalsh(self.corr_bank)) < -1e-12:
            raise ValueError("all correlation banks must be positive semidefinite")
        for name in ("mu7", "alpha7", "state_weights", "H", "corr_bank"):
            getattr(self, name).setflags(write=False)

    def one_gene_covariance(self):
        """Return the complete spatial latent covariance, common to all genes."""
        n = self.mu7.shape[0]
        flat_basis = self.H.reshape(n, -1)
        return (1.0 - self.gamma) * np.eye(n) + self.gamma * (flat_basis @ flat_basis.T)

    def cross_covariance(self, g, h):
        """Return Cov(Z[:, g], Z[:, h]) on the complete support."""
        g = _integer_argument(g, "g")
        h = _integer_argument(h, "h")
        if g >= self.mu7.shape[1] or h >= self.mu7.shape[1]:
            raise ValueError("gene indices must be within 0..G-1")
        state_correlations = self.corr_bank[:, g, h]
        local = self.state_weights @ state_correlations
        global_covariance = np.einsum("imd,jmd,m->ij", self.H, self.H, state_correlations)
        return (1.0 - self.gamma) * np.diag(local) + self.gamma * global_covariance

    def sample_gene_region_totals(self, roi_indices, M, seed_domain, scenario_start=0, chunk_size=64):
        """Draw complete worlds, then return (M by R by G int64 totals, receipt).

        The domain must include the caller's library and replicate identities.
        A world depends only on its domain, index and frozen complete support;
        ROI labels and chunk_size never enter its random address.
        """
        n, g = self.mu7.shape
        M = _integer_argument(M, "M", 1)
        scenario_start = _integer_argument(scenario_start, "scenario_start")
        chunk_size = _integer_argument(chunk_size, "chunk_size", 1)
        if not isinstance(seed_domain, str) or not seed_domain:
            raise ValueError("seed_domain must be a nonempty string containing library/replicate identity")
        roi_indices = np.asarray(roi_indices)
        if (roi_indices.shape != (n,) or roi_indices.dtype.kind not in "iuf"
                or np.any(~np.isfinite(roi_indices)) or np.any(roi_indices < 0)
                or np.any(roi_indices != np.trunc(roi_indices)) or np.any(roi_indices >= float(2 ** 63))):
            raise ValueError("roi_indices must contain N exact nonnegative integer labels")
        roi_indices = roi_indices.astype(np.int64)
        labels = np.unique(roi_indices)
        if not np.array_equal(labels, np.arange(labels.size)):
            raise ValueError("ROI labels must be contiguous 0..R-1 with every ROI nonempty")
        regions = labels.size
        region_sizes = np.bincount(roi_indices, minlength=regions)
        max_safe_count = np.iinfo(np.int64).max // int(region_sizes.max())
        totals = np.zeros((M, regions, g), dtype=np.int64)
        local_correlations = np.einsum("nm,mgh->ngh", self.state_weights, self.corr_bank)
        local_values, local_vectors = np.linalg.eigh(local_correlations)
        state_values, state_vectors = np.linalg.eigh(self.corr_bank)
        local_factor = local_vectors * np.sqrt(np.maximum(local_values, 0.0))[:, None, :]
        state_factor = state_vectors * np.sqrt(np.maximum(state_values, 0.0))[:, None, :]
        marginal = CountMarginal(self.mu7, self.alpha7)
        zero_endpoints = 0
        one_endpoints = 0
        world_hash = hashlib.sha256()
        for chunk_start in range(0, M, chunk_size):
            for offset in range(chunk_start, min(chunk_start + chunk_size, M)):
                world_id = scenario_start + offset
                address = json.dumps(["FieldLaw/v1", seed_domain, world_id], ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                digest = hashlib.sha256(address).digest()
                world_hash.update(digest)
                rng = np.random.Generator(np.random.PCG64(int.from_bytes(digest, "big")))
                # All complete-support epsilon and all global factors precede
                # any ROI projection, including zero-mean locations/genes.
                epsilon = rng.standard_normal((n, g))
                global_vectors = rng.standard_normal((4, 16, g))
                local = np.einsum("nij,nj->ni", local_factor, epsilon)
                global_correlated = np.einsum("mdk,mjk->mdj", global_vectors, state_factor)
                shared = np.einsum("nmd,mdg->ng", self.H, global_correlated)
                latent = np.sqrt(1.0 - self.gamma) * local + np.sqrt(self.gamma) * shared
                probabilities = ndtr(latent)
                zero_mask = probabilities == 0.0
                one_mask = probabilities == 1.0
                zero_endpoints += int(np.count_nonzero(zero_mask))
                one_endpoints += int(np.count_nonzero(one_mask))
                probabilities[zero_mask] = np.nextafter(0.0, 1.0)
                probabilities[one_mask] = np.nextafter(1.0, 0.0)
                counts = marginal.quantile(probabilities)
                if int(counts.max()) <= max_safe_count:
                    np.add.at(totals[offset], roi_indices, counts)
                else:
                    # Use exact Python integers only on a possible-overflow
                    # path. This detects failure; no total is capped/repaired.
                    for region in range(regions):
                        region_counts = counts[roi_indices == region]
                        for gene in range(g):
                            total = sum(int(value) for value in region_counts[:, gene])
                            if total > np.iinfo(np.int64).max:
                                raise ValueError("ROI gene total exceeds int64; forecast not returned")
                            totals[offset, region, gene] = total
        array_hash = hashlib.sha256()
        for name in ("mu7", "alpha7", "state_weights", "H", "corr_bank"):
            array = np.asarray(getattr(self, name), dtype="<f8")
            array_hash.update(name.encode("ascii"))
            array_hash.update(json.dumps(array.shape).encode("ascii"))
            array_hash.update(array.tobytes(order="C"))
        array_hash.update(float(self.gamma).hex().encode("ascii"))
        receipt = {
            "schema": "FieldLaw-sampling-v1",
            "seed_domain": seed_domain,
            "scenario_start": int(scenario_start),
            "world_count": int(M),
            "support_size": n,
            "gene_count": g,
            "region_count": regions,
            "chunk_size": int(chunk_size),
            "generator": "NumPy-PCG64",
            "numpy_version": np.__version__,
            "seed_address_scheme": "SHA256(UTF8 compact JSON [FieldLaw/v1, domain, world_id]); full digest big-endian PCG64 seed",
            "world_seed_sha256": world_hash.hexdigest(),
            "field_arrays_sha256": array_hash.hexdigest(),
            "roi_indices_sha256": hashlib.sha256(roi_indices.astype("<i8").tobytes()).hexdigest(),
            "canonical_support_policy": "complete caller-sorted constructor rows; no subset generation",
            "phi_endpoint_zero_count": zero_endpoints,
            "phi_endpoint_one_count": one_endpoints,
            "endpoint_policy": "only exact normal-CDF 0/1 replaced by nearest interior float",
            "extra_worlds": 0,
            "integer_sum_policy": "exact int64 totals; potential overflow verified with Python integers and blocked",
            "factor_roundoff_negative_eigenvalues": int(np.count_nonzero(local_values < 0) + np.count_nonzero(state_values < 0)),
            "factor_minimum_eigenvalue": float(min(np.min(local_values), np.min(state_values))),
        }
        return totals, receipt
