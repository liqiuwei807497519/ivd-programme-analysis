import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class WorkflowTests(unittest.TestCase):
    def test_synthetic_pipeline_commits_all_laws_before_truth_and_scores(self):
        with tempfile.TemporaryDirectory(prefix='fieldlaw_synthetic_') as directory:
            completed = subprocess.run([sys.executable, '-B', str(Path(__file__).with_name('workflow.py')),
                                        'synthetic', '--output', directory],
                                       text=True, capture_output=True)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            import json
            receipt = json.loads((Path(directory) / 'SYNTHETIC_COMPLETE.json').read_text())
            self.assertEqual(receipt['generative_laws'], 4)
            self.assertTrue(receipt['prediction_barrier_precedes_truth'])
            self.assertEqual(receipt['real_source_or_target_reads'], 0)
            self.assertEqual(receipt['new_point_model_fits'], 0)


if __name__ == '__main__':
    unittest.main()
