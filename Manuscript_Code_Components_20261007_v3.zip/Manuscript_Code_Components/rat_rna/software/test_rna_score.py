"""Public RNA count-score seams with literal examples, synthetic values only."""

import unittest
import json
from pathlib import Path
import tempfile
import subprocess

import numpy as np

from rna_score import mean_evaluation, poisson_deviance, score_committed


class RNAPointScoreTests(unittest.TestCase):
    def test_poisson_deviance_has_literal_values_and_exact_zero_limits(self):
        values = poisson_deviance(np.array([0, 2, 0, 3]), np.array([0.0, 1.0, 4.0, 0.0]))
        np.testing.assert_allclose(values[:3], [0.0, 0.7725887222397811, 8.0], atol=1e-14)
        self.assertTrue(np.isposinf(values[3]))

    def test_near_equal_means_retain_a_small_positive_literal_deviance(self):
        # Analytic decimal expansion is 1e-13 - (2/3)*1e-21 + ...;
        # binary input mean adds a relative error below1e-8.
        value = poisson_deviance(np.array([1000]), np.array([1000.00001]))[0]
        self.assertGreater(value, 0.0)
        self.assertAlmostEqual(value, 9.999999933333334e-14, delta=2e-21)

    def test_seven_member_native_and_roi_losses_have_literal_allocation_decomposition(self):
        truth = np.zeros((2, 7), dtype=np.int64)
        truth[0, 0] = 2
        means = np.zeros((2, 7))
        means[0, :2] = 1
        means[1, 0] = 1
        result = mean_evaluation(means, truth, np.array([0, 0]), {"members": [1.0] * 7, "total": 1.0})
        np.testing.assert_allclose(result["native"]["sum_member_deviance"], [2.772588722239781, 2.0], atol=1e-13)
        np.testing.assert_allclose(result["native"]["programme_deviance"], [0.0, 2.0], atol=1e-13)
        np.testing.assert_allclose(result["native"]["allocation_deviance"], [2.772588722239781, 0.0], atol=1e-13)
        np.testing.assert_allclose(result["ROI"]["sum_member_deviance"], [2.0], atol=1e-13)
        np.testing.assert_allclose(result["ROI"]["programme_deviance"], [0.37813956756734245], atol=1e-13)
        np.testing.assert_allclose(result["ROI"]["allocation_deviance"], [1.6218604324326575], atol=1e-13)
        np.testing.assert_allclose(result["ROI"]["decomposition_error"], 0.0, atol=1e-13)

    def test_zero_programme_predictions_keep_infinite_loss_and_undefined_allocation(self):
        truth = np.zeros((2, 7), dtype=np.int64)
        truth[0, 0] = 1
        result = mean_evaluation(np.zeros((2, 7)), truth, np.array([0, 1]), {"members": [1.0] * 7, "total": 1.0})
        self.assertTrue(np.isposinf(result["native"]["sum_member_deviance"][0]))
        self.assertTrue(np.isposinf(result["native"]["programme_deviance"][0]))
        self.assertFalse(result["native"]["allocation_defined"][0])
        self.assertTrue(result["native"]["allocation_defined"][1])
        self.assertEqual(result["native"]["sum_member_deviance"][1], 0.0)
        self.assertEqual(result["native"]["allocation_deviance"][1], 0.0)
        self.assertEqual(result["native"]["member_truth"].shape, (2, 7))

    def test_unrepresentable_count_totals_block_instead_of_wrapping_negative(self):
        truth = np.zeros((1, 7), dtype=np.float64)
        truth[0, 0] = float(2**63)
        with np.errstate(invalid="raise"), self.assertRaises(ValueError):
            mean_evaluation(np.ones((1, 7)), truth, np.array([0]), {"members": [1.0] * 7, "total": 1.0})

    def test_scorer_requires_all_forecast_barrier_before_opening_any_source_labels(self):
        with tempfile.TemporaryDirectory(prefix="RNA_SYN_score_barrier_") as temporary:
            root = Path(temporary)
            config = root / "CONFIG.json"
            config.write_text(json.dumps({"mode": "SYNTHETIC_SOURCE_ONLY_RNA_MEAN"}), encoding="utf8")
            with self.assertRaisesRegex(ValueError, "ALL_FORECASTS_COMMIT"):
                score_committed(config, root / "run", root / "score")
            self.assertFalse((root / "score").exists())

    def test_complete_actual_synthetic_forecasts_score_every_native_roi_member_and_method(self):
        from test_rna_inputs import synthetic_fixture, PINNED_PYTHON, HERE, binding, write_json
        from rna_inputs import prepare
        with tempfile.TemporaryDirectory(prefix="RNA_SYN_complete_score_") as temporary:
            root = Path(temporary)
            config_path, config = synthetic_fixture(root)
            run = root / "run"
            run.mkdir()
            prepared = run / "prepared"
            prepare(config_path, prepared)
            (run / "process_receipts").mkdir()
            folds = {}
            for parent in config["outer_groups"]:
                command = [str(PINNED_PYTHON), "-B", str(HERE / "rna_fold.py"), "--config", str(config_path),
                           "--prepared", str(prepared), "--holdout-parent", parent, "--output", str(run / "folds" / parent)]
                process = subprocess.run(command, text=True, capture_output=True, timeout=60)
                self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
                write_json(run / "process_receipts" / ("fold_" + parent + ".json"),
                           {"stage": "fold_" + parent, "command": command, "external_exit_code": process.returncode, "resource_violation": None})
                folds[parent] = {**binding(run / "folds" / parent / "FORECAST_COMMIT.json"), "external_exit_code": process.returncode}
            write_json(run / "ALL_FORECASTS_COMMIT.json", {"status": "ALL_FOUR_OUTER_FORECASTS_COMMITTED", "folds": folds,
                       "config_sha256": binding(config_path)["sha256"], "prepared_commit_sha256": binding(prepared / "PREPARE_COMMIT.json")["sha256"]})
            commit = score_committed(config_path, run, run / "score")
            self.assertEqual(commit["status"], "SCORES_COMPLETE")
            self.assertEqual(commit["native_observations"], 32)
            self.assertEqual(commit["sections"], 8)
            self.assertEqual(commit["rows"], 2560)
            self.assertEqual(set(commit["artifacts"]), {"ROWS.tsv", "SUMMARY.json"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
