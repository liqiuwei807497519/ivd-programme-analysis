"""Native RNA127-feature Poisson booster; caller arrays only, no file I/O."""
import base64,copy,hashlib,json
import numpy as np

VERSION='3.4.1'
ROUNDS=200
PARAMS={'objective':'count:poisson','booster':'gbtree','tree_method':'hist','device':'cpu','nthread':2,
        'max_depth':3,'eta':.05,'min_child_weight':1,'reg_lambda':1,'seed':2026100602,
        'subsample':1,'colsample_bytree':1,'colsample_bylevel':1,'colsample_bynode':1,
        'base_score':1.,'boost_from_average':0,'disable_default_eval_metric':True,'validate_parameters':True,'verbosity':0}
FEATURE_NAMES=['f'+str(i).zfill(3) for i in range(127)]

def _xgb():
    import xgboost as xgb
    if xgb.__version__!=VERSION:raise ValueError('Native reference requires installedXGBoost3.4.1 exact')
    return xgb

def _counts(value,ncol,label):
    a=np.asarray(value)
    if (a.ndim!=2 or len(a)==0 or a.shape[1]!=ncol or a.dtype.kind not in 'iuf'
            or not np.isfinite(a).all() or np.any(a<0) or np.any(a!=np.trunc(a))):
        raise ValueError(label+' must preserve finite nonnegative integer-valued native counts')
    return a.astype(float)

def _roles(value):
    if not isinstance(value,dict) or set(value)!={'input_uids','member_uids'}:raise ValueError('Ordered native source roles required')
    iu,mu=list(value['input_uids']),list(value['member_uids'])
    if len(iu)!=126 or len(mu)!=7 or len(set(iu+mu))!=133 or not all(isinstance(s,str) and s for s in iu+mu):
        raise ValueError('All133 stable roles must be present, unique and target-disjoint')
    return {'input_uids':iu,'member_uids':mu}

def _features(x):
    with np.errstate(over='raise',invalid='raise',divide='raise'):
        e=1.+x.sum(axis=1)
        raw=np.column_stack((np.log1p(1000.*x/e[:,None]),np.log(e)))
    if not np.isfinite(raw).all() or not np.isfinite(e).all():raise ValueError('Native input transform is not representable')
    return raw,e

def fit_native_xgb(trainingX,Y,capture_ids,roles):
    """Fit exactlyseven fixed source-count heads on complete caller arrays."""
    x=_counts(trainingX,126,'trainingX');y=_counts(Y,7,'Y');role=_roles(roles)
    labels=np.asarray(capture_ids,dtype=str)
    if y.shape[0]!=x.shape[0] or labels.shape!=(len(x),) or not all(labels):raise ValueError('Source captures/response rows must align')
    captures,sizes=np.unique(labels,return_counts=True)
    counts=dict(zip(captures.tolist(),sizes.tolist()))
    w=np.asarray([len(x)/(len(captures)*counts[s]) for s in labels])
    raw,e=_features(x)
    mean=np.average(raw,axis=0,weights=w)
    sd=np.maximum(.1,np.sqrt(np.average((raw-mean)**2,axis=0,weights=w)))
    z=(raw-mean)/sd
    prior=(w[:,None]*y).sum(axis=0)/float(w@e)
    if not np.isfinite(prior).all():raise ValueError('Source rate denominator/initialization is invalid')
    xgb=_xgb();heads=[]
    for j in range(7):
        if not np.any(y[:,j]>0):
            heads.append({'kind':'zero','member_uid':role['member_uids'][j],'reason':'all_zero_training_gene','count_mean':0.})
            continue
        if prior[j]<=0:raise ValueError('Positive training initialization rate underflowed')
        margin=np.log(e)+np.log(prior[j])
        d=xgb.DMatrix(z,label=y[:,j],weight=w,base_margin=margin,feature_names=FEATURE_NAMES,nthread=2)
        booster=xgb.train(dict(PARAMS),d,num_boost_round=ROUNDS,verbose_eval=False)
        booster.set_attr(member_uid=role['member_uids'][j],member_index=str(j),feature_contract='native127_nointercept_nosize',offset_contract='log_e_plus_log_balanced_source_rate',rate_prior_b=repr(float(prior[j])))
        payload=bytes(booster.save_raw(raw_format='ubj'))
        heads.append({'kind':'count_poisson_xgb','member_uid':role['member_uids'][j],'model_ubj_base64':base64.b64encode(payload).decode('ascii'),'model_sha256':hashlib.sha256(payload).hexdigest(),'effective_xgboost_config':json.loads(booster.save_config())})
    fingerprint=hashlib.sha256()
    for a in (x,y,w):fingerprint.update(np.asarray(a,dtype='<f8').tobytes(order='C'))
    return {'schema':'NATIVE127_XGB_SOURCE_COUNT_MEAN_V1','xgboost_version':VERSION,'roles':role,'params':dict(PARAMS),'rounds':ROUNDS,
            'feature_names':list(FEATURE_NAMES),'feature_order':['logcp1000:'+uid for uid in role['input_uids']]+['log_anchor_load'],
            'standardizer':{'mean127':mean.tolist(),'sd127':sd.tolist()},'rate_prior_b':prior.tolist(),'training_weights':w.tolist(),
            'source_capture_sizes':counts,'training_array_fingerprint':fingerprint.hexdigest(),'heads':heads,
            'prediction_semantics':'XGBoost inverse-link outputalreadycountmean;do notmultiplyeagain','new_total_head_or_reconciliation':False}

def predict_native_xgb(frozen,inputX,roles):
    """Apply frozen nativeheads to inputXonly; no fitting, labels or adaptation."""
    x=_counts(inputX,126,'inputX');role=_roles(roles)
    if frozen.get('schema')!='NATIVE127_XGB_SOURCE_COUNT_MEAN_V1' or frozen.get('xgboost_version')!=VERSION or frozen.get('params')!=PARAMS or frozen.get('rounds')!=ROUNDS:
        raise ValueError('Frozen native reference contract differs')
    if (role!=frozen.get('roles') or frozen.get('feature_names')!=FEATURE_NAMES
            or frozen.get('feature_order')!=['logcp1000:'+uid for uid in role['input_uids']]+['log_anchor_load']):
        raise ValueError('Frozen native ordered roles/features differ')
    mean=np.asarray(frozen['standardizer']['mean127']);sd=np.asarray(frozen['standardizer']['sd127']);b=np.asarray(frozen['rate_prior_b'])
    if mean.shape!=(127,) or sd.shape!=(127,) or b.shape!=(7,) or not np.isfinite(mean).all() or not np.isfinite(sd).all() or np.any(sd<.1) or not np.isfinite(b).all() or np.any(b<0):
        raise ValueError('Frozen scaler/rate is invalid')
    raw,e=_features(x);z=(raw-mean)/sd
    xgb=_xgb();result=np.empty((len(x),7),dtype=float)
    if len(frozen['heads'])!=7:raise ValueError('Allseven frozen heads required')
    for j,head in enumerate(frozen['heads']):
        if head.get('member_uid')!=role['member_uids'][j]:raise ValueError('Frozen head member order differs')
        if head.get('kind')=='zero':
            if b[j]!=0 or head.get('reason')!='all_zero_training_gene' or head.get('count_mean')!=0:
                raise ValueError('Invalid frozen exactzero head')
            result[:,j]=0.
            continue
        if head.get('kind')!='count_poisson_xgb' or b[j]<=0:raise ValueError('Invalid positive frozen head')
        payload=base64.b64decode(head['model_ubj_base64'],validate=True)
        if hashlib.sha256(payload).hexdigest()!=head['model_sha256']:raise ValueError('Frozen booster bytes changed')
        booster=xgb.Booster(params={'nthread':2});booster.load_model(bytearray(payload))
        if booster.num_features()!=127 or booster.num_boosted_rounds()!=ROUNDS:raise ValueError('Wrong nativefeature/round count')
        if (booster.attr('member_uid')!=role['member_uids'][j] or booster.attr('member_index')!=str(j)
                or booster.attr('feature_contract')!='native127_nointercept_nosize'
                or booster.attr('offset_contract')!='log_e_plus_log_balanced_source_rate'
                or float(booster.attr('rate_prior_b'))!=b[j]):raise ValueError('Storedhead identity/offset differs')
        d=xgb.DMatrix(z,base_margin=np.log(e)+np.log(b[j]),feature_names=FEATURE_NAMES,nthread=2)
        result[:,j]=booster.predict(d)
    positive=[j for j,head in enumerate(frozen['heads']) if head['kind']=='count_poisson_xgb']
    if not np.isfinite(result).all() or np.any(result<0) or np.any(result[:,positive]<=0):raise ValueError('Native count head is nonfinite, negative or underflowed')
    return result
