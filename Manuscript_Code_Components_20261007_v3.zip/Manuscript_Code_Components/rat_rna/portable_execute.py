"""Optional new-host stage orchestration; source prerequisites must be supplied.

This adapter does not alter the preserved scientific modules. It has not been
used to perform raw-source training reproduction from this release package.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import psutil

PACKAGE = Path(__file__).resolve().parent
sys.path.insert(0, str(PACKAGE / "software"))


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def writej(path, value):
    with Path(path).open("x", encoding="utf8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def readj(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def identity(process):
    return {"pid": process.pid, "creation_time": process.create_time(), "command": process.cmdline()}


def matches(process, record):
    try:
        return identity(process) == record
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return False


def stop(process, record):
    if not matches(process, record):
        return
    family = [(child, identity(child)) for child in process.children(recursive=True)] + [(process, record)]
    for child, saved in reversed(family):
        if matches(child, saved):
            child.terminate()
    _, alive = psutil.wait_procs([child for child, _ in family], timeout=2)
    for child in alive:
        saved = next(item for member, item in family if member.pid == child.pid)
        if matches(child, saved):
            child.kill()


def execute(config, run_root):
    import numpy
    import scipy
    if {"numpy": numpy.__version__, "scipy": scipy.__version__, "psutil": psutil.__version__} != {"numpy": "2.5.2", "scipy": "1.18.1", "psutil": "7.2.2"}:
        raise ValueError("Use the declared completed dependency versions; no installation is performed")
    config, run = Path(config).resolve(), Path(run_root).resolve()
    cfg = readj(config)
    if run.exists():
        raise ValueError("Fresh run required; no existing run is cleared or resumed")
    bindings = list(cfg["code_binding"]) + [cfg["plan_binding"], cfg["authorization_binding"]]
    for section in cfg["sections"]:
        bindings += [section[key] for key in ("counts", "coordinates", "features", "exports")]
    def immutable():
        for item in bindings:
            if sha(item["path"]) != item["sha256"]:
                raise ValueError("A source/code/plan binding changed")
    immutable()
    run.mkdir(parents=True)
    (run / "logs").mkdir()
    (run / "process_receipts").mkdir()
    owner = psutil.Process(os.getpid())
    affinity = owner.cpu_affinity()[:2]
    owner.cpu_affinity(affinity)
    budget = cfg["resource_contract"]
    if any(budget[key] != value for key, value in {"CPU": 2, "RSS_bytes": 4294967296, "wall_seconds": 14400, "output_bytes": 2147483648}.items()):
        raise ValueError("Preserve the declared four-hour/CPU2/RSS4GiB/output2GiB resource contract")
    started = time.monotonic()
    writej(run / "OWNER_LOCK.json", {**identity(owner), "config_sha256": sha(config), "portable_adapter": True})
    writej(run / "RUN_START.json", {"monotonic_start": started, "resource_contract": budget, "config_sha256": sha(config)})
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        env[key] = "2"
    def child(stage, arguments):
        command = [sys.executable, "-B", *map(str, arguments)]
        with (run / "logs" / (stage + ".stdout.log")).open("xb") as out, (run / "logs" / (stage + ".stderr.log")).open("xb") as err:
            process = subprocess.Popen(command, stdout=out, stderr=err, env=env)
            live = psutil.Process(process.pid)
            saved = identity(live)
            violation = None
            while process.poll() is None:
                family = [owner] + owner.children(recursive=True)
                rss = 0
                for item in family:
                    try:
                        rss += item.memory_info().rss
                        item.cpu_affinity(affinity)
                    except psutil.NoSuchProcess:
                        pass
                size = sum(path.stat().st_size for path in run.rglob("*") if path.is_file())
                if time.monotonic() - started >= budget["wall_seconds"] or rss > budget["RSS_bytes"] or size > budget["output_bytes"]:
                    violation = "Original resource bound exceeded"
                    stop(live, saved)
                    break
                time.sleep(0.1)
            code = process.wait()
        writej(run / "process_receipts" / (stage + ".json"), {"stage": stage, "command": command, "process_identity": saved,
               "external_exit_code": code, "resource_violation": violation})
        if code != 0 or violation:
            raise ValueError("Actual stage failed: " + stage)
        immutable()
    child("prepare", [PACKAGE / "software/rna_inputs.py", "prepare", "--config", config, "--output", run / "prepared"])
    folds = {}
    for parent in cfg["outer_groups"]:
        child("fold_" + parent, [PACKAGE / "software/rna_fold.py", "--config", config, "--prepared", run / "prepared", "--holdout-parent", parent, "--output", run / "folds" / parent])
        path = run / "folds" / parent / "FORECAST_COMMIT.json"
        folds[parent] = {"path": str(path), "sha256": sha(path), "external_exit_code": 0}
    writej(run / "ALL_FORECASTS_COMMIT.json", {"status": "ALL_FOUR_OUTER_FORECASTS_COMMITTED", "folds": folds,
           "config_sha256": sha(config), "prepared_commit_sha256": sha(run / "prepared/PREPARE_COMMIT.json")})
    child("score", [PACKAGE / "software/rna_score.py", "score", "--config", config, "--run-root", run, "--output", run / "score"])
    child("audit", [PACKAGE / "software/rna_audit.py", "--config", config, "--run-root", run, "--output", run / "INDEPENDENT_AUDIT.json"])
    audit = readj(run / "INDEPENDENT_AUDIT.json")
    if audit["status"] != "RNA_INDEPENDENT_AUDIT_PASS" or audit["native_observations"] != cfg["expected_total_rows"]:
        raise ValueError("Independent complete source audit did not pass")
    writej(run / "PORTABLE_COMPLETE.json", {"status": "NEW_HOST_SOURCE_STAGE_EXECUTION_COMPLETE", "config_sha256": sha(config),
           "independent_audit_sha256": sha(run / "INDEPENDENT_AUDIT.json"), "new_independent_test_claim": False})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--run-root", required=True)
    args = parser.parse_args()
    execute(args.config, args.run_root)
