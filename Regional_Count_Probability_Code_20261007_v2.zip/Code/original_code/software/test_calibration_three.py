import unittest
import numpy as np
from calibration_three import calibrate_three_capture_nb2


class ThreeCaptureCalibration(unittest.TestCase):
    def fixture(self):
        captures=np.array(["A","B","B","C","C","C"])
        ids=np.array(["A|0","B|0","B|1","C|0","C|1","C|2"])
        y=np.repeat(np.array([0,2,2,4,4,4])[:,None],7,axis=1).astype(np.int64)
        mu=np.ones((6,7))
        roles=["UID"+str(i) for i in range(7)]
        return y,mu,captures,ids,roles

    def test_source_zero_mean_positive_truth_refuses_before_PIT(self):
        y,mu,captures,ids,roles=self.fixture()
        y[0,0]=1
        mu[0,0]=0
        with self.assertRaisesRegex(ValueError,"BLOCKED_SOURCE_MEAN_SUPPORT_MISMATCH"):
            calibrate_three_capture_nb2(y,mu,captures,ids,roles)

    def test_literal_uncapped_NB2_moment_and_three_balanced_captures(self):
        result=calibrate_three_capture_nb2(*self.fixture())
        np.testing.assert_allclose(result["alpha7"],np.full(7,8./3.),rtol=0,atol=1e-12)
        np.testing.assert_allclose(result["observation_weights"],[1/3,1/6,1/6,1/9,1/9,1/9],rtol=0,atol=1e-15)
        np.testing.assert_allclose(list(result["capture_weight_mass"].values()),[1/3]*3,rtol=0,atol=1e-15)
        R=np.array(result["pooled_correlation"])
        np.testing.assert_array_equal(np.diag(R),np.ones(7))
        np.testing.assert_allclose(R,R.T,rtol=0,atol=1e-14)
        self.assertGreaterEqual(np.linalg.eigvalsh(R).min(),.1-1e-12)
        self.assertEqual(result["native_count_replacement"],False)
        self.assertEqual(result["capture_count"],3)


if __name__=="__main__":
    unittest.main()
