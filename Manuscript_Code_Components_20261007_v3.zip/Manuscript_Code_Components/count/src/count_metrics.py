"""Established count reconciliation and Poisson-deviance identities.

These analytic constructions are not introduced as a new algorithm. They do
not add a calibrated joint probability model to the mean-count predictions.
"""
import numpy as np
from baseline_core import ContractError, _finite_positive


def reconcile_to_total(member_means, total_mean):
    """Preserve member proportions under a common total (existing construction)."""
    mu = np.asarray(member_means, dtype=float)
    total = np.asarray(total_mean, dtype=float)
    if mu.ndim != 2 or mu.shape[1] != 7 or total.shape != (len(mu),):
        raise ContractError('Reconciliation shape mismatch')
    _finite_positive(mu, 'reconciliation_members')
    _finite_positive(total, 'reconciliation_total')
    relative = mu / mu.max(axis=1, keepdims=True)
    q = relative / relative.sum(axis=1, keepdims=True)
    result = total[:, None] * q
    _finite_positive(result, 'reconciliation_result')
    return result


def poisson_deviance(observed, mean):
    """Elementwise raw count deviance; a zero observation contributes 2*mean."""
    y, mu = np.asarray(observed, dtype=float), np.asarray(mean, dtype=float)
    if y.shape != mu.shape or not np.isfinite(y).all() or np.any(y < 0) or np.any(y != np.floor(y)):
        raise ContractError('Deviance requires aligned nonnegative integer observations')
    _finite_positive(mu, 'deviance_means')
    result = 2 * (mu - y)
    nonzero = y > 0
    result[nonzero] += 2 * y[nonzero] * np.log(y[nonzero] / mu[nonzero])
    return result


def raw_deviance_decomposition(observed7, means7):
    """Return the established raw D7=DT+2*T*KL(p||q) identity by region.

    This identity does not decompose the per-member-scaled primary endpoint.
    All seven targets, including zero observations, remain in the deviance.
    """
    y, mu = np.asarray(observed7, dtype=float), np.asarray(means7, dtype=float)
    if y.ndim != 2 or y.shape[1] != 7:
        raise ContractError('Expected seven observed target columns')
    member = poisson_deviance(y, mu).sum(axis=1)
    total_y, total_mu = y.sum(axis=1), mu.sum(axis=1)
    total = poisson_deviance(total_y, total_mu)
    allocation = np.zeros(len(y))
    nz = y > 0
    # Each nonzero observed atom has a positive regional total.
    rows, cols = np.nonzero(nz)
    values = 2 * y[rows, cols] * np.log((y[rows, cols] / total_y[rows]) /
                                       (mu[rows, cols] / total_mu[rows]))
    np.add.at(allocation, rows, values)
    return {'member_raw_deviance': member, 'total_raw_deviance': total,
            'allocation_raw_deviance': allocation}
