"""Stream allowed MatrixMarket rows without parsing other rows' values.

Source text bytes and record structure are handled in this process. This is
an input-role contract, not operating-system isolation.
"""
from decimal import Decimal, InvalidOperation
import gzip
import operator
from pathlib import Path
import re

import numpy as np

INT64_MAX = 9223372036854775807


def _exact_count(token):
    if re.fullmatch(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?", token) is None:
        raise ValueError("Allowed-row value is not a valid exact count")
    try:
        value = Decimal(token)
    except InvalidOperation:
        raise ValueError("Allowed-row value is not a valid exact count") from None
    if not value.is_finite() or value < 0 or value > INT64_MAX:
        raise ValueError("Allowed-row value must be a finite nonnegative int64 count")
    if value != value.to_integral_value():
        raise ValueError("Allowed-row value must be an exact integer")
    return int(value)


def _structural_integer(token):
    if re.fullmatch(r"[+-]?[0-9]+", token) is None:
        raise ValueError("MatrixMarket dimensions and coordinates must be integer tokens")
    return int(token)


def _positive_index(value):
    try:
        if isinstance(value, (bool, np.bool_)):
            raise TypeError
        result = operator.index(value)
    except TypeError:
        raise ValueError("Shape and allowed-row descriptors must be positive integers") from None
    if result < 1:
        raise ValueError("Shape and allowed-row descriptors must be positive integers")
    return result


def extract_allowed_counts(path, allowed_gene_rows, n_genes, n_spots):
    """Return (spot-by-allowed-gene int64 counts, non-value receipt).

    Allowed rows are one-based and their supplied order defines output columns.
    Missing sparse records represent zero observed counts, not absent features.
    Repeated allowed coordinates are summed exactly; int64 overflow rejects the
    entire extraction. Unsupported value tokens are never included in receipts
    or errors and are never passed to a numeric parser.
    """
    n_genes = _positive_index(n_genes)
    n_spots = _positive_index(n_spots)
    try:
        rows = [_positive_index(row) for row in allowed_gene_rows]
    except TypeError:
        raise ValueError("Allowed rows must be an ordered integer sequence") from None
    if not rows or len(set(rows)) != len(rows) or any(row > n_genes for row in rows):
        raise ValueError("Allowed rows must be nonempty, unique and within the declared gene dimension")
    columns = {row: column for column, row in enumerate(rows)}
    counts = np.zeros((n_spots, len(rows)), dtype=np.int64)
    checked = selected = 0
    path = Path(path)
    opener = gzip.open if path.suffix.lower() == ".gz" else open
    with opener(path, "rt", encoding="utf8") as stream:
        header = stream.readline().strip().split()
        if (len(header) != 5 or header[:3] != ["%%MatrixMarket", "matrix", "coordinate"]
                or header[3] not in ("integer", "real") or header[4] != "general"):
            raise ValueError("Unsupported MatrixMarket header")
        records = (line.split() for line in stream if line.strip() and not line.lstrip().startswith("%"))
        dimensions = next(records, [])
        if len(dimensions) != 3:
            raise ValueError("Missing MatrixMarket dimensions")
        gene_count, spot_count, expected = map(_structural_integer, dimensions)
        if (gene_count, spot_count) != (n_genes, n_spots):
            raise ValueError("Matrix dimensions differ from the declared shape")
        if expected < 0:
            raise ValueError("Declared nnz must be nonnegative")
        for record in records:
            if len(record) != 3:
                raise ValueError("Coordinate record must contain three fields")
            row, spot = map(_structural_integer, record[:2])
            if not (1 <= row <= n_genes and 1 <= spot <= n_spots):
                raise ValueError("Coordinate record is outside the declared dimensions")
            checked += 1
            if checked > expected:
                raise ValueError("Extra coordinate records beyond declared nnz")
            if row in columns:
                value = _exact_count(record[2])
                current = int(counts[spot - 1, columns[row]])
                if value > INT64_MAX - current:
                    raise ValueError("Duplicate coordinate sum exceeds int64 capacity")
                counts[spot - 1, columns[row]] = current + value
                selected += 1
        if checked != expected:
            raise ValueError("Coordinate record count differs from declared nnz")
    return counts, {
        "schema": "ALLOWED_MATRIX_RECEIPT_V1",
        "shape": [n_genes, n_spots],
        "allowed_gene_rows_1based": rows,
        "records_checked": checked,
        "allowed_records": selected,
        "unsupported_records": checked - selected,
        "numeric_values_parsed_only_for_allowed_rows": True,
        "duplicate_coordinate_policy": "accumulate_exact_int64_or_reject_overflow",
        "OS_isolation_proved": False,
    }
