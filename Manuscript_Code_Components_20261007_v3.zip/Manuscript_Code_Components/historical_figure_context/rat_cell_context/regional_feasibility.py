from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
R=Path(__file__).resolve().parent;SRC=R.parent/'IVD_Member_Analysis_20260926/extracted';OUT=R/'region_results';OUT.mkdir(exist_ok=True)
genes=['TBXT','KRT8','KRT18','KRT19','ACAN','COL2A1','SOX9'];records=[];summary=[];checks=[]
for folder in sorted(SRC.iterdir()):
 m=pd.read_csv(folder/'spots.csv');c=pd.read_csv(folder/'counts.csv');assert m.barcode.tolist()==c.barcode.tolist()
 s=m.section.iloc[0];sample=m.sampleid.iloc[0]
 for K in [4,8,16]:
  tile_row=(m.array_row//K).astype(int);tile_col=(m.array_col//K).astype(int)
  x=c[genes].copy();x['full_library']=m.library_total;x['tile_row']=tile_row;x['tile_col']=tile_col;x['n_spots']=1
  agg=x.groupby(['tile_row','tile_col'],sort=True).sum();assert np.array_equal(agg[genes].sum().to_numpy(),c[genes].sum().to_numpy());assert agg.full_library.sum()==m.library_total.sum() and agg.n_spots.sum()==len(m)
  agg['Resident7_total']=agg[genes].sum(axis=1);agg['all7_positive']=(agg[genes]>0).all(axis=1);agg['any7_positive']=agg.Resident7_total>0;agg['eligible_n8']=agg.n_spots>=8
  a=agg[agg.eligible_n8]
  summary.append({'section':s,'sampleid':sample,'K_array_indices':K,'all_intersected_tiles':len(agg),'eligible_tiles':len(a),'eligible_spot_fraction':float(a.n_spots.sum()/len(m)),'all7_positive_fraction':float(a.all7_positive.mean()) if len(a) else np.nan,'any7_positive_fraction':float(a.any7_positive.mean()) if len(a) else np.nan,'KRT19_positive_fraction':float((a.KRT19>0).mean()) if len(a) else np.nan,'median_spots_per_eligible_tile':float(a.n_spots.median()) if len(a) else np.nan})
  out=agg.reset_index();out.insert(0,'K_array_indices',K);out.insert(0,'sampleid',sample);out.insert(0,'section',s);records.append(out)
 checks.append({'section':s,'all3_grids_exact_member_and_library_conservation':True,'spots':len(m)})
pd.concat(records,ignore_index=True).to_csv(OUT/'all_tiles.tsv',sep='\t',index=False)
df=pd.DataFrame(summary);df.to_csv(OUT/'section_feasibility.tsv',sep='\t',index=False)
df.groupby(['sampleid','K_array_indices'],sort=True)[['all7_positive_fraction','KRT19_positive_fraction','eligible_spot_fraction']].mean().reset_index().to_csv(OUT/'sampleid_equal_section_feasibility.tsv',sep='\t',index=False)
report={'status':'COMPLETE_LABEL_FREE_MEASUREMENT_FEASIBILITY','primary_K':8,'sensitivity_K':[4,16],'minimum_retained_spots_per_eligible_tile':8,'eligible_primary_tiles':int(df[df.K_array_indices==8].eligible_tiles.sum()),'sections':8,'source_spots':11893,'exact_checks':checks,'prediction_evaluation':False,'animal_level_inference':False,'new_training':False,'NP_labels_used':False}
(R/'REGION_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(df[df.K_array_indices==8].to_string(index=False))
