import unittest
import numpy as np
from independent_scores import independent_count_scores


class IndependentScoresTests(unittest.TestCase):
    def test_discrete_cdf_support_integration_is_independent_of_sorted_pair_formula(self):
        value = independent_count_scores([0, 1, 2], 1, IID=True)
        self.assertAlmostEqual(value['empirical_rps'], 2 / 9)
        self.assertAlmostEqual(value['fair_rps'], 0)
        self.assertEqual(value['intervals']['90']['lower'], 0)
        self.assertEqual(value['intervals']['90']['upper'], 2)
        self.assertEqual(value['intervals']['90']['interval_score'], 2)

    def test_zero_and_far_tail_observation_remain_on_the_full_count_support(self):
        self.assertEqual(independent_count_scores([0, 0, 0], 0)['empirical_rps'], 0)
        self.assertEqual(independent_count_scores([2, 2, 2], 6)['empirical_rps'], 4)
        self.assertEqual(independent_count_scores([2, 2, 2], 0)['empirical_rps'], 2)

    def test_non_iid_diagnostics_do_not_receive_fair_correction(self):
        self.assertIsNone(independent_count_scores([0, 1, 2], 1, IID=False)['fair_rps'])

    def test_matches_literal_all_pairs_u_statistic_and_interval_utility(self):
        samples = [0, 2, 2, 7, 8]
        truth = 3
        expected = np.mean(np.abs(np.asarray(samples)-truth)) - sum(abs(a-b) for i,a in enumerate(samples) for b in samples[i+1:]) / 20
        self.assertAlmostEqual(independent_count_scores(samples, truth)['fair_rps'], expected)


if __name__ == '__main__':
    unittest.main()
