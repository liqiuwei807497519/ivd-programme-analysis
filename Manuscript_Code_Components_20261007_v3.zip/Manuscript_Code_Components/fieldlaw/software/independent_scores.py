"""Independent count-CDF integration for final audit, not the production scorer.

Uses integer support intervals and integer numerators. It does not import the
production scoring module, fit parameters, repair scores, or access files.
"""
import math
from fractions import Fraction


def independent_count_scores(samples, truth, *, IID=True):
    values = list(samples)
    if not isinstance(IID, bool) or len(values) < (2 if IID else 1):
        raise ValueError('Invalid IID or ensemble-size contract')
    if any(not math.isfinite(float(v)) or float(v) < 0 or float(v) != int(v) for v in values + [truth]):
        raise ValueError('Only exact finite nonnegative integer counts can be audited')
    values, truth = sorted(int(v) for v in values), int(truth)
    count = len(values)
    frequencies = {}
    for value in values:
        frequencies[value] = frequencies.get(value, 0) + 1
    support = sorted(set(frequencies) | {0, truth})
    cumulative, numerator = 0, 0
    for lower, upper in zip(support[:-1], support[1:]):
        cumulative += frequencies.get(lower, 0)
        deviation = cumulative - count * int(lower >= truth)
        numerator += (upper - lower) * deviation ** 2
    absolute_numerator = sum(abs(value - truth) for value in values)
    empirical = Fraction(numerator, count ** 2)
    fair = Fraction(numerator - absolute_numerator, count * (count - 1)) if IID else None
    median = values[(count + 1) // 2 - 1]
    weighted = Fraction(abs(median - truth), 2)
    intervals = {}
    for percentage in (50, 80, 90, 95):
        lower = values[max(0, ((100 - percentage) * count + 199) // 200 - 1)]
        upper = values[min(count - 1, ((100 + percentage) * count + 199) // 200 - 1)]
        width = upper - lower
        miss = max(0, lower - truth) + max(0, truth - upper)
        interval_score = Fraction(width) + Fraction(200 * miss, 100 - percentage)
        weighted += Fraction((100 - percentage) * width, 200) + miss
        intervals[str(percentage)] = {'lower': lower, 'upper': upper, 'width': width,
                                      'left_miss': truth < lower, 'right_miss': truth > upper,
                                      'interval_score': float(interval_score)}
    return {'empirical_rps': float(empirical), 'fair_rps': float(fair) if IID else None,
            'median': median, 'intervals': intervals, 'wis': float(weighted / Fraction(9, 2))}
