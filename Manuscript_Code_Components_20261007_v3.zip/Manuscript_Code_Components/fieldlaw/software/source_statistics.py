"""Source-only nuisance statistics for the fixed FieldLaw software protocol.

Inputs are arrays supplied by the caller. This module performs no I/O, never
reads target responses, and returns JSON-serializable source parameters.
"""

import numpy as np
from scipy.special import betainc, betaincc, gammainc, gammaincc, ndtri


def _validate_counts(values, name):
    if not np.all(np.isfinite(values)) or np.any(values < 0) or np.any(values != np.floor(values)):
        raise ValueError(name + " must contain exact finite nonnegative integer-valued counts")


def _anchor_features(x):
    exposure = 1.0 + x.sum(axis=1)
    return np.column_stack((np.log1p(1000.0 * x / exposure[:, None]), np.log(exposure)))


def source_state_weights(x126, parameters):
    """Apply frozen source standardization and centroids to inputs alone."""
    x = np.asarray(x126, dtype=float)
    if x.ndim != 2 or x.shape[1] != 126:
        raise ValueError("x126 must have shape (N, 126)")
    _validate_counts(x, "x126")
    try:
        mean = np.asarray(parameters["anchor_mean127"], dtype=float)
        sd = np.asarray(parameters["anchor_sd127"], dtype=float)
        centroids = np.asarray(parameters["state_centroids4x127"], dtype=float)
    except (KeyError, TypeError) as error:
        raise ValueError("frozen source state parameters are missing or invalid") from error
    if mean.shape != (127,) or sd.shape != (127,) or centroids.shape != (4, 127):
        raise ValueError("frozen source features/centroids have invalid shapes")
    if not np.all(np.isfinite(mean)) or not np.all(np.isfinite(sd)) or not np.all(np.isfinite(centroids)):
        raise ValueError("frozen source state parameters must be finite")
    if np.any(sd < 0.1):
        raise ValueError("frozen source standard deviations must respect the 0.1 floor")
    try:
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            z = (_anchor_features(x) - mean) / sd
            distances = np.sum((z[:, None, :] - centroids[None, :, :]) ** 2, axis=2)
            logits = -distances / 127.0
            logits -= logits.max(axis=1, keepdims=True)
            weights = np.exp(logits)
            weights = weights / weights.sum(axis=1, keepdims=True)
    except FloatingPointError as error:
        raise ValueError("source state mapping has undefined numerical distances") from error
    if not np.all(np.isfinite(weights)):
        raise ValueError("source state weights must be finite")
    return weights


def source_basis(coords_um):
    """Gaussian RBFs on the complete support, with y-major 4x4 centers.

    Each coordinate axis uses its complete-support minimum and maximum. The
    Gaussian bandwidth is 0.35: exp(-distance_squared / (2 * 0.35**2)).
    Call once on the complete released support before any ROI or batch slicing.
    """
    coords = np.asarray(coords_um, dtype=float)
    if coords.ndim != 2 or coords.shape[1] != 2 or len(coords) == 0:
        raise ValueError("coords_um must have nonempty shape (N, 2)")
    if not np.all(np.isfinite(coords)):
        raise ValueError("coordinates must be finite")
    minimum = coords.min(axis=0)
    span = coords.max(axis=0) - minimum
    if not np.all(np.isfinite(span)) or np.any(span <= 0):
        raise ValueError("complete coordinate support needs positive spans on both axes")
    normalized = (coords - minimum) / span
    axis = np.linspace(0.0, 1.0, 4)
    centers = np.asarray([(x, y) for y in axis for x in axis])
    distances = np.sum((normalized[:, None, :] - centers[None, :, :]) ** 2, axis=2)
    return np.exp(-distances / (2.0 * 0.35 ** 2))


def source_state_basis(coords_um, state_weights):
    """Return N x 4 x 16 H, with the L2 norm across all state/basis entries."""
    phi = source_basis(coords_um)
    weights = np.asarray(state_weights, dtype=float)
    if weights.shape != (len(phi), 4):
        raise ValueError("state_weights must have shape (N, 4)")
    if not np.all(np.isfinite(weights)) or np.any(weights < 0):
        raise ValueError("state weights must be finite and nonnegative")
    precision = 32 * np.finfo(float).eps
    if np.any(np.abs(weights.sum(axis=1) - 1.0) > precision):
        raise ValueError("each observation's four state weights must sum to one")
    h = np.sqrt(weights[:, :, None]) * phi[:, None, :]
    norm_rows = np.sqrt(np.sum(h * h, axis=(1, 2)))
    if not np.all(np.isfinite(norm_rows)) or np.any(norm_rows <= 0):
        raise ValueError("H rows have undefined L2 norms")
    return h / norm_rows[:, None, None]


def _weighted_kmeans(z, weights, seed):
    rng = np.random.default_rng(seed)
    centers = [z[rng.choice(len(z), p=weights / weights.sum())].copy()]
    closest = np.sum((z - centers[0]) ** 2, axis=1)
    for _ in range(3):
        probabilities = weights * closest
        mass = probabilities.sum()
        if not np.isfinite(mass) or mass <= 0:
            raise ValueError("four source states are undefined: insufficient distinct anchor features")
        centers.append(z[rng.choice(len(z), p=probabilities / mass)].copy())
        closest = np.minimum(closest, np.sum((z - centers[-1]) ** 2, axis=1))
    centers = np.asarray(centers)
    converged = False
    for steps in range(1, 101):
        distances = np.sum((z[:, None, :] - centers[None, :, :]) ** 2, axis=2)
        assignment = np.argmin(distances, axis=1)
        updated = []
        for state in range(4):
            selected = assignment == state
            mass = weights[selected].sum()
            if not np.isfinite(mass) or mass <= 0:
                raise ValueError("empty or undefined source state blocks fitting")
            updated.append(np.sum(weights[selected, None] * z[selected], axis=0) / mass)
        updated = np.asarray(updated)
        change = np.sqrt(np.sum((updated - centers) ** 2, axis=1)).max()
        centers = updated
        if not np.all(np.isfinite(centers)):
            raise ValueError("nonfinite source centroids block fitting")
        if change <= 1e-8:
            converged = True
            break
    assignment = np.argmin(np.sum((z[:, None, :] - centers[None, :, :]) ** 2, axis=2), axis=1)
    counts = np.bincount(assignment, minlength=4)
    if np.any(counts == 0):
        raise ValueError("empty final source state blocks fitting")
    return centers, {"steps": steps, "converged": converged, "hard_state_counts": counts.tolist()}


def source_pit_gaussian_scores(y, mu, alpha):
    """Fixed-seed randomized count PIT using whichever tail is smaller.

    The CDF and survival function are evaluated independently. No source PIT,
    normal score, or count variance is clipped. A selected tail that underflows
    to zero blocks fitting with BLOCKED_NUMERIC_SOURCE.
    """
    y = np.asarray(y, dtype=float)
    mu = np.asarray(mu, dtype=float)
    alpha = np.asarray(alpha, dtype=float)
    if y.ndim != 2 or y.shape[1] != 7 or mu.shape != y.shape or alpha.shape != (7,):
        raise ValueError("source PIT requires y/mu shape (N, 7) and alpha shape (7,)")
    _validate_counts(y, "source PIT y7")
    if not np.all(np.isfinite(mu)) or np.any(mu < 0) or not np.all(np.isfinite(alpha)) or np.any(alpha < 0):
        raise ValueError("source PIT mu and alpha must be finite and nonnegative")
    rng = np.random.default_rng(2026100602)
    uniforms = rng.random(y.shape)
    while np.any(uniforms == 0.0):
        zero = uniforms == 0.0
        uniforms[zero] = rng.random(np.count_nonzero(zero))
    lower = np.empty_like(mu)
    upper = np.empty_like(mu)
    survival_lower = np.empty_like(mu)
    survival_upper = np.empty_like(mu)
    for gene in range(7):
        observed = y[:, gene]
        mean = mu[:, gene]
        if alpha[gene] == 0.0:
            lower[:, gene] = np.where(observed == 0, 0.0, gammaincc(observed, mean))
            upper[:, gene] = gammaincc(observed + 1.0, mean)
            survival_lower[:, gene] = np.where(observed == 0, 1.0, gammainc(observed, mean))
            survival_upper[:, gene] = gammainc(observed + 1.0, mean)
        else:
            shape = 1.0 / alpha[gene]
            product = alpha[gene] * mean
            failure_probability = product / (1.0 + product)
            probability = 1.0 / (1.0 + product)
            # Complementary beta orientations preserve both tiny q (near the
            # Poisson limit) and tiny p (large uncapped dispersion). This is
            # one identical NB2 law, without subtracting either tail from 1.
            small_q = failure_probability <= 0.5
            lower[:, gene] = np.where(observed == 0, 0.0, np.where(
                small_q, betaincc(observed, shape, failure_probability),
                betainc(shape, observed, probability)))
            upper[:, gene] = np.where(small_q, betaincc(observed + 1.0, shape, failure_probability),
                                     betainc(shape, observed + 1.0, probability))
            survival_lower[:, gene] = np.where(observed == 0, 1.0, np.where(
                small_q, betainc(observed, shape, failure_probability),
                betaincc(shape, observed, probability)))
            survival_upper[:, gene] = np.where(small_q, betainc(observed + 1.0, shape, failure_probability),
                                               betaincc(shape, observed + 1.0, probability))
    if (not np.all(np.isfinite(lower)) or not np.all(np.isfinite(upper))
            or not np.all(np.isfinite(survival_lower)) or not np.all(np.isfinite(survival_upper))
            or np.any(lower < 0) or np.any(upper > 1) or np.any(upper < lower)
            or np.any(survival_upper < 0) or np.any(survival_lower > 1)
            or np.any(survival_lower < survival_upper)):
        raise ValueError("BLOCKED_NUMERIC_SOURCE: invalid source count CDF/survival function")
    lower_pit = (1.0 - uniforms) * lower + uniforms * upper
    upper_pit = (1.0 - uniforms) * survival_lower + uniforms * survival_upper
    use_lower = lower_pit <= 0.5
    selected = np.where(use_lower, lower_pit, upper_pit)
    if not np.all(np.isfinite(selected)) or np.any(selected <= 0.0):
        raise ValueError("BLOCKED_NUMERIC_SOURCE: selected randomized PIT tail is undefined or underflowed")
    scores = ndtri(selected)
    scores[~use_lower] *= -1.0
    if not np.all(np.isfinite(scores)):
        raise ValueError("BLOCKED_NUMERIC_SOURCE: nonfinite source Gaussian PIT scores")
    return scores


def _weighted_correlation(scores, weights):
    mass = weights.sum()
    if not np.isfinite(mass) or mass <= 0:
        raise ValueError("undefined residual state weights block fitting")
    mean = np.sum(weights[:, None] * scores, axis=0) / mass
    centered = scores - mean
    weighted_centered = centered * np.sqrt(weights[:, None])
    covariance = weighted_centered.T @ weighted_centered / mass
    variance = np.diag(covariance)
    if not np.all(np.isfinite(covariance)) or np.any(variance <= 0):
        raise ValueError("zero or nonfinite source residual variance blocks fitting")
    correlation = covariance / np.sqrt(variance[:, None] * variance[None, :])
    np.fill_diagonal(correlation, 1.0)
    shrunk = 0.9 * correlation + 0.1 * np.eye(7)
    if not np.all(np.isfinite(shrunk)) or not np.array_equal(shrunk, shrunk.T):
        raise ValueError("source correlation must be finite and symmetric")
    if not np.array_equal(np.diag(shrunk), np.ones(7)):
        raise ValueError("source correlation must have unit diagonal")
    try:
        np.linalg.cholesky(shrunk)
    except np.linalg.LinAlgError as error:
        raise ValueError("source correlation is not positive semidefinite") from error
    return shrunk


def fit_source(x126, y7, mu7, capture_ids, seed=2026100601):
    """Fit frozen NB2 dispersion, four anchor states, and residual correlations.

    Exactly two source captures contribute weight 0.5 each. ``mu7`` contains
    frozen, original cross-capture means supplied by the source adapter; this
    function never fits a mean model. Randomized discrete PIT uses its separate
    fixed source-only seed 2026100602. Independently evaluated CDF/survival tails
    avoid endpoint cancellation. Selected-tail underflow or undefined variance
    blocks fitting without clipping or a variance cap.
    """
    x = np.asarray(x126, dtype=float)
    y = np.asarray(y7, dtype=float)
    mu = np.asarray(mu7, dtype=float)
    captures = np.asarray(capture_ids)
    if x.ndim != 2 or x.shape[1] != 126:
        raise ValueError("x126 must have shape (N, 126)")
    if y.shape != (x.shape[0], 7) or mu.shape != y.shape:
        raise ValueError("y7 and mu7 must have shape (N, 7)")
    _validate_counts(x, "x126")
    _validate_counts(y, "y7")
    if not np.all(np.isfinite(mu)) or np.any(mu < 0):
        raise ValueError("mu7 must contain finite nonnegative means")
    if captures.shape != (x.shape[0],) or x.shape[0] == 0:
        raise ValueError("capture_ids must have one value per source observation")
    if captures.dtype.kind in "fci" and not np.all(np.isfinite(captures)):
        raise ValueError("capture identifiers must not be missing or nonfinite")
    if captures.dtype.kind in "SU" and np.any(np.char.strip(captures.astype(str)) == ""):
        raise ValueError("capture identifiers must not be empty")
    if captures.dtype.kind == "O" and any(value is None for value in captures):
        raise ValueError("capture identifiers must not be missing")
    try:
        labels, indices, counts = np.unique(captures, return_inverse=True, return_counts=True)
    except TypeError as error:
        raise ValueError("capture identifiers must have comparable categories") from error
    if len(labels) != 2:
        raise ValueError("source fit requires exactly two source captures")
    weights = 0.5 / counts[indices]
    denominator = np.sum(weights[:, None] * mu * mu, axis=0)
    if not np.all(np.isfinite(denominator)) or np.any(denominator <= 0):
        raise ValueError("NB2 moment denominator must be finite and positive")
    numerator = np.sum(weights[:, None] * ((y - mu) ** 2 - mu), axis=0)
    alpha = np.maximum(0.0, numerator / denominator)
    features = _anchor_features(x)
    mean = np.sum(weights[:, None] * features, axis=0)
    variance = np.sum(weights[:, None] * (features - mean) ** 2, axis=0)
    sd = np.maximum(0.1, np.sqrt(variance))
    centroids, state_fit = _weighted_kmeans((features - mean) / sd, weights, seed)
    parameters = {
        "seed": int(seed),
        "capture_ids": labels.tolist(),
        "observation_weights": weights.tolist(),
        "alpha7": alpha.tolist(),
        "anchor_mean127": mean.tolist(),
        "anchor_sd127": sd.tolist(),
        "state_centroids4x127": centroids.tolist(),
        "state_fit": state_fit,
    }
    state_weights = source_state_weights(x, parameters)
    parameters["state_weights"] = state_weights.tolist()
    scores = source_pit_gaussian_scores(y, mu, alpha)
    parameters["pit_seed"] = 2026100602
    parameters["residual_correlations"] = {
        "pooled": _weighted_correlation(scores, weights).tolist(),
        "states": [_weighted_correlation(scores, weights * state_weights[:, state]).tolist()
                   for state in range(4)],
    }
    return parameters
