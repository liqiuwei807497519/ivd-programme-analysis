"""Public path/style availability seam only; no data or actual Matplotlib call."""
from pathlib import Path
import json,subprocess,sys,unittest
ROOT=Path(__file__).resolve().parent
class PublicFigurePath(unittest.TestCase):
 def test_bundled_default_style_and_help_without_external_packages(self):
  for option in ['--help','--describe-inputs']:
   r=subprocess.run([sys.executable,'-I','-S','-B',str(ROOT/'build_figures.py'),option],capture_output=True,text=True,timeout=5)
   self.assertEqual(r.returncode,0,r.stderr)
   if option=='--help':self.assertIn('--style-file',r.stdout)
   else:
    d=json.loads(r.stdout);self.assertEqual(d['data_reads'],0);self.assertEqual(d['heavy_imports'],0)
    self.assertEqual(d['required_bindings'],['project_root','output_root','source_root'])
    self.assertEqual(d['style_default'],'multiomics_style.py')
    self.assertTrue(d['style_bundled'])
if __name__=='__main__':unittest.main(verbosity=2)
