"""Complete-support Gaussian fields with count NB2 marginal distributions.

Only caller-supplied arrays are used. This module does not load data or models.
"""

import hashlib
import json

import numpy as np
from scipy.special import betainc, betaincc, gammaincc, ndtr
from scipy.stats import nbinom, poisson


def _integer_argument(value, name, minimum=0):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value < minimum:
        raise ValueError(name + " must be an integer >= " + str(minimum))
    return int(value)


class CountMarginal:
    """Broadcast NB2 marginals, with Poisson/zero-mean limits.

    CDF inputs are exact nonnegative counts. Quantile probabilities are in
    [0, 1), and probability zero returns the lower support endpoint zero.
    Quantiles are int64; unrepresentable values raise rather than being capped.
    """

    def __init__(self, mu, alpha):
        mu, alpha = np.broadcast_arrays(np.asarray(mu, dtype=float), np.asarray(alpha, dtype=float))
        if not np.all(np.isfinite(mu)) or not np.all(np.isfinite(alpha)) or np.any(mu < 0) or np.any(alpha < 0):
            raise ValueError("mu and alpha must be finite and nonnegative")
        self.mu = mu.copy()
        self.alpha = alpha.copy()
        self.mu.setflags(write=False)
        self.alpha.setflags(write=False)
        self._zero_cdf = self.cdf(0)

    @staticmethod
    def _nb_parameters(mu, alpha):
        with np.errstate(over="raise", divide="raise", invalid="raise"):
            try:
                shape = 1.0 / alpha
                probability = 1.0 / (1.0 + alpha * mu)
            except FloatingPointError as error:
                raise ValueError("NB2 parameters are not numerically representable") from error
        if np.any(~np.isfinite(shape)) or np.any(probability <= 0):
            raise ValueError("NB2 parameters are not numerically representable")
        return shape, probability

    @staticmethod
    def _nb_probability(counts, shape, success_probability, failure_probability, survival=False):
        # Use the smaller beta argument. This preserves both tiny alpha*mu
        # and huge alpha*mu without rounding the relevant mass to zero/one.
        use_failure = failure_probability <= 0.5
        result = np.empty(counts.shape, dtype=float)
        failure_function = betainc if survival else betaincc
        success_function = betaincc if survival else betainc
        result[use_failure] = failure_function(counts[use_failure] + 1.0, shape[use_failure], failure_probability[use_failure])
        result[~use_failure] = success_function(shape[~use_failure], counts[~use_failure] + 1.0, success_probability[~use_failure])
        return result

    def _verified_nb_quantile(self, probabilities, mu, alpha):
        shape, probability = self._nb_parameters(mu, alpha)
        candidate = np.zeros(probabilities.shape, dtype=float)
        rounded_success = probability == 1.0
        candidate[~rounded_success] = nbinom.ppf(probabilities[~rounded_success], shape[~rounded_success], probability[~rounded_success])
        # This is only an initial inverse-search candidate. Positive alpha
        # retains the exact NB2 beta CDF/SF for every certification/correction.
        candidate[rounded_success] = poisson.ppf(probabilities[rounded_success], mu[rounded_success])
        if np.any(~np.isfinite(candidate)) or np.any(candidate < 0) or np.any(candidate >= float(2 ** 63)):
            raise ValueError("NB2 quantile is not representable as nonnegative int64")
        candidate = candidate.astype(np.int64)
        failure_probability = alpha * mu / (1.0 + alpha * mu)

        def reached(counts):
            result = np.zeros(counts.shape, dtype=bool)
            valid = counts >= 0
            lower = valid & (probabilities <= 0.5)
            upper = valid & ~lower
            lower_values = self._nb_probability(counts[lower], shape[lower], probability[lower], failure_probability[lower])
            upper_values = self._nb_probability(counts[upper], shape[upper], probability[upper], failure_probability[upper], survival=True)
            if np.any(~np.isfinite(lower_values)) or np.any(~np.isfinite(upper_values)):
                raise ValueError("NB2 inverse verification returned nonfinite probabilities")
            result[lower] = lower_values >= probabilities[lower]
            result[upper] = upper_values <= 1.0 - probabilities[upper]
            return result

        # Verify the discrete inverse in the stable tail, instead of trusting
        # a rounded-CDF ppf candidate near probability one.
        too_high = (candidate > 0) & reached(candidate - 1)
        while np.any(too_high):
            candidate[too_high] -= 1
            too_high = (candidate > 0) & reached(candidate - 1)
        too_low = ~reached(candidate)
        while np.any(too_low):
            if np.any(candidate[too_low] == np.iinfo(np.int64).max):
                raise ValueError("NB2 quantile exceeds int64")
            candidate[too_low] += 1
            too_low = ~reached(candidate)
        return candidate

    def cdf(self, counts):
        counts = np.asarray(counts, dtype=float)
        if np.any(~np.isfinite(counts)) or np.any(counts < 0) or np.any(counts != np.trunc(counts)):
            raise ValueError("CDF counts must be exact finite nonnegative integers")
        mu, alpha, counts = np.broadcast_arrays(self.mu, self.alpha, counts)
        result = np.ones(mu.shape, dtype=float)
        poisson_mask = (mu > 0) & (alpha == 0)
        nb_mask = (mu > 0) & (alpha > 0)
        result[poisson_mask] = gammaincc(counts[poisson_mask] + 1.0, mu[poisson_mask])
        shape, success_probability = self._nb_parameters(mu[nb_mask], alpha[nb_mask])
        failure_probability = alpha[nb_mask] * mu[nb_mask] / (1.0 + alpha[nb_mask] * mu[nb_mask])
        result[nb_mask] = self._nb_probability(counts[nb_mask], shape, success_probability, failure_probability)
        if np.any(~np.isfinite(result)):
            raise ValueError("count CDF returned nonfinite values")
        return result.item() if result.ndim == 0 else result

    def quantile(self, probabilities):
        probabilities = np.asarray(probabilities, dtype=float)
        if np.any(~np.isfinite(probabilities)) or np.any(probabilities < 0) or np.any(probabilities >= 1):
            raise ValueError("quantile probabilities must be finite in [0, 1)")
        mu, alpha, probabilities, zero_cdf = np.broadcast_arrays(self.mu, self.alpha, probabilities, self._zero_cdf)
        result = np.zeros(mu.shape, dtype=np.int64)
        poisson_mask = (mu > 0) & (alpha == 0) & (probabilities > zero_cdf)
        nb_mask = (mu > 0) & (alpha > 0) & (probabilities > zero_cdf)
        poisson_result = poisson.ppf(probabilities[poisson_mask], mu[poisson_mask])
        if np.any(~np.isfinite(poisson_result)) or np.any(poisson_result < 0) or np.any(poisson_result >= float(2 ** 63)):
            raise ValueError("Poisson quantile is not representable as nonnegative int64")
        result[poisson_mask] = poisson_result.astype(np.int64)
        result[nb_mask] = self._verified_nb_quantile(probabilities[nb_mask], mu[nb_mask], alpha[nb_mask])
        if (np.any(~np.isfinite(result)) or np.any(result < 0)
                or np.any(result != np.trunc(result)) or np.any(result >= float(2 ** 63))):
            raise ValueError("count quantile is not representable as nonnegative int64")
        return result.item() if result.ndim == 0 else result
