"""Independent scalar RNA point-mean checks; no production scorer imports."""
import math


def independent_deviance(truth, mean):
    if (not math.isfinite(float(truth)) or truth < 0 or int(truth) != truth
            or not math.isfinite(float(mean)) or mean < 0):
        raise ValueError('Exact nonnegative count and finite nonnegative mean required')
    truth, mean = int(truth), float(mean)
    if truth == 0:
        return 2 * mean
    if mean == 0:
        return math.inf
    delta = (mean-truth)/truth
    if abs(delta) < 0.01:
        # The literal power series for delta-log(1+delta) avoids cancelling
        # the first-order terms. No negative loss is clipped to zero.
        return 2 * truth * math.fsum((-1)**power * delta**power/power for power in range(2, 13))
    return 2 * math.fsum((truth * (math.log(truth) - math.log(mean)), -truth, mean))


def independent_decomposition(truths, means):
    truths, means = list(truths), list(means)
    if not truths or len(truths) != len(means):
        raise ValueError('Complete aligned member vectors required')
    values = [independent_deviance(y, mu) for y, mu in zip(truths, means)]
    member_sum = math.fsum(values) if all(math.isfinite(v) for v in values) else math.inf
    total_y, total_mu = sum(int(v) for v in truths), math.fsum(float(v) for v in means)
    total_loss = independent_deviance(total_y, total_mu)
    if total_y == 0 or total_mu == 0:
        return {'D7': member_sum, 'Dtotal': total_loss, 'allocation': None,
                'allocation_defined': False, 'status': 'zero_total_limit'}
    contributions = []
    for y, mu in zip(truths, means):
        if y == 0:
            contributions.append(0.0)
        elif mu == 0:
            contributions.append(math.inf)
        else:
            contributions.append(2 * y * (math.log(y) - math.log(total_y) - math.log(mu) + math.log(total_mu)))
    allocation = math.fsum(contributions) if all(math.isfinite(v) for v in contributions) else math.inf
    return {'D7': member_sum, 'Dtotal': total_loss, 'allocation': allocation,
            'allocation_defined': True, 'status': 'finite' if math.isfinite(member_sum) else 'positive_truth_zero_mean'}
