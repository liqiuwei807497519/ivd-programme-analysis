# Public path adaptation: help/description precedes all original scientific imports.
import argparse as _public_argparse
import json as _public_json
from pathlib import Path as _PublicPath
import sys as _public_sys
_public_description = {'purpose': 'path-interface description; no scientific execution', 'required_bindings': ['marker_file', 'programme_file', 'project_root'], 'expected_layout': 'project-root/extracted/<8 sections>/{counts.csv,spots.csv,FEATURE_MAP.csv}; project-root/PLAN.md and original analyze_v2.py provenance. Results and audit files retain original locations under project-root.', 'data_reads': 0, 'heavy_imports': 0, 'original_scientific_body_preserved_except_declared_path_assignment_values': True}
_public_parser = _public_argparse.ArgumentParser(description="Original analysis with explicit caller-owned paths; no data are bundled.")
_public_parser.add_argument('--describe-inputs', action='store_true', help='Print input layout and exit before imports/data access')
for _public_key in _public_description['required_bindings']:
    _public_parser.add_argument('--'+_public_key.replace('_','-'))
_public_args = _public_parser.parse_args()
if _public_args.describe_inputs:
    print(_public_json.dumps(_public_description))
    raise SystemExit(0)
for _public_key in _public_description['required_bindings']:
    if getattr(_public_args,_public_key) is None:
        _public_parser.error('Required binding: --'+_public_key.replace('_','-'))
def _public_binding(_public_key):
    return _PublicPath(getattr(_public_args,_public_key)).expanduser().resolve()
# Begin the preserved original body. Only declared path-assignment values differ.
"""Exploratory member measurements; no inferential p values, no predictor fitting."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import hashlib,json,time,itertools
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from scipy.spatial import cKDTree
from scipy.sparse import csr_matrix
ROOT=_public_binding('project_root')
SIG=_public_binding('programme_file')
MARK=_public_binding('marker_file')
RES=['TBXT','KRT8','KRT18','KRT19','ACAN','COL2A1','SOX9'];A=['ACAN','COL2A1'];B=[g for g in RES if g not in A]
def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def corr(x,y):
    good=np.isfinite(x)&np.isfinite(y);x=np.asarray(x)[good];y=np.asarray(y)[good]
    if len(x)<30 or np.ptp(x)==0 or np.ptp(y)==0:return np.nan
    return float(np.corrcoef(x,y)[0,1])
def spearman(x,y):return corr(rankdata(x),rankdata(y)) if np.all(np.isfinite(x)) and np.all(np.isfinite(y)) else np.nan
def adjusted(x,y,cov):
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):return np.nan
    c=np.column_stack([np.ones(len(x)),cov]);x=rankdata(x);y=rankdata(y)
    return corr(x-c@np.linalg.lstsq(c,x,rcond=None)[0],y-c@np.linalg.lstsq(c,y,rcond=None)[0])
def ratio_stats(x,y,minimum=1):
    mask=(x>=minimum)&(y>=minimum);n=int(mask.sum())
    r=np.log2(x[mask]/y[mask]);q=np.quantile(r,[.25,.5,.75]) if n>=30 else [np.nan]*3
    return {'eligible_spots':len(x),'co_detected':n,'co_detected_fraction':float(mask.mean()),'log2_ratio_median':float(q[1]),'log2_ratio_IQR':float(q[2]-q[0]),'status':'ESTIMABLE_CONDITIONAL_DESCRIPTION' if n>=30 else 'INSUFFICIENT_CODETECTION'}
def main():
    start=time.monotonic();out=ROOT/'results_v2';out.mkdir(exist_ok=True)
    source_paths=[SIG,MARK,ROOT/'PLAN.md',ROOT/'analyze_v2.py']+sorted((ROOT/'extracted').glob('*/*.csv'))
    lock=[{'path':str(p),'sha256':hashfile(p)} for p in source_paths]
    (ROOT/'ANALYSIS_LOCK_attempt2.json').write_text(json.dumps(lock,indent=2,ensure_ascii=False),encoding='utf8')
    pg=pd.read_csv(SIG,sep='\t');programmes=dict(zip(pg.programme,pg.genes.str.split(';')))
    targets=set().union(*map(set,programmes.values()));assert len(targets)==47
    assert not set(programmes['Resident_identity'])&set(programmes['Fibrosis'])
    mk=pd.read_csv(MARK);mk['gene']=mk.gene.str.upper();mk=mk[~mk.gene.isin(targets)].drop_duplicates()
    gene_rows=[];pairs=[];assoc=[];sections=[];prg_rows=[];spotframes=[];graphs=[];mapping=[]
    dirs=sorted((ROOT/'extracted').iterdir());assert len(dirs)==8
    for d in dirs:
        meta=pd.read_csv(d/'spots.csv');cnt=pd.read_csv(d/'counts.csv');fmap=pd.read_csv(d/'FEATURE_MAP.csv')
        assert meta.barcode.tolist()==cnt.barcode.tolist()
        section=meta.section.iloc[0];sample=meta.sampleid.iloc[0];n=len(meta)
        c=cnt.drop(columns='barcode');v=c.to_numpy();assert np.isfinite(v).all() and (v>=0).all() and np.equal(v,np.floor(v)).all()
        lib=meta.library_total.to_numpy();assert np.all(v.sum(axis=1)<=lib)
        log=pd.DataFrame(np.log1p(c.to_numpy()/lib[:,None]*1e4),columns=c.columns)
        complete={p:all(g in c for g in gs) for p,gs in programmes.items()}
        assert complete['Resident_identity'] and complete['Fibrosis']
        for _,r in fmap.iterrows():mapping.append({'section':section,**r.to_dict()})
        # No imputation for unavailable genes; programmes with a missing member remain NA.
        scores={p:log[gs].mean(axis=1).to_numpy() if complete[p] else np.full(n,np.nan) for p,gs in programmes.items()}
        am=log[A].mean(axis=1).to_numpy();bm=log[B].mean(axis=1).to_numpy();rscore=scores['Resident_identity']
        logden=log[RES].sum(axis=1).to_numpy();rawden=c[RES].sum(axis=1).to_numpy()
        share=np.divide(log[A].sum(axis=1),logden,out=np.full(n,np.nan),where=logden>0)
        rawshare=np.divide(c[A].sum(axis=1),rawden,out=np.full(n,np.nan),where=rawden>0)
        smeta={'section':section,'sampleid':sample,'spots':n,'original_library_sum':float(lib.sum()),'library_median':float(np.median(lib)),
               'all7_detected_fraction':float((c[RES]>0).all(axis=1).mean()),'any7_detected_fraction':float((rawden>0).mean()),
               'matrix2_share_of_summed_log_score':float(log[A].to_numpy().sum()/logden.sum()),
               'matrix2_raw_transcript_share':float(c[A].to_numpy().sum()/rawden.sum()),
               'full7_other5_spearman_overlapping_diagnostic':spearman(rscore,bm),
               'missing_target_symbols':';'.join(sorted(targets-set(c.columns)))}
        sections.append(smeta)
        for p,gs in programmes.items():
            prg_rows.append({'section':section,'sampleid':sample,'programme':p,'complete_feature_match':complete[p],
                             'mean_logCP10K':float(np.mean(scores[p])),'requested_genes':len(gs),'matched_genes':sum(g in c for g in gs)})
        for p,gs in programmes.items():
            for g in gs:
                exists=g in c
                gene_rows.append({'section':section,'sampleid':sample,'programme':p,'gene':g,'feature_present':exists,
                                  'total_count':int(c[g].sum()) if exists else np.nan,'detected_spots':int((c[g]>0).sum()) if exists else np.nan,
                                  'detection_fraction':float((c[g]>0).mean()) if exists else np.nan,
                                  'mean_logCP10K':float(log[g].mean()) if exists else np.nan})
        xy=meta[['image_x','image_y']].to_numpy();dist,idx=cKDTree(xy).query(xy,k=7)
        assert np.all(dist[:,1]>0)
        spacing=float(np.median(dist[:,1]));rr=np.repeat(np.arange(n),6);cc=idx[:,1:].ravel();keep=dist[:,1:].ravel()<=1.25*spacing
        w=csr_matrix((np.ones(keep.sum()),(rr[keep],cc[keep])),shape=(n,n));w=w.maximum(w.T);w.setdiag(1);w.data[:]=1
        pool=pd.DataFrame(w@c.to_numpy(),columns=c.columns);plib=w@lib;plog=pd.DataFrame(np.log1p(pool.to_numpy()/plib[:,None]*1e4),columns=c.columns)
        graphs.append({'section':section,'spots':n,'median_nn_image_pixels':spacing,'cutoff_image_pixels':1.25*spacing,'directed_edges_excluding_self':int(w.nnz-n),'pool_size_min':float(np.min(w.sum(axis=1))),'pool_size_max':float(np.max(w.sum(axis=1)))})
        q=np.asarray(pd.qcut(lib,4,labels=False,duplicates='drop'))
        for scale,counts in [('native_spot',c),('one_neighbourhood_sensitivity',pool)]:
            for ga,gb in itertools.product(A,B):
                for minimum in [1,3]:
                    for stratum,mask in [('all',np.ones(n,dtype=bool))]+[(f'UMI_Q{k+1}',q==k) for k in sorted(np.unique(q))]:
                        row={'section':section,'sampleid':sample,'scale':scale,'gene_numerator':ga,'gene_denominator':gb,'min_count_each':minimum,'depth_stratum':stratum}
                        row.update(ratio_stats(counts[ga].to_numpy()[mask],counts[gb].to_numpy()[mask],minimum));pairs.append(row)
        standardized_xy=(xy-xy.mean(axis=0))/xy.std(axis=0)
        spatial=np.column_stack([standardized_xy,standardized_xy**2,standardized_xy[:,0]*standardized_xy[:,1]])
        proxy=[]
        for ct,mg in mk.groupby('cell_type'):
            gs=[g for g in mg.gene if g in log];assert not set(gs)&targets
            if gs:proxy.append(log[gs].mean(axis=1).to_numpy())
        depth=rankdata(lib)[:,None]/n
        nuisance=np.column_stack([depth,*proxy,spatial]);nuisance=(nuisance-nuisance.mean(axis=0))/np.where(nuisance.std(axis=0)>0,nuisance.std(axis=0),1)
        comparisons=[('Matrix2','Other5',am,bm),('Resident_identity','Fibrosis',rscore,scores['Fibrosis']),('Resident_identity','Stress_senescence',rscore,scores['Stress_senescence'])]
        for left,right,x,y in comparisons:
            for treatment,value in [('native_unadjusted',spearman(x,y)),('depth_rank_projection',adjusted(x,y,depth)),('depth_proxy_space_projection',adjusted(x,y,nuisance))]:
                assoc.append({'section':section,'sampleid':sample,'left':left,'right':right,'treatment':treatment,'stratum':'all','spots':n,'association':value})
            for zone,mi in meta.groupby('partition').groups.items():
                mi=np.asarray(mi)
                if len(mi)>=30:assoc.append({'section':section,'sampleid':sample,'left':left,'right':right,'treatment':'unverified_partition_sensitivity','stratum':str(zone),'spots':len(mi),'association':spearman(x[mi],y[mi])})
        assoc.append({'section':section,'sampleid':sample,'left':'Matrix2','right':'Other5','treatment':'one_neighbourhood_sensitivity','stratum':'all','spots':n,'association':spearman(plog[A].mean(axis=1),plog[B].mean(axis=1))})
        sf=meta.copy();sf['Matrix2']=am;sf['Other5']=bm
        sf['matrix2_log_score_share']=share;sf['matrix2_transcript_share']=rawshare
        for p,s in scores.items():sf[p]=s
        for g in RES:sf[g+'_raw']=c[g];sf[g+'_logCP10K']=log[g]
        # Showcase map fixed to Acan/Krt19 before inspecting values; all ten pairs remain in tables.
        mask=(c.ACAN>0)&(c.KRT19>0);sf['ACAN_KRT19_log2_raw_ratio']=np.where(mask,np.log2(c.ACAN.where(mask)/c.KRT19.where(mask)),np.nan)
        spotframes.append(sf)
        print(section,n,'primary pairs',sum(x['status'].startswith('ESTIMABLE') for x in pairs if x['section']==section and x['scale']=='native_spot' and x['min_count_each']==1 and x['depth_stratum']=='all'),flush=True)
    tables={'section_summary':sections,'gene_section_measurements':gene_rows,'pair_ratio_measurements':pairs,'associations':assoc,'programmes_by_section':prg_rows,'spatial_neighbourhoods':graphs,'feature_reconciliation':mapping}
    for name,rows in tables.items():pd.DataFrame(rows).to_csv(out/f'{name}.tsv',sep='\t',index=False)
    spots=pd.concat(spotframes,ignore_index=True);assert len(spots)==11893 and not spots.duplicated(['section','barcode']).any()
    spots.to_csv(out/'spot_measurements.tsv.gz',sep='\t',index=False,compression='gzip')
    p=pd.DataFrame(pairs);primary=p[(p.scale=='native_spot')&(p.min_count_each==1)&(p.depth_stratum=='all')];assert len(primary)==80
    sample_rows=[]
    for keys,grp in primary.groupby(['sampleid','gene_numerator','gene_denominator']):
        assert len(grp)==2
        ok=grp.log2_ratio_IQR.notna().all()
        sample_rows.append(dict(zip(['sampleid','gene_numerator','gene_denominator'],keys))|{'sections_available':int(grp.log2_ratio_IQR.notna().sum()),'section_equal_IQR':float(grp.log2_ratio_IQR.mean()) if ok else np.nan,'section_equal_median':float(grp.log2_ratio_median.mean()) if ok else np.nan,'section_equal_codetection':float(grp.co_detected_fraction.mean())})
    pd.DataFrame(sample_rows).to_csv(out/'pair_ratios_by_sampleid.tsv',sep='\t',index=False)
    sec=pd.DataFrame(sections)
    report={'status':'COMPLETE_DESCRIPTIVE_ANALYSIS_PENDING_RECHECK','sections':8,'sampleid_groups':4,'spots':11893,'independent_animals':None,'primary_pair_records':80,'estimable_primary_pair_records':int(primary.log2_ratio_IQR.notna().sum()),'all_primary_pair_records_retained':True,'complete_programmes':dict(pd.DataFrame(prg_rows).groupby('programme').complete_feature_match.all()),'matrix2_log_score_share_minmax':[float(sec.matrix2_share_of_summed_log_score.min()),float(sec.matrix2_share_of_summed_log_score.max())],'all7_detection_fraction_minmax':[float(sec.all7_detected_fraction.min()),float(sec.all7_detected_fraction.max())],'elapsed_seconds':time.monotonic()-start,'predictive_model_training':False,'raw_CTM_read':True,'sealed_cohorts_read':False,'p_values_computed':False,'orthology_certified':False,'partition_anatomy_certified':False,'claim':'conditional member-ratio heterogeneity and descriptive associations, not degeneration-induced cellular decoupling'}
    (ROOT/'REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False,default=lambda x:bool(x) if isinstance(x,np.bool_) else x.item()),encoding='utf8');print(json.dumps(report,ensure_ascii=False,default=lambda x:bool(x) if isinstance(x,np.bool_) else x.item()),flush=True)
if __name__=='__main__':main()
