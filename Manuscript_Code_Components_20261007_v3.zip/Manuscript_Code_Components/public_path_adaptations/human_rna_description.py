# Public path adaptation: help/description precedes all original scientific imports.
import argparse as _public_argparse
import json as _public_json
from pathlib import Path as _PublicPath
import sys as _public_sys
_public_description = {'purpose': 'path-interface description; no scientific execution', 'required_bindings': ['programme_file', 'project_root', 'source_root'], 'expected_layout': 'source-root/derived_structure/GSM906*.loom and source-root/downloads/*.loom.gz (5 paired files); project-root/PLAN.md. Original REPORT.json remains under project-root.', 'data_reads': 0, 'heavy_imports': 0, 'original_scientific_body_preserved_except_declared_path_assignment_values': True}
_public_parser = _public_argparse.ArgumentParser(description="Original analysis with explicit caller-owned paths; no data are bundled.")
_public_parser.add_argument('--describe-inputs', action='store_true', help='Print input layout and exit before imports/data access')
for _public_key in _public_description['required_bindings']:
    _public_parser.add_argument('--'+_public_key.replace('_','-'))
_public_args = _public_parser.parse_args()
if _public_args.describe_inputs:
    print(_public_json.dumps(_public_description))
    raise SystemExit(0)
for _public_key in _public_description['required_bindings']:
    if getattr(_public_args,_public_key) is None:
        _public_parser.error('Required binding: --'+_public_key.replace('_','-'))
def _public_binding(_public_key):
    return _PublicPath(getattr(_public_args,_public_key)).expanduser().resolve()
# Begin the preserved original body. Only declared path-assignment values differ.
import os
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
import time
import h5py
import numpy as np
import psutil

here=_public_binding('project_root')
old=_public_binding('source_root')
frozen=_public_binding('programme_file')
assert hashlib.sha256(frozen.read_bytes()).hexdigest()=='ee2ea983f83bf63c8d4424113c69e9ebce59decaf7d6717c724f3c9ef5343afd'
with frozen.open(encoding='utf-8-sig') as f:programmes={r['programme']:r['genes'].split(';') for r in csv.DictReader(f,delimiter='\t')}
targets=sorted(set().union(*map(set,programmes.values())));assert len(targets)==47
def digest(stream):
    sha=hashlib.sha256()
    for block in iter(lambda:stream.read(4*1024*1024),b''):sha.update(block)
    return sha.hexdigest()
def check(a):
    if not np.isfinite(a).all() or (a<0).any() or not np.equal(a,np.floor(a)).all():raise ValueError('Invalid counts')
def score(c,den):
    if den==0:return None
    return np.log1p(10000*c/den)
assert np.allclose(score(np.array([1.,3.]),4),np.log1p([2500.,7500.]))
assert score(np.zeros(2),0) is None
for bad in (np.array([-1]),np.array([.5]),np.array([np.nan])):
    try:check(bad)
    except ValueError:pass
    else:raise AssertionError('Invalid input accepted')
records=[];t=time.monotonic();peak=0
files=sorted((old/'derived_structure').glob('GSM906*.loom'));assert len(files)==5
for i,path in enumerate(files,1):
    with path.open('rb') as stream:derived_sha=digest(stream)
    with gzip.open(old/'downloads'/(path.name+'.gz'),'rb') as stream:original_derived_sha=digest(stream)
    assert derived_sha==original_derived_sha
    with h5py.File(path,'r') as h:
        decode=lambda xs:[x.decode() if isinstance(x,bytes) else str(x) for x in xs]
        genes=decode(h['row_attrs/Gene'][:]);accessions=decode(h['row_attrs/Accession'][:]);cells=decode(h['col_attrs/CellID'][:])
        assert all(genes.count(g)==1 for g in targets) and len(set(cells))==len(cells)
        arrays={k:np.asarray(h['layers'][k][:],dtype=np.float64) for k in ('spliced','unspliced','ambiguous')}
        arrays['matrix']=np.asarray(h['matrix'][:],dtype=np.float64)
        for a in arrays.values():check(a)
        assert all(a.shape==(len(genes),len(cells)) for a in arrays.values())
        idx=[genes.index(g) for g in targets]
        views={'assigned_S_U':arrays['spliced']+arrays['unspliced'],'spliced_only':arrays['spliced'],
               'inclusive_S_U_A':arrays['spliced']+arrays['unspliced']+arrays['ambiguous']}
        rec={'file':path.name,'source_assigned_donor':i,'columns':len(cells),'gene_rows':len(genes),'derived_sha256':derived_sha,
             'human_Ensembl_id_count':sum(g.startswith('ENSG') for g in accessions),
             'matrix_equalities':{'S':np.array_equal(arrays['matrix'],arrays['spliced']),
                                  'S_U':np.array_equal(arrays['matrix'],views['assigned_S_U']),
                                  'S_U_A':np.array_equal(arrays['matrix'],views['inclusive_S_U_A'])},'views':{}}
        for view,a in views.items():
            pooled=a.sum(axis=1);library=float(pooled.sum());target_counts=pooled[idx]
            values=score(target_counts,library)
            rec['views'][view]={'library_total':library,'zero_columns':int((a.sum(axis=0)==0).sum()),
                                'target_counts':dict(zip(targets,map(float,target_counts))),
                                'target_log1p_CP10K':None if values is None else dict(zip(targets,map(float,values))),
                                'programmes':{p:None if values is None else float(np.mean([values[targets.index(g)] for g in gs])) for p,gs in programmes.items()}}
        rec['layer_totals']={k:float(a.sum()) for k,a in arrays.items()}
        records.append(rec)
    peak=max(peak,psutil.Process().memory_info().rss)
    if peak>512*1024**2 or time.monotonic()-t>120:raise RuntimeError('Budget exceeded')
    print(json.dumps({'file':path.name,'library':rec['views']['assigned_S_U']['library_total'],'programmes':rec['views']['assigned_S_U']['programmes']}),flush=True)
    del arrays,views
out={'status':'NUMERICAL_DESCRIPTION_COMPLETE_PENDING_INDEPENDENT_RECHECK','records':records,'programmes':programmes,
     'genes':targets,'elapsed_seconds':time.monotonic()-t,'peak_own_sampled_rss':peak,'fits':0,'pvalues_computed':False,
     'plan_sha256':hashlib.sha256((here/'PLAN.md').read_bytes()).hexdigest()}
(here/'REPORT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
