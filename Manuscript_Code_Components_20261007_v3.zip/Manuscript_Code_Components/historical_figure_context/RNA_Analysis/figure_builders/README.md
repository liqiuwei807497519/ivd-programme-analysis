# Original RNA Figure4 builder

`build_source_rna_figure.py` is the exact plotting implementation that generated the current12-panel RNA plate. It retains the original completed-run bindings and local installed multiomics style dependency. Derived regional results and summary tables are supplied in `Source_Data/RNA_Mean`; native source-count inputs for measured spatial panels are not redistributed.

This is a source-provenance implementation with separately authorized source inputs, not an independently executed public-source acquisition or self-contained all-panel replay. The portable adapters elsewhere in `RNA_Analysis` concern the RNA scientific stages; the FieldLaw replay in Additional21 concerns regional probability arithmetic, not this figure.
