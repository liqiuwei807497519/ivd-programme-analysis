"""Fresh-process target stages; forecasts precede all response decoding."""

import argparse
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import sys

for _thread_name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_thread_name] = "2"

import numpy as np

SYNTHETIC_MODE = "SYNTHETIC_TARGET_STAGES"
SYNTHETIC_CONFIG_MODES = (SYNTHETIC_MODE, "SYNTHETIC_SUPERVISOR_TEST")
REAL_CONFIG_MODE = "AUTHORIZED_REAL_SOURCE_FIT"
REAL_MODE = "AUTHORIZED_REAL_TARGET_STAGES"
GENES = ["TBXT", "KRT8", "KRT18", "KRT19", "ACAN", "COL2A1", "SOX9"]
LAWS = ("INDEPENDENT_GENE_FIELDS", "FIXED_RHO025_COMMON_FIELD", "POOLED_SOURCE_CORR", "CONDITIONAL_SOURCE_CORR")
SUPPORT_SHIFT = "source48um_square_and_target_native55um_visium_counts; no physical_support_or_assay_equivalence_claim"


def _sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def _write_json(path, value):
    def converter(item):
        if isinstance(item, np.ndarray):
            return item.tolist()
        if isinstance(item, np.generic):
            return item.item()
        raise TypeError(type(item).__name__)
    with Path(path).open("x", encoding="utf8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False, default=converter) + "\n")


def _record(path):
    return {"path": str(Path(path).resolve()), "sha256": _sha(path)}


def _verified(records):
    results = {}
    for record in records:
        path = Path(record["path"]).resolve()
        if re.fullmatch("[0-9a-f]{64}", record["sha256"]) is None or _sha(path) != record["sha256"]:
            raise ValueError("frozen file hash mismatch: " + str(path))
        results[str(path)] = record["sha256"]
    return results


def _install_guard(allowed, output, code_records):
    allowed = {str(Path(path).resolve()).casefold() for path in allowed}
    output = output.resolve()
    runtime = [Path(sys.prefix).resolve(), Path(sys.base_prefix).resolve(), Path(np.__file__).resolve().parents[1]]
    code_parents = {Path(record["path"]).resolve().parent for record in code_records if Path(record["path"]).suffix == ".py"}
    reads, writes, denied = [], [], []

    def audit(event, args):
        if event != "open" or isinstance(args[0], int):
            return
        path = Path(os.fsdecode(args[0])).resolve()
        mode, flags = args[1] or "", args[2] or 0
        writing = any(letter in mode for letter in "wax+") or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC))
        is_output = path == output or output in path.parents
        is_runtime = any(path == prefix or prefix in path.parents for prefix in runtime)
        is_source_code = path.suffix.casefold() == ".py" and path.parent in code_parents
        forbidden = path.suffix.casefold() in (".rds", ".rdata") or "sealed_b" in path.name.casefold()
        accepted = not forbidden and (is_output if writing else
                    (str(path).casefold() in allowed or is_output or is_runtime or is_source_code))
        if not accepted:
            denied.append({"path": str(path), "writing": writing})
            raise PermissionError("target stage Python open guard denied: " + str(path))
        (writes if writing else reads).append(str(path))

    sys.addaudithook(audit)
    return reads, writes, denied


def _metadata(target, config):
    with gzip.open(target["features"]["path"], "rt", encoding="utf8") as stream:
        features = [line.rstrip("\r\n").split("\t") for line in stream]
    if len(features) != target["gene_rows"] or any(len(row) < 2 or not row[0] or not row[1] for row in features):
        raise ValueError("released feature metadata differs from declared complete gene rows")
    roles = {}
    for column, row in enumerate(features, 1):
        for token in set(row[:2]):
            roles.setdefault(token, []).append(column)
    input_ids = config["linkage"]["input_ids"]
    if any(len(roles.get(token, [])) != 1 for token in input_ids):
        raise ValueError("all 126 exact input roles must map uniquely to released rows")
    member_ids = target.get("member_feature_ids", config["linkage"]["member_ids"])
    if config["mode"] == REAL_CONFIG_MODE and "member_feature_ids" not in target:
        raise ValueError("real target member rows require seven frozen exact feature IDs")
    if len(member_ids) != 7 or len(set(member_ids)) != 7:
        raise ValueError("target member feature IDs must be exactly seven distinct ordered IDs")
    member_lookup = {}
    for index, row in enumerate(features, 1):
        member_lookup.setdefault(row[0], []).append(index)
    if any(len(member_lookup.get(token, [])) != 1 for token in member_ids):
        raise ValueError("all seven frozen member feature IDs must map uniquely to released rows")
    input_rows = [roles[token][0] for token in input_ids]
    member_rows = [member_lookup[token][0] for token in member_ids]
    if "member_feature_rows" in target and member_rows != target["member_feature_rows"]:
        raise ValueError("target member rows differ from the frozen feature-ID row binding")
    if len(set(input_rows + member_rows)) != 133:
        raise ValueError("released input/member roles must be disjoint")
    with gzip.open(target["barcodes"]["path"], "rt", encoding="utf8") as stream:
        barcodes = [line.strip() for line in stream]
    if len(barcodes) != target["observations"] or not all(barcodes) or len(set(barcodes)) != len(barcodes):
        raise ValueError("released barcodes must match the complete declared observations uniquely")
    with Path(config["target_coordinates"]["path"]).open(encoding="utf-8-sig", newline="") as stream:
        coordinates = list(csv.DictReader(stream, delimiter="\t"))
    selected = [row for row in coordinates if row["sample"] == target["capture"]]
    if len(selected) != len(barcodes) or {row["observed_barcode"] for row in selected} != set(barcodes):
        raise ValueError("native coordinates must match every published barcode exactly")
    lookup = {}
    for row in selected:
        barcode = row["observed_barcode"]
        if barcode in lookup:
            raise ValueError("native coordinates contain duplicate barcodes")
        array_coordinates = np.asarray([float(row["array_row"]), float(row["array_col"])])
        relative = np.asarray([float(row["native_relative_lattice_x_pitch"]), float(row["native_relative_lattice_y_pitch"])])
        if not np.isfinite(array_coordinates).all() or np.any(array_coordinates != np.trunc(array_coordinates)) or not np.isfinite(relative).all():
            raise ValueError("native array/lattice coordinates must be finite, with integer row/column")
        expected_relative = np.asarray([array_coordinates[1] / 2.0, array_coordinates[0] * np.sqrt(3.0) / 2.0])
        if not np.allclose(relative, expected_relative, rtol=0, atol=1e-10):
            raise ValueError("native relative lattice differs from array_col/2 and array_row*sqrt(3)/2")
        lookup[barcode] = 100.0 * relative
    return input_rows, member_rows, barcodes, np.asarray([lookup[barcode] for barcode in barcodes])


def _prepare(config, target, run_root, output):
    from matrix_io import extract_allowed_counts
    from workflow import region_indices
    matrix = run_root / "acquired" / target["matrix_name"]
    if matrix.stat().st_size != target["matrix_expected_bytes"]:
        raise ValueError("cached matrix bytes differ from the released fixed expectation")
    input_rows, member_rows, barcodes, coordinates = _metadata(target, config)
    x, matrix_receipt = extract_allowed_counts(matrix, input_rows, target["gene_rows"], target["observations"])
    ids = np.asarray([target["capture"] + "|" + barcode for barcode in barcodes])
    order = np.argsort(ids, kind="stable")
    ids, x, coordinates = ids[order], x[order], coordinates[order]
    roi_indices, roi_keys = region_indices(coordinates)
    output.mkdir(parents=True, exist_ok=False)
    capsule = output / "INPUTS.npz"
    np.savez_compressed(capsule, x_counts=x, region_id=ids, coords_um=coordinates,
                        roi_indices=roi_indices, roi_keys=roi_keys,
                        input_rows=np.asarray(input_rows), member_rows=np.asarray(member_rows))
    return {"artifacts": {"INPUTS.npz": _record(capsule)}, "observations": len(ids),
            "regions": len(roi_keys), "matrix_sha256": _sha(matrix), "matrix_expected_bytes": matrix.stat().st_size,
            "matrix_receipt": matrix_receipt, "target_member_numeric_values_parsed": 0,
            "complete_published_support_sorted_together": True, "target_predictive_input_gene_count": 126}


def _child_commit(config, run_root, capture, stage, source_hash):
    output = run_root / "targets" / capture / stage
    path = output / (stage.upper() + "_COMMIT.json")
    commit = _read_json(path)
    if (commit["status"] != "TARGET_" + stage.upper() + "_COMMITTED" or commit["capture"] != capture
            or commit["stage"] != stage or commit["source_params_sha256"] != source_hash
            or commit["config_sha256"] != config):
        raise ValueError("prior target stage commit role/config/source mismatch")
    required = {"prepare": {"INPUTS.npz"}, "forecast": {name + ending for name in LAWS for ending in (".npz", "_RECEIPT.json")},
                "truth": {"TRUTH.npz"}, "score": {"ROWS.tsv", "SCORES.json"}}[stage]
    if set(commit["artifacts"]) != required:
        raise ValueError("prior target stage has an incomplete artifact set")
    for name, artifact in commit["artifacts"].items():
        if Path(artifact["path"]).resolve() != (output / name).resolve() or _sha(artifact["path"]) != artifact["sha256"]:
            raise ValueError("prior target artifact hash/path mismatch")
    return commit


def _global_barrier(config, run_root, stage, source_hash, config_hash):
    path = run_root / ("GLOBAL_" + stage.upper() + "_COMMIT.json")
    value = _read_json(path)
    expected_status = "ALL_TARGET_" + ("FORECASTS" if stage == "forecast" else "TRUTHS") + "_COMMITTED"
    captures = {item["capture"] for item in config["targets"]}
    if value["status"] != expected_status or value["config_sha256"] != config_hash or set(value["captures"]) != captures:
        raise ValueError("global barrier must commit the complete capture set and fixed config")
    records = [_record(path)]
    for capture in sorted(captures):
        child_record = value["captures"][capture]
        expected_path = run_root / "targets" / capture / stage / (stage.upper() + "_COMMIT.json")
        if (type(child_record.get("external_exit_code")) is not int or child_record["external_exit_code"] != 0
                or Path(child_record["path"]).resolve() != expected_path.resolve()
                or _sha(expected_path) != child_record["sha256"]):
            raise ValueError("global barrier requires every matching child hash and external exit0")
        child = _child_commit(config_hash, run_root, capture, stage, source_hash)
        records.append({"path": str(expected_path), "sha256": child_record["sha256"]})
        records.extend(child["artifacts"].values())
        if stage == "forecast":
            worlds = 64 if config["mode"] in SYNTHETIC_CONFIG_MODES else 2048
            if set(child["laws"]) != set(LAWS) or child["world_count"] != worlds:
                raise ValueError("global forecast barrier requires all four fixed laws and world count")
            for law in LAWS:
                descriptor = child["laws"][law]
                if ({"path": descriptor["path"], "sha256": descriptor["sha256"]} != child["artifacts"][law + ".npz"]
                        or descriptor["receipt"] != child["artifacts"][law + "_RECEIPT.json"]):
                    raise ValueError("global forecast law artifact/receipt descriptors disagree")
                receipt = _read_json(descriptor["receipt"]["path"])
                if (receipt["world_count"] != worlds or receipt["capture"] != capture or receipt["law"] != law
                        or receipt["source_params_sha256"] != source_hash or receipt["config_sha256"] != config_hash
                        or receipt["new_point_model_fits"] != 0 or receipt["target_member_reads"] != 0
                        or receipt["extra_worlds"] != 0):
                    raise ValueError("global forecast receipt identity/count/role mismatch")
    return records, _sha(path)


def _load_inputs(path, target):
    from workflow import region_indices
    with np.load(path, allow_pickle=False) as archive:
        required = {"x_counts", "region_id", "coords_um", "roi_indices", "roi_keys", "input_rows", "member_rows"}
        if set(archive.files) != required:
            raise ValueError("prepared A0 capsule role schema differs from fixed contract")
        data = {name: archive[name] for name in archive.files}
    n = target["observations"]
    ids, x, coordinates = data["region_id"].astype(str), data["x_counts"], data["coords_um"]
    if (ids.shape != (n,) or len(set(ids)) != n or ids.tolist() != sorted(ids.tolist())
            or any(not value.startswith(target["capture"] + "|") for value in ids)
            or x.shape != (n, 126) or x.dtype.kind not in "iu" or np.any(x < 0) or coordinates.shape != (n, 2)):
        raise ValueError("prepared capsule must preserve complete canonical integer input support")
    roi, keys = region_indices(coordinates)
    if not np.array_equal(roi, data["roi_indices"]) or not np.array_equal(keys, data["roi_keys"]):
        raise ValueError("prepared ROI projection differs from frozen complete geometry")
    return data


def _forecast(config, target, run_root, output, source_hash, config_hash):
    from frozen_adapter import FrozenMeanPredictor
    from source_statistics import source_state_weights, source_state_basis
    from field_core import FieldLaw
    from workflow import bank_for
    prepare = _child_commit(config_hash, run_root, target["capture"], "prepare", source_hash)
    inputs_path = prepare["artifacts"]["INPUTS.npz"]["path"]
    inputs = _load_inputs(inputs_path, target)
    capsule = _read_json(run_root / "source" / "SOURCE_PARAMS.json")
    params = capsule.get("parameters", capsule)
    if capsule["linkage"] != config["linkage"]:
        raise ValueError("frozen source/input/member linkage differs from config")
    sources = sorted(config["source_records"], key=lambda record: record["capture"])
    if len(sources) != 2:
        raise ValueError("frozen point replay requires exactly two source predictors")
    heads = [_read_json(source["head_params"]["path"]) for source in sources]
    totals = [_read_json(source["total_params"]["path"]) for source in sources]
    for head in heads:
        if head["input_ids"] != config["linkage"]["input_ids"] or head["member_ids"] != GENES:
            raise ValueError("frozen head role ordering differs from A0/member linkage")
    predictor = FrozenMeanPredictor(heads, totals)
    mu7, prediction_receipt = predictor.predict(inputs["x_counts"], inputs["region_id"].tolist())
    weights = source_state_weights(inputs["x_counts"], params)
    H = source_state_basis(inputs["coords_um"], weights)
    worlds = 64 if config["mode"] in SYNTHETIC_CONFIG_MODES else 2048
    if config.get("worlds", worlds) != worlds:
        raise ValueError("world count differs from fixed stage mode; no extra or fewer real worlds")
    mode = SYNTHETIC_MODE if config["mode"] in SYNTHETIC_CONFIG_MODES else REAL_MODE
    domain = ("FieldLawSyntheticV1:" if mode == SYNTHETIC_MODE else "FieldLawRealV1:") + target["capture"]
    output.mkdir(parents=True, exist_ok=False)
    laws, artifacts = {}, {}
    for law in LAWS:
        field = FieldLaw(mu7, np.asarray(params["alpha7"]), weights, H, bank_for(law, params), gamma=0.25)
        samples, field_receipt = field.sample_gene_region_totals(inputs["roi_indices"], worlds, domain, chunk_size=64)
        path = output / (law + ".npz")
        np.savez_compressed(path, gene_region_totals=samples, region_keys=inputs["roi_keys"], mu7=mu7,
                            member_ids=np.asarray(GENES), canonical_ids=inputs["region_id"])
        receipt_path = output / (law + "_RECEIPT.json")
        _write_json(receipt_path, {**field_receipt, "law": law, "mode": mode, "capture": target["capture"],
                    "date_utc": datetime.now(timezone.utc).isoformat(), "global_barrier": "SOURCE_COMMIT_AND_PREPARE_VERIFIED",
                    "source_params_sha256": source_hash, "input_capsule_sha256": prepare["artifacts"]["INPUTS.npz"]["sha256"],
                    "config_sha256": config_hash, "count_support_shift": SUPPORT_SHIFT,
                    "frozen_prediction_receipt": prediction_receipt, "new_point_model_fits": 0, "target_member_reads": 0})
        artifacts[path.name], artifacts[receipt_path.name] = _record(path), _record(receipt_path)
        laws[law] = {**artifacts[path.name], "receipt": artifacts[receipt_path.name]}
    return {"artifacts": artifacts, "laws": laws, "world_count": worlds,
            "observations": target["observations"], "regions": len(inputs["roi_keys"]),
            "input_capsule_sha256": prepare["artifacts"]["INPUTS.npz"]["sha256"], "target_member_numeric_values_parsed": 0}


def _aggregate(values, roi, regions):
    totals = np.zeros((regions, values.shape[1]), dtype=np.int64)
    safe = np.iinfo(np.int64).max // int(np.bincount(roi, minlength=regions).max())
    if int(values.max()) <= safe:
        np.add.at(totals, roi, values)
    else:
        for region in range(regions):
            selected = values[roi == region]
            for gene in range(values.shape[1]):
                total = sum(int(value) for value in selected[:, gene])
                if total > np.iinfo(np.int64).max:
                    raise ValueError("truth ROI total exceeds int64; no rounding or cap")
                totals[region, gene] = total
    return totals


def _truth(config, target, run_root, output, source_hash, config_hash, global_hash):
    from matrix_io import extract_allowed_counts
    prepare = _child_commit(config_hash, run_root, target["capture"], "prepare", source_hash)
    inputs = _load_inputs(prepare["artifacts"]["INPUTS.npz"]["path"], target)
    matrix = run_root / "acquired" / target["matrix_name"]
    if matrix.stat().st_size != target["matrix_expected_bytes"] or _sha(matrix) != prepare["matrix_sha256"]:
        raise ValueError("truth matrix differs from the complete input-stage matrix commitment")
    input_rows, member_rows, barcodes, coordinates = _metadata(target, config)
    if not np.array_equal(inputs["input_rows"], input_rows) or not np.array_equal(inputs["member_rows"], member_rows):
        raise ValueError("truth/input gene-role mapping differs from prepared commitment")
    counts, receipt = extract_allowed_counts(matrix, list(range(1, target["gene_rows"] + 1)),
                                             target["gene_rows"], target["observations"])
    ids = np.asarray([target["capture"] + "|" + barcode for barcode in barcodes])
    order = np.argsort(ids, kind="stable")
    if (not np.array_equal(ids[order], inputs["region_id"])
            or not np.array_equal(coordinates[order], inputs["coords_um"])
            or not np.array_equal(counts[order][:, np.asarray(input_rows) - 1], inputs["x_counts"])):
        raise ValueError("truth decoder input columns/IDs/coordinates differ from committed A0 capsule")
    y7 = counts[order][:, np.asarray(member_rows) - 1]
    truth = _aggregate(y7, inputs["roi_indices"], len(inputs["roi_keys"]))
    del counts
    output.mkdir(parents=True, exist_ok=False)
    path = output / "TRUTH.npz"
    np.savez_compressed(path, gene_region_truth=truth, region_keys=inputs["roi_keys"],
                        canonical_ids=inputs["region_id"], member_ids=np.asarray(GENES), spot_member_counts=y7)
    return {"artifacts": {"TRUTH.npz": _record(path)}, "global_forecast_sha256": global_hash,
            "complete_matrix_all_rows_integer_validated": True, "input_capsule_exact_match": True,
            "target_gene_rows_validated": target["gene_rows"], "observations": target["observations"],
            "regions": len(inputs["roi_keys"]), "truth_matrix_sha256": _sha(matrix), "matrix_receipt": receipt,
            "input_capsule_sha256": prepare["artifacts"]["INPUTS.npz"]["sha256"]}


def _score_vectors(result):
    vectors = {name: np.asarray(result[name]) for name in
               ("empirical_rps", "scaled_empirical_rps", "wis", "scaled_wis", "median",
                "median_absolute_error", "scaled_median_absolute_error")}
    for name in ("fair_rps", "scaled_fair_rps"):
        if result[name] is not None:
            vectors[name] = np.asarray(result[name])
    for level, interval in result["intervals"].items():
        for name in ("lower", "upper", "left_miss", "right_miss", "width", "scaled_width", "interval_score", "scaled_interval_score"):
            vectors[name + "_" + level] = np.asarray(interval[name], dtype=float)
        vectors["coverage_" + level] = (~interval["left_miss"] & ~interval["right_miss"]).astype(float)
    return vectors


def _score_summary(result):
    summary = {name + "_mean": float(np.mean(result[name])) for name in
               ("empirical_rps", "scaled_empirical_rps", "wis", "scaled_wis", "median_absolute_error", "scaled_median_absolute_error")}
    for name in ("fair_rps", "scaled_fair_rps"):
        summary[name + "_mean"] = None if result[name] is None else float(np.mean(result[name]))
    summary["IID"] = result["IID"]
    summary["scenario_count"] = result["scenario_count"]
    summary["intervals"] = {}
    for level, interval in result["intervals"].items():
        summary["intervals"][level] = {
            "nominal_coverage": interval["level"],
            "coverage": float(np.mean(~interval["left_miss"] & ~interval["right_miss"])),
            "left_miss_rate": float(np.mean(interval["left_miss"])),
            "right_miss_rate": float(np.mean(interval["right_miss"])),
            **{name + "_mean": float(np.mean(interval[name])) for name in
               ("width", "scaled_width", "interval_score", "scaled_interval_score")}}
    return summary


def _evaluate(gene_totals, truth, scales, IID=True):
    from workflow import sum_functionals
    from scoring import score_ensembles, event_brier
    functions = sum_functionals(gene_totals)
    truth_functions = sum_functionals(truth[None, :, :])
    results = {name: score_ensembles(values, truth_functions[name][0], scales[name], IID=IID)
               for name, values in functions.items()}
    observed = np.all(truth > 0, axis=1)
    event = event_brier(np.all(gene_totals > 0, axis=2), observed)
    event_summary = {"brier_mean": float(np.mean(event["brier"])),
                     "event_probability_mean": float(np.mean(event["event_probability"])),
                     "truth_event_rate": float(np.mean(observed))}
    return results, event, {"functionals": {name: _score_summary(value) for name, value in results.items()}, "event": event_summary}


def _precision(gene_totals, truth, scales):
    worlds = len(gene_totals)
    if worlds % 16 or worlds < 32:
        raise ValueError("fixed MC precision requires two equal blocks and 16 shared world groups")
    blocks = []
    for start in (0, worlds // 2):
        _, _, summary = _evaluate(gene_totals[start:start + worlds // 2], truth, scales)
        blocks.append({"scenario_start": start, "world_count": worlds // 2, **summary})
    groups = np.array_split(np.arange(worlds, dtype=np.int64), 16)
    estimates, event_estimates = {}, {"event_probability": [], "brier": []}
    for group in groups:
        keep = np.ones(worlds, dtype=bool)
        keep[group] = False
        results, event, _ = _evaluate(gene_totals[keep], truth, scales)
        for functional, result in results.items():
            slots = estimates.setdefault(functional, {})
            for metric, values in _score_vectors(result).items():
                slots.setdefault(metric, []).append(values)
        for metric, values in event.items():
            event_estimates[metric].append(values)

    def package(slots):
        array = {metric: np.stack(values) for metric, values in slots.items()}
        roi_means = {metric: values.mean(axis=1) for metric, values in array.items()}
        mcse_regions = {metric: np.sqrt(15.0 / 16.0 * np.sum((values - values.mean(axis=0)) ** 2, axis=0)) for metric, values in array.items()}
        mcse_means = {metric: float(np.sqrt(15.0 / 16.0 * np.sum((values - values.mean()) ** 2))) for metric, values in roi_means.items()}
        return {"delete_group_region_metric_arrays": array, "delete_group_roi_mean_estimates": roi_means,
                "mcse_region_metrics": mcse_regions, "mcse_roi_means": mcse_means}

    return {"interpretation": "numerical Monte Carlo integration uncertainty only",
            "biological_confidence_interval": False, "two_seed_blocks": blocks,
            "shared_world_delete_group": {
                "group_count": 16, "group_size": worlds // 16,
                "group_world_ids_sha256": [hashlib.sha256(group.astype("<i8").tobytes()).hexdigest() for group in groups],
                "membership": "consecutive world IDs; same deletion groups across every ROI, functional, law and library",
                "functionals": {name: package(slots) for name, slots in estimates.items()}, "event": package(event_estimates)}}


def _append_rows(rows, header, law, results, event, region_keys, scales, diagnostic="NONE", seed="", precision=None):
    for functional, result in results.items():
        vectors = _score_vectors(result)
        for region, key in enumerate(region_keys):
            row = {**header, "law": law, "diagnostic": diagnostic, "permutation_seed": seed,
                   "functional": functional, "roi_x": int(key[0]), "roi_y": int(key[1]),
                   "source_scale": scales[functional], "scenario_count": result["scenario_count"],
                   "IID": "true" if result["IID"] else "false", "fair_rps": "", "scaled_fair_rps": ""}
            row.update({metric: float(values[region]) for metric, values in vectors.items()})
            if precision is not None:
                mcse = precision["shared_world_delete_group"]["functionals"][functional]["mcse_region_metrics"]
                row.update({"mcse_" + metric: float(values[region]) for metric, values in mcse.items()})
            rows.append(row)
    for region, key in enumerate(region_keys):
        row = {**header, "law": law, "diagnostic": diagnostic, "permutation_seed": seed,
               "functional": "ALL7_REGIONAL_TOTALS_POSITIVE_EVENT", "roi_x": int(key[0]), "roi_y": int(key[1]),
               "scenario_count": next(iter(results.values()))["scenario_count"], "IID": "true" if diagnostic == "NONE" else "false",
               "fair_rps": "", "scaled_fair_rps": "", **{metric: float(values[region]) for metric, values in event.items()}}
        if precision is not None:
            mcse = precision["shared_world_delete_group"]["event"]["mcse_region_metrics"]
            row.update({"mcse_" + metric: float(values[region]) for metric, values in mcse.items()})
        rows.append(row)


def _score(config, target, run_root, output, source_hash, config_hash, forecast_hash, truth_hash):
    forecast = _child_commit(config_hash, run_root, target["capture"], "forecast", source_hash)
    committed_truth = _child_commit(config_hash, run_root, target["capture"], "truth", source_hash)
    if committed_truth["global_forecast_sha256"] != forecast_hash:
        raise ValueError("truth was decoded under a different global forecast commitment")
    with np.load(committed_truth["artifacts"]["TRUTH.npz"]["path"], allow_pickle=False) as archive:
        truth, keys, truth_ids = archive["gene_region_truth"], archive["region_keys"], archive["canonical_ids"]
        if archive["member_ids"].astype(str).tolist() != GENES:
            raise ValueError("truth member ordering differs from the fixed seven roles")
    if truth.dtype.kind not in "iu" or truth.shape != (len(keys), 7) or np.any(truth < 0):
        raise ValueError("truth must contain exact nonnegative ROI integer counts")
    source = _read_json(run_root / "source" / "SOURCE_PARAMS.json")
    scales = source["source_scales"]
    if set(scales) != {"ALL7", "ACAN_COL2A1", "OTHER5"} or any(not np.isfinite(value) or value <= 0 for value in scales.values()):
        raise ValueError("three fixed positive source scales are required")
    mode = SYNTHETIC_MODE if config["mode"] in SYNTHETIC_CONFIG_MODES else REAL_MODE
    header = {"date_utc": datetime.now(timezone.utc).isoformat(), "mode": mode, "capture": target["capture"],
              "source_params_sha256": source_hash, "global_forecast_sha256": forecast_hash,
              "global_truth_sha256": truth_hash, "count_support_shift": SUPPORT_SHIFT}
    rows, summaries, precision, conditional = [], {}, {}, None
    for law in LAWS:
        with np.load(forecast["laws"][law]["path"], allow_pickle=False) as archive:
            values, forecast_keys, ids = archive["gene_region_totals"], archive["region_keys"], archive["canonical_ids"]
            if archive["member_ids"].astype(str).tolist() != GENES:
                raise ValueError("forecast member ordering differs from fixed roles")
        if (values.shape != (forecast["world_count"], len(keys), 7) or values.dtype.kind not in "iu" or np.any(values < 0)
                or not np.array_equal(forecast_keys, keys) or not np.array_equal(ids, truth_ids)):
            raise ValueError("forecast/truth complete support and ROI keys must match exactly")
        results, event, summaries[law] = _evaluate(values, truth, scales)
        precision[law] = _precision(values, truth, scales)
        _append_rows(rows, header, law, results, event, keys, scales, precision=precision[law])
        if law == "CONDITIONAL_SOURCE_CORR":
            conditional = values
    diagnostics = []
    for seed in range(2026100611, 2026100615):
        rng = np.random.default_rng(seed)
        values = np.empty_like(conditional)
        hashes = []
        for gene in range(7):
            permutation = rng.permutation(len(conditional))
            values[:, :, gene] = conditional[permutation, :, gene]
            hashes.append(hashlib.sha256(permutation.astype("<i8").tobytes()).hexdigest())
        results, event, summary = _evaluate(values, truth, scales, IID=False)
        diagnostic = "GLOBAL_GENE_WORLD_PERMUTATION"
        diagnostics.append({"seed": seed, "law": "CONDITIONAL_SOURCE_CORR", "diagnostic": diagnostic, "IID": False,
                            "world_count": len(values), "per_gene_world_permutation_sha256": hashes, **summary})
        _append_rows(rows, header, "CONDITIONAL_SOURCE_CORR", results, event, keys, scales, diagnostic=diagnostic, seed=seed)
    output.mkdir(parents=True, exist_ok=False)
    rows_path, scores_path = output / "ROWS.tsv", output / "SCORES.json"
    columns = list(dict.fromkeys(key for row in rows for key in row))
    with rows_path.open("x", encoding="utf8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    _write_json(scores_path, {"status": "TARGET_SCORES_COMPLETE", **header, "world_count": forecast["world_count"],
                "region_count": len(keys), "source_scales": scales, "generative_laws": summaries,
                "permutation_diagnostics": diagnostics, "mc_precision": precision, "row_count": len(rows),
                "primary_functional": "ALL7", "primary_score": "IID-fair RPS", "all_results_retained": True,
                "equal_roi_within_library": True, "equal_library_aggregation_is_parent_responsibility": True,
                "IID_fair_only_for_generative_laws": True, "extra_worlds": 0, "new_point_model_fits": 0})
    return {"artifacts": {"ROWS.tsv": _record(rows_path), "SCORES.json": _record(scores_path)},
            "global_forecast_sha256": forecast_hash, "global_truth_sha256": truth_hash,
            "score_rows": len(rows), "world_count": forecast["world_count"], "regions": len(keys),
            "permutation_repeats": 4, "mc_group_count": 16, "two_seed_blocks": 2}


def run_target_stage(stage, config_path, run_root, capture):
    """Execute one explicitly selected stage in a fresh CLI process."""
    config = json.loads(Path(config_path).read_text(encoding="utf8"))
    run_root = Path(run_root).resolve()
    if not (run_root / "source" / "SOURCE_COMMIT.json").is_file():
        raise ValueError("SOURCE_COMMIT is required before any target work")
    config_path = Path(config_path).resolve()
    source_commit_path = run_root / "source" / "SOURCE_COMMIT.json"
    source_params_path = run_root / "source" / "SOURCE_PARAMS.json"
    source_commit = _read_json(source_commit_path)
    config_hash = _sha(config_path)
    if (source_commit["status"] != "SOURCE_ONLY_PARAMETERS_COMMITTED"
            or source_commit["SOURCE_PARAMS_sha256"] != _sha(source_params_path)
            or source_commit["config_sha256"] != config_hash
            or source_commit["new_point_model_fits"] != 0 or source_commit["target_reads"] != 0):
        raise ValueError("SOURCE_COMMIT/config/source parameter integrity barrier failed")
    if config["mode"] not in SYNTHETIC_CONFIG_MODES + (REAL_CONFIG_MODE,):
        raise ValueError("invalid target stage mode")
    synthetic = config["mode"] in SYNTHETIC_CONFIG_MODES
    targets = config["targets"]
    if len({item["capture"] for item in targets}) != len(targets) or len(targets) < 2:
        raise ValueError("complete target list must have distinct captures")
    if synthetic and any(not item["capture"].startswith("SYN_") for item in targets):
        raise ValueError("synthetic target stages require SYN_ capture identifiers")
    if synthetic and any(not item["capture"].startswith("SYN_") for item in config["source_records"]):
        raise ValueError("synthetic target stages require SYN_ source identifiers")
    if not synthetic and (len(targets) != 3 or sum(item["observations"] for item in targets) != 3942):
        raise ValueError("real target stages require all three libraries and 3942 observations")
    if len(config["linkage"]["input_ids"]) != 126 or len(set(config["linkage"]["input_ids"])) != 126 or config["linkage"]["member_ids"] != GENES:
        raise ValueError("frozen 126 input/seven member linkage is invalid")
    if set(config["linkage"]["input_ids"]) & set(GENES):
        raise ValueError("input/member gene roles overlap")
    selected = [item for item in targets if item["capture"] == capture]
    if len(selected) != 1:
        raise ValueError("capture must identify exactly one configured complete library")
    target = selected[0]
    if stage == "truth" and not (run_root / "GLOBAL_FORECAST_COMMIT.json").is_file():
        raise ValueError("GLOBAL_FORECAST_COMMIT is required before any target response decoding")
    if stage == "score" and not (run_root / "GLOBAL_TRUTH_COMMIT.json").is_file():
        raise ValueError("GLOBAL_TRUTH_COMMIT is required before any target scoring")
    if Path(target["matrix_name"]).name != target["matrix_name"]:
        raise ValueError("cached matrix name must be a filename, not an alternate path")
    output = run_root / "targets" / capture / stage
    if output.exists():
        raise ValueError("target stage output must be fresh")
    records = list(config["code_binding"]) + [config["spec_binding"], config["authorization_binding"]]
    for source in config["source_records"]:
        records.extend([source["head_params"], source["total_params"]])
    records += [{"path": str(source_params_path), "sha256": source_commit["SOURCE_PARAMS_sha256"]}, _record(source_commit_path)]
    allowed = [config_path] + [item["path"] for item in records]
    if stage in ("prepare", "truth"):
        metadata = [config["target_coordinates"]]
        for item in targets:
            metadata.extend([item["features"], item["barcodes"]])
        records += metadata
        allowed += [item["path"] for item in metadata] + [run_root / "acquired" / target["matrix_name"]]
    if stage in ("forecast", "truth"):
        prepare_path = run_root / "targets" / capture / "prepare" / "PREPARE_COMMIT.json"
        input_path = prepare_path.with_name("INPUTS.npz")
        records += [_record(prepare_path)]
        allowed += [prepare_path, input_path]
    if stage in ("truth", "score"):
        allowed += [run_root / "GLOBAL_FORECAST_COMMIT.json"]
        for item in targets:
            prior = run_root / "targets" / item["capture"] / "forecast"
            allowed += [prior / "FORECAST_COMMIT.json"] + [prior / (law + suffix) for law in LAWS for suffix in (".npz", "_RECEIPT.json")]
    if stage == "score":
        allowed += [run_root / "GLOBAL_TRUTH_COMMIT.json"]
        for item in targets:
            prior = run_root / "targets" / item["capture"] / "truth"
            allowed += [prior / "TRUTH_COMMIT.json", prior / "TRUTH.npz"]
    reads, writes, denied = _install_guard(allowed, output, config["code_binding"])
    global_hash = None
    if stage in ("truth", "score"):
        global_records, global_hash = _global_barrier(config, run_root, "forecast", source_commit["SOURCE_PARAMS_sha256"], config_hash)
        records += global_records
    truth_hash = None
    if stage == "score":
        truth_records, truth_hash = _global_barrier(config, run_root, "truth", source_commit["SOURCE_PARAMS_sha256"], config_hash)
        records += truth_records
    before = _verified(records)
    probes = [run_root / "SEALED_B_335_READ_GUARD_PROBE_DO_NOT_CREATE.npz", run_root / "UNLISTED_READ_GUARD_PROBE_DO_NOT_CREATE.bin"]
    if stage in ("forecast", "score"):
        probes.append(run_root / "acquired" / target["matrix_name"])
    for probe in probes:
        try:
            with probe.open("rb"):
                pass
        except PermissionError:
            pass
        else:
            raise ValueError("target stage read-guard probe was not denied")
    if stage == "prepare":
        details = _prepare(config, target, run_root, output)
    elif stage == "forecast":
        details = _forecast(config, target, run_root, output, source_commit["SOURCE_PARAMS_sha256"], config_hash)
    elif stage == "truth":
        details = _truth(config, target, run_root, output, source_commit["SOURCE_PARAMS_sha256"], config_hash, global_hash)
    elif stage == "score":
        details = _score(config, target, run_root, output, source_commit["SOURCE_PARAMS_sha256"], config_hash, global_hash, truth_hash)
    else:
        raise ValueError("target stage has not been implemented")
    after = _verified(records)
    if before != after or _sha(config_path) != config_hash:
        raise ValueError("frozen code/source/config/metadata changed during target stage")
    commit = {"status": "TARGET_" + stage.upper() + "_COMMITTED", "stage": stage, "capture": capture,
              "mode": SYNTHETIC_MODE if synthetic else REAL_MODE, "date_utc": datetime.now(timezone.utc).isoformat(),
              "global_barrier": "ALL_TARGET_TRUTHS_AND_FORECASTS_DEEP_VERIFIED" if stage == "score" else
                                ("ALL_TARGET_FORECASTS_DEEP_VERIFIED" if stage == "truth" else "SOURCE_COMMIT_VERIFIED"),
              "source_params_sha256": source_commit["SOURCE_PARAMS_sha256"],
              "source_commit_sha256": _sha(source_commit_path), "config_sha256": config_hash,
              "bindings_before": before, "bindings_after": after, "count_support_shift": SUPPORT_SHIFT,
              "new_point_model_fits": 0, **details,
              "read_audit": {"scope": "fresh-process Python open audit; not an OS sandbox",
                             "read_paths": sorted(set(reads)), "write_paths": sorted(set(writes)), "denied_paths": denied}}
    _write_json(output / (stage.upper() + "_COMMIT.json"), commit)
    return commit


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("prepare", "forecast", "truth", "score"))
    parser.add_argument("--config", required=True)
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--capture", required=True)
    args = parser.parse_args()
    try:
        receipt = run_target_stage(args.stage, args.config, args.run_root, args.capture)
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({"status": "TARGET_STAGE_BLOCKED", "stage": args.stage, "reason": str(error)}), flush=True)
        return 2
    print(json.dumps(receipt, ensure_ascii=False, allow_nan=False), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
