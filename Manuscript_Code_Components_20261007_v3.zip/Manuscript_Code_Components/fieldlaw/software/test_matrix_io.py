"""Synthetic-file tests through the agreed input-only reader seam."""
import gzip
import tempfile
import unittest
from pathlib import Path

import numpy as np

from matrix_io import extract_allowed_counts


class MatrixReaderTests(unittest.TestCase):
    def test_extracts_requested_rows_in_declared_order(self):
        text = """%%MatrixMarket matrix coordinate integer general
% Synthetic records only.
3 2 4
1 1 2
2 1 99
3 2 4
1 2 1
"""
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic.mtx"
            path.write_text(text, encoding="utf8")
            counts, receipt = extract_allowed_counts(path, [3, 1], 3, 2)
        np.testing.assert_array_equal(counts, [[0, 2], [4, 1]])
        self.assertEqual(counts.dtype, np.dtype("int64"))
        self.assertEqual(receipt["records_checked"], 4)
        self.assertTrue(receipt["numeric_values_parsed_only_for_allowed_rows"])

    def test_gzip_mask_keeps_unsupported_values_opaque_until_truth_selection(self):
        template = """%%MatrixMarket matrix coordinate real general
3 2 3
1 1 2e0
2 1 {unsupported}
3 2 4.000
"""
        with tempfile.TemporaryDirectory() as folder:
            observed = []
            for index, unsupported in enumerate(("garbage", "0.375")):
                path = Path(folder) / (str(index) + ".mtx.gz")
                with gzip.open(path, "wt", encoding="utf8") as stream:
                    stream.write(template.format(unsupported=unsupported))
                counts, receipt = extract_allowed_counts(path, [1, 3], 3, 2)
                observed.append(counts)
                self.assertNotIn(unsupported, repr(receipt))
                with self.assertRaises(ValueError) as caught:
                    extract_allowed_counts(path, [2], 3, 2)
                self.assertNotIn(unsupported, str(caught.exception))
        np.testing.assert_array_equal(observed[0], [[2, 0], [0, 4]])
        np.testing.assert_array_equal(observed[0], observed[1])

    def test_rejects_ambiguous_or_out_of_range_allowed_row_contract(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic.mtx"
            path.write_text("%%MatrixMarket matrix coordinate integer general\n3 2 0\n", encoding="utf8")
            for rows in ([1, 1], [0], [4], [1.0], [True], [[1]], []):
                with self.subTest(rows=rows), self.assertRaises(ValueError):
                    extract_allowed_counts(path, rows, 3, 2)
            for genes, spots in ((3.0, 2), (3, 0), (0, 2), (True, 2)):
                with self.subTest(shape=(genes, spots)), self.assertRaises(ValueError):
                    extract_allowed_counts(path, [1], genes, spots)

    def test_checks_all_record_coordinates_dimensions_and_nnz(self):
        header = "%%MatrixMarket matrix coordinate integer general\n"
        invalid = (
            "3 2 1\n1 0 2\n", "3 2 1\n0 1 garbage\n",
            "3 2 1\n4 1 garbage\n", "3 2 1\n2 3 garbage\n",
            "3 2 2\n1 1 2\n", "3 2 0\n2 1 garbage\n",
            "4 2 0\n", "3 2 -1\n", "3 2 1\n1 1\n",
            "0_3 2 0\n", "3 2 1\n0_1 1 2\n",
        )
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic.mtx"
            for index, body in enumerate(invalid):
                path.write_text(header + body, encoding="utf8")
                with self.subTest(case=index), self.assertRaises(ValueError):
                    extract_allowed_counts(path, [1], 3, 2)

    def test_accumulates_duplicate_coordinates_exactly_and_rejects_overflow(self):
        header = "%%MatrixMarket matrix coordinate real general\n"
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic.mtx"
            path.write_text(header + "1 2 3\n1 1 2.000\n1 1 3e0\n1 2 9223372036854775807\n", encoding="utf8")
            counts, receipt = extract_allowed_counts(path, [1], 1, 2)
            np.testing.assert_array_equal(counts, [[5], [9223372036854775807]])
            self.assertEqual(receipt["duplicate_coordinate_policy"], "accumulate_exact_int64_or_reject_overflow")
            path.write_text(header + "1 1 2\n1 1 9223372036854775807\n1 1 1\n", encoding="utf8")
            with self.assertRaises(ValueError):
                extract_allowed_counts(path, [1], 1, 1)

    def test_allowed_counts_are_exact_finite_nonnegative_int64_without_repair(self):
        header = "%%MatrixMarket matrix coordinate real general\n1 1 1\n1 1 "
        invalid = ("0.1", "-1", "NaN", "Inf", "1_0", "9223372036854775808", "1e999999",
                   "2.000000000000000000000000001")
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic.mtx"
            for index, value in enumerate(invalid):
                path.write_text(header + value + "\n", encoding="utf8")
                with self.subTest(case=index), self.assertRaises(ValueError):
                    extract_allowed_counts(path, [1], 1, 1)


if __name__ == "__main__":
    unittest.main()
