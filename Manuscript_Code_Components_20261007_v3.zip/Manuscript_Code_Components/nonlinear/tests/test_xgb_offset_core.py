"""Synthetic-only offset, storage, identity, scale, and guard tests."""
import copy
import inspect
import json
from pathlib import Path
import sys
import unittest
from unittest import mock
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src import xgb_offset_core as core
from examples.synthetic_offset_fixture import fixture, EXPECTED_PRIORS, EXPECTED_DIRECT_ZERO_TREE, MEMBER_SCALES


class OffsetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = fixture()
        cls.zero = core.synthetic_zero_tree_probe(**cls.data, mode="synthetic")
        cls.fitted = core.fit_predict(**cls.data)

    def test_zero_tree_count_means_independent_literal(self):
        np.testing.assert_allclose(self.zero["predictions"]["XGBDirect"], EXPECTED_DIRECT_ZERO_TREE, rtol=3e-6, atol=1e-6)

    def test_training_only_initialization_prior_literal(self):
        np.testing.assert_allclose(self.zero["models"]["rate_init_b"], EXPECTED_PRIORS, rtol=1e-14, atol=0)

    def test_counts_are_not_multiplied_by_exposure_again(self):
        self.assertLess(float(self.zero["predictions"]["XGBDirect"].max()), 43.)

    def test_same_total_conserved(self):
        for answer in [self.zero,self.fitted]:
            np.testing.assert_allclose(answer["predictions"]["TotalXGB"].sum(axis=1),self.data["frozen_total"],rtol=1e-12,atol=0)

    def test_member_proportions_preserved(self):
        for answer in [self.zero,self.fitted]:
            d=answer["predictions"]["XGBDirect"]
            r=answer["predictions"]["TotalXGB"]
            np.testing.assert_allclose(d/d.sum(axis=1,keepdims=True),r/r.sum(axis=1,keepdims=True),rtol=1e-12,atol=0)

    def test_changed_frozen_total_does_not_change_direct_head(self):
        new=core.predict_from_fitted(self.fitted["models"],self.data["eval_x126"],
                                    self.data["frozen_total"]*2,eval_ids=self.data["eval_ids"])
        np.testing.assert_array_equal(new["XGBDirect"],self.fitted["predictions"]["XGBDirect"])
        np.testing.assert_array_equal(new["TotalXGB"],self.fitted["predictions"]["TotalXGB"]*2)

    def test_public_offset_ratio_with_identical_features(self):
        # Identical feature matrix, same stored model; only exposure changes.
        x=np.ones((2,129)); e=np.array([100000.,300000.]);t=np.array([25.,25.])
        ans=core.predict_standardized(self.zero["models"],x,e,t)
        np.testing.assert_allclose(ans["XGBDirect"][1]/ans["XGBDirect"][0],3.,rtol=3e-6,atol=0)

    def test_serialized_model_replay(self):
        capsule=json.loads(json.dumps(core.serialize_model(self.fitted["models"]),allow_nan=False))
        model=core.deserialize_model(capsule)
        new=core.predict_from_fitted(model,self.data["eval_x126"],self.data["frozen_total"],eval_ids=self.data["eval_ids"])
        for method in core.METHODS:
            np.testing.assert_array_equal(new[method],self.fitted["predictions"][method])

    def test_serialized_zero_tree_replay(self):
        model=core.deserialize_model(core.serialize_model(self.zero["models"]))
        ans=core.predict_from_fitted(model,self.data["eval_x126"],self.data["frozen_total"],eval_ids=self.data["eval_ids"])
        np.testing.assert_array_equal(ans["XGBDirect"],self.zero["predictions"]["XGBDirect"])

    def test_production_rounds_and_no_extra_total_fit(self):
        self.assertEqual([b.num_boosted_rounds() for b in self.fitted["models"]["boosters"]],[200]*7)
        self.assertEqual(len(self.fitted["fit_ledger"]),7)
        self.assertEqual(self.fitted["diagnostics"]["new_total_fits"],0)
        self.assertTrue(all(v["watchlist_rows"]==0 and not v["early_stopping"] for v in self.fitted["fit_ledger"]))

    def test_no_evaluation_target_or_round_parameter(self):
        names=set(inspect.signature(core.fit_predict).parameters)
        self.assertNotIn("eval_y7",names)
        self.assertNotIn("rounds",names)
        self.assertNotIn("num_boost_round",names)

    def test_original_training_scales(self):
        np.testing.assert_allclose(self.fitted["member_scales"],MEMBER_SCALES,rtol=1e-14,atol=0)
        self.assertAlmostEqual(self.fitted["total_scale"],350.,places=12)
        np.testing.assert_array_equal(self.fitted["models"]["standardizer"]["sd"][1:126],np.full(125,.1))

    def test_eval_inputs_do_not_change_train_only_statistics(self):
        model=self.fitted["models"]
        before=core.serialize_model(model)
        core.predict_from_fitted(model,self.data["eval_x126"]*3,self.data["frozen_total"],eval_ids=self.data["eval_ids"])
        self.assertEqual(before,core.serialize_model(model))

    def test_reordered_eval_rows_reorder_predictions(self):
        order=np.array([5,1,3,0,4,2])
        new=core.predict_from_fitted(self.fitted["models"],self.data["eval_x126"][order],self.data["frozen_total"][order],eval_ids=self.data["eval_ids"][order])
        for method in core.METHODS:
            np.testing.assert_array_equal(new[method],self.fitted["predictions"][method][order])

    def test_zero_training_member_stops(self):
        data=copy.deepcopy(self.data);data["train_y7"][:,3]=0
        with self.assertRaises(core.ContractError):core.fit_predict(**data)

    def test_noninteger_counts_stop(self):
        data=copy.deepcopy(self.data);data["eval_x126"]=data["eval_x126"].astype(float);data["eval_x126"][0,0]=.5
        with self.assertRaises(core.ContractError):core.fit_predict(**data)

    def test_nonfinite_input_stops(self):
        data=copy.deepcopy(self.data);data["train_x126"]=data["train_x126"].astype(float);data["train_x126"][0,0]=np.inf
        with self.assertRaises(core.ContractError):core.fit_predict(**data)

    def test_invalid_frozen_total_stops(self):
        for bad in [0.,np.nan,np.inf,-1.]:
            data=copy.deepcopy(self.data);data["frozen_total"][0]=bad
            with self.assertRaises(core.ContractError):core.fit_predict(**data)

    def test_overlapping_training_eval_ids_stop(self):
        data=copy.deepcopy(self.data);data["eval_ids"]=data["eval_ids"].astype("U40");data["eval_ids"][0]=data["train_ids"][0]
        with self.assertRaises(core.ContractError):core.fit_predict(**data)

    def test_target_identity_as_input_stops(self):
        data=copy.deepcopy(self.data);data["input_ids"]=data["input_ids"].astype("U40");data["input_ids"][0]=data["member_ids"][0]
        with self.assertRaises(core.ContractError):core.fit_predict(**data)

    def test_duplicate_eval_id_stops(self):
        data=copy.deepcopy(self.data);data["eval_ids"][0]=data["eval_ids"][1]
        with self.assertRaises(core.ContractError):core.fit_predict(**data)

    def test_zero_tree_not_available_under_real_mode(self):
        with self.assertRaises(core.ContractError):core.synthetic_zero_tree_probe(**self.data,mode="real")

    def test_tampered_model_bytes_stop(self):
        capsule=core.serialize_model(self.zero["models"])
        capsule["booster_ubj"][0]["sha256"]="0"*64
        with self.assertRaises(core.ContractError):core.deserialize_model(capsule)

    def test_changed_rate_prior_zero_stops(self):
        model=dict(self.zero["models"]);model["rate_init_b"]=np.zeros(7)
        with self.assertRaises(core.ContractError):core.predict_from_fitted(model,self.data["eval_x126"],self.data["frozen_total"],eval_ids=self.data["eval_ids"])

    def test_changed_positive_rate_prior_stops(self):
        model=dict(self.zero["models"]);model["rate_init_b"]=np.array(EXPECTED_PRIORS)*2
        with self.assertRaises(core.ContractError):core.predict_from_fitted(model,self.data["eval_x126"],self.data["frozen_total"],eval_ids=self.data["eval_ids"])

    def test_nonpositive_returned_mean_stops_without_repair(self):
        with mock.patch.object(self.zero["models"]["boosters"][0],"predict",return_value=np.zeros(6)):
            with self.assertRaises(core.ContractError):
                core.predict_from_fitted(self.zero["models"],self.data["eval_x126"],
                                         self.data["frozen_total"],eval_ids=self.data["eval_ids"])

    def test_nonfinite_returned_mean_stops_without_repair(self):
        with mock.patch.object(self.zero["models"]["boosters"][0],"predict",return_value=np.full(6,np.nan)):
            with self.assertRaises(core.ContractError):
                core.predict_from_fitted(self.zero["models"],self.data["eval_x126"],
                                         self.data["frozen_total"],eval_ids=self.data["eval_ids"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

