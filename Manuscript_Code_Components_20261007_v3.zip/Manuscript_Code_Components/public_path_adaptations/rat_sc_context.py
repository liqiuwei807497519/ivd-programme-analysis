# Public path adaptation: help/description precedes all original scientific imports.
import argparse as _public_argparse
import json as _public_json
from pathlib import Path as _PublicPath
import sys as _public_sys
_public_description = {'purpose': 'path-interface description; no scientific execution', 'required_bindings': ['programme_file', 'project_root', 'source_root'], 'expected_layout': 'source-root: 16 official GSE211407 processed *.txt.gz; project-root/PLAN.md. Original sc_results/progress/report outputs remain under project-root.', 'data_reads': 0, 'heavy_imports': 0, 'original_scientific_body_preserved_except_declared_path_assignment_values': True}
_public_parser = _public_argparse.ArgumentParser(description="Original analysis with explicit caller-owned paths; no data are bundled.")
_public_parser.add_argument('--describe-inputs', action='store_true', help='Print input layout and exit before imports/data access')
for _public_key in _public_description['required_bindings']:
    _public_parser.add_argument('--'+_public_key.replace('_','-'))
_public_args = _public_parser.parse_args()
if _public_args.describe_inputs:
    print(_public_json.dumps(_public_description))
    raise SystemExit(0)
for _public_key in _public_description['required_bindings']:
    if getattr(_public_args,_public_key) is None:
        _public_parser.error('Required binding: --'+_public_key.replace('_','-'))
def _public_binding(_public_key):
    return _PublicPath(getattr(_public_args,_public_key)).expanduser().resolve()
# Begin the preserved original body. Only declared path-assignment values differ.
"""Read published processed tables without inventing UMI or expression units."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import csv,gzip,json,hashlib,re,time,collections
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import rankdata
R=_public_binding('project_root');SRC=_public_binding('source_root')
SIG=_public_binding('programme_file')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def main():
 started=time.monotonic();files=sorted(SRC.glob('*.txt.gz'));assert len(files)==16
 pg=pd.read_csv(SIG,sep='\t');programmes=dict(zip(pg.programme,pg.genes.str.split(';')));targets=sorted(set().union(*map(set,programmes.values())))
 resident=programmes['Resident_identity'];matrix=['ACAN','COL2A1'];other=[g for g in resident if g not in matrix]
 source_manifest=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files+[SIG,R/'PLAN.md',Path(__file__)]]
 (R/'INPUT_LOCK_SC.json').write_text(json.dumps(source_manifest,indent=2,ensure_ascii=False),encoding='utf8')
 out=R/'sc_results';out.mkdir(exist_ok=True);filesummary=[];diagnostics=[];gsummary=[];ssummary=[]
 known={'Chondrocyte','Chondrocyte cell','Endothelial','Immune','Immune cells','Macrophage','N/A','NA',''}
 column_map=[]
 columns=['GSM','sample','condition','cell','author_celltype','broad_category','reported_total_count','expressed_genes','mitochondrial_pct']+targets
 with gzip.open(out/'selected_cells.csv.gz','wt',encoding='utf8',newline='') as of:
  writer=csv.writer(of);writer.writerow(columns)
  for path in files:
   gsm,sample=re.match(r'(GSM\d+)_([CS]\d+)\.txt\.gz',path.name).groups();condition='Control' if sample[0]=='C' else 'Stab'
   with gzip.open(path,'rt',encoding='utf-8-sig',newline='') as f:
    reader=csv.reader(f,delimiter='\t');header=next(reader);start=header.index('Total count')+1
    first=[]
    for _ in range(50):
     try:first.append(next(reader))
     except StopIteration:break
    candidates=[]
    for j in range(start):
     values={row[j] for row in first};hits=values & (known-{'N/A','NA',''})
     if hits:candidates.append(j)
    assert len(candidates)==1,(sample,candidates,header[:start]);ctindex=candidates[0]
    genehead=[h.upper() for h in header[start:]]
    if len(set(genehead))!=len(genehead):raise ValueError('nonunique uppercase feature names')
    idx={g:start+genehead.index(g) for g in targets if g in genehead}
    for g in targets:column_map.append({'sample':sample,'GSM':gsm,'requested_symbol':g,'native_feature':header[idx[g]] if g in idx else '', 'present':g in idx,'column_index':idx.get(g,-1)})
    buckets=collections.defaultdict(list);seen=set();row_count=0;integer=nonzero=0;author_types=collections.Counter()
    import itertools
    for row in itertools.chain(first,reader):
     assert len(row)==len(header),(sample,row_count,len(row),len(header))
     cid=row[header.index('Cell name')];assert cid not in seen;seen.add(cid)
     assert row[header.index('Sample name')]==sample
     ct=row[ctindex];assert ct in known,(sample,ct)
     broad='Chondrocyte' if ct=='Chondrocyte cell' else ct
     vals=np.array([float(row[idx[g]]) if g in idx else np.nan for g in targets])
     assert np.isfinite(vals[[g in idx for g in targets]]).all()
     if row_count<3:
      full=np.array(row[start:],dtype=float);positive=full[full>0]
      diagnostics.append({'sample':sample,'row_number_1based':row_count+1,'gene_columns':len(full),'supplied_sum':float(full.sum()),'supplied_min':float(full.min()),'supplied_max':float(full.max()),'positive_values':len(positive),'noninteger_positive_values':int(np.count_nonzero(np.abs(positive-np.rint(positive))>1e-8)),
       'candidate_sum_2pow_value_minus1':float(np.expm1(full*np.log(2)).sum()) if full.max()<100 else None,
       'reported_Total_count':float(row[header.index('Total count')]),'candidate_transform_is_not_certified':True})
     nz=vals[np.isfinite(vals)&(vals!=0)];integer+=int(np.count_nonzero(np.abs(nz-np.rint(nz))<1e-8));nonzero+=len(nz)
     writer.writerow([gsm,sample,condition,cid,ct,broad,row[header.index('Total count')],row[header.index('Expressed genes')],row[header.index('Mitochondrial reads percent')]]+vals.tolist())
     buckets[broad].append(vals);author_types[ct]+=1;row_count+=1
   # Reaching gzip EOF verifies decompression/trailer CRC; all original rows preserved.
   for ct,values in buckets.items():
    v=np.array(values);n=len(v);eligible=n>=30
    for gi,g in enumerate(targets):
     good=np.isfinite(v[:,gi]);assert good.all() or (~good).all()
     gsummary.append({'GSM':gsm,'sample':sample,'condition':condition,'category':ct,'gene':g,'cells':n,'eligible_n30':eligible,'feature_present':g in idx,
       'mean_supplied_value':float(np.mean(v[:,gi])) if good.all() else np.nan,'median_supplied_value':float(np.median(v[:,gi])) if good.all() else np.nan,'positive_supplied_fraction':float(np.mean(v[:,gi]>0)) if good.all() else np.nan})
    summary={'GSM':gsm,'sample':sample,'condition':condition,'category':ct,'cells':n,'eligible_n30':eligible,'complete_Resident7':all(g in idx for g in resident)}
    for name,genes in list(programmes.items())+[('Matrix2',matrix),('Other5',other)]:
     summary[name+'_mean_supplied']=float(v[:,[targets.index(g) for g in genes]].mean()) if all(g in idx for g in genes) else np.nan
    if summary['complete_Resident7']:
     rv=v[:,[targets.index(g) for g in resident]];ranks=rankdata(rv,axis=1,method='average');aidx=[resident.index(g) for g in matrix];bidx=[resident.index(g) for g in other]
     summary['matrix2_minus_other5_mean_supplied']=summary['Matrix2_mean_supplied']-summary['Other5_mean_supplied']
     summary['matrix2_minus_other5_within7_rank']=float((ranks[:,aidx].mean(axis=1)-ranks[:,bidx].mean(axis=1)).mean())
     summary['all7_positive_fraction']=float(np.all(rv>0,axis=1).mean())
    else:
     for k in ['matrix2_minus_other5_mean_supplied','matrix2_minus_other5_within7_rank','all7_positive_fraction']:summary[k]=np.nan
    ssummary.append(summary)
   filesummary.append({'GSM':gsm,'sample':sample,'condition':condition,'cells':row_count,'gene_columns':len(genehead),'author_type_column':header[ctindex],'author_types':dict(author_types),'matched_requested_genes':len(idx),'missing_requested_genes':sorted(set(targets)-set(idx)),'integer_fraction_of_nonzero_selected_values':integer/nonzero if nonzero else None,'gzip_eof_crc_passed':True})
   print(json.dumps({'sample':sample,'cells':row_count,'types':dict(author_types),'matched':len(idx),'elapsed_seconds':time.monotonic()-started}),flush=True)
   (R/'SC_PROGRESS.json').write_text(json.dumps({'completed_files':len(filesummary),'expected_files':16,'cells':sum(x['cells'] for x in filesummary)}),encoding='utf8')
 pd.DataFrame(gsummary).to_csv(out/'gene_by_sample_category.tsv',sep='\t',index=False)
 pd.DataFrame(ssummary).to_csv(out/'scores_by_sample_category.tsv',sep='\t',index=False)
 pd.DataFrame(column_map).to_csv(out/'feature_reconciliation.tsv',sep='\t',index=False)
 pd.DataFrame(diagnostics).to_csv(out/'scale_diagnostics_first3_per_file.tsv',sep='\t',index=False)
 gdf=pd.DataFrame(gsummary);contrasts=[]
 for (ct,g),rows in gdf.groupby(['category','gene']):
  keep=rows[rows.eligible_n30 & rows.feature_present];cc=keep[keep.condition=='Control'].mean_supplied_value;ss=keep[keep.condition=='Stab'].mean_supplied_value
  contrasts.append({'category':ct,'gene':g,'Control_libraries':len(cc),'Stab_libraries':len(ss),'Control_equal_library_mean':cc.mean(),'Stab_equal_library_mean':ss.mean(),'Stab_minus_Control':ss.mean()-cc.mean(),'not_paired_inference':True})
 pd.DataFrame(contrasts).to_csv(out/'unpaired_descriptive_member_directions.tsv',sep='\t',index=False)
 report={'status':'ALL16_PROCESSED_TABLES_COMPLETE_PENDING_INDEPENDENT_RECHECK','libraries':16,'cells':sum(x['cells'] for x in filesummary),'published_animals':8,'exact_C_S_pair_crosswalk_verified':False,'supplied_value_unit':'AUTHOR_PROCESSED_SCALE_NOT_RAW_UMI_OR_CERTIFIED_CPM','file_summaries':filesummary,'new_normalization':False,'p_values':False,'pseudo_count_rounding':False,'deconvolution':False,'author_labels_independent_of_target_genes':False,'sealed_inputs_opened':False,'wall_seconds':time.monotonic()-started,'input_hashes_unchanged':all(sha(Path(x['path']))==x['sha256'] for x in source_manifest)}
 assert report['input_hashes_unchanged'];(R/'SC_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in report.items() if k!='file_summaries'}),flush=True)
if __name__=='__main__':main()
