# Quantitative S1 plotting source

The preserved build script produced the current nine-panel Supplementary Figure1 from already committed, authorized local RNA source outputs. It uses the original source completion/configuration bindings and the locally installed `advanced-multiomics-analysis` style helper. The script is supplied as exact author-owned provenance, not a portable standalone replay.

`../../Source_Data/S1_Quantitative/` supplies all64 section detection-distribution rows and56 section-member summaries. The native observation-by-gene count CSV, committed source inputs and histology are not redistributed. The spatial panels therefore require separately authorized source exports plus the declared style-helper dependency. Do not interpret the supplied aggregates as enough to reconstruct every native spatial value, or substitute fabricated counts.

There are11893 native observations in eight nested sections/four parent identifiers;1072 have zero counts for allseven members. Detection is strictly observed count>0, not cell identity or biological activation. Geometry is nominal source array geometry, without cross-platform registration. Author-owned code uses the project MIT licence; original data access conditions apply.
