"""Fixed V2 seven-head Poisson booster; numerical inputs only, no data-file I/O.

The baseline input transform and train-only scaler are reused byte-for-byte
from the vendored capture core. Both train and prediction margins are
log(exposure)+log(training-only member rate). XGBoost's inverse-link output is
already a count mean. It is never multiplied by exposure a second time.
"""
from __future__ import annotations

import base64
import hashlib
from types import MappingProxyType
import numpy as np

from vendor.baseline_core import (
    ContractError, input_features, _counts, _finite_positive, _standardize,
)

XGB_VERSION = "3.4.1"
NUM_BOOST_ROUND = 200
MODEL_KIND = "XGB_POISSON_TRAIN_RATE_OFFSET_V2"
METHODS = ("XGBDirect", "TotalXGB")
FIXED_PARAMS = MappingProxyType({
    "objective": "count:poisson", "booster": "gbtree", "tree_method": "hist",
    "device": "cpu", "nthread": 2, "max_depth": 3, "eta": .05,
    "max_bin": 255, "min_child_weight": 1, "reg_lambda": 1,
    "reg_alpha": 0, "max_delta_step": .7, "subsample": 1,
    "colsample_bytree": 1, "colsample_bylevel": 1, "colsample_bynode": 1,
    "sampling_method": "uniform", "seed": 2026100201,
    "base_score": 1., "boost_from_average": 0, "disable_default_eval_metric": True,
    "validate_parameters": True, "verbosity": 0,
})


def _fail(message, stage, **details):
    raise ContractError(message, {"stage": stage, **details})


def _xgb():
    import xgboost as xgb
    if xgb.__version__ != XGB_VERSION:
        _fail("Pinned XGBoost version differs", "runtime",
              expected=XGB_VERSION, actual=xgb.__version__)
    return xgb


def _ids(value, rows, label):
    raw = np.asarray(value)
    if raw.ndim != 1 or len(raw) != rows or raw.dtype.kind not in "US":
        _fail("IDs must be an aligned one-dimensional string array", "identity", field=label)
    result = raw.astype(str)
    if len(set(result.tolist())) != rows or any(not s for s in result):
        _fail("Duplicate or empty IDs", "identity", field=label)
    return result.tolist()


def _validate_roles(input_ids, member_ids):
    inputs = _ids(input_ids, 126, "input_ids")
    members = _ids(member_ids, 7, "member_ids")
    overlap = sorted(set(inputs) & set(members))
    if overlap:
        _fail("Targets entered the permitted input feature universe", "identity", overlap=overlap)
    return inputs, members


def _total(value, rows):
    total = np.asarray(value, dtype=float)
    if total.shape != (rows,):
        _fail("Frozen total must contain exactly one value per evaluation ID", "frozen_total")
    _finite_positive(total, "frozen_total")
    return total


def _model_arrays(model):
    if model.get("kind") != MODEL_KIND or model.get("xgboost_version") != XGB_VERSION:
        _fail("Unrecognized stored model contract", "stored_model")
    if model.get("params") != dict(FIXED_PARAMS):
        _fail("Stored fixed parameters differ", "stored_model")
    if model.get("num_boost_round") not in (0, NUM_BOOST_ROUND):
        _fail("Stored rounds differ", "stored_model")
    if model["num_boost_round"] == 0 and model.get("mode") != "synthetic_zero_tree_probe":
        _fail("Zero trees are reserved for synthetic initialization probes", "stored_model")
    b = np.asarray(model["rate_init_b"], dtype=float)
    mean = np.asarray(model["standardizer"]["mean"], dtype=float)
    sd = np.asarray(model["standardizer"]["sd"], dtype=float)
    scales = np.asarray(model["member_scales"], dtype=float)
    if (b.shape != (7,) or mean.shape != (128,) or sd.shape != (128,)
            or scales.shape != (7,) or not np.isfinite(mean).all()
            or not np.isfinite(sd).all() or np.any(sd < .1)
            or not np.isfinite(scales).all() or np.any(scales < 1)):
        _fail("Invalid stored scaler or member denominators", "stored_model")
    _finite_positive(b, "stored_rate_prior")
    _validate_roles(model["input_ids"], model["member_ids"])
    expected_order = ["intercept"] + ["logcp1000:" + g for g in model["input_ids"]] + ["log_exposure", "log_region_bins"]
    if model.get("feature_order") != expected_order:
        _fail("Stored feature order changed", "stored_model")
    if model.get("booster_feature_names") != [f"f{i:03d}" for i in range(129)]:
        _fail("Stored booster feature names changed", "stored_model")
    if len(model["boosters"]) != 7:
        _fail("Seven stored member heads required", "stored_model")
    for j, booster in enumerate(model["boosters"]):
        if (booster.num_boosted_rounds() != model["num_boost_round"]
                or booster.attr("member_id") != model["member_ids"][j]
                or booster.attr("member_index") != str(j)
                or float(booster.attr("rate_init_b")) != b[j]
                or booster.attr("offset_contract") != "log_e_plus_log_training_rate_V2"):
            _fail("Stored head identity or offset differs", "stored_model", member_index=j)
    return b, mean, sd


def predict_standardized(model, standardized_x, exposure, frozen_total):
    """Replay stored heads on explicitly fixed features and legal exposure.

    This low-level numerical replay also makes it possible to test an offset
    ratio while holding features fixed. It accepts no outcome labels or fitting
    options. The regular predictor derives these features from X126 itself.
    """
    xgb = _xgb()
    b, _, _ = _model_arrays(model)
    x = np.asarray(standardized_x, dtype=float)
    e = np.asarray(exposure, dtype=float)
    if (x.ndim != 2 or x.shape[1] != 129 or len(x) < 1
            or not np.isfinite(x).all() or e.shape != (len(x),)):
        _fail("Invalid frozen feature replay inputs", "prediction_features")
    _finite_positive(e, "prediction_exposure")
    total = _total(frozen_total, len(x))
    direct = np.empty((len(x), 7), dtype=float)
    for j, booster in enumerate(model["boosters"]):
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            margin = np.log(e) + np.log(b[j])
        if not np.isfinite(margin).all():
            _fail("Nonfinite prediction base margin", "prediction_offset", member_index=j)
        data = xgb.DMatrix(x, base_margin=margin, nthread=2,
                           feature_names=model["booster_feature_names"])
        # count:poisson predict(output_margin=False) already returns counts.
        direct[:, j] = booster.predict(data, output_margin=False, validate_features=True)
    _finite_positive(direct, "XGBDirect_prediction")
    relative = direct / direct.max(axis=1, keepdims=True)
    proportions = relative / relative.sum(axis=1, keepdims=True)
    reconciled = total[:, None] * proportions
    _finite_positive(reconciled, "TotalXGB_prediction")
    if not np.allclose(reconciled.sum(axis=1), total, rtol=1e-12, atol=0):
        _fail("Same-total conservation failed", "prediction_invariant")
    if not np.allclose(reconciled / reconciled.sum(axis=1, keepdims=True), proportions,
                       rtol=1e-12, atol=0):
        _fail("Reconciliation changed member proportions", "prediction_invariant")
    return {"XGBDirect": direct, "TotalXGB": reconciled}


def predict_from_fitted(model, eval_x126, frozen_total, *, eval_ids):
    """Predict without retraining, receiving no evaluation labels."""
    _, mean, sd = _model_arrays(model)
    counts = _counts(eval_x126, 126, "eval_inputs")
    ids = _ids(eval_ids, len(counts), "eval_ids")
    if set(ids) & set(model["train_ids"]):
        _fail("Training and evaluation IDs overlap", "identity")
    raw, e = input_features(counts)
    x = np.column_stack((np.ones(len(raw)), (raw - mean) / sd))
    return predict_standardized(model, x, e, frozen_total)


def _fit(train_x126, train_y7, eval_x126, frozen_total, *,
         train_ids, eval_ids, input_ids, member_ids, rounds, mode):
    xgb = _xgb()
    train = _counts(train_x126, 126, "train_inputs")
    y = _counts(train_y7, 7, "train_targets")
    evaluation = _counts(eval_x126, 126, "eval_inputs")
    if len(train) != len(y):
        _fail("Training rows do not align", "train_alignment")
    train_keys = _ids(train_ids, len(train), "train_ids")
    eval_keys = _ids(eval_ids, len(evaluation), "eval_ids")
    if set(train_keys) & set(eval_keys):
        _fail("Training and evaluation IDs overlap", "identity")
    inputs, members = _validate_roles(input_ids, member_ids)
    _total(frozen_total, len(evaluation))
    zero = ~np.any(y > 0, axis=0)
    if np.any(zero):
        _fail("A training member is entirely zero; stop without substitution",
              "train_target_support", zero_member_indices=np.flatnonzero(zero).tolist())
    raw_train, e_train = input_features(train)
    raw_eval, e_eval = input_features(evaluation)
    scaler_weights = np.full(len(train), 1. / len(train))
    x_train, _, scaler = _standardize(raw_train, raw_eval, scaler_weights)
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        b = y.sum(axis=0) / e_train.sum()
        mean_y = scaler_weights @ y
        total_mean = float(scaler_weights @ y.sum(axis=1))
    _finite_positive(b, "training_rate_initialization")
    if not np.isfinite(mean_y).all() or not np.isfinite(total_mean):
        _fail("Nonfinite training-only scale", "training_scales")
    member_scales = np.maximum(mean_y, 1.)
    feature_names = [f"f{i:03d}" for i in range(129)]
    boosters = []
    ledger = []
    for j in range(7):
        margin = np.log(e_train) + np.log(b[j])
        if not np.isfinite(margin).all():
            _fail("Nonfinite training base margin", "training_offset", member_index=j)
        data = xgb.DMatrix(x_train, label=y[:, j], base_margin=margin,
                           weight=np.ones(len(train)), nthread=2, feature_names=feature_names)
        # No evals/watchlist, callbacks, early-stopping, or parameter search.
        booster = xgb.train(dict(FIXED_PARAMS), data, num_boost_round=rounds)
        booster.set_attr(member_id=members[j], member_index=str(j),
                         rate_init_b=repr(float(b[j])),
                         offset_contract="log_e_plus_log_training_rate_V2")
        boosters.append(booster)
        ledger.append({"member_id": members[j], "member_index": j,
                       "rounds": rounds, "training_rows": len(train),
                       "row_weight": 1., "watchlist_rows": 0, "early_stopping": False})
    model = {
        "kind": MODEL_KIND, "mode": mode, "xgboost_version": XGB_VERSION,
        "params": dict(FIXED_PARAMS), "num_boost_round": rounds,
        "rate_init_b": b, "standardizer": scaler, "member_scales": member_scales,
        "total_scale": max(total_mean, 1.), "input_ids": inputs, "member_ids": members,
        "train_ids": train_keys, "boosters": boosters,
        "feature_order": ["intercept"] + ["logcp1000:" + g for g in inputs] + ["log_exposure", "log_region_bins"],
        "booster_feature_names": feature_names,
        "scaler_weights": "uniform_1_over_n", "fit_row_weights": "uniform_ones",
    }
    predictions = predict_from_fitted(model, evaluation, frozen_total, eval_ids=eval_keys)
    return {
        "predictions": predictions, "models": model, "member_scales": member_scales,
        "total_scale": max(total_mean, 1.), "fit_ledger": ledger,
        "diagnostics": {"training_rows": len(train), "evaluation_rows": len(evaluation),
                        "input_columns": 126, "region_bins": 9, "scalar_heads": 7,
                        "new_total_fits": 0, "CPU_threads": 2, "GPU_used": False,
                        "prediction_repairs": 0, "common_total_conserved": True,
                        "predictions_are_count_means": True,
                        "eval_exposure_min": float(e_eval.min()),
                        "eval_exposure_max": float(e_eval.max())},
    }


def fit_predict(train_x126, train_y7, eval_x126, frozen_total, *,
                train_ids, eval_ids, input_ids, member_ids):
    """Fit exactly seven 200-round fixed heads; no evaluation-label argument."""
    return _fit(train_x126, train_y7, eval_x126, frozen_total,
                train_ids=train_ids, eval_ids=eval_ids, input_ids=input_ids,
                member_ids=member_ids, rounds=NUM_BOOST_ROUND, mode="fixed_candidate_V2")


def synthetic_zero_tree_probe(train_x126, train_y7, eval_x126, frozen_total, *,
                              train_ids, eval_ids, input_ids, member_ids, mode):
    """Synthetic-only zero-tree initialization control, not a real candidate."""
    if mode != "synthetic" or not all(str(k).startswith("SYN_") for k in list(train_ids) + list(eval_ids)):
        _fail("Zero-tree probe requires explicit synthetic mode and IDs", "probe_permission")
    return _fit(train_x126, train_y7, eval_x126, frozen_total,
                train_ids=train_ids, eval_ids=eval_ids, input_ids=input_ids,
                member_ids=member_ids, rounds=0, mode="synthetic_zero_tree_probe")


def serialize_model(model):
    """Return a JSON-ready model capsule including seven hashed UBJ models."""
    _model_arrays(model)
    result = {k: v for k, v in model.items() if k not in ("boosters", "standardizer", "rate_init_b", "member_scales")}
    result["serialization_schema"] = "XGB_OFFSET_CAPSULE_V2"
    result["rate_init_b"] = np.asarray(model["rate_init_b"]).tolist()
    result["member_scales"] = np.asarray(model["member_scales"]).tolist()
    result["standardizer"] = {k: np.asarray(v).tolist() for k, v in model["standardizer"].items()}
    result["booster_ubj"] = []
    for booster in model["boosters"]:
        raw = bytes(booster.save_raw(raw_format="ubj"))
        result["booster_ubj"].append({"sha256": hashlib.sha256(raw).hexdigest(),
                                      "base64": base64.b64encode(raw).decode("ascii")})
    return result


def deserialize_model(capsule):
    """Reload a numerical capsule without any data-file path or fit."""
    xgb = _xgb()
    if capsule.get("serialization_schema") != "XGB_OFFSET_CAPSULE_V2":
        _fail("Unknown model serialization", "stored_model")
    model = {k: v for k, v in capsule.items() if k not in ("serialization_schema", "booster_ubj")}
    model["rate_init_b"] = np.asarray(model["rate_init_b"], dtype=float)
    model["member_scales"] = np.asarray(model["member_scales"], dtype=float)
    model["standardizer"] = {k: np.asarray(v, dtype=float) for k, v in model["standardizer"].items()}
    model["boosters"] = []
    for item in capsule["booster_ubj"]:
        try:
            raw = base64.b64decode(item["base64"], validate=True)
        except (TypeError, ValueError) as exc:
            _fail("Invalid model bytes", "stored_model", cause=str(exc))
        if hashlib.sha256(raw).hexdigest() != item["sha256"]:
            _fail("Stored booster hash changed", "stored_model")
        booster = xgb.Booster(params=dict(FIXED_PARAMS))
        booster.load_model(bytearray(raw))
        booster.set_param({"nthread": 2, "device": "cpu"})
        model["boosters"].append(booster)
    _model_arrays(model)
    return model

